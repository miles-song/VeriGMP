	.att_syntax
	.file	"fast_codegen.c423d76b1fceb8a4-cgu.0"
	.section	.text._RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECsgQ310fOaFLI_12fast_codegen,"ax",@progbits
	.hidden	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECsgQ310fOaFLI_12fast_codegen
	.globl	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECsgQ310fOaFLI_12fast_codegen
	.prefalign	4, .Lfunc_end0, nop
	.type	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECsgQ310fOaFLI_12fast_codegen,@function
_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECsgQ310fOaFLI_12fast_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%ecx, %r8d
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%rdi, (%rsp)
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.0(%rip), %rsi
	movq	%rsp, %rdi
	callq	*_RNvNtCs8ZKwes1zzDd_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECsgQ310fOaFLI_12fast_codegen, .Lfunc_end0-_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECsgQ310fOaFLI_12fast_codegen
	.cfi_endproc

	.section	.text._RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgQ310fOaFLI_12fast_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end1, nop
	.type	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgQ310fOaFLI_12fast_codegen,@function
_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgQ310fOaFLI_12fast_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	*%rdi
	#APP
	#NO_APP
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgQ310fOaFLI_12fast_codegen, .Lfunc_end1-_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgQ310fOaFLI_12fast_codegen
	.cfi_endproc

	.section	.text._RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0CsgQ310fOaFLI_12fast_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end2, nop
	.type	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0CsgQ310fOaFLI_12fast_codegen,@function
_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0CsgQ310fOaFLI_12fast_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgQ310fOaFLI_12fast_codegen
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0CsgQ310fOaFLI_12fast_codegen, .Lfunc_end2-_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0CsgQ310fOaFLI_12fast_codegen
	.cfi_endproc

	.section	.text._RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCsgQ310fOaFLI_12fast_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end3, nop
	.type	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCsgQ310fOaFLI_12fast_codegen,@function
_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCsgQ310fOaFLI_12fast_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsgQ310fOaFLI_12fast_codegen
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCsgQ310fOaFLI_12fast_codegen, .Lfunc_end3-_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCsgQ310fOaFLI_12fast_codegen
	.cfi_endproc

	.section	.text._RNvCsgQ310fOaFLI_12fast_codegen4main,"ax",@progbits
	.hidden	_RNvCsgQ310fOaFLI_12fast_codegen4main
	.globl	_RNvCsgQ310fOaFLI_12fast_codegen4main
	.prefalign	4, .Lfunc_end4, nop
	.type	_RNvCsgQ310fOaFLI_12fast_codegen4main,@function
_RNvCsgQ310fOaFLI_12fast_codegen4main:
	.cfi_startproc
	retq
.Lfunc_end4:
	.size	_RNvCsgQ310fOaFLI_12fast_codegen4main, .Lfunc_end4-_RNvCsgQ310fOaFLI_12fast_codegen4main
	.cfi_endproc

	.section	.text._RNvNtCsgQ310fOaFLI_12fast_codegen10fast_words14abs_difference,"ax",@progbits
	.prefalign	4, .Lfunc_end5, nop
	.type	_RNvNtCsgQ310fOaFLI_12fast_codegen10fast_words14abs_difference,@function
_RNvNtCsgQ310fOaFLI_12fast_codegen10fast_words14abs_difference:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	cmpq	%rcx, %rsi
	jne	.LBB5_39
	cmpq	%r9, %rsi
	jb	.LBB5_40
	testq	%rsi, %rsi
	je	.LBB5_9
	leaq	-1(%rsi), %rax
	.p2align	4
.LBB5_5:
	cmpq	%r9, %rax
	jae	.LBB5_6
	movq	(%r8,%rax,8), %rcx
	cmpq	%rcx, (%rdx,%rax,8)
	je	.LBB5_4
	jmp	.LBB5_8
	.p2align	4
.LBB5_6:
	xorl	%ecx, %ecx
	cmpq	%rcx, (%rdx,%rax,8)
	jne	.LBB5_8
.LBB5_4:
	addq	$-1, %rax
	jb	.LBB5_5
	jmp	.LBB5_9
.LBB5_8:
	jae	.LBB5_9
	testq	%r9, %r9
	je	.LBB5_26
	cmpq	$1, %r9
	jne	.LBB5_37
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	jmp	.LBB5_30
.LBB5_9:
	testq	%r9, %r9
	je	.LBB5_10
	cmpq	$1, %r9
	jne	.LBB5_18
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	jmp	.LBB5_14
.LBB5_10:
	xorl	%eax, %eax
	jmp	.LBB5_15
.LBB5_18:
	movabsq	$1152921504606846974, %r10
	andq	%r9, %r10
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB5_19:
	movq	(%rdx,%rcx,8), %r11
	subq	(%r8,%rcx,8), %r11
	setb	%bl
	subq	%rax, %r11
	setb	%al
	orb	%bl, %al
	movzbl	%al, %eax
	movq	%r11, (%rdi,%rcx,8)
	movq	8(%rdx,%rcx,8), %r11
	subq	8(%r8,%rcx,8), %r11
	setb	%bl
	subq	%rax, %r11
	setb	%al
	orb	%bl, %al
	movzbl	%al, %eax
	movq	%r11, 8(%rdi,%rcx,8)
	addq	$2, %rcx
	cmpq	%rcx, %r10
	jne	.LBB5_19
	testb	$1, %r9b
	je	.LBB5_15
.LBB5_14:
	movq	(%rdx,%rcx,8), %r10
	subq	(%r8,%rcx,8), %r10
	setb	%r11b
	subq	%rax, %r10
	setb	%al
	orb	%r11b, %al
	movzbl	%al, %eax
	movq	%r10, (%rdi,%rcx,8)
.LBB5_15:
	cmpq	%rsi, %r9
	jae	.LBB5_16
	movq	%r9, %rcx
	jmp	.LBB5_21
	.p2align	4
.LBB5_23:
	movq	(%r8,%rcx,8), %r10
.LBB5_24:
	movq	(%rdx,%rcx,8), %r11
	subq	%r10, %r11
	setb	%r10b
	subq	%rax, %r11
	setb	%al
	orb	%r10b, %al
	movzbl	%al, %eax
	movq	%r11, (%rdi,%rcx,8)
	incq	%rcx
	cmpq	%rcx, %rsi
	je	.LBB5_16
.LBB5_21:
	cmpq	%r9, %rcx
	jb	.LBB5_23
	xorl	%r10d, %r10d
	jmp	.LBB5_24
.LBB5_16:
	xorl	%eax, %eax
.LBB5_17:
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB5_26:
	.cfi_def_cfa_offset 16
	xorl	%ecx, %ecx
	jmp	.LBB5_31
.LBB5_37:
	movabsq	$1152921504606846974, %r10
	andq	%r9, %r10
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB5_38:
	movq	(%r8,%rax,8), %r11
	subq	(%rdx,%rax,8), %r11
	setb	%bl
	subq	%rcx, %r11
	setb	%cl
	orb	%bl, %cl
	movzbl	%cl, %ecx
	movq	%r11, (%rdi,%rax,8)
	movq	8(%r8,%rax,8), %r11
	subq	8(%rdx,%rax,8), %r11
	setb	%bl
	subq	%rcx, %r11
	setb	%cl
	orb	%bl, %cl
	movzbl	%cl, %ecx
	movq	%r11, 8(%rdi,%rax,8)
	addq	$2, %rax
	cmpq	%rax, %r10
	jne	.LBB5_38
	testb	$1, %r9b
	je	.LBB5_31
.LBB5_30:
	movq	(%r8,%rax,8), %r10
	subq	(%rdx,%rax,8), %r10
	setb	%r11b
	subq	%rcx, %r10
	setb	%cl
	orb	%r11b, %cl
	movzbl	%cl, %ecx
	movq	%r10, (%rdi,%rax,8)
.LBB5_31:
	movb	$1, %al
	cmpq	%rsi, %r9
	jae	.LBB5_17
	movq	%r9, %r10
	jmp	.LBB5_33
	.p2align	4
.LBB5_34:
	xorl	%r11d, %r11d
.LBB5_35:
	subq	(%rdx,%r10,8), %r11
	setb	%bl
	subq	%rcx, %r11
	setb	%cl
	orb	%bl, %cl
	movzbl	%cl, %ecx
	movq	%r11, (%rdi,%r10,8)
	incq	%r10
	cmpq	%r10, %rsi
	je	.LBB5_17
.LBB5_33:
	cmpq	%r9, %r10
	jae	.LBB5_34
	movq	(%r8,%r10,8), %r11
	jmp	.LBB5_35
.LBB5_39:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.5(%rip), %rdi
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.6(%rip), %rdx
	movl	$38, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB5_40:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.7(%rip), %rdi
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.8(%rip), %rdx
	movl	$36, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end5:
	.size	_RNvNtCsgQ310fOaFLI_12fast_codegen10fast_words14abs_difference, .Lfunc_end5-_RNvNtCsgQ310fOaFLI_12fast_codegen10fast_words14abs_difference
	.cfi_endproc

	.section	.text._RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply3low,"ax",@progbits
	.prefalign	4, .Lfunc_end6, nop
	.type	_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply3low,@function
_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply3low:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	testq	%rcx, %rcx
	je	.LBB6_37
	movq	%rcx, %rbp
	cmpq	%r9, %rcx
	jne	.LBB6_37
	cmpq	%rbp, %rsi
	jne	.LBB6_38
	movq	120(%rsp), %rsi
	leaq	(,%rbp,4), %rax
	cmpq	%rax, %rsi
	jb	.LBB6_38
	movq	%r8, %r15
	movq	%rdx, %r11
	movq	%rdi, %rbx
	cmpq	$64, %rbp
	movq	%rdx, 8(%rsp)
	ja	.LBB6_20
	movq	(%r11), %rcx
	movq	%rbp, %rax
	decq	%rax
	movq	%rax, 16(%rsp)
	je	.LBB6_6
	movl	%ebp, %r10d
	andl	$126, %r10d
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	.p2align	4
.LBB6_8:
	movq	%rcx, %rax
	mulq	(%r15,%r9,8)
	movq	%rdx, %rsi
	movq	%rax, %rdi
	leaq	(%rax,%r8), %r11
	movq	%rcx, %rax
	mulq	8(%r15,%r9,8)
	addq	%r8, %rdi
	adcq	%rsi, %rax
	movq	%rdx, %r8
	adcq	$0, %r8
	movq	%r11, (%rbx,%r9,8)
	movq	%rax, 8(%rbx,%r9,8)
	addq	$2, %r9
	cmpq	%r9, %r10
	jne	.LBB6_8
	testb	$1, %bpl
	movq	8(%rsp), %r11
	jne	.LBB6_10
	cmpq	$2, %rbp
	jae	.LBB6_12
	jmp	.LBB6_36
.LBB6_20:
	movabsq	$-2049638230412172401, %rcx
	movq	%rbp, %rax
	mulq	%rcx
	shrq	$5, %rdx
	leaq	(%rdx,%rdx,4), %rax
	leaq	(%rdx,%rax,2), %rax
	shll	$2, %edx
	leal	(%rdx,%rdx,8), %ecx
	movl	%ebp, %edx
	subl	%ecx, %edx
	leal	(%rdx,%rdx,4), %ecx
	leal	(%rdx,%rcx,2), %ecx
	movzwl	%cx, %ecx
	imull	$1821, %ecx, %r13d
	shrl	$16, %r13d
	addq	%rax, %r13
	movq	%rbp, %r9
	subq	%r13, %r9
	leaq	(%r9,%r9), %r14
	movq	%rsi, %rax
	subq	%r14, %rax
	jb	.LBB6_39
	cmpq	%r13, %rbp
	jb	.LBB6_40
	movq	%rbp, %r12
	movq	112(%rsp), %rbp
	leaq	(,%r14,8), %r10
	addq	%rbp, %r10
	movq	%rbp, %rdi
	movq	%r14, %rsi
	movq	%r11, %rdx
	movq	%r9, %rcx
	movq	%r15, %r8
	movq	%r9, 16(%rsp)
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	callq	_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply4full
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	cmpq	%r14, %r12
	ja	.LBB6_25
	movabsq	$1152921504606846974, %r14
	shlq	$3, %r12
	movq	%rbx, %rdi
	movq	%rbp, %rsi
	movq	%r12, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	leaq	(,%r13,8), %r10
	addq	%rbp, %r10
	movq	120(%rsp), %rax
	subq	%r13, %rax
	movq	16(%rsp), %r12
	movq	8(%rsp), %rcx
	leaq	(%rcx,%r12,8), %rdx
	movq	%rbp, %rdi
	movq	%r13, %rsi
	movq	%r13, %rcx
	movq	%r15, %r8
	movq	%r13, %r9
	movq	%rax, 40(%rsp)
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	callq	_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply3low
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	leaq	(%rbx,%r12,8), %r8
	movq	%r13, %rax
	decq	%rax
	movq	%rax, 32(%rsp)
	je	.LBB6_24
	movq	%r13, %rdx
	andq	%r14, %rdx
	leaq	(%rbx,%r12,8), %rsi
	addq	$8, %rsi
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB6_27:
	xorl	%edi, %edi
	addq	-8(%rsi,%rcx,8), %rax
	setb	%dil
	addq	(%rbp,%rcx,8), %rax
	movq	%rax, -8(%rsi,%rcx,8)
	adcq	(%rsi,%rcx,8), %rdi
	setb	%al
	movzbl	%al, %eax
	addq	8(%rbp,%rcx,8), %rdi
	adcq	$0, %rax
	movq	%rdi, (%rsi,%rcx,8)
	addq	$2, %rcx
	cmpq	%rcx, %rdx
	jne	.LBB6_27
	testb	$1, %r13b
	movq	8(%rsp), %rdx
	jne	.LBB6_29
	jmp	.LBB6_30
.LBB6_6:
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
.LBB6_10:
	imulq	(%r15,%r9,8), %rcx
	addq	%r8, %rcx
	movq	%rcx, (%rbx,%r9,8)
	cmpq	$2, %rbp
	jb	.LBB6_36
.LBB6_12:
	leaq	-2(%rbp), %r12
	leaq	16(%rbx), %rdi
	movl	$1, %r9d
	xorl	%r10d, %r10d
	movq	16(%rsp), %r8
	movq	%rbx, 48(%rsp)
	jmp	.LBB6_13
	.p2align	4
.LBB6_14:
	xorl	%r13d, %r13d
	xorl	%r14d, %r14d
.LBB6_18:
	leaq	(%rbx,%r9,8), %rax
	imulq	(%r15,%r14,8), %rcx
	addq	(%rax,%r14,8), %r13
	addq	%rcx, %r13
	movq	%r13, (%rax,%r14,8)
.LBB6_19:
	incq	%r9
	incq	%r10
	addq	$8, %rdi
	decq	%r8
	cmpq	%rbp, %r9
	je	.LBB6_36
.LBB6_13:
	movq	(%r11,%r9,8), %rcx
	cmpq	%r10, %r12
	je	.LBB6_14
	movq	%rbp, %rbx
	movq	%r8, %r11
	andq	$-2, %r11
	movq	16(%rsp), %rbp
	subq	%r10, %rbp
	xorl	%r13d, %r13d
	xorl	%r14d, %r14d
	.p2align	4
.LBB6_16:
	movq	%rcx, %rax
	mulq	(%r15,%r14,8)
	xorl	%esi, %esi
	addq	-8(%rdi,%r14,8), %r13
	setb	%sil
	addq	%rax, %r13
	adcq	%rdx, %rsi
	movq	%r13, -8(%rdi,%r14,8)
	movq	%rcx, %rax
	mulq	8(%r15,%r14,8)
	xorl	%r13d, %r13d
	addq	(%rdi,%r14,8), %rsi
	setb	%r13b
	addq	%rax, %rsi
	adcq	%rdx, %r13
	movq	%rsi, (%rdi,%r14,8)
	addq	$2, %r14
	cmpq	%r14, %r11
	jne	.LBB6_16
	testb	$1, %bpl
	movq	8(%rsp), %r11
	movq	%rbx, %rbp
	movq	48(%rsp), %rbx
	jne	.LBB6_18
	jmp	.LBB6_19
.LBB6_24:
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	movq	8(%rsp), %rdx
.LBB6_29:
	addq	(%r8,%rcx,8), %rax
	addq	(%rbp,%rcx,8), %rax
	movq	%rax, (%r8,%rcx,8)
.LBB6_30:
	movq	%r8, 24(%rsp)
	leaq	(%r15,%r12,8), %r8
	movq	%rbp, %rdi
	movq	%r13, %rsi
	movq	%r13, %rcx
	movq	%r13, %r9
	pushq	40(%rsp)
	.cfi_adjust_cfa_offset 8
	leaq	(,%r13,8), %rax
	addq	%rbp, %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	callq	_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply3low
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	cmpq	$0, 32(%rsp)
	je	.LBB6_31
	andq	%r13, %r14
	leaq	(%rbx,%r12,8), %rdx
	addq	$8, %rdx
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB6_33:
	xorl	%esi, %esi
	addq	-8(%rdx,%rcx,8), %rax
	setb	%sil
	addq	(%rbp,%rcx,8), %rax
	movq	%rax, -8(%rdx,%rcx,8)
	adcq	(%rdx,%rcx,8), %rsi
	setb	%al
	movzbl	%al, %eax
	addq	8(%rbp,%rcx,8), %rsi
	adcq	$0, %rax
	movq	%rsi, (%rdx,%rcx,8)
	addq	$2, %rcx
	cmpq	%rcx, %r14
	jne	.LBB6_33
	testb	$1, %r13b
	movq	24(%rsp), %rdx
	jne	.LBB6_35
	jmp	.LBB6_36
.LBB6_31:
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	movq	24(%rsp), %rdx
.LBB6_35:
	addq	(%rdx,%rcx,8), %rax
	addq	(%rbp,%rcx,8), %rax
	movq	%rax, (%rdx,%rcx,8)
.LBB6_36:
	addq	$56, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB6_37:
	.cfi_def_cfa_offset 112
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.10(%rip), %rdi
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.12(%rip), %rdx
	movl	$51, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB6_38:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.13(%rip), %rdi
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.14(%rip), %rdx
	movl	$70, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB6_25:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.17(%rip), %rcx
	xorl	%edi, %edi
	movq	%r12, %rsi
	movq	%r14, %rdx
	callq	*_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB6_39:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.1(%rip), %rdi
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.15(%rip), %rdx
	movl	$19, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking9panic_fmt@GOTPCREL(%rip)
.LBB6_40:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.16(%rip), %rcx
	xorl	%edi, %edi
	movq	%r9, %rsi
	movq	%rbp, %rdx
	callq	*_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Lfunc_end6:
	.size	_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply3low, .Lfunc_end6-_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply3low
	.cfi_endproc

	.section	.text._RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply4full,"ax",@progbits
	.prefalign	4, .Lfunc_end7, nop
	.type	_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply4full,@function
_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply4full:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	testq	%rcx, %rcx
	je	.LBB7_55
	movq	%rcx, %rbp
	cmpq	%r9, %rcx
	jne	.LBB7_55
	movq	%rsi, %r10
	leaq	(,%rbp,2), %rax
	cmpq	%rax, %rsi
	jne	.LBB7_56
	leaq	(,%rbp,2), %rax
	addq	%rbp, %rax
	cmpq	%rax, 136(%rsp)
	jb	.LBB7_56
	movq	%r8, %r12
	movq	%rdx, %r13
	movq	%rdi, %r14
	cmpq	$25, %rbp
	jae	.LBB7_5
	movq	(%r13), %rcx
	movq	%rbp, %r8
	decq	%r8
	je	.LBB7_8
	movl	%ebp, %r11d
	andl	$30, %r11d
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	.p2align	4
.LBB7_10:
	movq	%rcx, %rax
	mulq	(%r12,%r10,8)
	movq	%rdx, %rsi
	movq	%rax, %rdi
	leaq	(%rax,%r9), %rbx
	movq	%rcx, %rax
	mulq	8(%r12,%r10,8)
	addq	%r9, %rdi
	adcq	%rsi, %rax
	movq	%rdx, %r9
	adcq	$0, %r9
	movq	%rbx, (%r14,%r10,8)
	movq	%rax, 8(%r14,%r10,8)
	addq	$2, %r10
	cmpq	%r10, %r11
	jne	.LBB7_10
	testb	$1, %bpl
	jne	.LBB7_12
	movq	%r9, (%r14,%rbp,8)
	cmpq	$2, %rbp
	jae	.LBB7_14
	jmp	.LBB7_54
.LBB7_5:
	movq	%r13, %rcx
	movq	%rbp, %r13
	shrq	%r13
	movq	%rbp, %rbx
	subq	%r13, %rbx
	movq	%r10, %rax
	subq	%rbx, %rax
	jb	.LBB7_6
	movq	%rax, 32(%rsp)
	movq	%rcx, %rdx
	leaq	(%rcx,%rbx,8), %r8
	movq	%r14, %rdi
	movq	%rbx, %rsi
	movq	%rcx, 64(%rsp)
	movq	%rbx, %rcx
	movq	%r8, 56(%rsp)
	movq	%r13, %r9
	movq	%r10, 24(%rsp)
	callq	_RNvNtCsgQ310fOaFLI_12fast_codegen10fast_words14abs_difference
	movq	24(%rsp), %rdx
	leaq	(%rbx,%rbx), %r15
	movq	%rdx, %r10
	subq	%r15, %r10
	jb	.LBB7_57
	movq	%r13, %r9
	movq	%r13, 8(%rsp)
	movq	128(%rsp), %r13
	leaq	(%r14,%rbx,8), %rdi
	leaq	(%r12,%rbx,8), %r8
	movq	%rbx, %rsi
	movq	%r12, %rdx
	movb	%al, 7(%rsp)
	movq	%rbx, %rcx
	movq	%r10, 16(%rsp)
	callq	_RNvNtCsgQ310fOaFLI_12fast_codegen10fast_words14abs_difference
	movb	%al, 6(%rsp)
	leaq	(,%r15,8), %r10
	addq	%r13, %r10
	movq	136(%rsp), %rax
	subq	%r15, %rax
	movq	%rax, 40(%rsp)
	movq	%r13, %rdi
	movq	%r15, %rsi
	movq	%r14, %rdx
	movq	%rbx, %rcx
	leaq	(%r14,%rbx,8), %r8
	movq	%r8, 48(%rsp)
	leaq	(%r14,%rbx,8), %r8
	movq	%rbx, %r9
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	callq	_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply4full
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	leaq	(%r14,%r15,8), %rdi
	movq	16(%rsp), %rsi
	movq	56(%rsp), %rdx
	movq	8(%rsp), %rcx
	leaq	(%r12,%rbx,8), %r8
	movq	%rcx, %r9
	pushq	40(%rsp)
	.cfi_adjust_cfa_offset 8
	leaq	(,%r15,8), %rax
	addq	%r13, %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	callq	_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply4full
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movq	%r14, %rdi
	movq	%r15, %rsi
	movq	64(%rsp), %rdx
	movq	%rbx, %rcx
	movq	%r12, %r8
	movq	%rbx, %r9
	pushq	40(%rsp)
	.cfi_adjust_cfa_offset 8
	leaq	(,%r15,8), %rax
	addq	%r13, %rax
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	callq	_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply4full
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	movzbl	6(%rsp), %eax
	cmpb	%al, 7(%rsp)
	je	.LBB7_22
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	movq	32(%rsp), %r9
	movq	24(%rsp), %r10
	movq	16(%rsp), %r11
	leaq	(,%rbp,2), %r8
	.p2align	4
.LBB7_26:
	xorl	%edx, %edx
	addq	(%r13,%rax,8), %rcx
	setb	%dl
	addq	(%r14,%rax,8), %rcx
	movq	%rcx, (%r13,%rax,8)
	adcq	8(%r13,%rax,8), %rdx
	setb	%cl
	movzbl	%cl, %ecx
	addq	8(%r14,%rax,8), %rdx
	adcq	$0, %rcx
	movq	%rdx, 8(%r13,%rax,8)
	addq	$2, %rax
	cmpq	%rax, %r15
	jne	.LBB7_26
	jmp	.LBB7_27
.LBB7_22:
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	movq	32(%rsp), %r9
	leaq	(,%rbp,2), %r8
	.p2align	4
.LBB7_23:
	movq	(%r14,%rax,8), %rdx
	subq	(%r13,%rax,8), %rdx
	setb	%sil
	subq	%rcx, %rdx
	setb	%cl
	orb	%sil, %cl
	movzbl	%cl, %ecx
	movq	%rdx, (%r13,%rax,8)
	movq	8(%r14,%rax,8), %rdx
	subq	8(%r13,%rax,8), %rdx
	setb	%sil
	subq	%rcx, %rdx
	setb	%cl
	orb	%sil, %cl
	movzbl	%cl, %ecx
	movq	%rdx, 8(%r13,%rax,8)
	addq	$2, %rax
	cmpq	%rax, %r15
	jne	.LBB7_23
	negq	%rcx
	movq	24(%rsp), %r10
	movq	16(%rsp), %r11
.LBB7_27:
	cmpq	%r11, %r15
	jb	.LBB7_58
	cmpq	%r15, %r10
	jne	.LBB7_30
	xorl	%eax, %eax
.LBB7_41:
	cmpq	%r15, %r9
	jb	.LBB7_59
	addq	%rcx, %rax
	movq	8(%rsp), %rdx
	shlq	$3, %rdx
	leaq	(%r14,%rbp,8), %rcx
	subq	%rdx, %rcx
	addq	$8, %rcx
	xorl	%esi, %esi
	xorl	%edx, %edx
	.p2align	4
.LBB7_43:
	xorl	%edi, %edi
	addq	-8(%rcx,%rdx,8), %rsi
	setb	%dil
	addq	(%r13,%rdx,8), %rsi
	movq	%rsi, -8(%rcx,%rdx,8)
	adcq	(%rcx,%rdx,8), %rdi
	setb	%sil
	movzbl	%sil, %esi
	addq	8(%r13,%rdx,8), %rdi
	adcq	$0, %rsi
	movq	%rdi, (%rcx,%rdx,8)
	addq	$2, %rdx
	cmpq	%rdx, %r15
	jne	.LBB7_43
	movq	%r9, %rcx
	movq	48(%rsp), %rdx
	leaq	(%rdx,%r15,8), %rdx
	subq	%r15, %rcx
	je	.LBB7_49
	testq	%rsi, %rsi
	je	.LBB7_49
	movl	$1, %edi
	.p2align	4
.LBB7_47:
	xorl	%r8d, %r8d
	addq	%rsi, -8(%rdx,%rdi,8)
	setb	%sil
	cmpq	%rcx, %rdi
	jae	.LBB7_49
	movb	%sil, %r8b
	incq	%rdi
	movq	%r8, %rsi
	testb	%r8b, %r8b
	jne	.LBB7_47
.LBB7_49:
	cmpq	%r15, %r9
	je	.LBB7_54
	testq	%rax, %rax
	je	.LBB7_54
	movl	$1, %esi
	.p2align	4
.LBB7_52:
	xorl	%edi, %edi
	addq	%rax, -8(%rdx,%rsi,8)
	setb	%al
	cmpq	%rcx, %rsi
	jae	.LBB7_54
	movb	%al, %dil
	incq	%rsi
	movq	%rdi, %rax
	testb	%dil, %dil
	jne	.LBB7_52
	jmp	.LBB7_54
.LBB7_30:
	movabsq	$1152921504606846974, %rax
	andq	%rbp, %rax
	leaq	(%r10,%rax), %rdx
	leaq	1(%r8), %rsi
	cmpq	%rsi, %rdx
	jne	.LBB7_32
	xorl	%eax, %eax
	xorl	%edx, %edx
	jmp	.LBB7_35
.LBB7_8:
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
.LBB7_12:
	movq	%rcx, %rax
	mulq	(%r12,%r10,8)
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, (%r14,%r10,8)
	movq	%rdx, %r9
	movq	%r9, (%r14,%rbp,8)
	cmpq	$2, %rbp
	jb	.LBB7_54
.LBB7_14:
	movl	%ebp, %esi
	andl	$30, %esi
	leaq	16(%r14), %rdi
	movl	$1, %r9d
	jmp	.LBB7_15
	.p2align	4
.LBB7_18:
	movq	%rcx, %rax
	mulq	(%r12,%r11,8)
	xorl	%ecx, %ecx
	addq	(%r10,%r11,8), %rbx
	setb	%cl
	addq	%rax, %rbx
	adcq	%rdx, %rcx
	movq	%rbx, (%r10,%r11,8)
	movq	%rcx, %rbx
.LBB7_19:
	movq	%rbx, (%r10,%rbp,8)
	incq	%r9
	addq	$8, %rdi
	cmpq	%rbp, %r9
	je	.LBB7_54
.LBB7_15:
	leaq	(%r14,%r9,8), %r10
	movq	(%r13,%r9,8), %rcx
	xorl	%ebx, %ebx
	xorl	%r11d, %r11d
	testq	%r8, %r8
	je	.LBB7_18
	.p2align	4
.LBB7_16:
	movq	%rcx, %rax
	mulq	(%r12,%r11,8)
	xorl	%r15d, %r15d
	addq	-8(%rdi,%r11,8), %rbx
	setb	%r15b
	addq	%rax, %rbx
	adcq	%rdx, %r15
	movq	%rbx, -8(%rdi,%r11,8)
	movq	%rcx, %rax
	mulq	8(%r12,%r11,8)
	xorl	%ebx, %ebx
	addq	(%rdi,%r11,8), %r15
	setb	%bl
	addq	%rax, %r15
	adcq	%rdx, %rbx
	movq	%r15, (%rdi,%r11,8)
	addq	$2, %r11
	cmpq	%r11, %rsi
	jne	.LBB7_16
	testb	$1, %bpl
	jne	.LBB7_18
	jmp	.LBB7_19
.LBB7_54:
	addq	$72, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB7_32:
	.cfi_def_cfa_offset 128
	movq	%rbp, %rdx
	shlq	$4, %rdx
	movq	8(%rsp), %rsi
	shlq	$4, %rsi
	subq	%rsi, %rdx
	leaq	(%r14,%rdx), %rsi
	addq	$8, %rsi
	movq	%r10, %rdi
	andq	$-2, %rdi
	addq	%rax, %rdi
	subq	%r8, %rdi
	xorl	%eax, %eax
	xorl	%edx, %edx
	.p2align	4
.LBB7_33:
	xorl	%r8d, %r8d
	addq	(%r13,%rdx,8), %rax
	setb	%r8b
	addq	-8(%rsi,%rdx,8), %rax
	movq	%rax, (%r13,%rdx,8)
	adcq	8(%r13,%rdx,8), %r8
	setb	%al
	movzbl	%al, %eax
	addq	(%rsi,%rdx,8), %r8
	adcq	$0, %rax
	movq	%r8, 8(%r13,%rdx,8)
	addq	$2, %rdx
	cmpq	%rdx, %rdi
	jne	.LBB7_33
	testb	$1, %r10b
	je	.LBB7_36
.LBB7_35:
	xorl	%esi, %esi
	addq	(%r13,%rdx,8), %rax
	setb	%sil
	leaq	(%r14,%r15,8), %rdi
	addq	(%rdi,%rdx,8), %rax
	adcq	$0, %rsi
	movq	%rax, (%r13,%rdx,8)
	movq	%rsi, %rax
.LBB7_36:
	movq	%r15, %rdx
	subq	%r11, %rdx
	je	.LBB7_41
	testq	%rax, %rax
	je	.LBB7_41
	movq	8(%rsp), %rsi
	shlq	$4, %rsi
	leaq	(%rsi,%r10,8), %rsi
	movq	%rbp, %rdi
	shlq	$4, %rdi
	subq	%rdi, %rsi
	addq	%r13, %rsi
	movl	$1, %edi
	.p2align	4
.LBB7_39:
	addq	%rax, -8(%rsi,%rdi,8)
	setb	%r8b
	xorl	%eax, %eax
	movb	%r8b, %al
	cmpq	%rdx, %rdi
	jae	.LBB7_41
	incq	%rdi
	testb	%r8b, %r8b
	jne	.LBB7_39
	jmp	.LBB7_41
.LBB7_55:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.10(%rip), %rdi
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.18(%rip), %rdx
	movl	$51, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB7_56:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.19(%rip), %rdi
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.20(%rip), %rdx
	movl	$74, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB7_6:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.22(%rip), %rcx
	xorl	%edi, %edi
	movq	%rbx, %rsi
	movq	%r10, %rdx
	callq	*_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB7_57:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.21(%rip), %rcx
	movq	%rbx, %rdi
	movq	%r15, %rsi
	callq	*_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB7_58:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.3(%rip), %rdi
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.4(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB7_59:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.3(%rip), %rdi
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.9(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end7:
	.size	_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply4full, .Lfunc_end7-_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply4full
	.cfi_endproc

	.section	.text.ordinary_sub,"ax",@progbits
	.globl	ordinary_sub
	.prefalign	4, .Lfunc_end8, nop
	.type	ordinary_sub,@function
ordinary_sub:
	.cfi_startproc
	movq	%rdi, %rax
	subq	%rsi, %rax
	setb	%cl
	subq	%rdx, %rax
	setb	%dl
	orb	%cl, %dl
	movzbl	%dl, %edx
	retq
.Lfunc_end8:
	.size	ordinary_sub, .Lfunc_end8-ordinary_sub
	.cfi_endproc

	.section	.text.verified_fast,"ax",@progbits
	.globl	verified_fast
	.prefalign	4, .Lfunc_end9, nop
	.type	verified_fast,@function
verified_fast:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movl	48(%rsp), %r15d
	leal	-1(%r15), %eax
	cmpl	$64, %eax
	jae	.LBB9_3
	movq	%rsi, %rbx
	movq	%rdi, %r14
	pushq	40(%rsp)
	.cfi_adjust_cfa_offset 8
	pushq	40(%rsp)
	.cfi_adjust_cfa_offset 8
	callq	_RNvNtCsgQ310fOaFLI_12fast_codegen13fast_multiply3low
	addq	$16, %rsp
	.cfi_adjust_cfa_offset -16
	testq	%rbx, %rbx
	je	.LBB9_4
	movq	$-1, %rax
	movq	$-1, %rdx
	movl	%r15d, %ecx
	shlq	%cl, %rdx
	cmpl	$64, %r15d
	notq	%rdx
	cmoveq	%rax, %rdx
	andq	%rdx, -8(%r14,%rbx,8)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB9_3:
	.cfi_def_cfa_offset 32
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.23(%rip), %rdi
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.24(%rip), %rdx
	movl	$39, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB9_4:
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.25(%rip), %rdi
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.27(%rip), %rdx
	movl	$31, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end9:
	.size	verified_fast, .Lfunc_end9-verified_fast
	.cfi_endproc

	.section	.text.main,"ax",@progbits
	.globl	main
	.prefalign	4, .Lfunc_end10, nop
	.type	main,@function
main:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, %rcx
	movslq	%edi, %rdx
	leaq	_RNvCsgQ310fOaFLI_12fast_codegen4main(%rip), %rax
	movq	%rax, (%rsp)
	leaq	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.0(%rip), %rsi
	movq	%rsp, %rdi
	xorl	%r8d, %r8d
	callq	*_RNvNtCs8ZKwes1zzDd_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end10:
	.size	main, .Lfunc_end10-main
	.cfi_endproc

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.0,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.0,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCsgQ310fOaFLI_12fast_codegen
	.quad	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0CsgQ310fOaFLI_12fast_codegen
	.quad	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0CsgQ310fOaFLI_12fast_codegen
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.0, 48

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.1,@object
	.section	.rodata..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.1,"a",@progbits
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.1:
	.ascii	"mid > len"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.1, 9

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.2,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.2:
	.asciz	"/tmp/verigmp-hfu69d_4/native/verified/fast_words.rs"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.2, 52

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.3,@object
	.section	.rodata..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.3,"a",@progbits
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.3:
	.ascii	"assertion failed: dst.len() >= rhs.len()"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.3, 40

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.4,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.4,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.4:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.2
	.asciz	"3\000\000\000\000\000\000\000\312\000\000\000\005\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.4, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.5,@object
	.section	.rodata..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.5,"a",@progbits
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.5:
	.ascii	"assertion failed: dst.len() == a.len()"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.5, 38

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.6,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.6,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.6:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.2
	.asciz	"3\000\000\000\000\000\000\000\215\000\000\000\005\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.6, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.7,@object
	.section	.rodata..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.7,"a",@progbits
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.7:
	.ascii	"assertion failed: a.len() >= b.len()"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.7, 36

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.8,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.8,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.8:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.2
	.asciz	"3\000\000\000\000\000\000\000\215\000\000\000\"\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.8, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.9,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.9,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.9:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.2
	.asciz	"3\000\000\000\000\000\000\000M\001\000\000\005\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.9, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.10,@object
	.section	.rodata..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.10,"a",@progbits
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.10:
	.ascii	"assertion failed: a.len() > 0 && a.len() == b.len()"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.10, 51

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11:
	.asciz	"/tmp/verigmp-hfu69d_4/native/verified/fast_multiply.rs"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11, 55

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.12,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.12,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.12:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11
	.asciz	"6\000\000\000\000\000\000\000\302\000\000\000\005\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.12, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.13,@object
	.section	.rodata..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.13,"a",@progbits
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.13:
	.ascii	"assertion failed: dst.len() == a.len() && scratch.len() >= 4 * a.len()"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.13, 70

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.14,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.14,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.14:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11
	.asciz	"6\000\000\000\000\000\000\000\303\000\000\000\005\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.14, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.15,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.15,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.15:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11
	.asciz	"6\000\000\000\000\000\000\000\317\000\000\000$\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.15, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.16,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.16,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.16:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11
	.asciz	"6\000\000\000\000\000\000\000\320\000\000\000 \000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.16, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.17,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.17,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.17:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11
	.asciz	"6\000\000\000\000\000\000\000\322\000\000\000'\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.17, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.18,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.18,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.18:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11
	.asciz	"6\000\000\000\000\000\000\000Y\000\000\000\005\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.18, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.19,@object
	.section	.rodata..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.19,"a",@progbits
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.19:
	.ascii	"assertion failed: dst.len() == 2 * a.len() && scratch.len() >= 3 * a.len()"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.19, 74

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.20,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.20,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.20:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11
	.asciz	"6\000\000\000\000\000\000\000Z\000\000\000\005\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.20, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.21,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.21,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.21:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11
	.asciz	"6\000\000\000\000\000\000\000a\000\000\000-\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.21, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.22,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.22,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.22:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11
	.asciz	"6\000\000\000\000\000\000\000`\000\000\000-\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.22, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.23,@object
	.section	.rodata..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.23,"a",@progbits
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.23:
	.ascii	"assertion failed: 1 <= top && top <= 64"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.23, 39

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.24,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.24,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.24:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.11
	.asciz	"6\000\000\000\000\000\000\000\360\000\000\000\005\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.24, 24

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.25,@object
	.section	.rodata..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.25,"a",@progbits
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.25:
	.ascii	"assertion failed: dst.len() > 0"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.25, 31

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.26,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.26:
	.asciz	"/tmp/verigmp-hfu69d_4/native/verified/pow2.rs"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.26, 46

	.type	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.27,@object
	.section	.data.rel.ro..Lanon.419cafbcf8f538b2f5a7fd3379fd0137.27,"aw",@progbits
	.p2align	3, 0x0
.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.27:
	.quad	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.26
	.asciz	"-\000\000\000\000\000\000\000>\000\000\000\005\000\000"
	.size	.Lanon.419cafbcf8f538b2f5a7fd3379fd0137.27, 24

	.globl	verified_sub
	.type	verified_sub,@function
verified_sub = ordinary_sub
	.ident	"rustc version 1.99.1 (58cf8f9c3 2026-10-13)"
	.section	".note.GNU-stack","",@progbits

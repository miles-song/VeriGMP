	.att_syntax
	.file	"multiply_codegen.3e7a7ac819bec00f-cgu.0"
	.section	.text._RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs5mzpSzIrvxb_16multiply_codegen,"ax",@progbits
	.hidden	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs5mzpSzIrvxb_16multiply_codegen
	.globl	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs5mzpSzIrvxb_16multiply_codegen
	.prefalign	4, .Lfunc_end0, nop
	.type	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs5mzpSzIrvxb_16multiply_codegen,@function
_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs5mzpSzIrvxb_16multiply_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%ecx, %r8d
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%rdi, (%rsp)
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.0(%rip), %rsi
	movq	%rsp, %rdi
	callq	*_RNvNtCs8ZKwes1zzDd_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs5mzpSzIrvxb_16multiply_codegen, .Lfunc_end0-_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs5mzpSzIrvxb_16multiply_codegen
	.cfi_endproc

	.section	.text._RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5mzpSzIrvxb_16multiply_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end1, nop
	.type	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5mzpSzIrvxb_16multiply_codegen,@function
_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5mzpSzIrvxb_16multiply_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	*%rdi
	#APP
	#NO_APP
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5mzpSzIrvxb_16multiply_codegen, .Lfunc_end1-_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5mzpSzIrvxb_16multiply_codegen
	.cfi_endproc

	.section	.text._RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs5mzpSzIrvxb_16multiply_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end2, nop
	.type	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs5mzpSzIrvxb_16multiply_codegen,@function
_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs5mzpSzIrvxb_16multiply_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5mzpSzIrvxb_16multiply_codegen
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs5mzpSzIrvxb_16multiply_codegen, .Lfunc_end2-_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs5mzpSzIrvxb_16multiply_codegen
	.cfi_endproc

	.section	.text._RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs5mzpSzIrvxb_16multiply_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end3, nop
	.type	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs5mzpSzIrvxb_16multiply_codegen,@function
_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs5mzpSzIrvxb_16multiply_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs5mzpSzIrvxb_16multiply_codegen
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs5mzpSzIrvxb_16multiply_codegen, .Lfunc_end3-_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs5mzpSzIrvxb_16multiply_codegen
	.cfi_endproc

	.section	.text._RNvCs5mzpSzIrvxb_16multiply_codegen4main,"ax",@progbits
	.hidden	_RNvCs5mzpSzIrvxb_16multiply_codegen4main
	.globl	_RNvCs5mzpSzIrvxb_16multiply_codegen4main
	.prefalign	4, .Lfunc_end4, nop
	.type	_RNvCs5mzpSzIrvxb_16multiply_codegen4main,@function
_RNvCs5mzpSzIrvxb_16multiply_codegen4main:
	.cfi_startproc
	retq
.Lfunc_end4:
	.size	_RNvCs5mzpSzIrvxb_16multiply_codegen4main, .Lfunc_end4-_RNvCs5mzpSzIrvxb_16multiply_codegen4main
	.cfi_endproc

	.section	.text.ordinary_low,"ax",@progbits
	.globl	ordinary_low
	.prefalign	4, .Lfunc_end5, nop
	.type	ordinary_low,@function
ordinary_low:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpq	%rcx, %rsi
	jne	.LBB5_14
	movq	%rsi, %rbp
	cmpq	%r9, %rsi
	jne	.LBB5_15
	movq	%r8, %rbx
	movq	%rdx, %r14
	movq	%rdi, %r12
	leaq	(,%rbp,8), %rdx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	testq	%rbp, %rbp
	je	.LBB5_13
	leaq	(%r14,%rbp,8), %rdx
	leaq	1(%rbp), %rsi
	leaq	8(%r12), %r8
	xorl	%r10d, %r10d
	movq	%rbp, %r15
	movq	%r12, 16(%rsp)
	movq	%rdx, 8(%rsp)
	jmp	.LBB5_4
	.p2align	4
.LBB5_7:
	xorl	%r13d, %r13d
	xorl	%edi, %edi
.LBB5_11:
	leaq	(%r12,%r11,8), %rax
	imulq	(%rbx,%rdi,8), %rcx
	addq	(%rax,%rdi,8), %r13
	addq	%rcx, %r13
	movq	%r13, (%rax,%rdi,8)
.LBB5_12:
	addq	$8, %r14
	addq	$8, %r8
	decq	%r15
	cmpq	%rdx, %r14
	je	.LBB5_13
.LBB5_4:
	cmpq	%rsi, %r10
	je	.LBB5_16
	movq	%r10, %r11
	incq	%r10
	cmpq	%r11, %rbp
	je	.LBB5_12
	movq	(%r14), %rcx
	cmpq	%r10, %rbp
	je	.LBB5_7
	movq	%r15, %r9
	andq	$-2, %r9
	movq	%rbp, %r12
	subq	%r11, %r12
	xorl	%r13d, %r13d
	xorl	%edi, %edi
	.p2align	4
.LBB5_9:
	movq	%rcx, %rax
	mulq	(%rbx,%rdi,8)
	xorl	%esi, %esi
	addq	-8(%r8,%rdi,8), %r13
	setb	%sil
	addq	%rax, %r13
	adcq	%rdx, %rsi
	movq	%r13, -8(%r8,%rdi,8)
	movq	%rcx, %rax
	mulq	8(%rbx,%rdi,8)
	xorl	%r13d, %r13d
	addq	(%r8,%rdi,8), %rsi
	setb	%r13b
	addq	%rax, %rsi
	movq	%rsi, (%r8,%rdi,8)
	leaq	2(%rdi), %rdi
	adcq	%rdx, %r13
	cmpq	%rdi, %r9
	jne	.LBB5_9
	testb	$1, %r12b
	movq	16(%rsp), %r12
	movq	8(%rsp), %rdx
	leaq	1(%rbp), %rsi
	jne	.LBB5_11
	jmp	.LBB5_12
.LBB5_13:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB5_16:
	.cfi_def_cfa_offset 80
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.5(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.6(%rip), %rdx
	movl	$37, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB5_14:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.9(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.10(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB5_15:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.11(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.12(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end5:
	.size	ordinary_low, .Lfunc_end5-ordinary_low
	.cfi_endproc

	.section	.text.ordinary_mac,"ax",@progbits
	.globl	ordinary_mac
	.prefalign	4, .Lfunc_end6, nop
	.type	ordinary_mac,@function
ordinary_mac:
	.cfi_startproc
	movq	%rdx, %r8
	movq	%rsi, %rax
	mulq	%rdi
	addq	%r8, %rax
	adcq	$0, %rdx
	addq	%rcx, %rax
	adcq	$0, %rdx
	retq
.Lfunc_end6:
	.size	ordinary_mac, .Lfunc_end6-ordinary_mac
	.cfi_endproc

	.section	.text.ordinary_mul,"ax",@progbits
	.globl	ordinary_mul
	.prefalign	4, .Lfunc_end7, nop
	.type	ordinary_mul,@function
ordinary_mul:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, 8(%rsp)
	testq	%rsi, %rsi
	je	.LBB7_17
	movl	80(%rsp), %eax
	decl	%eax
	cmpl	$64, %eax
	jae	.LBB7_18
	movq	%rsi, %r14
	cmpq	%rcx, %rsi
	jne	.LBB7_19
	cmpq	%r9, %r14
	jne	.LBB7_20
	movq	%r8, %r15
	movq	%rdx, %r13
	leaq	(,%r14,8), %rdx
	xorl	%ebp, %ebp
	movq	8(%rsp), %rbx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	leaq	(,%r14,8), %rdx
	addq	%r13, %rdx
	leaq	1(%r14), %rsi
	leaq	8(%rbx), %r8
	movq	%r14, %r12
	movq	%rdx, 16(%rsp)
	jmp	.LBB7_5
	.p2align	4
.LBB7_8:
	xorl	%r11d, %r11d
	xorl	%edi, %edi
.LBB7_12:
	movq	8(%rsp), %rax
	leaq	(%rax,%r10,8), %rax
	imulq	(%r15,%rdi,8), %rcx
	addq	(%rax,%rdi,8), %r11
	addq	%rcx, %r11
	movq	%r11, (%rax,%rdi,8)
.LBB7_13:
	addq	$8, %r13
	addq	$8, %r8
	decq	%r12
	cmpq	%rdx, %r13
	je	.LBB7_14
.LBB7_5:
	cmpq	%rsi, %rbp
	je	.LBB7_21
	movq	%rbp, %r10
	incq	%rbp
	cmpq	%r10, %r14
	je	.LBB7_13
	movq	(%r13), %rcx
	cmpq	%rbp, %r14
	je	.LBB7_8
	movq	%r12, %r9
	andq	$-2, %r9
	movq	%r14, %rbx
	subq	%r10, %rbx
	xorl	%r11d, %r11d
	xorl	%edi, %edi
	.p2align	4
.LBB7_10:
	movq	%rcx, %rax
	mulq	(%r15,%rdi,8)
	xorl	%esi, %esi
	addq	-8(%r8,%rdi,8), %r11
	setb	%sil
	addq	%rax, %r11
	adcq	%rdx, %rsi
	movq	%r11, -8(%r8,%rdi,8)
	movq	%rcx, %rax
	mulq	8(%r15,%rdi,8)
	xorl	%r11d, %r11d
	addq	(%r8,%rdi,8), %rsi
	setb	%r11b
	addq	%rax, %rsi
	movq	%rsi, (%r8,%rdi,8)
	leaq	2(%rdi), %rdi
	adcq	%rdx, %r11
	cmpq	%rdi, %r9
	jne	.LBB7_10
	testb	$1, %bl
	movq	16(%rsp), %rdx
	leaq	1(%r14), %rsi
	jne	.LBB7_12
	jmp	.LBB7_13
.LBB7_14:
	movl	80(%rsp), %ecx
	cmpl	$63, %ecx
	ja	.LBB7_16
	movq	$-1, %rax
	shlq	%cl, %rax
	notq	%rax
	movq	8(%rsp), %rcx
	andq	%rax, -8(%rcx,%r14,8)
.LBB7_16:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB7_21:
	.cfi_def_cfa_offset 80
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.5(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.6(%rip), %rdx
	movl	$37, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB7_18:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.14(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.15(%rip), %rdx
	movl	$39, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB7_17:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.1(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.13(%rip), %rdx
	movl	$31, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB7_19:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.9(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.10(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB7_20:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.11(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.12(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end7:
	.size	ordinary_mul, .Lfunc_end7-ordinary_mul
	.cfi_endproc

	.section	.text.ordinary_row,"ax",@progbits
	.globl	ordinary_row
	.prefalign	4, .Lfunc_end8, nop
	.type	ordinary_row,@function
ordinary_row:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	cmpq	%rcx, %rsi
	jne	.LBB8_10
	movq	%rsi, %rcx
	subq	%r9, %rcx
	jb	.LBB8_11
	je	.LBB8_9
	movq	%rdx, %r10
	leaq	1(%r9), %rax
	cmpq	%rax, %rsi
	jne	.LBB8_5
	xorl	%esi, %esi
	xorl	%r14d, %r14d
	jmp	.LBB8_8
.LBB8_5:
	movabsq	$1152921504606846974, %r11
	andq	%rcx, %r11
	leaq	(%rdi,%r9,8), %rbx
	addq	$8, %rbx
	xorl	%esi, %esi
	xorl	%r14d, %r14d
	.p2align	4
.LBB8_6:
	movq	%r8, %rax
	mulq	(%r10,%r14,8)
	xorl	%r15d, %r15d
	addq	-8(%rbx,%r14,8), %rsi
	setb	%r15b
	addq	%rax, %rsi
	adcq	%rdx, %r15
	movq	%rsi, -8(%rbx,%r14,8)
	movq	%r8, %rax
	mulq	8(%r10,%r14,8)
	xorl	%esi, %esi
	addq	(%rbx,%r14,8), %r15
	setb	%sil
	addq	%rax, %r15
	movq	%r15, (%rbx,%r14,8)
	leaq	2(%r14), %r14
	adcq	%rdx, %rsi
	cmpq	%r14, %r11
	jne	.LBB8_6
	testb	$1, %cl
	je	.LBB8_9
.LBB8_8:
	leaq	(%rdi,%r9,8), %rax
	imulq	(%r10,%r14,8), %r8
	addq	(%rax,%r14,8), %rsi
	addq	%r8, %rsi
	movq	%rsi, (%rax,%r14,8)
.LBB8_9:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB8_10:
	.cfi_def_cfa_offset 32
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.2(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.4(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB8_11:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.5(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.6(%rip), %rdx
	movl	$37, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end8:
	.size	ordinary_row, .Lfunc_end8-ordinary_row
	.cfi_endproc

	.section	.text.ordinary_word,"ax",@progbits
	.globl	ordinary_word
	.prefalign	4, .Lfunc_end9, nop
	.type	ordinary_word,@function
ordinary_word:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	cmpq	%rcx, %rsi
	ja	.LBB9_5
	testq	%rsi, %rsi
	je	.LBB9_2
	movq	%rdx, %r10
	cmpq	$1, %rsi
	jne	.LBB9_6
	xorl	%r9d, %r9d
	xorl	%r11d, %r11d
	jmp	.LBB9_9
.LBB9_2:
	xorl	%r9d, %r9d
.LBB9_10:
	movq	%r9, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB9_6:
	.cfi_def_cfa_offset 16
	movabsq	$1152921504606846974, %rcx
	andq	%rsi, %rcx
	xorl	%r9d, %r9d
	xorl	%r11d, %r11d
	.p2align	4
.LBB9_7:
	movq	%r8, %rax
	mulq	(%r10,%r11,8)
	xorl	%ebx, %ebx
	addq	(%rdi,%r11,8), %r9
	setb	%bl
	addq	%rax, %r9
	adcq	%rdx, %rbx
	movq	%r9, (%rdi,%r11,8)
	movq	%r8, %rax
	mulq	8(%r10,%r11,8)
	xorl	%r9d, %r9d
	addq	8(%rdi,%r11,8), %rbx
	setb	%r9b
	addq	%rax, %rbx
	movq	%rbx, 8(%rdi,%r11,8)
	leaq	2(%r11), %r11
	adcq	%rdx, %r9
	cmpq	%r11, %rcx
	jne	.LBB9_7
	testb	$1, %sil
	je	.LBB9_10
.LBB9_9:
	movq	%r8, %rax
	mulq	(%r10,%r11,8)
	xorl	%ecx, %ecx
	addq	(%rdi,%r11,8), %r9
	setb	%cl
	addq	%rax, %r9
	adcq	%rdx, %rcx
	movq	%r9, (%rdi,%r11,8)
	movq	%rcx, %r9
	movq	%r9, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB9_5:
	.cfi_def_cfa_offset 16
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.7(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.8(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end9:
	.size	ordinary_word, .Lfunc_end9-ordinary_word
	.cfi_endproc

	.section	.text.verified_low,"ax",@progbits
	.globl	verified_low
	.prefalign	4, .Lfunc_end10, nop
	.type	verified_low,@function
verified_low:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, (%rsp)
	cmpq	%rcx, %rsi
	jne	.LBB10_12
	movq	%rsi, %r15
	cmpq	%r9, %rsi
	jne	.LBB10_13
	testq	%r15, %r15
	je	.LBB10_11
	movq	%r8, %rbx
	movq	%rdx, %r14
	leaq	(,%r15,8), %rdx
	xorl	%r13d, %r13d
	movq	(%rsp), %r12
	movq	%r12, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	leaq	8(%r12), %rsi
	movq	%r15, %rdi
	jmp	.LBB10_4
	.p2align	4
.LBB10_5:
	xorl	%r10d, %r10d
	xorl	%r9d, %r9d
.LBB10_9:
	movq	(%rsp), %rax
	leaq	(%rax,%r13,8), %rax
	imulq	(%rbx,%r9,8), %rcx
	addq	(%rax,%r9,8), %r10
	addq	%rcx, %r10
	movq	%r10, (%rax,%r9,8)
.LBB10_10:
	addq	$8, %rsi
	decq	%rdi
	movq	%r8, %r13
	cmpq	%r15, %r8
	je	.LBB10_11
.LBB10_4:
	leaq	1(%r13), %r8
	movq	(%r14,%r13,8), %rcx
	cmpq	%r8, %r15
	je	.LBB10_5
	movq	%rdi, %rbp
	andq	$-2, %rbp
	movq	%r15, %r11
	subq	%r13, %r11
	xorl	%r10d, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB10_7:
	movq	%rcx, %rax
	mulq	(%rbx,%r9,8)
	xorl	%r12d, %r12d
	addq	-8(%rsi,%r9,8), %r10
	setb	%r12b
	addq	%rax, %r10
	adcq	%rdx, %r12
	movq	%r10, -8(%rsi,%r9,8)
	movq	%rcx, %rax
	mulq	8(%rbx,%r9,8)
	xorl	%r10d, %r10d
	addq	(%rsi,%r9,8), %r12
	setb	%r10b
	addq	%rax, %r12
	adcq	%rdx, %r10
	movq	%r12, (%rsi,%r9,8)
	addq	$2, %r9
	cmpq	%r9, %rbp
	jne	.LBB10_7
	testb	$1, %r11b
	jne	.LBB10_9
	jmp	.LBB10_10
.LBB10_11:
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB10_12:
	.cfi_def_cfa_offset 64
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.9(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.20(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB10_13:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.11(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.21(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end10:
	.size	verified_low, .Lfunc_end10-verified_low
	.cfi_endproc

	.section	.text.verified_mul,"ax",@progbits
	.globl	verified_mul
	.prefalign	4, .Lfunc_end11, nop
	.type	verified_mul,@function
verified_mul:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, (%rsp)
	testq	%rsi, %rsi
	je	.LBB11_13
	movl	64(%rsp), %eax
	decl	%eax
	cmpl	$64, %eax
	jae	.LBB11_14
	movq	%rsi, %r12
	cmpq	%rcx, %rsi
	jne	.LBB11_15
	cmpq	%r9, %r12
	jne	.LBB11_16
	movq	%r8, %r15
	movq	%rdx, %r13
	leaq	(,%r12,8), %rdx
	xorl	%ebp, %ebp
	movq	(%rsp), %rbx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	leaq	8(%rbx), %rsi
	movq	%r12, %rbx
	jmp	.LBB11_5
	.p2align	4
.LBB11_6:
	xorl	%r10d, %r10d
	xorl	%r9d, %r9d
.LBB11_10:
	movq	(%rsp), %rax
	leaq	(%rax,%rbp,8), %rax
	imulq	(%r15,%r9,8), %rcx
	addq	(%rax,%r9,8), %r10
	addq	%rcx, %r10
	movq	%r10, (%rax,%r9,8)
.LBB11_11:
	addq	$8, %rsi
	decq	%rbx
	movq	%r8, %rbp
	cmpq	%r12, %r8
	je	.LBB11_12
.LBB11_5:
	leaq	1(%rbp), %r8
	movq	(%r13,%rbp,8), %rcx
	cmpq	%r8, %r12
	je	.LBB11_6
	movq	%rbx, %rdi
	andq	$-2, %rdi
	movq	%r12, %r11
	subq	%rbp, %r11
	xorl	%r10d, %r10d
	xorl	%r9d, %r9d
	.p2align	4
.LBB11_8:
	movq	%rcx, %rax
	mulq	(%r15,%r9,8)
	xorl	%r14d, %r14d
	addq	-8(%rsi,%r9,8), %r10
	setb	%r14b
	addq	%rax, %r10
	adcq	%rdx, %r14
	movq	%r10, -8(%rsi,%r9,8)
	movq	%rcx, %rax
	mulq	8(%r15,%r9,8)
	xorl	%r10d, %r10d
	addq	(%rsi,%r9,8), %r14
	setb	%r10b
	addq	%rax, %r14
	adcq	%rdx, %r10
	movq	%r14, (%rsi,%r9,8)
	addq	$2, %r9
	cmpq	%r9, %rdi
	jne	.LBB11_8
	testb	$1, %r11b
	jne	.LBB11_10
	jmp	.LBB11_11
.LBB11_12:
	movq	$-1, %rax
	movq	$-1, %rdx
	movl	64(%rsp), %ecx
	shlq	%cl, %rdx
	cmpl	$64, %ecx
	notq	%rdx
	cmoveq	%rax, %rdx
	movq	(%rsp), %rax
	andq	%rdx, -8(%rax,%r12,8)
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB11_14:
	.cfi_def_cfa_offset 64
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.14(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.23(%rip), %rdx
	movl	$39, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB11_13:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.1(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.22(%rip), %rdx
	movl	$31, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB11_15:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.9(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.20(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB11_16:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.11(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.21(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end11:
	.size	verified_mul, .Lfunc_end11-verified_mul
	.cfi_endproc

	.section	.text.verified_row,"ax",@progbits
	.globl	verified_row
	.prefalign	4, .Lfunc_end12, nop
	.type	verified_row,@function
verified_row:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	cmpq	%rcx, %rsi
	jne	.LBB12_10
	movq	%rsi, %rcx
	subq	%r9, %rcx
	jb	.LBB12_11
	je	.LBB12_9
	movq	%rdx, %r10
	leaq	1(%r9), %rax
	cmpq	%rax, %rsi
	jne	.LBB12_5
	xorl	%r11d, %r11d
	xorl	%esi, %esi
	jmp	.LBB12_8
.LBB12_5:
	movabsq	$1152921504606846974, %rbx
	andq	%rcx, %rbx
	leaq	(%rdi,%r9,8), %r14
	addq	$8, %r14
	xorl	%r11d, %r11d
	xorl	%esi, %esi
	.p2align	4
.LBB12_6:
	movq	%r8, %rax
	mulq	(%r10,%rsi,8)
	xorl	%r15d, %r15d
	addq	-8(%r14,%rsi,8), %r11
	setb	%r15b
	addq	%rax, %r11
	adcq	%rdx, %r15
	movq	%r11, -8(%r14,%rsi,8)
	movq	%r8, %rax
	mulq	8(%r10,%rsi,8)
	xorl	%r11d, %r11d
	addq	(%r14,%rsi,8), %r15
	setb	%r11b
	addq	%rax, %r15
	adcq	%rdx, %r11
	movq	%r15, (%r14,%rsi,8)
	addq	$2, %rsi
	cmpq	%rsi, %rbx
	jne	.LBB12_6
	testb	$1, %cl
	je	.LBB12_9
.LBB12_8:
	leaq	(%rdi,%r9,8), %rax
	imulq	(%r10,%rsi,8), %r8
	addq	(%rax,%rsi,8), %r11
	addq	%r8, %r11
	movq	%r11, (%rax,%rsi,8)
.LBB12_9:
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB12_10:
	.cfi_def_cfa_offset 32
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.2(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.17(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB12_11:
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.5(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.18(%rip), %rdx
	movl	$37, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end12:
	.size	verified_row, .Lfunc_end12-verified_row
	.cfi_endproc

	.section	.text.verified_word,"ax",@progbits
	.globl	verified_word
	.prefalign	4, .Lfunc_end13, nop
	.type	verified_word,@function
verified_word:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	cmpq	%rcx, %rsi
	ja	.LBB13_5
	testq	%rsi, %rsi
	je	.LBB13_2
	movq	%rdx, %r9
	cmpq	$1, %rsi
	jne	.LBB13_6
	xorl	%ecx, %ecx
	xorl	%r10d, %r10d
	jmp	.LBB13_9
.LBB13_2:
	xorl	%ecx, %ecx
.LBB13_10:
	movq	%rcx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB13_6:
	.cfi_def_cfa_offset 16
	movabsq	$1152921504606846974, %r11
	andq	%rsi, %r11
	xorl	%ecx, %ecx
	xorl	%r10d, %r10d
	.p2align	4
.LBB13_7:
	movq	%r8, %rax
	mulq	(%r9,%r10,8)
	xorl	%ebx, %ebx
	addq	(%rdi,%r10,8), %rcx
	setb	%bl
	addq	%rax, %rcx
	adcq	%rdx, %rbx
	movq	%rcx, (%rdi,%r10,8)
	movq	%r8, %rax
	mulq	8(%r9,%r10,8)
	xorl	%ecx, %ecx
	addq	8(%rdi,%r10,8), %rbx
	setb	%cl
	addq	%rax, %rbx
	adcq	%rdx, %rcx
	movq	%rbx, 8(%rdi,%r10,8)
	addq	$2, %r10
	cmpq	%r10, %r11
	jne	.LBB13_7
	testb	$1, %sil
	je	.LBB13_10
.LBB13_9:
	movq	%r8, %rax
	mulq	(%r9,%r10,8)
	xorl	%esi, %esi
	addq	(%rdi,%r10,8), %rcx
	setb	%sil
	addq	%rax, %rcx
	adcq	%rdx, %rsi
	movq	%rcx, (%rdi,%r10,8)
	movq	%rsi, %rcx
	movq	%rcx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB13_5:
	.cfi_def_cfa_offset 16
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.7(%rip), %rdi
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.19(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end13:
	.size	verified_word, .Lfunc_end13-verified_word
	.cfi_endproc

	.section	.text.main,"ax",@progbits
	.globl	main
	.prefalign	4, .Lfunc_end14, nop
	.type	main,@function
main:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, %rcx
	movslq	%edi, %rdx
	leaq	_RNvCs5mzpSzIrvxb_16multiply_codegen4main(%rip), %rax
	movq	%rax, (%rsp)
	leaq	.Lanon.5af23a15d8904dacab9943c832668ea3.0(%rip), %rsi
	movq	%rsp, %rdi
	xorl	%r8d, %r8d
	callq	*_RNvNtCs8ZKwes1zzDd_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end14:
	.size	main, .Lfunc_end14-main
	.cfi_endproc

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.0,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.0,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs5mzpSzIrvxb_16multiply_codegen
	.quad	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs5mzpSzIrvxb_16multiply_codegen
	.quad	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs5mzpSzIrvxb_16multiply_codegen
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.0, 48

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.1,@object
	.section	.rodata..Lanon.5af23a15d8904dacab9943c832668ea3.1,"a",@progbits
.Lanon.5af23a15d8904dacab9943c832668ea3.1:
	.ascii	"assertion failed: dst.len() > 0"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.1, 31

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.2,@object
	.section	.rodata..Lanon.5af23a15d8904dacab9943c832668ea3.2,"a",@progbits
.Lanon.5af23a15d8904dacab9943c832668ea3.2:
	.ascii	"assertion failed: dst.len() == rhs.len()"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.2, 40

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.3,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.5af23a15d8904dacab9943c832668ea3.3:
	.asciz	"/tmp/verigmp-hfu69d_4/native/controls/multiply.rs"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.3, 50

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.4,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.4,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.4:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.3
	.asciz	"1\000\000\000\000\000\000\000\023\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.4, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.5,@object
	.section	.rodata..Lanon.5af23a15d8904dacab9943c832668ea3.5,"a",@progbits
.Lanon.5af23a15d8904dacab9943c832668ea3.5:
	.ascii	"assertion failed: offset <= dst.len()"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.5, 37

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.6,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.6,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.6:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.3
	.asciz	"1\000\000\000\000\000\000\000\024\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.6, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.7,@object
	.section	.rodata..Lanon.5af23a15d8904dacab9943c832668ea3.7,"a",@progbits
.Lanon.5af23a15d8904dacab9943c832668ea3.7:
	.ascii	"assertion failed: dst.len() <= rhs.len()"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.7, 40

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.8,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.8,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.8:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.3
	.asciz	"1\000\000\000\000\000\000\000\b\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.8, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.9,@object
	.section	.rodata..Lanon.5af23a15d8904dacab9943c832668ea3.9,"a",@progbits
.Lanon.5af23a15d8904dacab9943c832668ea3.9:
	.ascii	"assertion failed: dst.len() == lhs.len()"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.9, 40

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.10,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.10,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.10:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.3
	.asciz	"1\000\000\000\000\000\000\000\031\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.10, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.11,@object
	.section	.rodata..Lanon.5af23a15d8904dacab9943c832668ea3.11,"a",@progbits
.Lanon.5af23a15d8904dacab9943c832668ea3.11:
	.ascii	"assertion failed: lhs.len() == rhs.len()"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.11, 40

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.12,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.12,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.12:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.3
	.asciz	"1\000\000\000\000\000\000\000\032\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.12, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.13,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.13,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.13:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.3
	.asciz	"1\000\000\000\000\000\000\000\"\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.13, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.14,@object
	.section	.rodata..Lanon.5af23a15d8904dacab9943c832668ea3.14,"a",@progbits
.Lanon.5af23a15d8904dacab9943c832668ea3.14:
	.ascii	"assertion failed: 1 <= top && top <= 64"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.14, 39

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.15,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.15,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.15:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.3
	.asciz	"1\000\000\000\000\000\000\000#\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.15, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.16,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.5af23a15d8904dacab9943c832668ea3.16:
	.asciz	"/tmp/verigmp-hfu69d_4/native/verified/multiply.rs"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.16, 50

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.17,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.17,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.17:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.16
	.asciz	"1\000\000\000\000\000\000\000Q\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.17, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.18,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.18,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.18:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.16
	.asciz	"1\000\000\000\000\000\000\000R\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.18, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.19,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.19,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.19:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.16
	.asciz	"1\000\000\000\000\000\000\000#\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.19, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.20,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.20,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.20:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.16
	.asciz	"1\000\000\000\000\000\000\000\203\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.20, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.21,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.21,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.21:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.16
	.asciz	"1\000\000\000\000\000\000\000\204\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.21, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.22,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.22,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.22:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.16
	.asciz	"1\000\000\000\000\000\000\000\273\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.22, 24

	.type	.Lanon.5af23a15d8904dacab9943c832668ea3.23,@object
	.section	.data.rel.ro..Lanon.5af23a15d8904dacab9943c832668ea3.23,"aw",@progbits
	.p2align	3, 0x0
.Lanon.5af23a15d8904dacab9943c832668ea3.23:
	.quad	.Lanon.5af23a15d8904dacab9943c832668ea3.16
	.asciz	"1\000\000\000\000\000\000\000\274\000\000\000\005\000\000"
	.size	.Lanon.5af23a15d8904dacab9943c832668ea3.23, 24

	.globl	verified_mac
	.type	verified_mac,@function
verified_mac = ordinary_mac
	.ident	"rustc version 1.99.1 (58cf8f9c3 2026-10-13)"
	.section	".note.GNU-stack","",@progbits

	.att_syntax
	.file	"limbs_codegen.3874b4ae22a11e52-cgu.0"
	.section	.text._RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs4QvPg5AucF2_13limbs_codegen,"ax",@progbits
	.hidden	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs4QvPg5AucF2_13limbs_codegen
	.globl	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs4QvPg5AucF2_13limbs_codegen
	.prefalign	4, .Lfunc_end0, nop
	.type	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs4QvPg5AucF2_13limbs_codegen,@function
_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs4QvPg5AucF2_13limbs_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%ecx, %r8d
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%rdi, (%rsp)
	leaq	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.0(%rip), %rsi
	movq	%rsp, %rdi
	callq	*_RNvNtCs8ZKwes1zzDd_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs4QvPg5AucF2_13limbs_codegen, .Lfunc_end0-_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs4QvPg5AucF2_13limbs_codegen
	.cfi_endproc

	.section	.text._RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4QvPg5AucF2_13limbs_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end1, nop
	.type	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4QvPg5AucF2_13limbs_codegen,@function
_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4QvPg5AucF2_13limbs_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	*%rdi
	#APP
	#NO_APP
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4QvPg5AucF2_13limbs_codegen, .Lfunc_end1-_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4QvPg5AucF2_13limbs_codegen
	.cfi_endproc

	.section	.text._RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs4QvPg5AucF2_13limbs_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end2, nop
	.type	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs4QvPg5AucF2_13limbs_codegen,@function
_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs4QvPg5AucF2_13limbs_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4QvPg5AucF2_13limbs_codegen
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs4QvPg5AucF2_13limbs_codegen, .Lfunc_end2-_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs4QvPg5AucF2_13limbs_codegen
	.cfi_endproc

	.section	.text._RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs4QvPg5AucF2_13limbs_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end3, nop
	.type	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs4QvPg5AucF2_13limbs_codegen,@function
_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs4QvPg5AucF2_13limbs_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs4QvPg5AucF2_13limbs_codegen
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs4QvPg5AucF2_13limbs_codegen, .Lfunc_end3-_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs4QvPg5AucF2_13limbs_codegen
	.cfi_endproc

	.section	.text._RNvCs4QvPg5AucF2_13limbs_codegen4main,"ax",@progbits
	.hidden	_RNvCs4QvPg5AucF2_13limbs_codegen4main
	.globl	_RNvCs4QvPg5AucF2_13limbs_codegen4main
	.prefalign	4, .Lfunc_end4, nop
	.type	_RNvCs4QvPg5AucF2_13limbs_codegen4main,@function
_RNvCs4QvPg5AucF2_13limbs_codegen4main:
	.cfi_startproc
	retq
.Lfunc_end4:
	.size	_RNvCs4QvPg5AucF2_13limbs_codegen4main, .Lfunc_end4-_RNvCs4QvPg5AucF2_13limbs_codegen4main
	.cfi_endproc

	.section	.text.ordinary_add_assign,"ax",@progbits
	.globl	ordinary_add_assign
	.prefalign	4, .Lfunc_end5, nop
	.type	ordinary_add_assign,@function
ordinary_add_assign:
	.cfi_startproc
	cmpq	%rcx, %rsi
	jne	.LBB5_5
	testq	%rsi, %rsi
	je	.LBB5_2
	cmpq	$1, %rsi
	jne	.LBB5_6
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	jmp	.LBB5_9
.LBB5_2:
	xorl	%eax, %eax
	retq
.LBB5_6:
	movabsq	$1152921504606846974, %r8
	andq	%rsi, %r8
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB5_7:
	xorl	%r9d, %r9d
	addq	(%rdi,%rcx,8), %rax
	setb	%r9b
	addq	(%rdx,%rcx,8), %rax
	movq	%rax, (%rdi,%rcx,8)
	adcq	8(%rdi,%rcx,8), %r9
	setb	%al
	movzbl	%al, %eax
	addq	8(%rdx,%rcx,8), %r9
	adcq	$0, %rax
	movq	%r9, 8(%rdi,%rcx,8)
	addq	$2, %rcx
	cmpq	%rcx, %r8
	jne	.LBB5_7
	testb	$1, %sil
	je	.LBB5_10
.LBB5_9:
	xorl	%esi, %esi
	addq	(%rdi,%rcx,8), %rax
	setb	%sil
	addq	(%rdx,%rcx,8), %rax
	adcq	$0, %rsi
	movq	%rax, (%rdi,%rcx,8)
	movq	%rsi, %rax
.LBB5_10:
	retq
.LBB5_5:
	pushq	%rax
	.cfi_def_cfa_offset 16
	leaq	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.1(%rip), %rdi
	leaq	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.5(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end5:
	.size	ordinary_add_assign, .Lfunc_end5-ordinary_add_assign
	.cfi_endproc

	.section	.text.verified_add_assign,"ax",@progbits
	.globl	verified_add_assign
	.prefalign	4, .Lfunc_end6, nop
	.type	verified_add_assign,@function
verified_add_assign:
	.cfi_startproc
	cmpq	%rcx, %rsi
	jne	.LBB6_5
	testq	%rsi, %rsi
	je	.LBB6_2
	cmpq	$1, %rsi
	jne	.LBB6_6
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	jmp	.LBB6_9
.LBB6_2:
	xorl	%eax, %eax
	retq
.LBB6_6:
	movabsq	$1152921504606846974, %r8
	andq	%rsi, %r8
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB6_7:
	xorl	%r9d, %r9d
	addq	(%rdi,%rcx,8), %rax
	setb	%r9b
	addq	(%rdx,%rcx,8), %rax
	movq	%rax, (%rdi,%rcx,8)
	adcq	8(%rdi,%rcx,8), %r9
	setb	%al
	movzbl	%al, %eax
	addq	8(%rdx,%rcx,8), %r9
	adcq	$0, %rax
	movq	%r9, 8(%rdi,%rcx,8)
	addq	$2, %rcx
	cmpq	%rcx, %r8
	jne	.LBB6_7
	testb	$1, %sil
	je	.LBB6_10
.LBB6_9:
	xorl	%esi, %esi
	addq	(%rdi,%rcx,8), %rax
	setb	%sil
	addq	(%rdx,%rcx,8), %rax
	adcq	$0, %rsi
	movq	%rax, (%rdi,%rcx,8)
	movq	%rsi, %rax
.LBB6_10:
	retq
.LBB6_5:
	pushq	%rax
	.cfi_def_cfa_offset 16
	leaq	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.1(%rip), %rdi
	leaq	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.3(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end6:
	.size	verified_add_assign, .Lfunc_end6-verified_add_assign
	.cfi_endproc

	.section	.text.main,"ax",@progbits
	.globl	main
	.prefalign	4, .Lfunc_end7, nop
	.type	main,@function
main:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, %rcx
	movslq	%edi, %rdx
	leaq	_RNvCs4QvPg5AucF2_13limbs_codegen4main(%rip), %rax
	movq	%rax, (%rsp)
	leaq	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.0(%rip), %rsi
	movq	%rsp, %rdi
	xorl	%r8d, %r8d
	callq	*_RNvNtCs8ZKwes1zzDd_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end7:
	.size	main, .Lfunc_end7-main
	.cfi_endproc

	.type	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.0,@object
	.section	.data.rel.ro..Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.0,"aw",@progbits
	.p2align	3, 0x0
.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs4QvPg5AucF2_13limbs_codegen
	.quad	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs4QvPg5AucF2_13limbs_codegen
	.quad	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs4QvPg5AucF2_13limbs_codegen
	.size	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.0, 48

	.type	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.1,@object
	.section	.rodata..Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.1,"a",@progbits
.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.1:
	.ascii	"assertion failed: dst.len() == rhs.len()"
	.size	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.1, 40

	.type	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.2,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.2:
	.asciz	"/tmp/verigmp-hfu69d_4/native/verified/limbs.rs"
	.size	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.2, 47

	.type	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.3,@object
	.section	.data.rel.ro..Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.3,"aw",@progbits
	.p2align	3, 0x0
.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.3:
	.quad	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.2
	.asciz	".\000\000\000\000\000\000\000\023\000\000\000\005\000\000"
	.size	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.3, 24

	.type	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.4,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.4:
	.asciz	"/tmp/verigmp-hfu69d_4/native/controls/limbs.rs"
	.size	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.4, 47

	.type	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.5,@object
	.section	.data.rel.ro..Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.5,"aw",@progbits
	.p2align	3, 0x0
.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.5:
	.quad	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.4
	.asciz	".\000\000\000\000\000\000\000\003\000\000\000\005\000\000"
	.size	.Lanon.76deb5e1b5d4f9fa2ec549b1b838ced5.5, 24

	.ident	"rustc version 1.99.1 (58cf8f9c3 2026-10-13)"
	.section	".note.GNU-stack","",@progbits

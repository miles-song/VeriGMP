	.att_syntax
	.file	"pow2_codegen.141816f8ca621123-cgu.0"
	.section	.text._RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs1IXxSiXPUL7_12pow2_codegen,"ax",@progbits
	.hidden	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs1IXxSiXPUL7_12pow2_codegen
	.globl	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs1IXxSiXPUL7_12pow2_codegen
	.prefalign	4, .Lfunc_end0, nop
	.type	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs1IXxSiXPUL7_12pow2_codegen,@function
_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs1IXxSiXPUL7_12pow2_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%ecx, %r8d
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%rdi, (%rsp)
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.0(%rip), %rsi
	movq	%rsp, %rdi
	callq	*_RNvNtCs8ZKwes1zzDd_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs1IXxSiXPUL7_12pow2_codegen, .Lfunc_end0-_RINvNtCs8ZKwes1zzDd_3std2rt10lang_startuECs1IXxSiXPUL7_12pow2_codegen
	.cfi_endproc

	.section	.text._RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1IXxSiXPUL7_12pow2_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end1, nop
	.type	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1IXxSiXPUL7_12pow2_codegen,@function
_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1IXxSiXPUL7_12pow2_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	*%rdi
	#APP
	#NO_APP
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1IXxSiXPUL7_12pow2_codegen, .Lfunc_end1-_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1IXxSiXPUL7_12pow2_codegen
	.cfi_endproc

	.section	.text._RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs1IXxSiXPUL7_12pow2_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end2, nop
	.type	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs1IXxSiXPUL7_12pow2_codegen,@function
_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs1IXxSiXPUL7_12pow2_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1IXxSiXPUL7_12pow2_codegen
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs1IXxSiXPUL7_12pow2_codegen, .Lfunc_end2-_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs1IXxSiXPUL7_12pow2_codegen
	.cfi_endproc

	.section	.text._RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs1IXxSiXPUL7_12pow2_codegen,"ax",@progbits
	.prefalign	4, .Lfunc_end3, nop
	.type	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs1IXxSiXPUL7_12pow2_codegen,@function
_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs1IXxSiXPUL7_12pow2_codegen:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs8ZKwes1zzDd_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs1IXxSiXPUL7_12pow2_codegen
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs1IXxSiXPUL7_12pow2_codegen, .Lfunc_end3-_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs1IXxSiXPUL7_12pow2_codegen
	.cfi_endproc

	.section	.text._RNvCs1IXxSiXPUL7_12pow2_codegen4main,"ax",@progbits
	.hidden	_RNvCs1IXxSiXPUL7_12pow2_codegen4main
	.globl	_RNvCs1IXxSiXPUL7_12pow2_codegen4main
	.prefalign	4, .Lfunc_end4, nop
	.type	_RNvCs1IXxSiXPUL7_12pow2_codegen4main,@function
_RNvCs1IXxSiXPUL7_12pow2_codegen4main:
	.cfi_startproc
	retq
.Lfunc_end4:
	.size	_RNvCs1IXxSiXPUL7_12pow2_codegen4main, .Lfunc_end4-_RNvCs1IXxSiXPUL7_12pow2_codegen4main
	.cfi_endproc

	.section	.text.ordinary_add_mod,"ax",@progbits
	.globl	ordinary_add_mod
	.prefalign	4, .Lfunc_end5, nop
	.type	ordinary_add_mod,@function
ordinary_add_mod:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	testq	%rsi, %rsi
	je	.LBB5_11
	leal	-1(%r8), %eax
	cmpl	$64, %eax
	jae	.LBB5_12
	cmpq	%rcx, %rsi
	jne	.LBB5_5
	cmpq	$1, %rsi
	jne	.LBB5_6
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	jmp	.LBB5_9
.LBB5_6:
	movabsq	$1152921504606846974, %r9
	andq	%rsi, %r9
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB5_7:
	xorl	%r10d, %r10d
	addq	(%rdi,%rcx,8), %rax
	setb	%r10b
	addq	(%rdx,%rcx,8), %rax
	movq	%rax, (%rdi,%rcx,8)
	adcq	8(%rdi,%rcx,8), %r10
	setb	%al
	movzbl	%al, %eax
	addq	8(%rdx,%rcx,8), %r10
	adcq	$0, %rax
	movq	%r10, 8(%rdi,%rcx,8)
	addq	$2, %rcx
	cmpq	%rcx, %r9
	jne	.LBB5_7
	testb	$1, %sil
	je	.LBB5_10
.LBB5_9:
	addq	(%rdi,%rcx,8), %rax
	addq	(%rdx,%rcx,8), %rax
	movq	%rax, (%rdi,%rcx,8)
.LBB5_10:
	movq	$-1, %rax
	movq	$-1, %rdx
	movl	%r8d, %ecx
	shlq	%cl, %rdx
	cmpl	$64, %r8d
	notq	%rdx
	cmoveq	%rax, %rdx
	andq	%rdx, -8(%rdi,%rsi,8)
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.LBB5_12:
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.5(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.20(%rip), %rdx
	movl	$39, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB5_11:
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.1(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.19(%rip), %rdx
	movl	$31, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB5_5:
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.13(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.26(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end5:
	.size	ordinary_add_mod, .Lfunc_end5-ordinary_add_mod
	.cfi_endproc

	.section	.text.ordinary_layout,"ax",@progbits
	.globl	ordinary_layout
	.prefalign	4, .Lfunc_end6, nop
	.type	ordinary_layout,@function
ordinary_layout:
	.cfi_startproc
	testq	%rdi, %rdi
	je	.LBB6_2
	decq	%rdi
	movq	%rdi, %rax
	shrq	$6, %rax
	incq	%rax
	andl	$63, %edi
	incl	%edi
	movl	%edi, %edx
	retq
.LBB6_2:
	pushq	%rax
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.9(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.23(%rip), %rdx
	movl	$26, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end6:
	.size	ordinary_layout, .Lfunc_end6-ordinary_layout
	.cfi_endproc

	.section	.text.ordinary_mask,"ax",@progbits
	.globl	ordinary_mask
	.prefalign	4, .Lfunc_end7, nop
	.type	ordinary_mask,@function
ordinary_mask:
	.cfi_startproc
	leal	-1(%rsi), %eax
	cmpl	$64, %eax
	jae	.LBB7_2
	movq	$-1, %rax
	movl	%esi, %ecx
	shlq	%cl, %rax
	movq	$-1, %rcx
	cmpl	$64, %esi
	notq	%rax
	cmoveq	%rcx, %rax
	andq	%rdi, %rax
	retq
.LBB7_2:
	pushq	%rax
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.11(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.24(%rip), %rdx
	movl	$41, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end7:
	.size	ordinary_mask, .Lfunc_end7-ordinary_mask
	.cfi_endproc

	.section	.text.ordinary_normalize,"ax",@progbits
	.globl	ordinary_normalize
	.prefalign	4, .Lfunc_end8, nop
	.type	ordinary_normalize,@function
ordinary_normalize:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	testq	%rsi, %rsi
	je	.LBB8_3
	leal	-1(%rdx), %eax
	cmpl	$64, %eax
	jae	.LBB8_4
	movq	$-1, %rax
	movq	$-1, %r8
	movl	%edx, %ecx
	shlq	%cl, %r8
	cmpl	$64, %edx
	notq	%r8
	cmoveq	%rax, %r8
	andq	%r8, -8(%rdi,%rsi,8)
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.LBB8_4:
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.11(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.24(%rip), %rdx
	movl	$41, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB8_3:
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.1(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.18(%rip), %rdx
	movl	$31, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end8:
	.size	ordinary_normalize, .Lfunc_end8-ordinary_normalize
	.cfi_endproc

	.section	.text.ordinary_sub_mod,"ax",@progbits
	.globl	ordinary_sub_mod
	.prefalign	4, .Lfunc_end9, nop
	.type	ordinary_sub_mod,@function
ordinary_sub_mod:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	testq	%rsi, %rsi
	je	.LBB9_11
	leal	-1(%r8), %eax
	cmpl	$64, %eax
	jae	.LBB9_12
	cmpq	%rcx, %rsi
	jne	.LBB9_5
	cmpq	$1, %rsi
	jne	.LBB9_6
	xorl	%r9d, %r9d
	xorl	%eax, %eax
	jmp	.LBB9_9
.LBB9_6:
	movabsq	$1152921504606846974, %rcx
	andq	%rsi, %rcx
	xorl	%r9d, %r9d
	xorl	%eax, %eax
	.p2align	4
.LBB9_7:
	movq	(%rdi,%rax,8), %r10
	movq	8(%rdi,%rax,8), %r11
	subq	(%rdx,%rax,8), %r10
	setb	%bl
	subq	%r9, %r10
	setb	%r9b
	orb	%bl, %r9b
	movzbl	%r9b, %r9d
	movq	%r10, (%rdi,%rax,8)
	subq	8(%rdx,%rax,8), %r11
	setb	%r10b
	subq	%r9, %r11
	setb	%r9b
	orb	%r10b, %r9b
	movzbl	%r9b, %r9d
	movq	%r11, 8(%rdi,%rax,8)
	addq	$2, %rax
	cmpq	%rax, %rcx
	jne	.LBB9_7
	testb	$1, %sil
	je	.LBB9_10
.LBB9_9:
	addq	(%rdx,%rax,8), %r9
	subq	%r9, (%rdi,%rax,8)
.LBB9_10:
	movq	$-1, %rax
	movq	$-1, %rdx
	movl	%r8d, %ecx
	shlq	%cl, %rdx
	cmpl	$64, %r8d
	notq	%rdx
	cmoveq	%rax, %rdx
	andq	%rdx, -8(%rdi,%rsi,8)
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB9_12:
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.5(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.22(%rip), %rdx
	movl	$39, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB9_11:
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.1(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.21(%rip), %rdx
	movl	$31, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB9_5:
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.13(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.27(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end9:
	.size	ordinary_sub_mod, .Lfunc_end9-ordinary_sub_mod
	.cfi_endproc

	.section	.text.verified_add_mod,"ax",@progbits
	.globl	verified_add_mod
	.prefalign	4, .Lfunc_end10, nop
	.type	verified_add_mod,@function
verified_add_mod:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	testq	%rsi, %rsi
	je	.LBB10_11
	leal	-1(%r8), %eax
	cmpl	$64, %eax
	jae	.LBB10_12
	cmpq	%rcx, %rsi
	jne	.LBB10_5
	cmpq	$1, %rsi
	jne	.LBB10_6
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	jmp	.LBB10_9
.LBB10_6:
	movabsq	$1152921504606846974, %r9
	andq	%rsi, %r9
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB10_7:
	xorl	%r10d, %r10d
	addq	(%rdi,%rcx,8), %rax
	setb	%r10b
	addq	(%rdx,%rcx,8), %rax
	movq	%rax, (%rdi,%rcx,8)
	adcq	8(%rdi,%rcx,8), %r10
	setb	%al
	movzbl	%al, %eax
	addq	8(%rdx,%rcx,8), %r10
	adcq	$0, %rax
	movq	%r10, 8(%rdi,%rcx,8)
	addq	$2, %rcx
	cmpq	%rcx, %r9
	jne	.LBB10_7
	testb	$1, %sil
	je	.LBB10_10
.LBB10_9:
	addq	(%rdi,%rcx,8), %rax
	addq	(%rdx,%rcx,8), %rax
	movq	%rax, (%rdi,%rcx,8)
.LBB10_10:
	movq	$-1, %rax
	movq	$-1, %rdx
	movl	%r8d, %ecx
	shlq	%cl, %rdx
	cmpl	$64, %r8d
	notq	%rdx
	cmoveq	%rax, %rdx
	andq	%rdx, -8(%rdi,%rsi,8)
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.LBB10_12:
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.5(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.6(%rip), %rdx
	movl	$39, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB10_11:
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.1(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.4(%rip), %rdx
	movl	$31, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB10_5:
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.13(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.15(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end10:
	.size	verified_add_mod, .Lfunc_end10-verified_add_mod
	.cfi_endproc

	.section	.text.verified_layout,"ax",@progbits
	.globl	verified_layout
	.prefalign	4, .Lfunc_end11, nop
	.type	verified_layout,@function
verified_layout:
	.cfi_startproc
	testq	%rdi, %rdi
	je	.LBB11_2
	decq	%rdi
	movq	%rdi, %rax
	shrq	$6, %rax
	incq	%rax
	andl	$63, %edi
	incl	%edi
	movl	%edi, %edx
	retq
.LBB11_2:
	pushq	%rax
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.9(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.10(%rip), %rdx
	movl	$26, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end11:
	.size	verified_layout, .Lfunc_end11-verified_layout
	.cfi_endproc

	.section	.text.verified_mask,"ax",@progbits
	.globl	verified_mask
	.prefalign	4, .Lfunc_end12, nop
	.type	verified_mask,@function
verified_mask:
	.cfi_startproc
	leal	-1(%rsi), %eax
	cmpl	$64, %eax
	jae	.LBB12_2
	movq	$-1, %rax
	movl	%esi, %ecx
	shlq	%cl, %rax
	movq	$-1, %rcx
	cmpl	$64, %esi
	notq	%rax
	cmoveq	%rcx, %rax
	andq	%rdi, %rax
	retq
.LBB12_2:
	pushq	%rax
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.11(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.12(%rip), %rdx
	movl	$41, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end12:
	.size	verified_mask, .Lfunc_end12-verified_mask
	.cfi_endproc

	.section	.text.verified_normalize,"ax",@progbits
	.globl	verified_normalize
	.prefalign	4, .Lfunc_end13, nop
	.type	verified_normalize,@function
verified_normalize:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	testq	%rsi, %rsi
	je	.LBB13_3
	leal	-1(%rdx), %eax
	cmpl	$64, %eax
	jae	.LBB13_4
	movq	$-1, %rax
	movq	$-1, %r8
	movl	%edx, %ecx
	shlq	%cl, %r8
	cmpl	$64, %edx
	notq	%r8
	cmoveq	%rax, %r8
	andq	%r8, -8(%rdi,%rsi,8)
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.LBB13_4:
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.11(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.12(%rip), %rdx
	movl	$41, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB13_3:
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.1(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.3(%rip), %rdx
	movl	$31, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end13:
	.size	verified_normalize, .Lfunc_end13-verified_normalize
	.cfi_endproc

	.section	.text.verified_sub_mod,"ax",@progbits
	.globl	verified_sub_mod
	.prefalign	4, .Lfunc_end14, nop
	.type	verified_sub_mod,@function
verified_sub_mod:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	testq	%rsi, %rsi
	je	.LBB14_11
	leal	-1(%r8), %eax
	cmpl	$64, %eax
	jae	.LBB14_12
	cmpq	%rcx, %rsi
	jne	.LBB14_5
	cmpq	$1, %rsi
	jne	.LBB14_6
	xorl	%r9d, %r9d
	xorl	%eax, %eax
	jmp	.LBB14_9
.LBB14_6:
	movabsq	$1152921504606846974, %rcx
	andq	%rsi, %rcx
	xorl	%r9d, %r9d
	xorl	%eax, %eax
	.p2align	4
.LBB14_7:
	movq	(%rdi,%rax,8), %r10
	movq	8(%rdi,%rax,8), %r11
	subq	(%rdx,%rax,8), %r10
	setb	%bl
	subq	%r9, %r10
	setb	%r9b
	orb	%bl, %r9b
	movzbl	%r9b, %r9d
	movq	%r10, (%rdi,%rax,8)
	subq	8(%rdx,%rax,8), %r11
	setb	%r10b
	subq	%r9, %r11
	setb	%r9b
	orb	%r10b, %r9b
	movzbl	%r9b, %r9d
	movq	%r11, 8(%rdi,%rax,8)
	addq	$2, %rax
	cmpq	%rax, %rcx
	jne	.LBB14_7
	testb	$1, %sil
	je	.LBB14_10
.LBB14_9:
	addq	(%rdx,%rax,8), %r9
	subq	%r9, (%rdi,%rax,8)
.LBB14_10:
	movq	$-1, %rax
	movq	$-1, %rdx
	movl	%r8d, %ecx
	shlq	%cl, %rdx
	cmpl	$64, %r8d
	notq	%rdx
	cmoveq	%rax, %rdx
	andq	%rdx, -8(%rdi,%rsi,8)
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB14_12:
	.cfi_def_cfa_offset 16
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.5(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.8(%rip), %rdx
	movl	$39, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB14_11:
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.1(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.7(%rip), %rdx
	movl	$31, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB14_5:
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.13(%rip), %rdi
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.16(%rip), %rdx
	movl	$40, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end14:
	.size	verified_sub_mod, .Lfunc_end14-verified_sub_mod
	.cfi_endproc

	.section	.text.main,"ax",@progbits
	.globl	main
	.prefalign	4, .Lfunc_end15, nop
	.type	main,@function
main:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, %rcx
	movslq	%edi, %rdx
	leaq	_RNvCs1IXxSiXPUL7_12pow2_codegen4main(%rip), %rax
	movq	%rax, (%rsp)
	leaq	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.0(%rip), %rsi
	movq	%rsp, %rdi
	xorl	%r8d, %r8d
	callq	*_RNvNtCs8ZKwes1zzDd_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end15:
	.size	main, .Lfunc_end15-main
	.cfi_endproc

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.0,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.0,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNSNvYNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0INtNtNtCskADBYZwJmSU_4core3ops8function6FnOnceuE9call_once6vtableCs1IXxSiXPUL7_12pow2_codegen
	.quad	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs1IXxSiXPUL7_12pow2_codegen
	.quad	_RNCINvNtCs8ZKwes1zzDd_3std2rt10lang_startuE0Cs1IXxSiXPUL7_12pow2_codegen
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.0, 48

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.1,@object
	.section	.rodata..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.1,"a",@progbits
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.1:
	.ascii	"assertion failed: dst.len() > 0"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.1, 31

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.2,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.2:
	.asciz	"/tmp/verigmp-hfu69d_4/native/verified/pow2.rs"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.2, 46

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.3,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.3,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.3:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.2
	.asciz	"-\000\000\000\000\000\000\000>\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.3, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.4,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.4,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.4:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.2
	.asciz	"-\000\000\000\000\000\000\000L\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.4, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.5,@object
	.section	.rodata..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.5,"a",@progbits
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.5:
	.ascii	"assertion failed: 1 <= top && top <= 64"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.5, 39

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.6,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.6,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.6:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.2
	.asciz	"-\000\000\000\000\000\000\000M\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.6, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.7,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.7,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.7:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.2
	.asciz	"-\000\000\000\000\000\000\000_\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.7, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.8,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.8,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.8:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.2
	.asciz	"-\000\000\000\000\000\000\000_\000\000\000\032\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.8, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.9,@object
	.section	.rodata..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.9,"a",@progbits
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.9:
	.ascii	"assertion failed: bits > 0"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.9, 26

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.10,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.10,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.10:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.2
	.asciz	"-\000\000\000\000\000\000\000\025\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.10, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.11,@object
	.section	.rodata..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.11,"a",@progbits
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.11:
	.ascii	"assertion failed: 1 <= bits && bits <= 64"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.11, 41

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.12,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.12,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.12:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.2
	.asciz	"-\000\000\000\000\000\000\000$\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.12, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.13,@object
	.section	.rodata..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.13,"a",@progbits
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.13:
	.ascii	"assertion failed: dst.len() == rhs.len()"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.13, 40

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.14,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.14:
	.asciz	"/tmp/verigmp-hfu69d_4/native/verified/limbs.rs"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.14, 47

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.15,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.15,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.15:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.14
	.asciz	".\000\000\000\000\000\000\000\023\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.15, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.16,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.16,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.16:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.14
	.asciz	".\000\000\000\000\000\000\000Q\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.16, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.17,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.17:
	.asciz	"/tmp/verigmp-hfu69d_4/native/controls/pow2.rs"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.17, 46

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.18,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.18,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.18:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.17
	.asciz	"-\000\000\000\000\000\000\000\020\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.18, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.19,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.19,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.19:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.17
	.asciz	"-\000\000\000\000\000\000\000\026\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.19, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.20,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.20,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.20:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.17
	.asciz	"-\000\000\000\000\000\000\000\027\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.20, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.21,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.21,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.21:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.17
	.asciz	"-\000\000\000\000\000\000\000\035\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.21, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.22,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.22,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.22:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.17
	.asciz	"-\000\000\000\000\000\000\000\035\000\000\000\032\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.22, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.23,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.23,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.23:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.17
	.asciz	"-\000\000\000\000\000\000\000\005\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.23, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.24,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.24,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.24:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.17
	.asciz	"-\000\000\000\000\000\000\000\013\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.24, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.25,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.25:
	.asciz	"/tmp/verigmp-hfu69d_4/native/controls/limbs.rs"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.25, 47

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.26,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.26,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.26:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.25
	.asciz	".\000\000\000\000\000\000\000\003\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.26, 24

	.type	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.27,@object
	.section	.data.rel.ro..Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.27,"aw",@progbits
	.p2align	3, 0x0
.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.27:
	.quad	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.25
	.asciz	".\000\000\000\000\000\000\000\025\000\000\000\005\000\000"
	.size	.Lanon.e8f65ca8b3b29a70c93f97f0da3adfa4.27, 24

	.ident	"rustc version 1.99.1 (58cf8f9c3 2026-10-13)"
	.section	".note.GNU-stack","",@progbits

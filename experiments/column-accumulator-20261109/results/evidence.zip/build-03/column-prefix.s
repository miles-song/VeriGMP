_RNvNtCsh6HoSY7h0ok_6runner6column13column_prefix:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$168, %rsp
	.cfi_def_cfa_offset 224
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, 40(%rsp)
	movq	%rdx, 32(%rsp)
	movq	%rcx, 8(%rsp)
	leaq	-1(%rcx), %rax
	cmpq	$128, %rax
	jae	.LBB15_15
	leaq	-1(%r9), %rax
	movq	%rax, 72(%rsp)
	cmpq	$128, %rax
	jae	.LBB15_16
	movq	8(%rsp), %rax
	addq	%r9, %rax
	leaq	-1(%rsi), %rcx
	cmpq	%rax, %rcx
	jae	.LBB15_17
	leaq	(%rdi,%rsi,8), %rax
	movq	%rax, 56(%rsp)
	movq	40(%rsp), %rax
	leaq	-8(%rax), %r12
	movl	$1, %r10d
	xorl	%r15d, %r15d
	movq	32(%rsp), %r11
	xorl	%ebx, %ebx
	xorl	%r13d, %r13d
	xorl	%r14d, %r14d
	movq	%r9, 64(%rsp)
	jmp	.LBB15_4
	.p2align	4
.LBB15_11:
	movq	24(%rsp), %r12
	movq	16(%rsp), %rbx
	movq	48(%rsp), %r14
	addq	120(%rsp), %r13
	adcq	$0, %r8
	addq	%r15, %r13
	adcq	%r11, %r8
	addq	112(%rsp), %rcx
	adcq	$0, %r9
	addq	%r10, %rcx
	adcq	%rbp, %r9
	addq	%r8, %rcx
	movq	144(%rsp), %rax
	movq	%r13, (%rax)
	leaq	8(%rax), %rdi
	adcq	$0, %r9
	movq	136(%rsp), %r10
	incq	%r10
	decq	%rbx
	addq	$8, %r12
	movq	128(%rsp), %r11
	addq	$8, %r11
	movq	%rcx, %r15
	movq	%r9, %r13
	cmpq	56(%rsp), %rdi
	movq	64(%rsp), %r9
	je	.LBB15_12
.LBB15_4:
	movq	8(%rsp), %r8
	cmpq	%r10, %r8
	movq	%r10, %rax
	cmovbq	%r8, %rax
	movq	%r14, %rdx
	movq	72(%rsp), %rcx
	subq	%rcx, %rdx
	cmovbq	%r14, %rcx
	movl	$0, %ebp
	cmovaeq	%rdx, %rbp
	incq	%r14
	cmpq	%r14, %r8
	movq	%r14, %rsi
	cmovbq	%r8, %rsi
	movq	%rsi, %r8
	subq	%rbp, %r8
	jb	.LBB15_18
	movq	%rbx, 16(%rsp)
	movq	%r12, 24(%rsp)
	movq	%r15, %r12
	movq	%r14, %rdx
	subq	%rsi, %rdx
	movq	%r14, %r15
	subq	%rbp, %r15
	movq	%r9, %rbx
	cmpq	%r9, %r15
	ja	.LBB15_19
	movq	%r15, %rsi
	subq	%rdx, %rsi
	jb	.LBB15_19
	movq	%rdx, 80(%rsp)
	movq	%rbp, 88(%rsp)
	movq	%r13, 112(%rsp)
	movq	%r12, 120(%rsp)
	movq	%r14, 48(%rsp)
	movq	%r10, 136(%rsp)
	movq	%rdi, 144(%rsp)
	movq	%rsi, 96(%rsp)
	movq	%rsi, %rdx
	movabsq	$1152921504606846974, %rsi
	andq	%rsi, %rdx
	movq	%r8, 104(%rsp)
	movq	%r8, %rsi
	shrq	%rsi
	shrq	%rdx
	cmpq	%rsi, %rdx
	cmovaeq	%rsi, %rdx
	testq	%rdx, %rdx
	movq	%r11, 128(%rsp)
	je	.LBB15_8
	leaq	(%rax,%rcx), %rdx
	addq	16(%rsp), %rdx
	movq	%rdx, %rsi
	shrq	%rsi
	movabsq	$576460752303423487, %rdi
	andq	%rdi, %rsi
	movq	%rsi, %rbx
	negq	%rbx
	shlq	$4, %rsi
	andl	$1, %edx
	leaq	(%rsi,%rdx,8), %rdx
	shlq	$3, %rax
	subq	%rax, %rdx
	movq	%rdx, 152(%rsp)
	shlq	$3, %rcx
	movq	%r11, %rdi
	subq	%rcx, %rdi
	movq	24(%rsp), %r12
	xorl	%ecx, %ecx
	xorl	%r9d, %r9d
	xorl	%r13d, %r13d
	xorl	%r8d, %r8d
	xorl	%r10d, %r10d
	xorl	%ebp, %ebp
	xorl	%r15d, %r15d
	xorl	%r11d, %r11d
	.p2align	4
.LBB15_14:
	movq	%r15, 160(%rsp)
	movq	%r11, %r15
	movq	%r8, %r11
	movq	%rbp, %r8
	movq	%r10, %rbp
	movq	%r13, %r10
	movq	%r9, %r13
	movq	%rcx, %r9
	movq	152(%rsp), %rcx
	movq	8(%r12,%rcx), %rax
	mulq	(%rdi)
	movq	%rax, %rsi
	movq	%rdx, %r14
	movq	(%r12,%rcx), %rax
	movq	%r9, %rcx
	movq	%r13, %r9
	movq	%r10, %r13
	movq	%rbp, %r10
	movq	%r8, %rbp
	movq	%r11, %r8
	movq	%r15, %r11
	movq	160(%rsp), %r15
	mulq	8(%rdi)
	addq	%rsi, %r15
	adcq	$0, %r11
	addq	%r14, %r10
	adcq	$0, %rbp
	addq	%rax, %r13
	adcq	$0, %r8
	addq	%rdx, %rcx
	adcq	$0, %r9
	addq	$-16, %r12
	addq	$16, %rdi
	incq	%rbx
	jne	.LBB15_14
	jmp	.LBB15_9
	.p2align	4
.LBB15_8:
	xorl	%r15d, %r15d
	xorl	%r11d, %r11d
	xorl	%r10d, %r10d
	xorl	%ebp, %ebp
	xorl	%r13d, %r13d
	xorl	%r8d, %r8d
	xorl	%ecx, %ecx
	xorl	%r9d, %r9d
.LBB15_9:
	movq	96(%rsp), %rax
	andl	$1, %eax
	movq	104(%rsp), %rsi
	testl	%esi, %eax
	je	.LBB15_11
	movq	32(%rsp), %rax
	movq	88(%rsp), %rdx
	leaq	(%rax,%rdx,8), %rdx
	andl	$254, %esi
	movq	40(%rsp), %rax
	movq	80(%rsp), %rdi
	movq	(%rax,%rdi,8), %rax
	mulq	(%rdx,%rsi,8)
	addq	%rax, %r15
	adcq	$0, %r11
	addq	%rdx, %r10
	adcq	$0, %rbp
	jmp	.LBB15_11
.LBB15_12:
	addq	$168, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB15_18:
	.cfi_def_cfa_offset 224
	leaq	.Lanon.dd3a574fd9f33558501bb2d0c38b7fa4.61(%rip), %rcx
	movq	%rbp, %rdi
	movq	8(%rsp), %rdx
	callq	*_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB15_19:
	leaq	.Lanon.dd3a574fd9f33558501bb2d0c38b7fa4.60(%rip), %rcx
	movq	%rdx, %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	callq	*_RNvNtNtCskADBYZwJmSU_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB15_15:
	leaq	.Lanon.dd3a574fd9f33558501bb2d0c38b7fa4.54(%rip), %rdi
	leaq	.Lanon.dd3a574fd9f33558501bb2d0c38b7fa4.55(%rip), %rdx
	movl	$49, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB15_16:
	leaq	.Lanon.dd3a574fd9f33558501bb2d0c38b7fa4.56(%rip), %rdi
	leaq	.Lanon.dd3a574fd9f33558501bb2d0c38b7fa4.57(%rip), %rdx
	movl	$49, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.LBB15_17:
	leaq	.Lanon.dd3a574fd9f33558501bb2d0c38b7fa4.58(%rip), %rdi
	leaq	.Lanon.dd3a574fd9f33558501bb2d0c38b7fa4.59(%rip), %rdx
	movl	$67, %esi
	callq	*_RNvNtCskADBYZwJmSU_4core9panicking5panic@GOTPCREL(%rip)
.Lfunc_end15:
	.size	_RNvNtCsh6HoSY7h0ok_6runner6column13column_prefix, .Lfunc_end15-_RNvNtCsh6HoSY7h0ok_6runner6column13column_prefix
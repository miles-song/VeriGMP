"""Compile the isolated prototype with the existing source-bound comparator pair."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

SOURCE = Path('/mnt/c/Users/23247/.codex/worktrees/gmp-column-prototype-20261109/VeriGMP-scaled-experiments')
OUT = Path('/mnt/e/3sat/VeriGMP-root-column-prototype-20261109/build-03')
PAIR = Path('/mnt/e/3sat/VeriGMP-cross-fusion-baseline-fresh-20261109')
RUSTC = Path('/mnt/e/3sat/VeriCount/deps/rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustc')
VSTD = Path('/mnt/e/3sat/VeriCount/deps/verus/verus-x86-linux')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=False)
    summary = json.loads((PAIR / 'summary.json').read_text())
    for name in ('rlib', 'vir'):
        filename = 'libverigmp.rlib' if name == 'rlib' else 'verigmp.vir'
        assert sha(PAIR / filename) == summary['library_pair'][name + '_sha256']
    source = SOURCE / 'experiments/column-accumulator-20261109'
    env = os.environ.copy()
    env['PATH'] = str(RUSTC.parent) + os.pathsep + env.get('PATH', '')
    version = subprocess.check_output([str(RUSTC), '-vV'], text=True, env=env)
    rows = []
    for label, extra in (('overflow-checked', ['-C', 'overflow-checks=yes']), ('release', [])):
        command = [str(RUSTC), '--edition=2021', '-O', *extra, str(source / 'runner.rs'),
                   '--extern', 'verigmp=' + str(PAIR / 'libverigmp.rlib'), '-L', 'dependency=' + str(VSTD),
                   '--emit=asm,link', '-o', str(OUT / label)]
        result = subprocess.run(command, capture_output=True, env=env, timeout=90)
        (OUT / (label + '.stdout')).write_bytes(result.stdout)
        (OUT / (label + '.stderr')).write_bytes(result.stderr)
        rows.append(dict(label=label, command=command, returncode=result.returncode,
                         binary_sha256=sha(OUT / label) if result.returncode == 0 else None,
                         assembly_sha256=sha(OUT / (label + '.s')) if result.returncode == 0 else None))
        if result.returncode:
            raise RuntimeError('compile failed: ' + result.stderr.decode(errors='replace'))
    report = dict(status='compiled_unverified_prototype', compiler=str(RUSTC), compiler_sha256=sha(RUSTC),
                  compiler_version=version, baseline_summary_sha256=sha(PAIR / 'summary.json'),
                  baseline_native_tree=summary['native_tree'], baseline_pair=summary['library_pair'],
                  source_sha256={name: sha(source / name) for name in ('column.rs', 'runner.rs', 'oracle.py')},
                  builds=rows, benchmark_samples=0, verus_runs=0)
    (OUT / 'build.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()

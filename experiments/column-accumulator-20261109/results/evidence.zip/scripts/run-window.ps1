param([int]$QemuPid=11540)
$ErrorActionPreference='Stop'
$root='E:\3sat\VeriGMP-root-column-prototype-20261109'
$stop=Join-Path $root 'screen-01\resume-watchdog.stop'
$ready=Join-Path $root 'screen-01\resume-watchdog.ready'
if ((Test-Path -LiteralPath $stop) -or (Test-Path -LiteralPath (Join-Path $root 'screen-01\raw.jsonl'))) { throw 'No automatic retry' }
$row=Get-CimInstance Win32_Process -Filter "ProcessId = $QemuPid"
if (!$row -or $row.Name -ne 'qemu-system-x86_64.exe' -or $row.CommandLine -notmatch '-avd opc_toolchain_api36') { throw 'Authorized emulator identity changed' }
$creation=([DateTimeOffset]$row.CreationDate).ToString('o')
$api=Add-Type -MemberDefinition '[DllImport("ntdll.dll")] public static extern int NtSuspendProcess(IntPtr h); [DllImport("ntdll.dll")] public static extern int NtResumeProcess(IntPtr h);' -Name Native -Namespace ColumnWindow -PassThru
$qemu=[Diagnostics.Process]::GetProcessById($QemuPid)
$watchArgs=@('-NoProfile','-File',(Join-Path $root 'resume-watchdog.ps1'),'-QemuPid',$QemuPid,'-Creation',$creation,'-StopFile',$stop,'-Receipt',(Join-Path $root 'screen-01\watchdog.json'),'-ReadyFile',$ready,'-Seconds','140')
$watch=Start-Process -FilePath 'powershell.exe' -ArgumentList $watchArgs -WindowStyle Hidden -PassThru
$suspended=$false
$result=[ordered]@{qemu_pid=$QemuPid;qemu_creation=$creation;watchdog_pid=$watch.Id;started_utc=[DateTimeOffset]::UtcNow.ToString('o')}
try {
    $waitDeadline=[DateTimeOffset]::UtcNow.AddSeconds(10)
    while (!(Test-Path -LiteralPath $ready) -and [DateTimeOffset]::UtcNow -lt $waitDeadline -and !$watch.HasExited) { Start-Sleep -Milliseconds 100 }
    if (!(Test-Path -LiteralPath $ready)) { throw 'Independent watchdog did not acknowledge readiness' }
    if ($watch.HasExited) { throw 'Independent watchdog exited before suspension' }
    $status=$api::NtSuspendProcess($qemu.Handle)
    if ($status -ne 0) { throw "Suspend failed: $status" }
    $suspended=$true
    $cpu=(Get-Counter '\Processor(_Total)\% Processor Time' -SampleInterval 1 -MaxSamples 3).CounterSamples | ForEach-Object { $_.CookedValue }
    $result.cpu_samples_before=$cpu
    $result.host_cpu=(Get-CimInstance Win32_Processor | Select-Object -First 1).Name
    [IO.File]::WriteAllText((Join-Path $root 'screen-01\host-before.json'),($result|ConvertTo-Json -Depth 5))
    & wsl.exe -d Ubuntu -- taskset -c 8 /usr/bin/timeout --signal=TERM --kill-after=1s 120s python3 /mnt/e/3sat/VeriGMP-root-column-prototype-20261109/screen.py run
    $result.screen_exit=$LASTEXITCODE
}
catch {
    $result.error=($_|Out-String)
    throw
}
finally {
    if ($suspended) {
        $result.resume_status=$api::NtResumeProcess($qemu.Handle)
        if ($result.resume_status -eq 0) { [IO.File]::WriteAllText($stop,'resumed by root finally') }
    } else { [IO.File]::WriteAllText($stop,'no suspension occurred') }
    $result.finished_utc=[DateTimeOffset]::UtcNow.ToString('o')
    $qemu.Refresh()
    $result.qemu_alive=-not $qemu.HasExited
    [IO.File]::WriteAllText((Join-Path $root 'screen-01\window.json'),($result|ConvertTo-Json -Depth 5))
}
if ($result.screen_exit -ne 0) { throw "Prototype screen failed with exit $($result.screen_exit); original evidence retained" }
if ($result.resume_status -ne 0) { throw 'Resume failed; independent watchdog remains armed' }

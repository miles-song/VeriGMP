param([int]$QemuPid,[string]$Creation,[string]$StopFile,[string]$Receipt,[string]$ReadyFile,[int]$Seconds=140)
$ErrorActionPreference='Stop'
$deadline=[DateTimeOffset]::UtcNow.AddSeconds($Seconds)
[IO.File]::WriteAllText($ReadyFile,([DateTimeOffset]::UtcNow.ToString('o')))
while ([DateTimeOffset]::UtcNow -lt $deadline) {
    if (Test-Path -LiteralPath $StopFile) { exit 0 }
    Start-Sleep -Milliseconds 200
}
$row=Get-CimInstance Win32_Process -Filter "ProcessId = $QemuPid"
if (!$row -or $row.Name -ne 'qemu-system-x86_64.exe' -or
    $row.CommandLine -notmatch '-avd opc_toolchain_api36' -or
    ([DateTimeOffset]$row.CreationDate).ToString('o') -ne $Creation) {
    [IO.File]::WriteAllText($Receipt,'identity_changed_no_action')
    exit 2
}
$api=Add-Type -MemberDefinition '[DllImport("ntdll.dll")] public static extern int NtResumeProcess(IntPtr processHandle);' -Name Resume -Namespace ColumnWatchdog -PassThru
$process=[Diagnostics.Process]::GetProcessById($QemuPid)
$status=$api::NtResumeProcess($process.Handle)
[IO.File]::WriteAllText($Receipt,(@{action='watchdog_resume';status=$status;utc=[DateTimeOffset]::UtcNow.ToString('o')}|ConvertTo-Json))
exit $status

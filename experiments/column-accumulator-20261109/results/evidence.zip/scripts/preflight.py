"""Check the exact screen inputs using Python integers before any sample invocation."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
plan = json.loads((ROOT / 'screen-01/plan.json').read_text())
requests, expected = [], []
for cell in plan['cells']:
    q_text, a_text, b_text = Path(cell['input']).read_text().split()
    q = int(q_text)
    a, b = [[int(word, 16) for word in text.split(',')] for text in (a_text, b_text)]
    product = sum(word << (64 * i) for i, word in enumerate(a)) * sum(word << (64 * i) for i, word in enumerate(b))
    answer = ','.join(f'{(product >> (64 * i)) & ((1 << 64) - 1):016x}' for i in range(q))
    for side in ('row', 'column'):
        index = len(requests)
        requests.append(f'{index} {side}_{cell["operation"]} {q} {a_text} {b_text}\n')
        expected.append(f'{index} {answer}')
data = ''.join(requests).encode()
result = subprocess.run([plan['binary']], input=data, capture_output=True, timeout=10)
(ROOT / 'screen-01/preflight-input.txt').write_bytes(data)
(ROOT / 'screen-01/preflight-stdout.txt').write_bytes(result.stdout)
(ROOT / 'screen-01/preflight-stderr.txt').write_bytes(result.stderr)
assert result.returncode == 0 and result.stdout.decode().splitlines() == expected
report = dict(status='pass_independent_integer_screen_input_preflight', operations=len(requests),
              binary_sha256=hashlib.sha256(Path(plan['binary']).read_bytes()).hexdigest(),
              plan_sha256=hashlib.sha256((ROOT / 'screen-01/plan.json').read_bytes()).hexdigest(),
              inputs_sha256=hashlib.sha256(data).hexdigest(), stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
              stderr_sha256=hashlib.sha256(result.stderr).hexdigest(), samples=0, proof_claim=False)
(ROOT / 'screen-01/preflight.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))

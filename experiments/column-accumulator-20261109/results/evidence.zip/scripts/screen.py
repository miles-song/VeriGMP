"""One preregistered prototype screen; run under an owned coreutils timeout group."""
import hashlib
import json
import math
import os
from pathlib import Path
import random
import statistics
import subprocess
import time

ROOT = Path(__file__).resolve().parent
BINARY = ROOT / 'build-03/release'
OUTPUT = ROOT / 'screen-01'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def prepare():
    OUTPUT.mkdir(exist_ok=False)
    rng = random.Random(0xC0115C20261109)
    cells = []
    for operation, n, count in (('full', 15, 262144), ('full', 20, 131072),
                                ('low', 46, 65536), ('low', 115, 16384)):
        for pattern in ('random', 'max'):
            a = [rng.getrandbits(64) for _ in range(n)] if pattern == 'random' else [(1 << 64) - 1] * n
            b = [rng.getrandbits(64) for _ in range(n)] if pattern == 'random' else [(1 << 64) - 1] * n
            q = 2 * n if operation == 'full' else n
            path = OUTPUT / f'{operation}-{n}-{pattern}.txt'
            path.write_text(f'{q} ' + ','.join(f'{word:016x}' for word in a) + ' '
                            + ','.join(f'{word:016x}' for word in b) + '\n')
            cells.append(dict(operation=operation, n=n, pattern=pattern, count=count,
                              input=str(path), input_sha256=sha(path)))
    plan = dict(kind='unverified_prototype_investment_screen', binary=str(BINARY), binary_sha256=sha(BINARY),
                build_receipt_sha256=sha(ROOT / 'build-03/build.json'), cpu=8, cells=cells,
                blocks=7, order='ABBA if (cell_index+block_index)%2==0 else BAAB',
                minimum_batch_ns=10000000, go_geomean_ratio_max=0.90, go_cell_ratio_max=1.03,
                count_rule='Fixed prospectively from conservative leaf operation-count estimates; no timing calibration.',
                whole_window_seconds=120, child_timeout_seconds=10, retry=False,
                sample_invocations=224, proof_claim=False, production_acceptance=False)
    (OUTPUT / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    print(json.dumps(dict(status='prepared_no_samples', plan_sha256=sha(OUTPUT / 'plan.json'))))


def run():
    plan = json.loads((OUTPUT / 'plan.json').read_text())
    assert sha(BINARY) == plan['binary_sha256']
    assert sha(ROOT / 'build-03/build.json') == plan['build_receipt_sha256']
    assert os.sched_getaffinity(0) == {8}
    build = json.loads((ROOT / 'build-03/build.json').read_text())
    source = Path('/mnt/c/Users/23247/.codex/worktrees/gmp-column-prototype-20261109/VeriGMP-scaled-experiments/experiments/column-accumulator-20261109')
    for name, digest in build['source_sha256'].items():
        assert sha(source / name) == digest
    for cell in plan['cells']:
        assert sha(cell['input']) == cell['input_sha256']
    rows = []
    start = time.monotonic()
    with (OUTPUT / 'raw.jsonl').open('x') as stream:
        for index, cell in enumerate(plan['cells']):
            for block in range(plan['blocks']):
                order = ('row', 'column', 'column', 'row') if (index + block) % 2 == 0 else ('column', 'row', 'row', 'column')
                for position, side in enumerate(order):
                    if time.monotonic() - start >= 110:
                        raise TimeoutError('sample-launch cutoff before 120-second external deadline')
                    case = side + '_' + cell['operation']
                    command = [str(BINARY), 'sample', cell['input'], case, str(cell['count'])]
                    child = subprocess.run(command, capture_output=True, timeout=10)
                    row = dict(cell=index, block=block, position=position, side=side, command=command,
                               returncode=child.returncode, stdout=child.stdout.decode(errors='replace'),
                               stderr=child.stderr.decode(errors='replace'))
                    stream.write(json.dumps(row, sort_keys=True) + '\n')
                    stream.flush()
                    rows.append(row)
                    assert child.returncode == 0
                    fields = row['stdout'].split()
                    assert fields[:3] == ['sample', case, str(cell['count'])] and len(fields) == 5
    ratios = []
    cells = []
    for index, cell in enumerate(plan['cells']):
        samples = {side: [int(row['stdout'].split()[3]) for row in rows if row['cell'] == index and row['side'] == side]
                   for side in ('row', 'column')}
        assert all(len(values) == 14 for values in samples.values())
        ratio = statistics.median(samples['column']) / statistics.median(samples['row'])
        minimum = min(min(values) for values in samples.values())
        ratios.append(ratio)
        cells.append(dict(cell, ratio=ratio, minimum_batch_ns=minimum,
                          row_median_ns=statistics.median(samples['row']),
                          column_median_ns=statistics.median(samples['column']), samples=samples))
    gm = math.exp(statistics.mean(map(math.log, ratios)))
    usable = all(cell['minimum_batch_ns'] >= plan['minimum_batch_ns'] for cell in cells)
    assert len(rows) == plan['sample_invocations'] and sha(BINARY) == plan['binary_sha256']
    report = dict(status='complete_pending_environment_and_independent_review', cells=cells,
                  geomean_ratio=gm, every_cell_max=max(ratios), all_batches_usable=usable,
                  screen_numerical_go=usable and gm <= 0.90 and max(ratios) <= 1.03,
                  elapsed_seconds=time.monotonic() - start, raw_sha256=sha(OUTPUT / 'raw.jsonl'),
                  plan_sha256=sha(OUTPUT / 'plan.json'), binary_sha256=sha(BINARY),
                  proof_claim=False, production_acceptance=False, benchmark_scope='forced general multiplication leaves only')
    (OUTPUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'cells'}, indent=2))


if __name__ == '__main__':
    import sys
    if sys.argv[1:] == ['prepare']:
        prepare()
    elif sys.argv[1:] == ['run']:
        run()
    else:
        raise SystemExit('prepare or run required')

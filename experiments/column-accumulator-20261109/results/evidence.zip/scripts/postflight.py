"""Bind the completed prototype screen to unchanged sources and retained tools."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/mnt/c/Users/23247/.codex/worktrees/gmp-column-prototype-20261109/VeriGMP-scaled-experiments')
PAIR = Path('/mnt/e/3sat/VeriGMP-cross-fusion-baseline-fresh-20261109')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


build = json.loads((ROOT / 'build-03/build.json').read_text())
plan = json.loads((ROOT / 'screen-01/plan.json').read_text())
report = json.loads((ROOT / 'screen-01/report.json').read_text())
window = json.loads((ROOT / 'screen-01/window.json').read_text(encoding='utf-8-sig'))
checks = {}
checks['compiler'] = sha(build['compiler']) == build['compiler_sha256']
for name, digest in build['source_sha256'].items():
    checks['source/' + name] = sha(SOURCE / 'experiments/column-accumulator-20261109' / name) == digest
for kind, name in [('rlib', 'libverigmp.rlib'), ('vir', 'verigmp.vir')]:
    checks[kind] = sha(PAIR / name) == build['baseline_pair'][kind + '_sha256']
checks['baseline_summary'] = sha(PAIR / 'summary.json') == build['baseline_summary_sha256']
for row in build['builds']:
    checks['binary/' + row['label']] = sha(ROOT / 'build-03' / row['label']) == row['binary_sha256']
checks['plan'] = sha(ROOT / 'screen-01/plan.json') == report['plan_sha256']
checks['raw'] = sha(ROOT / 'screen-01/raw.jsonl') == report['raw_sha256']
checks['timed_binary'] = sha(plan['binary']) == plan['binary_sha256'] == report['binary_sha256']
checks['resume_success'] = window['resume_status'] == 0 and window['qemu_alive']
git_receipt = json.loads((ROOT / 'screen-01/windows-git-after.json').read_text(encoding='utf-8-sig'))
checks['source_clean'] = git_receipt['status'] == ''
checks['source_commit'] = git_receipt['commit'] == '8df6f173040f8cc9a0957420be9dfb832fe26807'
for cell in plan['cells']:
    checks['input/' + Path(cell['input']).name] = sha(cell['input']) == cell['input_sha256']
assert all(checks.values()), checks
receipt = dict(status='pass', checks=checks, decision='no_go_for_preregistered_broad_scope',
               low_115='prospective scoped hypothesis only; no accepted performance claim',
               proof_claim=False, production_acceptance=False,
               environment_limit='CPU affinity and emulator pause recorded; no claim of stable clocks or an exclusive host.',
               artifacts={name: sha(ROOT / name) for name in [
                   'screen.py', 'preflight.py', 'build-03.py', 'run-window.ps1', 'resume-watchdog.ps1',
                   'build-03/build.json', 'screen-01/plan.json', 'screen-01/preflight.json',
                   'screen-01/raw.jsonl', 'screen-01/report.json', 'screen-01/window.json',
                   'screen-01/windows-git-after.json', 'screen-01/emulator-after.json',
                   'oracle-overflow-03/oracle.json', 'oracle-release-03/oracle.json']})
(ROOT / 'screen-01/postflight.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))

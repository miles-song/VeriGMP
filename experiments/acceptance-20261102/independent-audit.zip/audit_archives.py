"""Independently bind the seven published archive tips to fresh archive audits."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
OUT = HERE / 'archive-audit-complete-windows'
BASE = 'e22a4dd00a28681fd27d68e2a78fa304cf17563e'
ARCHIVES = [
    ('scaled', 'VeriGMP-scaled-experiments', 'scaled-subtraction', '57d651a6be739dc43044f8c1cccc2681ebdfd37b', 'scaled-experiments.yml'),
    ('toom4', 'VeriGMP-toom4-experiment', 'toom4', '1e78a6d8edd9c38d87f9578a23dbb1ac49f2c0e1', 'toom4-experiment.yml'),
    ('entry', 'VeriGMP-toom4-entry-experiment', 'toom4-entry', '3361734df5489e0f4bb316bdff71d02bb7fc6f3a', 'toom4-entry-experiment.yml'),
    ('odd', 'VeriGMP-odd-division-experiment', 'odd-division', '6d4d967d69d1c1928f0394b1c2c3a348bd99537c', 'odd-division-experiment.yml'),
    ('fusion', 'VeriGMP-toom4-fusion-experiment', 'toom4-fusion', '6a6cd3509ec42013513eb9793fdae948726722aa', 'toom4-fusion-experiment.yml'),
    ('signed', 'VeriGMP-toom4-signed-eval-experiment', 'toom4-signed-eval', 'deadada9bc306bf3d550a91470ce5ea59884fcb2', 'toom4-signed-eval-experiment.yml'),
    ('toom8', 'VeriGMP-toom8-primitives-experiment', 'toom8-primitives', 'd9f78251606719c375efb76ba8c7e5301e46d95d', 'toom8-primitives-experiment.yml'),
]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(repo, *args):
    return subprocess.check_output(['git', '-c', f'safe.directory={repo}', '-C', str(repo), *args], text=True).strip()

def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def main():
    OUT.mkdir(exist_ok=False)
    target = OUT / 'report.json'
    report = {'status': 'running', 'started_utc': stamp(), 'baseline_commit': BASE,
              'scope': 'Exact published tips, clean tracked snapshots, disjoint archive/workflow changes, fresh archive/hash/oracle-summary audits and preparation boundary checks; no fresh Verus proof or performance timing',
              'script_sha256': sha(Path(__file__)), 'archives': {},
              'benchmark_run': False, 'production_promotion_approved': False}
    def save():
        target.write_text(json.dumps(report, indent=2) + '\n')
    save()
    try:
        for name, checkout, unit, tip, workflow in ARCHIVES:
            repo = HERE.parent / checkout
            root = repo / 'experiments' / unit
            if git(repo, 'rev-parse', 'HEAD') != tip:
                raise ValueError('Archive tip changed: ' + name)
            if git(repo, 'status', '--porcelain=v1'):
                raise ValueError('Dirty archive: ' + name)
            changed = git(repo, 'diff', '--name-only', BASE, tip).splitlines()
            allowed = f'.github/workflows/{workflow}'
            if not changed or any(not (p.startswith('experiments/' + unit + '/') or p == allowed) for p in changed):
                raise ValueError('Unexpected archive diff scope: ' + name)
            tracked = git(repo, 'ls-files', '-z').split('\0')
            tracked = [p for p in tracked if p]
            before = {p: sha(repo / p) for p in tracked}
            item = {'tip': tip, 'checkout': str(repo), 'archive': unit, 'changed_paths': changed,
                    'source_sha256': before, 'source_manifest_sha256': hashlib.sha256(json.dumps(before, sort_keys=True).encode()).hexdigest(),
                    'checks': []}
            report['archives'][name] = item
            save()
            scripts = [root / 'audit.py'] if name != 'toom8' else sorted(root.glob('*/audit.py'))
            scripts += sorted(root.glob('*/test_prepare_boundaries.py'))
            for script in scripts:
                label = name + '-' + script.relative_to(root).as_posix().replace('/', '-') + '.log'
                result = subprocess.run([sys.executable, '-B', str(script)], cwd=script.parent,
                                        capture_output=True, text=True, timeout=600,
                                        env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1'))
                (OUT / label).write_text(result.stdout + result.stderr)
                parsed = json.loads(result.stdout) if result.returncode == 0 else {}
                entry = {'script': script.relative_to(repo).as_posix(), 'script_sha256': sha(script),
                         'returncode': result.returncode, 'log': label, 'log_sha256': sha(OUT / label),
                         'result': parsed}
                item['checks'].append(entry)
                save()
                if result.returncode != 0 or parsed.get('status') != 'pass':
                    raise ValueError('Archive audit failed: ' + str(script))
            if git(repo, 'rev-parse', 'HEAD') != tip or git(repo, 'status', '--porcelain=v1'):
                raise ValueError('Archive changed during audit: ' + name)
            if any(sha(repo / p) != digest for p, digest in before.items()):
                raise ValueError('Tracked bytes changed during audit: ' + name)
            item.update(status='pass', source_checks_before_after=True, production_diff_empty=True)
            save()
            print(json.dumps({'archive': name, 'status': 'pass', 'checks': len(item['checks']),
                              'tracked_sources': len(before), 'manifest_sha256': item['source_manifest_sha256']}), flush=True)
        report.update(status='pass', finished_utc=stamp())
    except Exception as error:
        report.update(status='error', error=f'{type(error).__name__}: {error}', finished_utc=stamp())
    finally:
        save()
    print(json.dumps({k: report[k] for k in ['status', 'error'] if k in report}), flush=True)
    return report['status'] != 'pass'

if __name__ == '__main__':
    raise SystemExit(main())

"""Prospective actual-native fixed-row acceptance; no automatic retry."""
import hashlib,json,math,os,re,statistics,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BUILD=Path('/mnt/e/3sat/VeriGMP-fixed-row-local-gates-20261109/run-02')
ENV={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'}
MASK=(1<<64)-1
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def linkage(binary):
    r=subprocess.run(['/usr/bin/ldd',str(binary)],env=ENV,capture_output=True,text=True,timeout=10)
    assert r.returncode==0 and not r.stderr
    files={}
    for line in r.stdout.splitlines():
        if 'linux-vdso' in line:continue
        paths=re.findall(r'(/[^\s()]+)',line)
        assert len(paths)==1,line
        p=Path(paths[0]);real=p.resolve(strict=True)
        files[str(p)]={'canonical':str(real),'sha256':sha(real)}
    assert any('libgmp.so' in p for p in files)
    return {'argv':['/usr/bin/ldd',str(binary)],'env':ENV,'returncode':r.returncode,'stdout':r.stdout,'files':files}

def same_linkage(a,b):
    # Raw loader addresses vary with ASLR; complete canonical file maps must agree.
    return all(a[side][key]==b[side][key] for side in ('old','new')
               for key in ('argv','env','returncode','files'))

def checksum(ws):
    ans=0
    for j,w in enumerate(ws):
        s=j%64;ans^=((w<<s)|(w>>((64-s)%64)))&MASK
    return ans

def write(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n')

def prepare(name,groups,orientation):
    out=ROOT/name;out.mkdir(exist_ok=False)
    inputs=json.loads((BUILD/'timing-inputs.json').read_text())
    binding=json.loads((BUILD/'binding.json').read_text())
    cells=[]
    for item in inputs['cells']:
        if item['group'] not in groups:continue
        c=dict(item)
        if c['count'] is None:
            # Fixed conservative source-recurrence scaling, before observations.
            c['count']=2**math.ceil(math.log2(512*(1024/c['n'])**1.5))
        fields=Path(c['input']).read_text().split()
        a=[int(w,16) for w in fields[2].split(',')]
        b=[int(w,16) for w in fields[3].split(',')]
        expected=[int(w,16) for w in Path(c['expected']).read_text().strip().split(',')]
        c['checksums']=[checksum(a),checksum(b),checksum(expected)]
        assert sha(c['input'])==c['input_sha256'] and sha(c['expected'])==c['expected_sha256']
        cells.append(c)
    assert cells
    binaries={side:{'path':str(BUILD/('runner-'+side)),'sha256':sha(BUILD/('runner-'+side))} for side in ('old','new')}
    links={s:linkage(b['path']) for s,b in binaries.items()}
    write(out/'linkage-before.json',links)
    plan={'kind':'actual_native_fixed_row_incremental_feature_acceptance','phase':name,'groups':groups,
          'native_source_commit':'d12759a022d2e285d0bc6b5869ccfb5c1d85f665','native_tree':'5790ad2fbadc9877332124c6a66ae3b70b016d03',
          'proof_scope':'strict complete library371/0, full-r05-toolbound; ordinary runner is unverified test infrastructure',
          'binding_path':str(BUILD/'binding.json'),'binding_sha256':sha(BUILD/'binding.json'),
          'timing_inputs_sha256':sha(BUILD/'timing-inputs.json'),'driver_sha256':sha(__file__),
          'wrapper_sha256':sha(ROOT/'run-window.ps1'),
          'watchdog_path':'/mnt/e/3sat/VeriGMP-root-fixed-leaves-prototype-20261109/resume-watchdog.ps1',
          'watchdog_sha256':sha('/mnt/e/3sat/VeriGMP-root-fixed-leaves-prototype-20261109/resume-watchdog.ps1'),
          'cpu':8,'env':ENV,'binaries':binaries,'cells':cells,'blocks':7,'sample_invocations':len(cells)*28,
          'order':'For each cell/block, alternate ABBA and BAAB by (cell+block+orientation)%2. Two observations per side per block.',
          'orientation':orientation,'minimum_batch_ns':10_000_000,'child_timeout_seconds':10,'launch_cutoff_seconds':110,'window_seconds':120,
          'count_rule':'Principal512/64 and leaf262144 inherited prospectively from registered prototype; all boundary counts fixed as next power of two >=512*(1024/n)^1.5, same count for both sides, no calibration or retry.',
          'go_principal_gm_new_over_old_max':0.97,'go_worst_new_over_old_max':1.03,
          'acceptance':'Require >=3% principal eight-cell GM improvement and <=3% worst-cell regression in every declared principal, leaf and boundary cell, all batches>=10ms. Require second independently scheduled run. No retrospective subset acceptance or GMP parity claim.',
          'linkage_before_sha256':sha(out/'linkage-before.json'),'retry':False}
    assert binding['candidate_source_commit']==plan['native_source_commit']
    assert binding['candidate_native_tree']==plan['native_tree']
    write(out/'plan.json',plan)
    print(json.dumps({'phase':name,'cells':len(cells),'samples':plan['sample_invocations'],'plan_sha256':sha(out/'plan.json')}))

def identity(plan):
    assert sha(__file__)==plan['driver_sha256']
    assert sha(ROOT/'run-window.ps1')==plan['wrapper_sha256']
    assert sha(plan['watchdog_path'])==plan['watchdog_sha256']
    assert sha(plan['binding_path'])==plan['binding_sha256']
    binding=json.loads(Path(plan['binding_path']).read_text())
    for b in plan['binaries'].values():assert sha(b['path'])==b['sha256']
    for pair in binding['pairs'].values():
        for item in pair.values():assert sha(item['path'])==item['sha256']
    for c in plan['cells']:
        assert sha(c['input'])==c['input_sha256'] and sha(c['expected'])==c['expected_sha256']
    return binding

def invoke(plan,side,c,count):
    argv=[plan['binaries'][side]['path'],'sample',c['input'],c['op'],str(count)]
    t=time.monotonic();r=subprocess.run(argv,env=ENV,capture_output=True,text=True,timeout=plan['child_timeout_seconds'])
    item={'side':side,'argv':argv,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'child_wall_seconds':time.monotonic()-t}
    assert r.returncode==0 and not r.stderr,item
    f=r.stdout.split();assert len(f)==7 and f[:3]==['sample',c['op'],str(count)],item
    assert list(map(int,f[4:]))==c['checksums'],item
    item['ns']=int(f[3]);assert item['ns']>0
    return item

def preflight(name):
    out=ROOT/name;plan=json.loads((out/'plan.json').read_text());identity(plan)
    rows=[]
    for i,c in enumerate(plan['cells']):
        for side in ('old','new'):
            row=invoke(plan,side,c,1);row['cell']=i;rows.append(row)
    write(out/'preflight.json',{'status':'pass','plan_sha256':sha(out/'plan.json'),'operations':len(rows),'rows':rows,'benchmark_samples':0})
    print(json.dumps({'status':'pass','operations':len(rows),'benchmark_samples':0}))

def run(name):
    out=ROOT/name;plan=json.loads((out/'plan.json').read_text());identity(plan)
    pre=json.loads((out/'preflight.json').read_text())
    assert pre['status']=='pass' and pre['plan_sha256']==sha(out/'plan.json')
    assert os.sched_getaffinity(0)=={8}
    assert sha(out/'linkage-before.json')==plan['linkage_before_sha256']
    before=json.loads((out/'linkage-before.json').read_text())
    observed={s:linkage(b['path']) for s,b in plan['binaries'].items()}
    assert same_linkage(before,observed)
    write(out/'linkage-window-start.json',observed)
    rows=[];start=time.monotonic()
    with (out/'raw.jsonl').open('x') as stream:
        for i,c in enumerate(plan['cells']):
            for block in range(plan['blocks']):
                order=['old','new','new','old'] if (i+block+plan['orientation'])%2==0 else ['new','old','old','new']
                for position,side in enumerate(order):
                    if time.monotonic()-start>=plan['launch_cutoff_seconds']:raise TimeoutError('launch cutoff')
                    row=invoke(plan,side,c,c['count']);row.update(cell=i,block=block,position=position)
                    rows.append(row);stream.write(json.dumps(row)+'\n');stream.flush()
    assert len(rows)==plan['sample_invocations']
    report={'status':'completed','phase':name,'plan_sha256':sha(out/'plan.json'),'wall_seconds':time.monotonic()-start,'observations':len(rows),
            'all_batches_usable':all(r['ns']>=plan['minimum_batch_ns'] for r in rows),'minimum_batch_ns':min(r['ns'] for r in rows),'cells':[]}
    for i,c in enumerate(plan['cells']):
        samples={s:[r['ns']/c['count'] for r in rows if r['cell']==i and r['side']==s] for s in ('old','new')}
        assert all(len(v)==14 for v in samples.values())
        med={s:statistics.median(v) for s,v in samples.items()}
        report['cells'].append({'group':c['group'],'n':c['n'],'pattern':c['pattern'],'op':c['op'],'count':c['count'],'median_ns_per_operation':med,'new_over_old':med['new']/med['old'],'samples':samples})
    ratios=[c['new_over_old'] for c in report['cells']]
    principal=[c['new_over_old'] for c in report['cells'] if c['group']=='principal']
    report['worst_new_over_old']=max(ratios)
    report['gm_new_over_old']=math.exp(statistics.mean(math.log(r) for r in ratios))
    report['principal_gm_new_over_old']=math.exp(statistics.mean(math.log(r) for r in principal)) if principal else None
    report['numerical_go']=report['all_batches_usable'] and max(ratios)<=plan['go_worst_new_over_old_max'] and (not principal or report['principal_gm_new_over_old']<=plan['go_principal_gm_new_over_old_max'])
    report['raw_sha256']=sha(out/'raw.jsonl');write(out/'report.json',report)
    print(json.dumps({k:v for k,v in report.items() if k!='cells'},indent=2))

def postflight(name):
    out=ROOT/name;plan=json.loads((out/'plan.json').read_text());binding=identity(plan)
    after={s:linkage(b['path']) for s,b in plan['binaries'].items()}
    assert sha(out/'linkage-before.json')==plan['linkage_before_sha256']
    before=json.loads((out/'linkage-before.json').read_text());assert same_linkage(after,before)
    write(out/'linkage-after.json',after)
    checks={}
    for p,h in binding['tools'].items():checks[p]=sha(p)==h
    assert all(checks.values())
    write(out/'postflight.json',{'status':'pass','plan_sha256':sha(out/'plan.json'),'driver_sha256':sha(__file__),'binaries_pairs_inputs_stable':True,'canonical_linkage_stable':True,'tool_hashes_unchanged':checks,'raw_sha256':sha(out/'raw.jsonl'),'report_sha256':sha(out/'report.json')})
    print(json.dumps({'status':'pass','tool_files':len(checks),'plan_sha256':sha(out/'plan.json')}))

if __name__=='__main__':
    command,name=sys.argv[1:3]
    if command=='prepare':prepare(name,sys.argv[3].split(','),int(sys.argv[4]))
    elif command=='preflight':preflight(name)
    elif command=='run':run(name)
    elif command=='postflight':postflight(name)
    else:raise ValueError(command)

param([Parameter(Mandatory=$true)][string]$Phase,[int]$QemuPid=11540)
$ErrorActionPreference='Stop'
if($Phase -notmatch '^native-(principal-leaves|boundaries)-run[12]$'){throw 'Unexpected phase'}
$root='E:\3sat\VeriGMP-root-fixed-row-native-20261109'
$out=Join-Path $root $Phase
$stop=Join-Path $out 'resume-watchdog.stop'
$ready=Join-Path $out 'resume-watchdog.ready'
if((Test-Path -LiteralPath $stop) -or (Test-Path -LiteralPath (Join-Path $out 'raw.jsonl'))){throw 'No automatic retry'}
$row=Get-CimInstance Win32_Process -Filter "ProcessId = $QemuPid"
if(!$row -or $row.Name -ne 'qemu-system-x86_64.exe' -or $row.CommandLine -notmatch '-avd opc_toolchain_api36'){throw 'Authorized emulator identity changed'}
$creation=([DateTimeOffset]$row.CreationDate).ToString('o')
$api=Add-Type -MemberDefinition '[DllImport("ntdll.dll")] public static extern int NtSuspendProcess(IntPtr h); [DllImport("ntdll.dll")] public static extern int NtResumeProcess(IntPtr h);' -Name Native -Namespace FixedRowWindow -PassThru
$qemu=[Diagnostics.Process]::GetProcessById($QemuPid)
$watchScript='E:\3sat\VeriGMP-root-fixed-leaves-prototype-20261109\resume-watchdog.ps1'
$watchArgs=@('-NoProfile','-File',$watchScript,'-QemuPid',$QemuPid,'-Creation',$creation,'-StopFile',$stop,'-Receipt',(Join-Path $out 'watchdog.json'),'-ReadyFile',$ready,'-Seconds','140')
$windowClock=[Diagnostics.Stopwatch]::StartNew()
$watch=Start-Process -FilePath powershell.exe -ArgumentList $watchArgs -WindowStyle Hidden -PassThru
$suspended=$false
$result=[ordered]@{phase=$Phase;qemu_pid=$QemuPid;qemu_creation=$creation;watchdog_pid=$watch.Id;watchdog_script_sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $watchScript).Hash.ToLowerInvariant();started_utc=[DateTimeOffset]::UtcNow.ToString('o');outer_timeout_seconds=120;independent_watchdog_seconds=140}
try{
 $deadline=[DateTimeOffset]::UtcNow.AddSeconds(10)
 while(!(Test-Path -LiteralPath $ready) -and [DateTimeOffset]::UtcNow -lt $deadline -and !$watch.HasExited){Start-Sleep -Milliseconds 100}
 if(!(Test-Path -LiteralPath $ready) -or $watch.HasExited){throw 'Watchdog did not acknowledge ready'}
 $result.suspend_status=$api::NtSuspendProcess($qemu.Handle)
 if($result.suspend_status -ne 0){throw 'Suspend failed'}
 $suspended=$true
 $result.cpu_samples_before=@((Get-Counter '\Processor(_Total)\% Processor Time' -SampleInterval 1 -MaxSamples 3).CounterSamples | ForEach-Object {$_.CookedValue})
 $result.host_cpu=(Get-CimInstance Win32_Processor | Select-Object -First 1).Name
 [IO.File]::WriteAllText((Join-Path $out 'host-before.json'),($result | ConvertTo-Json -Depth 6))
 & wsl.exe -d Ubuntu -- taskset -c 8 /usr/bin/timeout --signal=TERM --kill-after=1s 120s python3 /mnt/e/3sat/VeriGMP-root-fixed-row-native-20261109/measure.py run $Phase
 $result.screen_exit=$LASTEXITCODE
}catch{$result.error=($_ | Out-String);throw}
finally{
 if($suspended){$result.resume_status=$api::NtResumeProcess($qemu.Handle);if($result.resume_status -eq 0){[IO.File]::WriteAllText($stop,'resumed by root finally')}}
 else{[IO.File]::WriteAllText($stop,'no suspension occurred')}
 $result.finished_utc=[DateTimeOffset]::UtcNow.ToString('o')
 $qemu.Refresh();$result.qemu_alive=-not $qemu.HasExited
 if($result.qemu_alive){
  $cpu0=$qemu.TotalProcessorTime.TotalMilliseconds
  for($attempt=0;$attempt -lt 4;$attempt++){
   Start-Sleep -Milliseconds 300;$qemu.Refresh()
   $result.qemu_cpu_advance_ms=$qemu.TotalProcessorTime.TotalMilliseconds-$cpu0
   if($result.qemu_cpu_advance_ms -gt 0){break}
  }
 }
 $result.window_wall_seconds=$windowClock.Elapsed.TotalSeconds
 $result.watchdog_fired=Test-Path -LiteralPath (Join-Path $out 'watchdog.json')
 $result.within_watchdog_deadline=$result.window_wall_seconds -lt 140
 [IO.File]::WriteAllText((Join-Path $out 'window.json'),($result | ConvertTo-Json -Depth 6))
}
if($result.screen_exit -ne 0){throw ('Measurement child failed '+$result.screen_exit)}
if($result.resume_status -ne 0 -or !$result.qemu_alive){throw 'Resume not confirmed; watchdog remains armed'}
if($result.watchdog_fired -or !$result.within_watchdog_deadline){throw 'Watchdog intervention or expired outer deadline invalidates measurements'}
if($result.qemu_cpu_advance_ms -le 0){throw 'Positive emulator CPU motion not observed; window remains unaccepted'}

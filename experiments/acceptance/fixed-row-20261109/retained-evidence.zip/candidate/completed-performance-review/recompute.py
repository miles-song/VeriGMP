"""Independent saved-data audit only; never invokes measured binaries or tools."""
import hashlib,json,math,statistics,datetime
from pathlib import Path
ROOT=Path(r'E:\3sat\VeriGMP-root-fixed-row-native-20261109')
OUT=ROOT/'completed-performance-review'
NAMES=['native-principal-leaves-run1','native-boundaries-run1','native-principal-leaves-run2','native-boundaries-run2']
FAILURES=[]
def ck(ok,msg):
    if not ok: FAILURES.append(msg)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''): h.update(chunk)
    return h.hexdigest()
def load(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def close(a,b): return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12)
def when(s): return datetime.datetime.fromisoformat(s.strip())
def local(path):
    if path.startswith('/mnt/'): return Path(path[5].upper()+':/'+path[7:])
    raise ValueError('Only mapped saved files: '+path)
prescreen=load(ROOT/'measurement-prescreen-review/review.json')
binding_path=Path(r'E:\3sat\VeriGMP-fixed-row-local-gates-20261109\run-02\binding.json')
binding=load(binding_path)
data=[]
for name in NAMES:
    phase=ROOT/name
    names=['plan.json','preflight.json','raw.jsonl','report.json','postflight.json','window.json','host-before.json','linkage-before.json','linkage-window-start.json','linkage-after.json','resume-watchdog.ready','resume-watchdog.stop']
    files={f:{'sha256':sha(phase/f),'bytes':(phase/f).stat().st_size} for f in names}
    p,r,post,w,host=[load(phase/f) for f in ['plan.json','report.json','postflight.json','window.json','host-before.json']]
    rows=[json.loads(s) for s in (phase/'raw.jsonl').read_text().splitlines()]
    prefix=name+': '
    original=next(x for x in prescreen['inputs']['phases'] if x['name']==name)
    ck(files['plan.json']['sha256']==original['plan_sha256'],prefix+'immutable plan')
    ck(files['preflight.json']['sha256']==original['preflight_sha256'],prefix+'immutable preflight')
    ck(p['binding_sha256']==sha(binding_path),prefix+'binding hash')
    ck(p['driver_sha256']==prescreen['inputs']['driver']['sha256'] and p['wrapper_sha256']==prescreen['inputs']['wrapper']['sha256'] and p['watchdog_sha256']==prescreen['inputs']['watchdog']['sha256'],prefix+'frozen controls')
    ck(len(rows)==p['sample_invocations']==len(p['cells'])*28==r['observations'],prefix+'sample count')
    for j,row in enumerate(rows):
        i,block,position=j//28,(j%28)//4,j%4
        c=p['cells'][i]
        order=['old','new','new','old'] if (i+block+p['orientation'])%2==0 else ['new','old','old','new']
        side=order[position]
        ck((row['cell'],row['block'],row['position'],row['side'])==(i,block,position,side),prefix+'order '+str(j))
        ck(row['argv']==[p['binaries'][side]['path'],'sample',c['input'],c['op'],str(c['count'])],prefix+'argv '+str(j))
        ck(row['returncode']==0 and row['stderr']=='',prefix+'child status '+str(j))
        parts=row['stdout'].split()
        ck(len(parts)==7 and parts[:3]==['sample',c['op'],str(c['count'])],prefix+'stdout format '+str(j))
        ck([int(x) for x in parts[4:]]==c['checksums'],prefix+'exact unsigned checksum '+str(j))
        ck(int(parts[3])==row['ns'] and isinstance(row['ns'],int) and row['ns']>=p['minimum_batch_ns'],prefix+'sample time '+str(j))
        ck(0<row['child_wall_seconds']<10 and row['ns']/1e9<=row['child_wall_seconds'],prefix+'child wall '+str(j))
    cells=[]
    for i,c in enumerate(p['cells']):
        perarm={s:[row['ns']/c['count'] for row in rows if row['cell']==i and row['side']==s] for s in ['old','new']}
        ck(all(len(v)==14 for v in perarm.values()),prefix+'per-arm count '+str(i))
        med={s:statistics.median(v) for s,v in perarm.items()}
        ratio=med['new']/med['old']
        stored=r['cells'][i]
        ck(all(stored[k]==c[k] for k in ['group','n','pattern','op','count']),prefix+'reported cell identity '+str(i))
        ck(all(close(med[s],stored['median_ns_per_operation'][s]) for s in med) and close(ratio,stored['new_over_old']),prefix+'reported medians and ratio '+str(i))
        ck(all(perarm[s]==stored['samples'][s] for s in perarm),prefix+'reported sample projection '+str(i))
        ck(ratio<=p['go_worst_new_over_old_max'],prefix+'cell regression gate '+str(i))
        cells.append({'cell':i,**{k:c[k] for k in ['group','n','pattern','op','count']},'observations_per_arm':14,'old_median_ns':med['old'],'new_median_ns':med['new'],'new_over_old':ratio,'change_percent':100*(ratio-1),'pass':ratio<=p['go_worst_new_over_old_max']})
    principal=[c['new_over_old'] for c in cells if c['group']=='principal']
    pgm=math.exp(statistics.mean(map(math.log,principal))) if principal else None
    gm=math.exp(statistics.mean(math.log(c['new_over_old']) for c in cells))
    worst=max(cells,key=lambda c:c['new_over_old'])
    minimum=min(row['ns'] for row in rows)
    sumwall=sum(row['child_wall_seconds'] for row in rows)
    ck(close(gm,r['gm_new_over_old']) and close(worst['new_over_old'],r['worst_new_over_old']) and (pgm is None and r['principal_gm_new_over_old'] is None or pgm is not None and close(pgm,r['principal_gm_new_over_old'])),prefix+'aggregate statistics')
    ck(pgm is None or pgm<=p['go_principal_gm_new_over_old_max'],prefix+'principal gate')
    ck(r['status']=='completed' and r['phase']==name and r['numerical_go'] is True and r['all_batches_usable'] is True and minimum==r['minimum_batch_ns'],prefix+'completion flags')
    ck(sumwall<=r['wall_seconds']<110,prefix+'all calls complete before sampling cutoff')
    ck(files['raw.jsonl']['sha256']==r['raw_sha256']==post['raw_sha256'],prefix+'raw hash chain')
    ck(files['report.json']['sha256']==post['report_sha256'],prefix+'report hash chain')
    ck(post['status']=='pass' and post['plan_sha256']==files['plan.json']['sha256']==r['plan_sha256'] and post['driver_sha256']==p['driver_sha256'],prefix+'postflight binding')
    ck(post['binaries_pairs_inputs_stable'] is True and post['canonical_linkage_stable'] is True,prefix+'postflight stability')
    ck(set(post['tool_hashes_unchanged'])==set(binding['tools']) and all(v is True for v in post['tool_hashes_unchanged'].values()),prefix+'all bound tools included')
    ck(w['phase']==name and w['qemu_pid']==11540 and w['suspend_status']==w['screen_exit']==w['resume_status']==0 and w['qemu_alive'] is True and w['qemu_cpu_advance_ms']>0 and w['watchdog_fired'] is False and w['within_watchdog_deadline'] is True and w['window_wall_seconds']<140,prefix+'window outcome')
    ck(w['watchdog_script_sha256']==p['watchdog_sha256'],prefix+'watchdog identity')
    ck(not (phase/'watchdog.json').exists() and (phase/'resume-watchdog.stop').read_text()=='resumed by root finally',prefix+'normal watchdog stop')
    ready=(phase/'resume-watchdog.ready').read_text()
    elapsed=(when(w['finished_utc'])-when(w['started_utc'])).total_seconds()
    ck(when(w['started_utc'])<when(ready)<when(w['finished_utc']) and elapsed<=w['window_wall_seconds']<elapsed+2,prefix+'timestamps')
    ck(all(w[k]==v for k,v in host.items()),prefix+'host-before projection')
    captures={cap:load(phase/cap) for cap in ['linkage-before.json','linkage-window-start.json','linkage-after.json']}
    ck(files['linkage-before.json']['sha256']==p['linkage_before_sha256'],prefix+'before linkage hash')
    import re
    for cap,v in captures.items():
        for side in ['old','new']:
            x=v[side]
            ck(x['argv']==['/usr/bin/ldd',p['binaries'][side]['path']] and x['env']==p['env'] and x['returncode']==0,prefix+cap+' command '+side)
            ck(x['files']==captures['linkage-before.json'][side]['files'],prefix+cap+' canonical map '+side)
            lines=[s for s in x['stdout'].splitlines() if s.strip() and 'linux-vdso' not in s]
            paths=[s for line in lines for s in re.findall(r'(/[^\s()]+)',line)]
            ck(len(paths)==len(x['files']) and set(paths)==set(x['files']),prefix+cap+' raw path coverage '+side)
            ck({entry['canonical']:entry['sha256'] for entry in x['files'].values()}==binding['linked_libraries'],prefix+cap+' exact bound library map '+side)
    data.append({'phase':name,'plan':p,'files':files,'observations':len(rows),'cells_count':len(cells),'principal_gm':pgm,'principal_time_reduction_percent':None if pgm is None else 100*(1-pgm),'all_cell_gm':gm,'worst_cell':worst,'minimum_batch_ns':minimum,'driver_wall_seconds':r['wall_seconds'],'sum_child_wall_seconds':sumwall,'max_child_wall_seconds':max(row['child_wall_seconds'] for row in rows),'sum_timed_seconds':sum(row['ns'] for row in rows)/1e9,'window':w,'postflight_tool_count':len(post['tool_hashes_unchanged']),'cells':cells})
for i in range(1,len(data)):
    ck(when(data[i-1]['window']['finished_utc'])<when(data[i]['window']['started_utc']),'sequential restored windows '+str(i))
    ck(data[i-1]['window']['qemu_creation']==data[i]['window']['qemu_creation'],'same emulator identity '+str(i))
for a,b in [(0,2),(1,3)]:
    pa,pb=data[a]['plan'],data[b]['plan']
    ck(pa['cells']==pb['cells'] and pa['binaries']==pb['binaries'] and pa['orientation']==0 and pb['orientation']==1,'same cells opposite orientation '+str(a))
# Recheck the executable pair and timing controls after root's explicit quiet release.
identity_checks={}
for label,item in [('driver',prescreen['inputs']['driver']),('wrapper',prescreen['inputs']['wrapper']),('watchdog',prescreen['inputs']['watchdog'])]:
    identity_checks[label]={'sha256':sha(item['path']),'expected':item['sha256']}
for side,item in data[0]['plan']['binaries'].items():
    identity_checks['runner_'+side]={'sha256':sha(local(item['path'])),'expected':item['sha256']}
for side,pair in binding['pairs'].items():
    for key,item in pair.items():
        identity_checks[side+'_'+key]={'sha256':sha(local(item['path'])),'expected':item['sha256']}
for k,v in identity_checks.items():ck(v['sha256']==v['expected'],'current content identity '+k)
# The retained full-r05 tool inventories, not a new compiler or proof run.
tb=load(ROOT/'full-r05-toolbound/tools-before.json')
ta=load(ROOT/'full-r05-toolbound/tools-after.json')
ck(tb==ta,'retained r05 before/after tool inventory equality')
receipt=load(ROOT/'full-r05-toolbound/receipt.json')
audit={'schema_version':1,'review_type':'independent completed actual-native fixed-row performance evidence review','reviewer_role':'independent leaf, no delegation','decision':'ACCEPT_COMPLETED_DECLARED_PERFORMANCE_EVIDENCE' if not FAILURES else 'REQUEST_CHANGES','failures':FAILURES,'new_execution':'Saved-data parsing, integer checksum comparison, statistical recomputation, and content hashing only. No measured binary, proof, build, oracle, benchmark or process/emulator control was executed.','source_binding':{k:binding[k] for k in ['candidate_source_commit','candidate_native_tree','baseline_native_tree','candidate_receipt_sha256','baseline_summary_sha256']},'prescreen_review_sha256':sha(ROOT/'measurement-prescreen-review/review.json'),'binding_sha256':sha(binding_path),'current_content_identity_checks':identity_checks,'retained_r05_tools_before_sha256':sha(ROOT/'full-r05-toolbound/tools-before.json'),'retained_r05_tools_after_sha256':sha(ROOT/'full-r05-toolbound/tools-after.json'),'retained_r05_receipt_sha256':sha(ROOT/'full-r05-toolbound/receipt.json'),'observations_total':sum(x['observations'] for x in data),'cell_run_total':sum(x['cells_count'] for x in data),'all_four_phases_complete':all(x['observations']==x['plan']['sample_invocations'] for x in data),'phases':[{k:v for k,v in x.items() if k!='plan'} for x in data]}
OUT.mkdir(exist_ok=True)
(OUT/'recalculation.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'decision':audit['decision'],'failures':FAILURES,'observations_total':audit['observations_total'],'phases':[{k:v for k,v in x.items() if k not in ['cells','files','window','plan']} for x in data]},indent=2))

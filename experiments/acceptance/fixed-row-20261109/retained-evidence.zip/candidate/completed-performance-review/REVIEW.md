**ACCEPT_COMPLETED_DECLARED_PERFORMANCE_EVIDENCE.** Independent recomputation found no discrepancy or remaining performance-evidence blocker for the exact frozen native fixed-row candidate and the predeclared workloads. Both separately scheduled confirmations pass all prospective gates. Final feature acceptance still requires root to combine the separate functional/proof evidence with the exact final source.

The review checked all **3,472 raw observations**, covering **124 cell/run results**. Every row has the required cell/block/position/side, exact recorded argument vector and count, successful return status, empty stderr, correctly formed output, exact unsigned 64-bit checksums and a usable elapsed time. Each arm has fourteen observations per cell. The seven ABBA/BAAB blocks and reversed second-run orientation match the frozen plans; no observation or cell was omitted.

| Phase | Observations | Principal GM new/old | Worst declared cell new/old | Minimum batch | Full window |
| --- | ---: | ---: | ---: | ---: | ---: |
| native-principal-leaves-run1 | 728 | 0.9256327471 | 1.0291525071 | 35.754047 ms | 80.968121 s |
| native-boundaries-run1 | 1008 | n/a | 1.0204333437 | 27.659370 ms | 105.224244 s |
| native-principal-leaves-run2 | 728 | 0.9177123141 | 1.0190359299 | 36.892222 ms | 72.296830 s |
| native-boundaries-run2 | 1008 | n/a | 1.0274416755 | 30.084902 ms | 103.670047 s |

The two principal geometric means correspond to **7.4367% and 8.2288% lower time**, exceeding the predeclared 3% requirement. Every declared principal, selected/neighbor leaf and boundary cell meets the 1.03 regression limit in each run. The overall maximum is **1.0291525071**, the run-1 forced leaf at n=24 with the max pattern. The minimum of all batches is **27.659370 ms**, above the 10 ms requirement. These are raw-data recomputations of per-arm medians and geometric means, and exactly reproduce the recorded summaries.

The principal results are:

| n | Pattern | Operation | Run 1 new/old | Run 2 new/old |
| ---: | --- | --- | ---: | ---: |
| 1024 | random | mul | 0.8359581801 | 0.8507172124 |
| 1024 | random | square | 0.9964253653 | 0.9763676220 |
| 1024 | max | mul | 0.8119189722 | 0.8516196040 |
| 1024 | max | square | 1.0065173020 | 0.9777143424 |
| 4096 | random | mul | 0.8958586510 | 0.8784397499 |
| 4096 | random | square | 1.0140824558 | 0.9780656882 |
| 4096 | max | mul | 0.8749577240 | 0.8761151760 |
| 4096 | max | square | 0.9959707732 | 0.9663958185 |

All four Windows intervals are sequential and nonoverlapping, with normal root-finally stop markers. Every window records suspend status 0, child exit 0, resume status 0, a live emulator, positive CPU advancement, and no watchdog intervention or watchdog receipt. Recorded CPU advancement is 906.25, 640.625, 640.625 and 703.125 ms respectively. Full windows range from 72.296830 to 105.224245 seconds; every sample phase finishes before its 110-second launch cutoff. The largest recorded individual child wall time is 0.307908 seconds. The four successful postflights bind the exact plan, raw and report hashes.

The reviewed performance source remains candidate commit d12759a022d2e285d0bc6b5869ccfb5c1d85f665, native tree 5790ad2fbadc9877332124c6a66ae3b70b016d03, against baseline native tree 72dc8a5da2cbb7eddcdd26c219d50770e8b73b06. After quiet-window release, I rehashed both measured binaries, both native rlib/Verus-metadata pairs, and the driver/wrapper/watchdog. All match the frozen identities. The retained full-r05 receipt hash matches the measured binding and identifies the same candidate source/tree.

All before/start/after linkage captures retain the raw ldd text and agree on command, clean environment, return status, complete raw-path coverage and canonical file paths/content hashes. Each of the four postflights covers exactly the 111 bound tool paths with successful results. The retained full-r05 tool inventories agree before/after and equal the measured binding. This review did not rehash all large tool files or run ldd; those historical postflight observations remain collector evidence. File identities and saved receipts do not constitute OS exec attestation or continuous filesystem monitoring.

Both binaries use the same saved runner and ordinary source with matching input, output, allocation and scratch semantics. The candidate compile additionally enables --cfg has_fixed_row for an unmeasured direct branch, so complete compiler argument lists are not literally identical. CPU 8 is enforced by the frozen driver; host records identify AMD Ryzen 7 7745HX. GMP is used for expected output outside the timer. The measured comparison is candidate VeriGMP versus prior VeriGMP, and establishes no whole-library GMP parity or backend-replacement acceptance.

The accompanying JSON retains all 124 cell/run statistics, complete input-artifact hashes, current executable-pair checks, window records and scope qualifications. The independent recompute.py reads saved evidence and computes statistics only; it invokes no measured executable. Root must still combine this result with separate correctness, oracle, alias/capacity, mutation, code-generation, 371/0 proof and exact-final-source acceptance. No source/ref changes, merge, publication, proof, build, oracle, benchmark, process/emulator action or delegation was performed by this reviewer.

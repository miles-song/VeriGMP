import hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path, PureWindowsPath
root=Path('/mnt/c/Users/23247/.codex/worktrees/gmp-fixed-row-refined-20261109/VeriGMP-scaled-experiments')
out=Path('/mnt/e/3sat/VeriGMP-root-fixed-row-native-20261109')/sys.argv[1]
out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):
    win=PureWindowsPath((root/'.git').read_text().removeprefix('gitdir:').strip())
    gd='/mnt/'+win.drive[0].lower()+'/'+ '/'.join(win.parts[1:])
    return subprocess.check_output(['git','--git-dir',gd,'--work-tree',str(root),*args],text=True).strip()
if git('status','--porcelain'):raise RuntimeError('dirty source')
snap=out/'snapshot';shutil.copytree(root/'native',snap/'native')
before={str(p.relative_to(snap)):sha(p) for p in sorted(snap.rglob('*')) if p.is_file()}
vdir=Path('/mnt/e/3sat/VeriCount/deps/verus/verus-x86-linux')
env={'HOME':os.environ['HOME'],'PATH':str(vdir)+':/mnt/e/3sat/VeriCount/deps/cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
     'RUSTUP_HOME':'/mnt/e/3sat/VeriCount/deps/rustup','CARGO_HOME':'/mnt/e/3sat/VeriCount/deps/cargo',
     'RUSTUP_TOOLCHAIN':'1.99.1-x86_64-unknown-linux-gnu','LC_ALL':'C','TZ':'UTC'}
def tool_resolution():
    cmds=[['rustup','which','rustc'],['rustc','-vV'],['rustc','--print','sysroot'],[str(vdir/'verus'),'--version']]
    result=[]
    for cmd in cmds:
        r=subprocess.run(cmd,cwd=snap,env=env,text=True,capture_output=True,timeout=15,check=True)
        result.append({'argv':cmd,'stdout':r.stdout,'stderr':r.stderr})
    expected='/mnt/e/3sat/VeriCount/deps/rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu/bin/rustc'
    if result[0]['stdout'].strip()!=expected:raise RuntimeError('resolved compiler differs')
    return result
resolution_before=tool_resolution()
tool_paths=set(str(p) for p in sorted(vdir.iterdir()) if p.is_file())
tool_paths.update(json.loads(Path('/mnt/e/3sat/VeriGMP-cross-fusion-baseline-fresh-20261109/tools-before.json').read_text()))
tools={p:sha(Path(p)) for p in sorted(tool_paths)}
(out/'environment.json').write_text(json.dumps(env,indent=2)+'\n')
(out/'tools-before.json').write_text(json.dumps(tools,indent=2)+'\n')
cmd=['taskset','-c','10',str(vdir/'verus'),str(snap/'native/lib.rs'),'--crate-name','verigmp','--crate-type','lib','--num-threads','1','--rlimit','10','--no-cheating']
if '--full' not in sys.argv:cmd+=['--verify-module','fixed_row']
cmd+=['--compile','-O','--export',str(out/'verigmp.vir'),'-o',str(out/'libverigmp.rlib')]
t=time.monotonic()
try:
    r=subprocess.run(cmd,cwd=snap,env=env,capture_output=True,text=True,timeout=180 if '--full' in sys.argv else 90)
    log=r.stdout+r.stderr;code=r.returncode
except subprocess.TimeoutExpired as e:
    log=(e.stdout or b'').decode()+(e.stderr or b'').decode();code='timeout'
wall=time.monotonic()-t
(out/'proof.log').write_text(log)
unchanged=all(sha(snap/p)==h and sha(root/p)==h for p,h in before.items())
toolstable=all(sha(Path(p))==h for p,h in tools.items())
resolution_after=tool_resolution()
(out/'tools-after.json').write_text(json.dumps({p:sha(Path(p)) for p in sorted(tool_paths)},indent=2)+'\n')
report={'source_commit':git('rev-parse','HEAD'),'native_tree':git('rev-parse','HEAD:native'),'argv':cmd,'returncode':code,'wall_seconds':wall,'source_hashes':before,'tool_hashes':tools,'environment':env,'tool_resolution_before':resolution_before,'tool_resolution_after':resolution_after,'resolution_unchanged':resolution_before==resolution_after,'collector_sha256':sha(Path(__file__)),'sources_unchanged':unchanged,'tools_unchanged':toolstable,'verification_summary':re.findall(r'verification results::.*',log),'scope':'full-library' if '--full' in sys.argv else 'fixed_row-only; other native bodies unchecked in this run','artifacts':{p.name:sha(p) for p in [out/'libverigmp.rlib',out/'verigmp.vir'] if p.is_file()}}
(out/'receipt.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('source_hashes','tool_hashes')},indent=2))
if code!=0:print(log[-10000:])
raise SystemExit(0 if code==0 and unchanged and toolstable else 1)

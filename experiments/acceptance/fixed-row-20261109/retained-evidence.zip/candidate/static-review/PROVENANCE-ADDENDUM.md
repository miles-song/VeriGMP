RUST_TOOLCHAIN_PROVENANCE_GAP_CLOSED_FOR_FULL_R05. The narrow provenance repair passes all **24 grouped checks**. The original full-r04 receipt and static review are unchanged; their historical limitation remains accurate.

The new strict full-library run verifies **371 items, 0 errors** with --no-cheating, no module/function filter, optimized compilation and paired export. Its 58 source files match immutable commit `d12759a022d2e285d0bc6b5869ccfb5c1d85f665`, native tree `5790ad2fbadc9877332124c6a66ae3b70b016d03`, the original source manifest and the clean worktree.

The inspected collector uses the same explicit seven-key environment for the resolution probes and proof/compile child. It records HOME, PATH, RUSTUP_HOME, CARGO_HOME, RUSTUP_TOOLCHAIN=1.99.1-x86_64-unknown-linux-gnu, LC_ALL=C and TZ=UTC. Before/after rustup compiler resolution, rustc -vV, sysroot and Verus version outputs match. All **111 unique tool files** match before, after and the independent review hash pass: 65 baseline/compiler/sysroot paths plus 54 Verus paths, with eight overlaps.

This is retained collector evidence, **not OS-level execution attestation**, process tracing, continuous filesystem monitoring or an exhaustive inventory of every dynamically loaded file. It closes the specific missing compiler/sysroot/environment binding at the receipt level without claiming a hermetic OS or removing the explicit tool trust boundary.

The new artifact pair is:

- rlib: `2d533b2038d572b6ab7d79295dec53143f7b7a5cde654ca5763f3695c6aec7c8`
- Verus metadata: `a53e2cfa19826103656eafcb0ff97bf0d4928e6fd3ffcc90f5eba5511d708d18`
- Full-r05 receipt: `17e33e5e751364715de148216d5d34aeab7e21ae01d1cfc629cf7eb7426b6fc0`
- Collector: `35fe5257d3a510760e78bb7184fa3ad46a1cc4d1366ab2660d8a8bf436d1394e`
- Before/after tool manifests: `061cd34a2db94967df42f2ff96f1ca345ea8f4687b655d0c7cbeefe533bf90f7`

The byte-distinct r05 pair does not inherit relabeled r04 oracle, imported-client, code-generation or timing receipts. Final runners and gates must bind to the selected pair. Runtime/performance acceptance and merge approval remain pending.

Requested reviewer profile: Astra Max; actual model and reasoning runtime identity remain **UNVERIFIED**. Review performed as a leaf without delegation, proof/build/oracle/timing execution, process control or source/ref changes.

import hashlib,json
from pathlib import Path

base=Path('/mnt/e/3sat/VeriGMP-fixed-row-local-gates-20261109')
source=Path('/mnt/c/Users/23247/.codex/worktrees/gmp-fixed-row-gates-20261109/VeriGMP-scaled-experiments/experiments/fixed-row-20261109')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
old=base/'run-01';new=base/'run-02'
binding=read(new/'binding.json')
assert binding['candidate_native_tree']=='5790ad2fbadc9877332124c6a66ae3b70b016d03'
runtime=read(old/'runtime.json');recheck=read(new/'recheck.json');consumer=read(new/'consumer.json');cg=read(new/'codegen-review.json')
assert all(r['status']=='pass' for r in [runtime,recheck,consumer,cg])
for label in ('old','new'):
    for artifact in ('libverigmp.rlib','verigmp.vir'):
        item=binding['pairs'][label][artifact];assert sha(item['path'])==item['sha256']
for name,digest in binding['tools'].items():assert sha(name)==digest
for name in ('runner.rs','ordinary.rs','codegen.rs','consumer.rs'):
    assert sha(source/name)==sha(new/'source'/name)
for p in cg['artifacts']:
    assert sha(new/p)==cg['artifacts'][p]
mutants=read(old/'proof-gates.json')['mutations']
accepted=[m for m in mutants if m['status']=='typed_failed_vc']
unaccepted=[m for m in mutants if m['status']!='typed_failed_vc']
assert len(accepted)==4 and len(unaccepted)==1
children=[r for root in (old,new) for r in read(root/'children.json')]
paths=[old/'binding.json',old/'runtime.json',old/'proof-gates.json',old/'children.json',
       new/'binding.json',new/'timing-inputs.json',new/'recheck.json',new/'consumer.json',new/'children.json',
       new/'codegen-artifacts.json',new/'codegen-review.json',new/'inspect-identity.json']
paths += sorted((old/'mutations').glob('*/mutation.json'))
paths += [source/name for name in ('runner.rs','ordinary.rs','consumer.rs','codegen.rs','oracle.py','gates.py','inspect_codegen.py','README.md')]
report=dict(schema='verigmp-fixed-row-focused-local-gates-v1',status='completed_scoped_local_gates',
    arithmetic_source_commit=binding['candidate_source_commit'],native_tree=binding['candidate_native_tree'],
    baseline_native_tree=binding['baseline_native_tree'],pairs=binding['pairs'],
    full_library_proof=dict(scope='coordinator-produced strict full-library proof, optimized compile and paired export',verified=371,errors=0,
        receipt='/mnt/e/3sat/VeriGMP-root-fixed-row-native-20261109/full-r05-toolbound/receipt.json',receipt_sha256=binding['candidate_receipt_sha256']),
    runtime=dict(baseline_integer_cases=4885,candidate_integer_cases=4905,lengths=51,patterns=5,top_values=[1,32,63,64],
        invalid_native_assertions=18,workspace_boundaries=5,original_pair='r04',final_pair='r05-toolbound',
        final_pair_recheck='all frozen Python-validated input/output bytes re-executed exactly; same source bytes',
        frames='dirty output, unchanged inputs, exact borrowed scratch length, outer guards and seven unborrowed suffix words'),
    imported_consumer=dict(verified=4,errors=0,executed=True,pair='r05-toolbound',borrow_negative_errors=['E0502','E0499']),
    mutations=dict(typed_failed_vc=[m['name'] for m in accepted],not_accepted=[dict(name=m['name'],reason='failed postcondition plus resource-limit diagnostic; not accepted detection') for m in unaccepted],
        actual_scope='fixed_row-module VCs over complete actual native snapshot copies; no full-library mutation verification claim',
        original_five_attempt_group_passed=False),
    codegen=dict(status='pass',wrapper_pairs=4,positive_path_instruction_counts=[282,380,416,432],
        ordinary_same_algorithm_positive_instructions_equal=True,actual_native_dispatch=[15,20,22,23],actual_native_call_closure_functions=16,
        selected_leaf_static_multiplies=[30,40,44,46],selected_leaf_calls=0,selected_leaf_divisions=0,
        scope='actual wrapper assembly and linked native dispatch/call closure; cold panic and unrelated runner/std/GMP code excluded',
        inspector_attempts=2,first_attempt='retained parser failure on final-block fallthrough; fixed inspector only'),
    bounded_children=dict(cpu=8,verus_threads=1,rlimit=10,no_cheating=True,maximum_child_timeout_seconds=60,
        aggregate_child_wall_seconds=sum(r['wall_seconds'] for r in children),aggregate_budget_seconds=480),
    benchmark_samples_by_this_leaf=0,performance_scope='coordinator owns independent frozen timing reports; this receipt supplies binaries/input protocol only',
    qualifications=['Invalid-domain calls are observed native assertion tests, not proofs of behavior outside contracts.',
        'Original r04 runtime/mutation identities remain original; final r05 runtime replay and imported consumer are separately bound.',
        'Four valid semantic VC rejections and one unaccepted dispatch/resource-limit attempt are reported individually.',
        'No checked resource/cost theorem, universal GMP parity, consuming-solver backend acceptance or independent Astra review follows from this receipt.'],
    evidence={str(p):sha(p) for p in paths},seal_script_sha256=sha(__file__))
target=base/'receipt.json';assert not target.exists();target.write_text(json.dumps(report,indent=2)+'\n')
small=dict(schema=report['schema'],receipt_path=str(target),receipt_sha256=sha(target),arithmetic_source_commit=report['arithmetic_source_commit'],
    native_tree=report['native_tree'],baseline_native_tree=report['baseline_native_tree'],runtime_cases=dict(old=4885,new=4905),
    imported_consumer='4 verified / 0 errors; executed',semantic_mutants='4 typed VC failures; extra dispatch/resource-limit attempt not accepted',
    codegen='4 equal positive-path controls; actual selected native leaves 15/20/22/23; 16 native function closure',
    bounded_child_wall_seconds=report['bounded_children']['aggregate_child_wall_seconds'],benchmark_samples_by_this_leaf=0,
    qualifications=report['qualifications'])
(source/'local-gates.json').write_text(json.dumps(small,indent=2)+'\n')
print(json.dumps(small,indent=2))

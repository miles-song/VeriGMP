"""Run only the unchanged offline raw/build validators, never a measurement."""
from pathlib import Path
import hashlib
import json
import sys
OUT=Path(__file__).resolve().parent
GATE=Path('/mnt/c/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108/gates-3a83671-01')
DATA=Path('/mnt/e/3sat/VeriGMP-fused-measurement-window-20261109-02/measurement-F1-02')
VALIDATOR=GATE/'source/experiments/fused-interpolation-20261108/raw_validate.py'
assert hashlib.sha256(VALIDATOR.read_bytes()).hexdigest()=='90f564d57098ac703b73635f47981c334b6c32ff9b0c98c17540991838c14e59'
sys.dont_write_bytecode=True
sys.path.insert(0,str(VALIDATOR.parent))
import raw_validate
DIGEST='bac446bdf52f2a9ce6babb653019427d3f65ec36c90de68b5a8459ae945a62c4'
build,identity=raw_validate.validate_build((GATE/'build-identity-01/bench-build.json').read_bytes(),DIGEST)
runs=[]
for n in (1,2):
    folder=DATA/f'fused-run-{n}'
    report=raw_validate.strict_json((folder/'measurement.json').read_bytes())
    _,receipt=raw_validate.validate_report(report,(folder/'raw.jsonl').read_bytes(),build,DIGEST)
    runs.append(dict(run=n,run_id=report['run_id'],**receipt))
result=dict(status='pass',validator_unmodified=True,validator_stubbed=False,
            build_sha256=DIGEST,identity_sha256=build['identity_receipt']['sha256'],runs=runs,
            benchmark_executed=False,calibration_executed=False,compiler_executed=False,verifier_executed=False)
(OUT/'frozen-protocol-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

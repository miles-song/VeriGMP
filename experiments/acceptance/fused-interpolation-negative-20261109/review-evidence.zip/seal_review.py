"""Seal the independent negative-performance evidence, without executing measured code."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile
OUT=Path(__file__).resolve().parent
def sha(data): return hashlib.sha256(data).hexdigest()
def read(name): return json.loads((OUT/name).read_bytes())
def save(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')
assert not (OUT/'receipt.json').exists(), 'Do not overwrite a sealed review'
raw=read('independent-adjudication.json'); host=read('host-and-provenance-audit.json')
protocol=read('frozen-protocol-validation.json'); comparison=read('author-comparison.json')
assert raw['status']==host['status']==protocol['status']==comparison['status']=='pass'
assert raw['verdict']=='NO-GO' and all(not r['primary_pass'] and not r['all_86_pass'] for r in raw['runs'])
assert raw['baseline_drift']['geomean_pass'] and not raw['baseline_drift']['all_cell_drift_pass']
assert len(raw['baseline_drift']['failed_cells'])==9
assert protocol['validator_unmodified'] and not protocol['validator_stubbed']
review=dict(schema='independent-fused-performance-review-v1',created_utc=datetime.now(timezone.utc).isoformat(),
    verdict='NO-GO',evidence_acceptance='ACCEPT_COMPLETE_FROZEN_NEGATIVE_EVIDENCE',
    performance_acceptance='REJECTED_REGISTERED_PRIMARY_REGRESSION_AND_BASELINE_DRIFT_GATES',
    source=host['source'],publication=host['publication'],
    source_tree='96bd28b9bc45702e1d7f6c8e9a60d7653f2cd941',native_tree='212dd5d00d4b2159abd4627a6aaec8b16a1157e5',
    publication_tree='639356e5233cc1456ad4de2cfe728a3b3894e1f3',
    build_sha256=host['build_sha256'],identity_sha256=host['identity_sha256'],
    prior_timing_ready_sha256=host['prior_timing_ready_sha256'],
    root_freeze_sha256=host['root_freeze_sha256'],host_sha256=host['host_sha256'],
    plan_sha256=host['plan_sha256'],root_grant_sha256=host['root_grant_sha256'],
    runs=raw['runs'],baseline_drift=raw['baseline_drift'],
    raw_structure_stdout_argv_state_machine='PASS_INDEPENDENT_AND_ORIGINAL_VALIDATORS',
    independent_exact_rational_reconstruction=True,author_adjudication_agrees=True,
    provenance_and_collection='PASS_WITH_RETAINED_HOST_OBSERVATIONS',
    pause_seconds=host['pause_seconds'],emulator_restored=True,
    quiet_window_bound_seconds=480,whole_run_retries=0,
    baseline_drift_does_not_discard_primary_or_regression_failures=True,
    baseline_drift_precludes_promoted_causal_performance_conclusion=True,
    historical_W1_W2_NO_GO='UNCHANGED',prior_actual_static_acceptance='UNCHANGED',
    causal_scope='Only the exact two complete builds on this registered machine and input set; executable-layout confound retained.',
    publication_delta_review='PENDING_SEPARATE_FROZEN_NEGATIVE_CHECKPOINT',
    candidate_promotion_authorized=False,remeasurement_authorized=False,gmp_parity=False,
    reviewer_benchmark_executed=False,reviewer_calibration_executed=False,
    reviewer_native_build_executed=False,reviewer_verifier_executed=False,
    reviewer_arithmetic_oracle_executed=False,reviewer_process_management=False,
    reviewer_source_edits=False,
    audit_sha256={name:sha((OUT/name).read_bytes()) for name in (
        'independent-adjudication.json','independent-raw-detail.json','frozen-protocol-validation.json',
        'host-and-provenance-audit.json','input-capture.json','author-comparison.json','REVIEW.md')})
save('review.json',review)
excluded={'manifest.json','evidence.zip','receipt.json'}
files=sorted(p for p in OUT.rglob('*') if p.is_file() and p.relative_to(OUT).as_posix() not in excluded)
manifest=dict(schema='independent-review-manifest-v1',files={p.relative_to(OUT).as_posix():dict(
    sha256=sha(p.read_bytes()),bytes=p.stat().st_size) for p in files})
save('manifest.json',manifest)
with zipfile.ZipFile(OUT/'evidence.zip','w') as z:
    for p in files+[OUT/'manifest.json']:
        z.write(p,p.relative_to(OUT).as_posix(),compress_type=zipfile.ZIP_STORED if p.suffix=='.zip' else zipfile.ZIP_DEFLATED)
with zipfile.ZipFile(OUT/'evidence.zip') as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(files)+1
    for name,row in manifest['files'].items():
        data=z.read(name); assert len(data)==row['bytes'] and sha(data)==row['sha256']
    assert z.read('manifest.json')==(OUT/'manifest.json').read_bytes()
receipt=dict(schema='independent-review-seal-v1',verdict='NO-GO',evidence_acceptance=review['evidence_acceptance'],
    performance_acceptance='REJECTED',source=host['source'],publication=host['publication'],
    build_sha256=host['build_sha256'],identity_sha256=host['identity_sha256'],
    root_freeze_sha256=host['root_freeze_sha256'],host_sha256=host['host_sha256'],
    review_sha256=sha((OUT/'review.json').read_bytes()),manifest_sha256=sha((OUT/'manifest.json').read_bytes()),
    archive_sha256=sha((OUT/'evidence.zip').read_bytes()),archive_members=len(files)+1,
    archive_verified=True,remeasurement_authorized=False,candidate_promotion_authorized=False,
    publication_review_pending=True)
save('receipt.json',receipt)
print(json.dumps(dict(receipt_sha256=sha((OUT/'receipt.json').read_bytes()),archive_bytes=(OUT/'evidence.zip').stat().st_size,**receipt),indent=2))

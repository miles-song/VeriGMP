# Independent fused interpolation timing-eligibility review

Verdict: **READY for the registered two-run timing experiment, subject to root's operational quiet-window grant.** This review accepts the actual untimed gate closure and the disclosed codegen/layout differences for measurement. It does not accept a performance claim, promote the candidate, or change either historical W1/W2 NO-GO result.

The accepted proof/runtime source is commit `3a836713adbb0a6632f5131e8d57c97296d22f62`, tree `96bd28b9bc45702e1d7f6c8e9a60d7653f2cd941`, native tree `212dd5d00d4b2159abd4627a6aaec8b16a1157e5`. A later metadata/publication commit cannot silently replace this source or build identity.

The explicitly mapped publication backup is direct child `97d3ee9b281b5c65d3b4c84caadb51cb79b550c0`, tree `639356e5233cc1456ad4de2cfe728a3b3894e1f3`. The independent Git-object check preserves all 4,603 original mode/kind/blob entries, checks all 74 consumed inputs against Git, live and frozen bytes, and permits exactly 11 additions in the declared static-archive directory. The source/publication mapping SHA-256 is `4795228610799bdca2aae9bfa3de43bcecebddada99dbc5f4ffadfa07c12a3b1`. Its unchanged native tree and build/identity bytes map back to the original proof/runtime source; the publication commit is not a new proof source. All 943 payloads of the retained author archive were read, hashed and compared against both its manifest and the live gate evidence. Host preparation must freeze this exact mapping as well as the original source/build pins.

| Frozen object | SHA-256 |
|---|---|
| Actual bench-build.json | `bac446bdf52f2a9ce6babb653019427d3f65ec36c90de68b5a8459ae945a62c4` |
| Actual identity.json | `2ef03539dfb28375a6de5ff09a7fad03245fcc9cd5c26447d775a73900c5ff01` |
| Candidate full proof/build receipt | `e73252c3da01bb60f05db5753a4815f0470d2796da558f93229567698964329b` |
| Untimed correctness/negative receipt | `dc43436ff9a7bb487125639bcc5c3a71d13c08ab79cf17c6a3b0b9f6807eb278` |
| Canonical control-identity.json | `22b4a942cbb1fd89bb70daf54b3d642ec36dd305dab7436024fe077fddf59630` |
| Baseline benchmark executable | `f9b3f8318426c6dfdd2887f2ea986bd2678f9865ef6a157b140cbbbf7f4375ac` |
| Candidate benchmark executable | `6bce14a79d96857f7ed4e7ce4e0d6fc46527951705382ee91661230777d89ccc` |
| GMP shared library | `0ccdfb6d6f5c039465f6d002cf7e4c072d48ac6a2cffc8dd6c748dec31592804` |

## Actual untimed gate closure

The reviewer freshly ran the unchanged `raw_validate.validate_build` against the root-supplied external build digest, with no stubs or substitutions. It passed. The retained result is `actual-build-validation.json`, SHA-256 `a403b7e8c4bd7db56168154bfcde6b2a5ccc462f680b78db985a6e25ec7fcc52`. Its checks reread the source, tools, accepted baseline receipt, full proof logs, exports, compile logs, binaries, GMP and gate receipts. This closes the real-build boundary that was explicitly pending in the earlier synthetic validator review.

An independent read-only audit matched all 71 previously sealed inputs against the actual gate source, checked the actual complete candidate command and unique 369 verified/0 errors summary, and verified all 15 untimed command stdout/stderr hashes and exit statuses. Both imported bridges were verified and optimized with the corresponding exact rlib/vir and reported 1 verified/0 errors. Each actual optimized runtime runner reported all 4,036 independent integer fixtures passing, with the unchanged fixture binary hash. The runner source and compilation paths bind the canary, dirty-output/scratch, capacity, input preservation, valid disjoint/shared-input and error-before-write checks to these executions.

All four mutant snapshots were independently compared file by file against the frozen native source: exactly the intended wrong-shift, lost-shift-carry, lost-borrow or zero-scalar-carry edit was present. The four mutant logs and two numerical-domain negative-client logs each pass the strict logical-rejection classifier; no timeout, parser, type, load or solver-resource failure is counted as a rejection. Three separate ownership negatives have the expected E0502/E0499 diagnostics. No producer, runner, oracle or proof was replayed by the reviewer.

The accepted baseline remains the exact 358-item producer, rlib `02dabb57ecbee4b82fe99b4ed555cbd892160b999b47d01d9ac0ab9788372d28` and vir `9890ff7d0d62f53101b41089017f913ecd6495421e54c79e2819735c3769ed41`. The candidate's exact pair is rlib `59151180a613df39efc32c6d9b012fd105d219fb2c678f9bf127b23407fefece` and vir `c896366cb7ec15f3ee57e78962607ea5e9b82901c9d04614cec4ce242421b5d8`.

## Codegen decision

The independent Python ar/ELF parser confirmed that each rlib contains exactly one native object and that its bytes equal the complete codegen input. All 156 baseline and 157 candidate native function sections were checked against actual ELF bytes. Both final executables' `.text` sections, symbol addresses/sizes and all 16 arithmetic function bodies were independently checked against their actual ELF bytes.

Exactly three existing function bodies change:

- `toom_interpolate::interpolate`: 1,679 to 1,215 bytes.
- `toom_multiply::full`: 2,640 to 2,672 bytes.
- `toom_square::full`: 2,299 to 2,286 bytes.

The complete interpolation disassembly contains the constant shift-4 subtraction loop at offset 0x2e0 and shift-1 loop at 0x3c0. The old scratch copy/scale pipelines are absent. The existing divide-by-2 and specialized divide-by-3 operations remain. The helper has no allocation, FFI, additional mathematical representation or extra pass in the executed arithmetic path. All its proof objects erase from that path.

The two Toom caller sources are unchanged, while their emitted code changes register allocation, stack/call setup and layout. In particular, the square caller's fixed stack allocation changes from 0x58 to 0x88 bytes; this can affect below-threshold control entries as well. This is a disclosed compiler consequence of the frozen candidate, not byte identity. It does not introduce a second source-level arithmetic algorithm, and the actual compiled producer is covered by the same-source proof and integer-oracle gates.

For the 71 control cells, the source-aware conservative whole-function footprint has matching library bodies and normalized relocations for 61. Ten square-control footprints include changed Toom caller bodies. These footprints deliberately overapproximate internal branches and are not executed-instruction traces. Final raw body/layout identity is false for all 71 controls. Among the 13 unchanged arithmetic functions present in both final executables, masking only their actual ELF relocation fields makes all 13 linked bodies identical. The remaining linked differences are the three declared functions. Final `.text` layout and addresses still differ, including `mul_mod` at 0x1a310 versus 0x19f10.

The additional `shift_factor` object section is a 26-byte cold panic stub. There are zero incoming arithmetic/callgraph references. Independent examination of every object relocation found one ordinary `.eh_frame` unwind-metadata reference; it is not an arithmetic call. The stub is absent from the final benchmark ELF. The claim is erasure from the executed arithmetic path, not absence of every spec stub from the library archive.

These differences are acceptable for the planned comparison of the two complete frozen builds. The experiment may establish a measured end-to-end difference for this candidate on the registered machine/cells. It cannot attribute every timing difference solely to deleted loop visits, nor claim unchanged controls were byte-identical. No padding, native edit, recompilation, cell removal or threshold adjustment is required to force layout equality.

The codegen-01 binary-to-text decoding failure, codegen-02 metadata-import failure and codegen-03 metadata assertion failure are retained. Codegen-04/05 reused the successful original compiled objects/binaries and completed metadata; no replacement native build or timing was used to improve an outcome. The original and corrected review-side unwind-reference check are also retained.

## Operational boundary for timing

The earlier raw-validator/protocol READY seal remains valid and is copied into this review. Actual untimed gates/codegen and unstubbed external-build validation are now READY for these exact pins. Root must still grant and coordinate the operational quiet window, with CPU 8, no concurrent heavy work, the same loaded GMP identity and the registered before/after source/tool/export/binary/GMP/affinity checks. The current host receipt only establishes read-only setup observations; live quiet-window conditions must be captured by the measurement owner.

Preserve the original two independent complete 86-cell runs, seven accepted samples of at least 10ms, all calibrations/short samples/retries, and the combined 480-second cap. Each run separately needs primary 15-cell geometric mean <= 0.98 and worst all-86 ratio <= 1.05. Across runs, the 71-control baseline GM must lie in [0.95,1.05] and each control ratio in [0.90,1.10]. No pooling, post-result cell selection, threshold tuning or outcome-driven replacement run is allowed. Both runs' real raw evidence must pass the unchanged validator and independent adjudication before any performance acceptance.

No timing, calibration, native build, arithmetic oracle, Verus process, process management, author source edit, commit or push was performed by this reviewer. **Performance acceptance remains pending.**

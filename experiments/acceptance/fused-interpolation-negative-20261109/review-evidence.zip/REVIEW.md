# Independent fused interpolation raw/performance decision

**Verdict: NO-GO.** Both complete runs independently fail the registered primary gain gate and the all-86 regression gate. The cross-run control geometric mean passes, but nine individual control cells fail the registered baseline drift interval. The frozen raw evidence and host/provenance binding pass review; the baseline drift is retained as an additional reason that this window cannot support a promoted causal performance conclusion. No run is discarded, pooled, replaced or reclassified because of an unfavorable candidate result.

This verdict covers the two frozen complete builds on the registered machine, seed and cells. It does not attribute differences solely to the fused loop, establish GMP parity, or authorize candidate promotion or remeasurement. The previous actual correctness/codegen acceptance remains source-bound and unchanged. Review of a later evidence-only publication checkpoint requires its separately frozen tree.

## Frozen identity

| Object | Identity |
|---|---|
| Arithmetic/proof/runtime source | `3a836713adbb0a6632f5131e8d57c97296d22f62` |
| Source tree | `96bd28b9bc45702e1d7f6c8e9a60d7653f2cd941` |
| Candidate native tree | `212dd5d00d4b2159abd4627a6aaec8b16a1157e5` |
| Mapped publication backup | `97d3ee9b281b5c65d3b4c84caadb51cb79b550c0` |
| Source/publication mapping SHA-256 | `4795228610799bdca2aae9bfa3de43bcecebddada99dbc5f4ffadfa07c12a3b1` |
| Frozen build SHA-256 | `bac446bdf52f2a9ce6babb653019427d3f65ec36c90de68b5a8459ae945a62c4` |
| Identity receipt SHA-256 | `2ef03539dfb28375a6de5ff09a7fad03245fcc9cd5c26447d775a73900c5ff01` |
| Prior independent timing-eligibility receipt SHA-256 | `b1d5eab025137690ab99dde178253431c27cc9c0b6ad6072d77bf8ff23b5cdb7` |
| Root measurement freeze SHA-256 | `29946c99d968c26b8216b34040d7769578db1d9d716690699b33228a1a965b27` |
| Host receipt SHA-256 | `66974bfa218ab35442d3d0006fc15d9b412e1104fe62d803bb72c12f8fcef6a1` |

The original 358-item baseline and 369-item candidate proof/export pairs, complete untimed oracle and negative gates, declared three codegen body changes and disclosed executable-layout differences are inherited from the exact prior independent seal. Publication metadata is not treated as a new proof source.

## Independent numerical reconstruction

The reviewer consumed every raw invocation/outcome/result triple, bound exact argv to the frozen binary/cell/seed/GMP selector/count/CPU, strictly decoded `stdout_hex`, and checked equality of stdout JSON and result payload. All calibration ladders, stopping conditions, checksums, accepted samples, short samples, count doubling and path/repetition order were checked. Median computation used exact rational `ns/iterations`, sorting each group of seven and taking its middle value. Geometric means used 60-digit Decimal logarithms/exponentials. The existing adjudication was compared only after this independent reconstruction was complete.

The unchanged registered offline validator was also freshly executed, including the real unstubbed `validate_build` and both `validate_report` calls. It passed. No measurement, calibration, native compiler, Verus process or arithmetic oracle was executed by this reviewer.

| Registered criterion | Run 1 | Run 2 |
|---|---:|---:|
| 15-primary candidate/baseline GM, required <= 0.98 | **0.985593927623950484 — FAIL** | **0.983314306812513253 — FAIL** |
| Worst candidate/baseline ratio over all 86, required <= 1.05 | **1.0617446394400472 — FAIL** | **1.0730485054388073 — FAIL** |
| Worst cell `(op,n,top)` | `(1,511,63)` | `(0,129,64)` |
| Complete cells / calibrations / accepted samples | 86 / 258 / 1,806 | 86 / 258 / 1,806 |
| Invocations | 2,064 | 2,065 |
| Retained short samples / retries | 0 / 0 | 1 / 1 |
| Minimum accepted sample | 14.960867 ms | 11.806349 ms |

Run 1 regression failures are `(0,8,64)` at 1.0589258324090898, `(0,1025,64)` at 1.0588294376303937, `(1,511,63)` at 1.0617446394400472, and `(2,256,63)` at 1.0584170369901076. Run 2 failures are `(0,48,64)` at 1.0506237840469277, `(0,129,64)` at 1.0730485054388073, and `(1,1,64)` at 1.061204819573276. Here op 0 denotes the registered forced-full multiplication control, op 1 default multiplication, and op 2 default square.

The sole short sample is run 2, baseline `(0,49,64)`, repetition 0: 4,096 iterations took 6.204513 ms. Its immediately adjacent retained retry uses 8,192 iterations and took 12.922755 ms. That doubled count carries forward to later repetitions. This is the original within-sample rule, not a repeated whole run.

For the 71 controls, baseline median `run2/run1` GM is **1.012098212025976025**, inside `[0.95,1.05]`. The following nine ratios lie outside the independent per-cell requirement `[0.90,1.10]`, so **baseline_drift=true**:

| Control `(op,n,top)` | Baseline run2/run1 |
|---|---:|
| `(0,2,64)` | 0.8938525923338395 |
| `(0,23,64)` | 0.8989710791495671 |
| `(0,31,64)` | 0.8884758037941818 |
| `(0,129,64)` | 1.1175555311461582 |
| `(0,257,64)` | 1.1734581278107470 |
| `(1,25,63)` | 1.1938396060874066 |
| `(1,65,63)` | 1.1075627697576900 |
| `(1,192,63)` | 1.1464549673308244 |
| `(2,63,63)` | 1.1073911844544150 |

All 71 baseline/GMP and GMP cross-run observations are retained in the independent derived evidence. The baseline/GMP control GM is 1.374316099675889132 in run 1 and 1.371280236711706302 in run 2; these are descriptive observations, not substitute gates. The raw reconstruction agrees with the original summarizer on both runs, every regression-failure cell and the control drift verdict.

## Collection and provenance

Plan SHA-256 `60832089950628d291458eabd6e5424c549714f5a8842f837a15041608de8242` and root grant `8761ad80973677ceaa5b7524c8eacd1be4abb8314f9c92eb9f67daf238dce891` bind the source, mapped publication, build, identity, prior independent eligibility and CPU 8. Fresh acknowledgments cover the complete recorded active-worker roster. The host records 14 ordered successful commands and two distinct, sequential measurement processes. Six hashed provenance receipts bracket the runs and restoration, preserving source/tool/export/binary identity, CPU availability, SMT sibling `8-9`, kernel, and the original runner's per-child CPU-8 affinity policy.

Both binaries resolve GMP via retained `ldd` output to `/lib/x86_64-linux-gnu/libgmp.so.10`, realpath `/usr/lib/x86_64-linux-gnu/libgmp.so.10.5.0`, SHA-256 `0ccdfb6d6f5c039465f6d002cf7e4c072d48ac6a2cffc8dd6c748dec31592804`. Pre/post records have no `LD_LIBRARY_PATH`, `LD_PRELOAD` or `LD_AUDIT`. This is a resolved-library identity check; no per-invocation memory-map trace is claimed.

The exact authorized emulator identities are stable in all 16 observations. Their CPU totals do not advance between the quiet observations and either completed run. Both exact owned process resumes return zero, both processes are no longer suspended afterward, and the AVD status returns to running. The recorded pause is **342.2724186 seconds**, within the 480-second cap. Ordinary Windows service CPU activity remains in the evidence. The six Linux snapshots contain no recorded concurrent Verus/Z3/native build or other benchmark process. Frequency interfaces are unavailable and thermal observations empty; these limitations are retained, not used to exclude unfavorable measurements. The retained `ps` terminal-size warning is also disclosed in the audit and does not replace its successful complete table output.

All 86 captured files of the earlier prelaunch attempt still match their hashes. Its failed host receipt contains no ADB command, pause, resume or benchmark launch. The revision-2 wrapper changes only canonical comparison of the same `start_utc` instant; the plan changes only its support/test hashes and output paths. Twenty identity fixture results include rejection of a one-tick timestamp change and each non-time identity change. Thus the earlier failure did not produce a trial that could be selected against these results.

## Durable evidence and scope

Run 1 measurement/raw SHA-256: `2716e9111364df389b976d3fb14f968138fbec284df169d2592b9b022dd7064a` / `c780a0b2072634cf7cb3f042c05ba8768cfa132268eb9e191ef9b38f1d95f66d`.

Run 2 measurement/raw SHA-256: `268219fcceb93b30484dfb121e3cb96c29c3f29c178181aef7494ae43a67da29` / `d50fd3fb95d374333fc3f811fb9a7bf4c90c2d7f1892c1738396fdd62ec42ad4`.

The package retains both complete raw files and reports, root freeze/grant/plan, wrapper and tests, all host/provenance logs, the preserved prelaunch evidence, independent exact-rational details, original-validator output, and the exact prior timing-eligibility archive containing the actual static evidence. `manifest.json` and `receipt.json` seal these files; original evidence and author source were not edited.

**Accepted outcome: retain this frozen experiment as NO-GO evidence. Performance promotion is rejected by the registered primary, regression and baseline-drift criteria. No retiming, threshold change, candidate enabling, GMP-parity claim or loop-only causal claim is authorized by this review.**

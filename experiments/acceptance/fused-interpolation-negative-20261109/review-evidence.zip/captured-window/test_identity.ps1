$ErrorActionPreference='Stop'
$text=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'timing_host.ps1'))
$tokens=$null;$errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseInput($text,[ref]$tokens,[ref]$errors)
if ($errors.Count) { throw 'Host script parse failed' }
foreach ($name in 'Utc-Time','Check-Identity') {
  $function=$ast.Find({param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq $name},$true)
  . ([scriptblock]::Create($function.Extent.Text))
}
# Real JSON parsing, pure identity data: no process API, ADB or native calls.
$plan=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'plan.json') -Raw | ConvertFrom-Json
$cases=@()
foreach ($target in $plan.emulator.targets) {
  if ($target.start_utc -isnot [DateTime]) { throw 'Expected the automatic ConvertFrom-Json DateTime conversion' }
  $actual=@{}
  foreach ($key in @('pid','name','start_ticks','start_utc','path','executable_sha256','parent_pid','command_line')) { $actual[$key]=$target.$key }
  $actual.start_utc=(Utc-Time $target.start_utc).ToString('o')
  if ($actual.start_utc -eq $target.start_utc) { throw 'Fixture did not reproduce the original string/DateTime mismatch' }
  Check-Identity $target $actual
  $cases+=@{case='parsed-plan-datetime-versus-live-iso-string';pid=$target.pid;status='pass'}
  $sameInstant=([DateTimeOffset](Utc-Time $target.start_utc)).ToOffset([TimeSpan]::FromHours(-8))
  $actual.start_utc=$sameInstant.ToString('o')
  Check-Identity $target $actual
  $cases+=@{case='equivalent-offset-same-instant';pid=$target.pid;status='pass'}
  $actual.start_utc=(Utc-Time $target.start_utc).AddTicks(1).ToString('o')
  $rejected=$false
  try { Check-Identity $target $actual } catch { $rejected=$_.Exception.Message -like '*/start_utc' }
  if (-not $rejected) { throw 'One-tick timestamp drift was accepted' }
  $cases+=@{case='reject-one-tick-drift';pid=$target.pid;status='pass'}
  foreach ($key in @('pid','name','start_ticks','path','executable_sha256','parent_pid','command_line')) {
    $actual.start_utc=(Utc-Time $target.start_utc).ToString('o')
    $original=$actual[$key]
    $actual[$key]=if ($key -in @('pid','parent_pid')) {[int]$original+1} else {[string]$original+'-changed'}
    $rejected=$false
    try { Check-Identity $target $actual } catch { $rejected=$_.Exception.Message.EndsWith('/'+$key) }
    if (-not $rejected) { throw ('Non-time identity drift was accepted: '+$key) }
    $actual[$key]=$original
    $cases+=@{case=('reject-'+$key+'-drift');pid=$target.pid;status='pass'}
  }
}
[ordered]@{status='pass';cases=$cases;real_process_calls=$false;live_adb_executed=$false;emulator_affected=$false;benchmark_executed=$false} | ConvertTo-Json -Depth 7

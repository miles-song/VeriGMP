"""Independent exact-rational reconstruction from retained stdout; no external execution."""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal, localcontext
import hashlib
import json
import math

OUT=Path(__file__).resolve().parent
ROOT=Path(r'E:\3sat\VeriGMP-fused-measurement-window-20261109-02')
DATA=ROOT/'measurement-F1-02'
GATE=Path(r'C:\Users\23247\.codex\worktrees\gmp-fused-interpolation-20261108\gates-3a83671-01')
BUILD_SHA='bac446bdf52f2a9ce6babb653019427d3f65ec36c90de68b5a8459ae945a62c4'
FREEZE_SHA='29946c99d968c26b8216b34040d7769578db1d9d716690699b33228a1a965b27'
FULL=(1,2,7,8,9,23,24,25,31,32,33,47,48,49,63,64,65,127,128,129,191,192,193,255,256,257,511,512,513,1023,1024,1025,2048,4096)
SHAPES=((1,1),(1,64),(2,1),(23,63),(24,63),(25,63),(63,63),(64,63),(65,63),(127,63),(128,63),(129,63),(191,63),(192,63),(193,63),(255,63),(256,63),(257,63),(511,63),(512,63),(513,63),(1023,63),(1024,63),(1025,63),(2048,63),(4096,63))
CELLS=[(0,n,64) for n in FULL]+[(op,n,t) for op in (1,2) for n,t in SHAPES]
PRIMARY={(1,n,63) for n in (512,513,1023,1024,1025,2048,4096)}|{(2,n,63) for n in (511,512,513,1023,1024,1025,2048,4096)}
PATHS=('baseline','candidate','gmp')

def sha(data): return hashlib.sha256(data).hexdigest()
def pairs(rows):
    out={}
    for k,v in rows:
        assert k not in out, ('duplicate JSON key',k)
        out[k]=v
    return out
def invalid(value): raise AssertionError(('invalid JSON constant',value))
def load(data): return json.loads(data,object_pairs_hook=pairs,parse_constant=invalid)
def read(path,digest=None):
    data=path.read_bytes()
    if digest: assert sha(data)==digest,str(path)
    return load(data)
def integer(n,lo,hi): assert type(n) is int and lo<=n<=hi,n
def decimal(x): return Decimal(x.numerator)/Decimal(x.denominator)
def gm(values):
    with localcontext() as context:
        context.prec=60
        return (sum(decimal(x).ln() for x in values)/Decimal(len(values))).exp()
def near(a,b): assert math.isclose(float(a),float(b),rel_tol=1e-13,abs_tol=1e-13),(a,b)
def save(name,data): (OUT/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')

freeze=read(DATA/'root-measurement-freeze.json',FREEZE_SHA)
for name,row in freeze['files'].items():
    data=(DATA/name).read_bytes()
    assert len(data)==row['bytes'] and sha(data)==row['sha256'],name
build=read(GATE/'build-identity-01/bench-build.json',BUILD_SHA)
assert build['key_shapes']==[list(x) for x in SHAPES]
assert len(CELLS)==86 and len(PRIMARY)==15
results=[]; all_medians=[]; raw_details=[]
for run in (1,2):
    folder=DATA/f'fused-run-{run}'
    report=read(folder/'measurement.json')
    raw=(folder/'raw.jsonl').read_bytes()
    assert report['build']==build and report['build_sha256']==BUILD_SHA
    assert report['status']=='pass' and report['cpu']==8 and report['seed']==20261108
    assert report['run_id']==f'fused-interpolation-cpu8-20261109-run-{run}'
    assert report['minimum_sample_ns']==10_000_000 and report['repetitions']==7
    assert report['raw_sha256']==sha(raw)
    lines=[load(line) for line in raw.splitlines()]
    cursor=0; calibrations=0; accepted=0; shorts=[]; retries=[]; minimum=None
    medians={}; details=[]
    def consume(cell,path,count,kind,rep):
        global cursor
        trio=lines[cursor:cursor+3]
        assert len(trio)==3
        cursor+=3
        iv,oc,rs=trio
        op,n,top=cell
        argv=[build['binaries']['candidate' if path=='candidate' else 'baseline']['path'],str(op),str(n),str(top),'20261108',str(path=='gmp').lower(),str(count),'registered']
        fields=dict(op=op,n=n,top=top,path=path,kind=kind,repetition=rep,argv=argv)
        assert iv==dict(fields,record='invocation',cpu=8,timeout_seconds=180)
        assert set(oc)==set(fields)|{'record','returncode','timed_out','stdout','stderr','stdout_hex','stderr_hex'}
        assert set(rs)==set(fields)|{'record','iterations','ns','checksum','calibration'}
        assert oc['record']=='outcome' and rs['record']=='result'
        for row in trio:
            assert all(row[key]==value for key,value in fields.items())
            for key in ('op','n','top','repetition'): assert type(row[key]) is int
        assert type(iv['cpu']) is int and type(iv['timeout_seconds']) is int
        assert type(oc['returncode']) is int and oc['returncode']==0 and oc['timed_out'] is False
        for stream in ('stdout','stderr'):
            b=bytes.fromhex(oc[stream+'_hex'])
            assert b.hex()==oc[stream+'_hex'] and b.decode(errors='replace')==oc[stream]
        assert oc['stderr']==''
        payload=load(bytes.fromhex(oc['stdout_hex']).decode('utf-8'))
        assert set(payload)=={'iterations','ns','checksum','calibration'}
        assert rs==dict(payload,**fields,record='result')
        integer(payload['iterations'],1,(1<<64)-1)
        integer(payload['ns'],1,(1<<128)-1)
        integer(payload['checksum'],0,(1<<64)-1)
        ladder=payload['calibration']; assert type(ladder) is list
        if kind=='calibration':
            assert 1<=len(ladder)<=64
            for j,pair in enumerate(ladder):
                assert type(pair) is list and len(pair)==2
                integer(pair[0],1,(1<<64)-1); integer(pair[1],0,(1<<128)-1)
                assert pair[0]==2**j and (pair[1]>=20_000_000)==(j==len(ladder)-1)
            assert ladder[-1]==[payload['iterations'],payload['ns']]
        else: assert ladder==[] and payload['iterations']==count
        return payload
    for index,cell in enumerate(CELLS):
        counts={}; checksums=set(); observations={p:[] for p in PATHS}
        for path in PATHS:
            v=consume(cell,path,0,'calibration',-1); calibrations+=1
            counts[path]=v['iterations']; checksums.add(v['checksum'])
        for repetition in range(7):
            ordered=['baseline','candidate'] if repetition%2==0 else ['candidate','baseline']
            ordered.insert((index+repetition)%3,'gmp')
            for path in ordered:
                kind='sample'
                while True:
                    v=consume(cell,path,counts[path],kind,repetition); checksums.add(v['checksum'])
                    record=dict(cell=cell,path=path,repetition=repetition,iterations=v['iterations'],ns=v['ns'])
                    if kind=='sample-retry': retries.append(record)
                    if v['ns']>=10_000_000: break
                    shorts.append(record); counts[path]*=2; kind='sample-retry'
                    integer(counts[path],1,(1<<64)-1)
                observations[path].append(v); accepted+=1
                minimum=v['ns'] if minimum is None else min(minimum,v['ns'])
        assert len(checksums)==1
        meds={p:sorted(Fraction(v['ns'],v['iterations']) for v in observations[p])[3] for p in PATHS}
        medians[cell]=meds
        recorded=report['summaries'][index]
        assert (recorded['op'],recorded['n'],recorded['top'])==cell
        for p in PATHS: near(meds[p],recorded['median_ns'][p])
        near(meds['candidate']/meds['baseline'],recorded['candidate_over_baseline'])
        near(meds['candidate']/meds['gmp'],recorded['candidate_over_gmp'])
        details.append(dict(cell=cell,accepted_samples=observations,
                            median_ns_exact={p:str(v) for p,v in meds.items()},
                            candidate_over_baseline_exact=str(meds['candidate']/meds['baseline']),
                            baseline_over_gmp_exact=str(meds['baseline']/meds['gmp'])))
    assert cursor==len(lines) and calibrations==258 and accepted==1806 and len(report['summaries'])==86
    ratios={c:m['candidate']/m['baseline'] for c,m in medians.items()}
    primary=gm([ratios[c] for c in sorted(PRIMARY)]); worst=max(ratios,key=ratios.get)
    result=dict(run=run,run_id=report['run_id'],raw_sha256=sha(raw),measurement_sha256=sha((folder/'measurement.json').read_bytes()),
                cells=86,calibrations=calibrations,accepted_samples=accepted,invocations=cursor//3,
                retained_short_samples=shorts,retained_retries=retries,minimum_accepted_ns=minimum,
                primary_geomean_decimal=str(primary),all_86_worst=float(ratios[worst]),worst_cell=worst,
                primary_pass=primary<=Decimal('0.98'),all_86_pass=ratios[worst]<=Fraction(105,100),
                failed_cells=[dict(cell=c,ratio=float(r)) for c,r in ratios.items() if r>Fraction(105,100)],
                baseline_over_gmp_control_geomean_decimal=str(gm([medians[c]['baseline']/medians[c]['gmp'] for c in CELLS if c not in PRIMARY])))
    result['performance_pass']=result['primary_pass'] and result['all_86_pass']
    results.append(result); all_medians.append(medians); raw_details.append(dict(run=run,cells=details))
controls=[c for c in CELLS if c not in PRIMARY]; assert len(controls)==71
drifts={c:all_medians[1][c]['baseline']/all_medians[0][c]['baseline'] for c in controls}
drift_gm=gm(list(drifts.values()))
failures=[dict(cell=c,run2_over_run1=float(v)) for c,v in drifts.items() if not Fraction(9,10)<=v<=Fraction(11,10)]
drift=dict(control_cells=71,geomean_decimal=str(drift_gm),geomean_pass=Decimal('0.95')<=drift_gm<=Decimal('1.05'),
           all_cell_drift_pass=not failures,failed_cells=failures,
           all_control_ratios=[dict(cell=c,run2_over_run1=float(v),exact=str(v),
               gmp_run2_over_run1=float(all_medians[1][c]['gmp']/all_medians[0][c]['gmp']),
               baseline_over_gmp_drift=float(v/(all_medians[1][c]['gmp']/all_medians[0][c]['gmp']))) for c,v in drifts.items()])
verdict='GO' if all(r['performance_pass'] for r in results) and drift['geomean_pass'] and drift['all_cell_drift_pass'] else 'NO-GO'
independent=dict(schema='independent-raw-rational-reconstruction-v1',status='pass',verdict=verdict,
                 build_sha256=BUILD_SHA,root_freeze_sha256=FREEZE_SHA,runs=results,baseline_drift=drift,
                 arithmetic_method='Exact Fraction ns/iterations, sorted middle of seven, Decimal ln/exp at 60 digits for geometric means',
                 benchmark_executed=False,calibration_executed=False,compiler_executed=False,verifier_executed=False)
save('independent-raw-detail.json',raw_details)
save('independent-adjudication.json',independent)
# Compare only after completing the independent reconstruction.
author=read(DATA/'adjudication.json')
for mine,theirs in zip(results,author['runs']):
    near(Decimal(mine['primary_geomean_decimal']),theirs['primary_geomean'])
    near(mine['all_86_worst'],theirs['all_86_worst'])
    assert mine['primary_pass']==theirs['primary_pass'] and mine['all_86_pass']==theirs['all_86_pass']
    assert len(mine['failed_cells'])==len(theirs['failed_cells'])
    for a,b in zip(mine['failed_cells'],theirs['failed_cells']):
        assert list(a['cell'])==b['cell']; near(a['ratio'],b['ratio'])
near(drift_gm,author['baseline_validation']['run2_over_run1_geomean'])
assert author['baseline_validation']['baseline_drift']==(bool(failures) or not drift['geomean_pass'])
assert author['numeric_gates_pass']==(verdict=='GO')
save('author-comparison.json',dict(status='pass',adjudication_sha256=sha((DATA/'adjudication.json').read_bytes()),
    independent_numeric_verdict=verdict,numeric_results_match=True))
print(json.dumps(dict(verdict=verdict,runs=results,drift_geomean=str(drift_gm),drift_failures=failures),indent=2))

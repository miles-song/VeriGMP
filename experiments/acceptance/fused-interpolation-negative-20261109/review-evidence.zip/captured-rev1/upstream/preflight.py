#!/usr/bin/env python3
"""Read-only measurement provenance checks. Never starts a benchmark or verifier."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def checked(path, expected):
    actual = digest(path)
    if actual != expected:
        raise RuntimeError('frozen identity drift: '+str(path))
    return actual


def review(folder, expected):
    folder = Path(folder)
    checked(folder/'review-artifacts.json', expected)
    manifest = load(folder/'review-artifacts.json')
    entries = manifest.get('sha256')
    if entries is None:
        entries = {row['path']:row['sha256'] for row in manifest['entries']}
    for name, value in entries.items():
        checked(folder/name, value)
    verdict = load(folder/'verdict.json')
    for key in ('static_candidate_verdict','frozen_protocol_verdict'):
        if verdict[key] != 'ACCEPT':
            raise RuntimeError('independent review does not accept '+str(folder))
    return dict(manifest_sha256=expected, sealed_files=len(entries), verdict=verdict)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError('use a fresh provenance receipt')
    plan = load(args.plan)
    report = dict(status='running', utc=datetime.now(timezone.utc).isoformat(),
                  plan_sha256=digest(args.plan), benchmark_executed=False,
                  calibration_executed=False, verifier_executed=False)
    try:
        for name, value in plan['support_sha256'].items():
            checked(args.plan.parent/name, value)
        for path, expected in plan['pinned_files_sha256'].items():
            checked(path, expected)
        double = plan['double']
        combo = plan['combination']
        single_gate = load(double['gate_path'])
        combo_gate = load(combo['gate_path'])
        single_build = load(double['build_path'])
        combo_build = load(combo['build_path'])
        # The two compiled sets deliberately remain distinct frozen binaries.
        for relative, value in single_gate['source']['all_inputs_sha256'].items():
            if relative == 'native/proof-status.json':
                if value != double['publication_status']['gate_sha256']:
                    raise RuntimeError('original status provenance changed')
                value = double['publication_status']['publication_sha256']
            checked(Path(double['repo'])/relative, value)
        for relative, value in combo_build['inputs_sha256'].items():
            checked(Path(combo['repo'])/relative, value)
        prepared = load(combo['prepared_path'])
        for label, cell in prepared['cells'].items():
            for relative, value in cell['native_sha256'].items():
                checked(Path(combo['prepared_path']).parent/label/relative, value)
        # Production combination checkout remains the baseline; the four cell
        # native sources are the separate immutable prepared trees above.
        for relative, value in prepared['cells']['baseline']['native_sha256'].items():
            checked(Path(combo['repo'])/relative, value)
        tools = dict(single_gate['tools']['runtime_sha256'])
        for path, value in combo_gate['ordinary_tools']['sha256'].items():
            if path in tools and tools[path] != value:
                raise RuntimeError('cross-experiment compiler/tool identity mismatch')
            tools[path] = value
        verifier = Path('/mnt/e/3sat/VeriCount/deps/verus/verus-x86-linux')
        for name, value in combo_build['proof_tools']['sha256'].items():
            checked(verifier/name, value)
        for path, value in tools.items():
            checked(path, value)
        report['tools_rehashed'] = len(tools)+len(combo_build['proof_tools']['sha256'])
        report['reviews'] = {kind:review(plan[kind]['review_folder'], plan[kind]['review_manifest_sha256'])
                             for kind in ('double','combination')}
        linked = []
        for kind, build in (('double',single_build),('combination',combo_build)):
            for label, row in build['binaries'].items():
                checked(row['path'], row['sha256'])
                result = subprocess.run(['ldd',row['path']], stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE, timeout=30, check=True)
                text = result.stdout.decode()
                match = re.search(r'libgmp\.so\.10\s*=>\s*(\S+)', text)
                if not match:
                    raise RuntimeError('loaded GMP missing: '+row['path'])
                path = match[1]
                if path != plan['loaded_gmp_path']:
                    raise RuntimeError('loaded GMP path drift: '+path)
                value = checked(path, plan['loaded_gmp_sha256'])
                linked.append(dict(experiment=kind,cell=label,binary_sha256=row['sha256'],
                                   gmp_path=path,gmp_realpath=str(Path(path).resolve()),
                                   gmp_sha256=value,ldd_stdout=text,ldd_stderr=result.stderr.decode()))
        affinity = sorted(os.sched_getaffinity(0))
        cpu = plan['cpu']
        if cpu not in affinity or Path(f'/sys/devices/system/cpu/cpu{cpu}/online').read_text().strip() != '1':
            raise RuntimeError('predetermined CPU unavailable')
        report.update(status='pass', binaries=linked, affinity=affinity,
                      cpu=cpu, cpu_siblings=Path(f'/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list').read_text().strip(),
                      uname=list(platform.uname()), python=sys.version,
                      python_executable=str(Path(sys.executable).resolve()),
                      python_sha256=digest(Path(sys.executable).resolve()),
                      dynamic_loader_environment={name:os.environ.get(name) for name in ('LD_LIBRARY_PATH','LD_PRELOAD','LD_AUDIT')})
        ps = subprocess.run(['ps','-eo','pid,ppid,stat,pcpu,comm,args'],stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,timeout=30,check=True)
        report['linux_process_snapshot'] = ps.stdout.decode()
    except BaseException as error:
        report.update(status='fail', failure=repr(error))
        raise
    finally:
        with args.output.open('x') as stream:
            json.dump(report, stream, indent=2)
            stream.write('\n')
    print(json.dumps(dict(status='pass', output=str(args.output), binaries=len(report['binaries']),
                          benchmark_executed=False, calibration_executed=False),indent=2))


if __name__ == '__main__':
    main()

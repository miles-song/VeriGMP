param(
  [Parameter(Mandatory=$true)][ValidateSet('W1','W2')][string]$Window,
  [Parameter(Mandatory=$true)][string]$RootGrant
)
$ErrorActionPreference='Stop'
$planPath=Join-Path $PSScriptRoot 'plan.json'
function Hash-File([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLower() }
function Wsl-Path([string]$Path) {
  $full=[System.IO.Path]::GetFullPath($Path)
  if ($full -notmatch '^([A-Za-z]):\\(.*)$') { throw 'Expected mounted drive path' }
  '/mnt/'+$Matches[1].ToLower()+'/'+$Matches[2].Replace('\','/')
}
$plan=Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json
$grant=Get-Content -LiteralPath $RootGrant -Raw | ConvertFrom-Json
if ($grant.status -ne 'granted' -or $grant.timing_authorized -ne $true -or $grant.window -ne $Window -or
    $grant.plan_sha256 -ne (Hash-File $planPath) -or
    $grant.all_active_workers_quiescent -ne $true -or
    $grant.independent_prereviews -ne 'ACCEPT' -or $grant.cpu -ne $plan.cpu -or
    $grant.worker_acknowledgements.Count -eq 0 -or
    @($grant.worker_acknowledgements | Where-Object {$_.status -ne 'quiescent'}).Count -gt 0) {
  throw 'Explicit root quiet-window grant and every worker acknowledgment are required'
}
$spec=$plan.windows.$Window
if ($grant.maximum_pause_seconds -lt $spec.pause_budget_seconds) { throw 'Root budget is below prepared window budget' }
foreach ($property in $plan.support_sha256.PSObject.Properties) {
  if ((Hash-File (Join-Path $PSScriptRoot $property.Name)) -ne $property.Value) { throw 'Prepared host support changed' }
}
foreach ($repo in @($plan.double,$plan.combination)) {
  $windowsRepo=$repo.repo.Replace('/mnt/e/','E:\').Replace('/','\')
  if ((& git -C $windowsRepo rev-parse HEAD).Trim() -ne $repo.head -or
      (& git -C $windowsRepo rev-parse 'HEAD^{tree}').Trim() -ne $repo.tree -or
      (& git -C $windowsRepo status --porcelain)) { throw 'Clean reviewed source checkout changed' }
}
$output=$spec.windows_output
if (Test-Path -LiteralPath $output) { throw 'Refusing to replace any prior window evidence' }
New-Item -ItemType Directory -Path $output | Out-Null
$held=@{};$paused=@();$adbPauseAttempted=$false;$initialRunning=$false;$pauseStart=$null
$report=[ordered]@{status='preflight';window=$Window;start_utc=[DateTime]::UtcNow.ToString('o');
  plan_sha256=(Hash-File $planPath);root_grant_sha256=(Hash-File $RootGrant);cpu=$plan.cpu;
  benchmark_launched=$false;commands=@();observations=@();resume=@();adb=@();quiet_grants=@()}
function Save-Report { $report | ConvertTo-Json -Depth 14 | Set-Content -LiteralPath (Join-Path $output 'host-receipt.json') -Encoding utf8 }
function Read-Identity($Process) {
  $Process.Refresh();$cim=Get-CimInstance Win32_Process -Filter ('ProcessId='+$Process.Id)
  $threads=@($Process.Threads | ForEach-Object {
    $state=$_.ThreadState.ToString();$reason=$null
    if ($state -eq 'Wait') { $reason=$_.WaitReason.ToString() }
    @{id=$_.Id;state=$state;wait_reason=$reason}
  })
  @{pid=$Process.Id;name=$Process.ProcessName;start_ticks=$Process.StartTime.ToUniversalTime().Ticks.ToString();
    path=$Process.Path;executable_sha256=(Hash-File $Process.Path);parent_pid=$cim.ParentProcessId;
    command_line=$cim.CommandLine;cpu_seconds=$Process.TotalProcessorTime.TotalSeconds;threads=$threads;
    all_threads_suspended=($threads.Count -gt 0 -and @($threads | Where-Object {$_.state -ne 'Wait' -or $_.wait_reason -ne 'Suspended'}).Count -eq 0)}
}
function Check-Identity($Target,$Actual) {
  foreach ($key in @('pid','name','start_ticks','path','executable_sha256','parent_pid','command_line')) {
    if ($Actual[$key] -ne $Target.$key) { throw ('Authorized emulator identity changed: '+$Target.pid+'/'+$key) }
  }
}
function Observe([string]$Phase) {
  $now=@{}
  foreach ($target in $plan.emulator.targets) {
    $identity=Read-Identity $held[[int]$target.pid];Check-Identity $target $identity
    $now[[int]$target.pid]=$identity
    $report.observations+=@{phase=$Phase;utc=[DateTime]::UtcNow.ToString('o');process=$identity}
  }
  Save-Report;return $now
}
function Run-Command([string]$Executable,[string[]]$Arguments,[string]$Name,[int]$TimeoutSeconds=60) {
  $info=[System.Diagnostics.ProcessStartInfo]::new();$info.FileName=$Executable
  $info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  foreach ($argument in $Arguments) { $info.ArgumentList.Add($argument) }
  $process=[System.Diagnostics.Process]::new();$process.StartInfo=$info
  $entry=@{name=$Name;argv=@($Executable)+$Arguments;start_utc=[DateTime]::UtcNow.ToString('o')}
  $report.commands+=$entry;Save-Report
  try {
    [void]$process.Start();$entry.windows_pid=$process.Id
    $stdout=$process.StandardOutput.ReadToEndAsync();$stderr=$process.StandardError.ReadToEndAsync()
    if (-not $process.WaitForExit($TimeoutSeconds*1000)) {
      # This is the exact relay/ADB client started here, never an enumerated PID.
      $entry.timed_out=$true;$process.Kill();$process.WaitForExit()
    }
    $outPath=Join-Path $output ($Name+'.stdout.log');$errPath=Join-Path $output ($Name+'.stderr.log')
    [IO.File]::WriteAllText($outPath,$stdout.Result);[IO.File]::WriteAllText($errPath,$stderr.Result)
    $entry.returncode=$process.ExitCode;$entry.stop_utc=[DateTime]::UtcNow.ToString('o')
    $entry.stdout_sha256=Hash-File $outPath;$entry.stderr_sha256=Hash-File $errPath;Save-Report
    if ($entry.returncode -ne 0 -or $entry.timed_out) { throw ('Owned command failed: '+$Name) }
    return $stdout.Result
  } finally { $process.Dispose() }
}
function Adb([string[]]$Arguments,[string]$Name) {
  Run-Command $plan.emulator.adb_path (@('-s',$plan.emulator.serial,'emu')+$Arguments) $Name 30
}
function Preflight([string]$Name) {
  $receipt=Join-Path $output ($Name+'.json')
  $null=Run-Command 'wsl.exe' @('--distribution','Ubuntu','--exec','python3',
    (Wsl-Path (Join-Path $PSScriptRoot 'preflight.py')),'--plan',(Wsl-Path $planPath),'--output',(Wsl-Path $receipt)) $Name 90
  $result=Get-Content -LiteralPath $receipt -Raw | ConvertFrom-Json
  if ($result.status -ne 'pass') { throw 'Source/tool/loaded-GMP preflight failed' }
  return $receipt
}
try {
  if ((Hash-File $plan.emulator.adb_path) -ne $plan.emulator.adb_sha256) { throw 'ADB executable changed' }
  foreach ($target in $plan.emulator.targets) {
    $process=Get-Process -Id $target.pid;$null=$process.Handle;$held[[int]$target.pid]=$process
    Check-Identity $target (Read-Identity $process)
  }
  $avd=Adb @('avd','name') 'avd-name-before'
  if ($avd -notmatch '(?m)^opc_toolchain_api36\s*$') { throw 'Wrong AVD behind emulator-5554' }
  $status=Adb @('avd','status') 'avd-status-before'
  if ($status -notmatch 'virtual device is running') { throw 'AVD was not initially running; preserve its state' }
  $initialRunning=$true
  $null=Preflight 'initial-provenance'
  $null=Observe 'before-pause'
  $adbPauseAttempted=$true;$pauseStart=[DateTime]::UtcNow
  $null=Adb @('avd','pause') 'avd-pause'
  $null=Adb @('avd','status') 'avd-status-paused'
  $a=Observe 'adb-paused-observation-1';Start-Sleep -Seconds 2;$b=Observe 'adb-paused-observation-2'
  $spinning=@($plan.emulator.targets | Where-Object {$a[[int]$_.pid].cpu_seconds -ne $b[[int]$_.pid].cpu_seconds}).Count -gt 0
  $report.pause_method='supported_adb_avd_pause'
  if ($spinning) {
    Add-Type @'
using System;using System.Runtime.InteropServices;
public static class VeriGMPWindowNative {
  [DllImport("ntdll.dll")] public static extern int NtSuspendProcess(IntPtr handle);
  [DllImport("ntdll.dll")] public static extern int NtResumeProcess(IntPtr handle);
}
'@
    foreach ($target in $plan.emulator.targets) {
      $process=$held[[int]$target.pid];$identity=Read-Identity $process;Check-Identity $target $identity
      $saved=@{target=$target;suspended_by_this_window=$false;before=$identity};$paused+=$saved
      if ($identity.all_threads_suspended) { throw 'Unexpected prior process suspension' }
      $saved.nt_status=[VeriGMPWindowNative]::NtSuspendProcess($process.Handle)
      if ($saved.nt_status -ne 0) { throw 'Exact authorized handle suspension failed' }
      $saved.suspended_by_this_window=$true
    }
    $report.pause_method='adb_pause_plus_previously_authorized_exact_handle_ntsuspend'
  }
  $quietA=Observe 'quiet-observation-1';Start-Sleep -Seconds 2;$quietB=Observe 'quiet-observation-2'
  foreach ($target in $plan.emulator.targets) {
    if ($quietA[[int]$target.pid].cpu_seconds -ne $quietB[[int]$target.pid].cpu_seconds) { throw 'Authorized emulator remains CPU-active' }
  }
  foreach ($run in $spec.runs) {
    $elapsed=([DateTime]::UtcNow-$pauseStart).TotalSeconds
    $remaining=[int][Math]::Floor($grant.maximum_pause_seconds-$elapsed-75)
    if ($remaining -lt $run.minimum_remaining_seconds) { throw 'Insufficient bounded window for next full registered run' }
    $provenance=Preflight ($run.name+'-provenance-before')
    $elapsed=([DateTime]::UtcNow-$pauseStart).TotalSeconds
    $remaining=[int][Math]::Floor($grant.maximum_pause_seconds-$elapsed-75)
    if ($remaining -lt $run.minimum_remaining_seconds) { throw 'Insufficient bounded window after provenance checks' }
    if ($run.phase -ge 0) {
      $quiet=[ordered]@{status='granted';phase=$run.phase;cpu=$plan.cpu;build_sha256=$plan.combination.build_sha256;
        independent_prereview='pass';known_heavy_jobs_quiescent=$true;root_grant_sha256=(Hash-File $RootGrant);
        preflight_sha256=(Hash-File $provenance);host_report=(Wsl-Path (Join-Path $output 'host-receipt.json'))}
      $quiet | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $run.windows_quiet_grant -Encoding utf8NoBOM
      $report.quiet_grants+=@{path=$run.windows_quiet_grant;sha256=(Hash-File $run.windows_quiet_grant)};Save-Report
    }
    # GNU timeout owns this command's process group. A bounded-window timeout is
    # a retained failed run, never grounds to relaunch it or select observations.
    $arguments=@('--distribution','Ubuntu','--exec','timeout','--signal=TERM','--kill-after=5s',([string]$remaining+'s'))+@($run.linux_argv)
    $report.benchmark_launched=$true;$report.status='measuring';Save-Report
    $null=Run-Command 'wsl.exe' $arguments $run.name ($remaining+15)
    $now=Observe ('after-'+$run.name)
    foreach ($target in $plan.emulator.targets) {
      if ($now[[int]$target.pid].cpu_seconds -ne $quietB[[int]$target.pid].cpu_seconds) { throw 'Emulator CPU advanced during registered measurements' }
    }
  }
  $report.status='registered_runs_collected_performance_pending_analysis'
} catch {
  $report.status='failed';$report.failure=$_.Exception.Message;throw
} finally {
  foreach ($saved in $paused) {
    if (-not $saved.suspended_by_this_window) { continue }
    $entry=@{pid=$saved.target.pid;start_ticks=$saved.target.start_ticks;utc=[DateTime]::UtcNow.ToString('o')}
    try {
      $process=$held[[int]$saved.target.pid]
      if ($process.HasExited) { throw 'Original emulator process exited' }
      Check-Identity $saved.target (Read-Identity $process)
      $entry.nt_status=[VeriGMPWindowNative]::NtResumeProcess($process.Handle)
      if ($entry.nt_status -ne 0) { throw 'Resume failed' }
      $entry.status='resumed'
    } catch { $entry.status='restore_error';$entry.error=$_.Exception.Message }
    $report.resume+=$entry
  }
  if ($adbPauseAttempted -and $initialRunning) {
    try {
      $null=Adb @('avd','resume') 'avd-resume-finally'
      $after=Adb @('avd','status') 'avd-status-after-finally'
      if ($after -notmatch 'virtual device is running') { throw 'AVD did not return to running' }
      $report.avd_restored=$true
      $report.pause_end_utc=[DateTime]::UtcNow.ToString('o')
    } catch { $report.avd_restored=$false;$report.restore_error=$_.Exception.Message }
  }
  if ($held.Count -eq $plan.emulator.targets.Count) {
    try { $null=Observe 'after-finally-restore' } catch { $report.final_identity_error=$_.Exception.Message }
  }
  if ($report.avd_restored -eq $true) {
    try { $null=Preflight 'final-provenance-after-restore' } catch { $report.final_provenance_error=$_.Exception.Message }
  }
  $report.stop_utc=[DateTime]::UtcNow.ToString('o')
  if ($pauseStart) {
    $pauseEnd=if ($report.pause_end_utc) { [DateTime]::Parse($report.pause_end_utc).ToUniversalTime() } else { [DateTime]::UtcNow }
    $report.pause_seconds=($pauseEnd-$pauseStart).TotalSeconds
  }
  if ($report.restore_error -or @($report.resume | Where-Object {$_.status -eq 'restore_error'}).Count -gt 0) {
    $report.status='restoration_failed'
  }
  Save-Report
  foreach ($process in $held.Values) { $process.Dispose() }
}

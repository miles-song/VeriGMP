#!/usr/bin/env python3
"""Static plan rejection fixtures; no subprocess, process API, ADB or measurements."""
import copy
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
import preflight

HERE = Path(__file__).resolve().parent
plan = preflight.load(HERE/'plan.json')
cases = []
FROZEN = plan['status'] == 'frozen'


def rejected(name, mutate, frozen=None):
    value = copy.deepcopy(plan)
    mutate(value)
    try:
        preflight.check_plan(value, HERE, frozen=FROZEN if frozen is None else frozen)
    except (ValueError, KeyError, TypeError) as error:
        cases.append(dict(case=name, status='pass', rejection=str(error)))
    else:
        raise AssertionError('unsafe plan accepted: '+name)


preflight.check_plan(plan, HERE, frozen=FROZEN)
cases.append(dict(case='static-plan-valid-but-never-grants-root-window', status='pass'))
rejected('prepared-plan-denies-timing', lambda p: p.update(status='prepared',timing_eligibility='pending',pending=['pending']), True)
rejected('plan-cannot-substitute-root-grant', lambda p: p.update(status='frozen', timing_authorized=True, pending=[]), True)
rejected('old-experiment-label', lambda p: p['windows']['F1'].update(experiment='combination'))
rejected('wrong-cpu', lambda p: p.update(cpu=9))
rejected('extended-cap', lambda p: p['windows']['F1'].update(pause_budget_seconds=481))
rejected('reduced-restore-reserve', lambda p: p['windows']['F1'].update(restore_reserve_seconds=74))
rejected('whole-run-retry', lambda p: p['windows']['F1'].update(whole_run_retry=True))
rejected('reduced-cell-matrix', lambda p: p['windows']['F1'].update(total_cells_per_run=85))
rejected('missing-run', lambda p: p['windows']['F1']['runs'].pop())
rejected('changed-runner-argv', lambda p: p['windows']['F1']['runs'][0]['linux_argv'].append('--phase'))
rejected('changed-candidate', lambda p: p['source'].update(head='0'*40))
print(json.dumps(dict(status='pass', cases=cases, emulator_affected=False, benchmark_executed=False,
                     native_build_executed=False, verifier_executed=False), indent=2))

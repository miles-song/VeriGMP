#!/usr/bin/env python3
"""Bind supplied static artifacts and a narrow public metadata map; keep timing unauthorized."""
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
WORK = Path('C:/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108')
REPO = WORK/'VeriGMP-negative-experiments-20261108'
BUILD = WORK/'gates-3a83671-01/build-identity-01/bench-build.json'
LINUX_BUILD = '/mnt/c/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108/gates-3a83671-01/build-identity-01/bench-build.json'
EXPECTED = 'bac446bdf52f2a9ce6babb653019427d3f65ec36c90de68b5a8459ae945a62c4'
IDENTITY = '2ef03539dfb28375a6de5ff09a7fad03245fcc9cd5c26447d775a73900c5ff01'
SOURCE = '3a836713adbb0a6632f5131e8d57c97296d22f62'
PUBLICATION = '97d3ee9b281b5c65d3b4c84caadb51cb79b550c0'


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args]).decode().strip('\n')


def save(name, value, mode='w'):
    with (HERE/name).open(mode, encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


assert sha(BUILD) == EXPECTED
build = load(BUILD)
assert build['identity_receipt']['sha256'] == IDENTITY
assert sha(BUILD.parent/'identity.json') == IDENTITY
assert build['timing_authorized'] is False and build['independent_review_pending'] is True
assert git('rev-parse','HEAD') == PUBLICATION
assert not git('status','--porcelain')
assert git('rev-parse','HEAD:native') == '212dd5d00d4b2159abd4627a6aaec8b16a1157e5'
fields = git('diff','--name-status','-z',SOURCE,PUBLICATION).split('\0')[:-1]
assert len(fields) % 2 == 0
delta = []
for status,name in zip(fields[::2], fields[1::2]):
    assert status == 'A' and name.startswith('experiments/acceptance/fused-interpolation-20261108/static-3a83671/')
    delta.append(dict(status=status,path=name,git_blob=git('rev-parse',PUBLICATION+':'+name)))
mapping = dict(schema='fused-source-publication-map-v1',status='static_pass',timing_authorized=False,
    root_acceptance='pending_explicit_root_grant',source_head=SOURCE,
    source_tree='96bd28b9bc45702e1d7f6c8e9a60d7653f2cd941',native_tree='212dd5d00d4b2159abd4627a6aaec8b16a1157e5',
    publication_head=PUBLICATION,publication_tree=git('rev-parse','HEAD^{tree}'),delta=delta)
save('source-publication-map.json',mapping,'x')
canonical = WORK/'source-map-97d3ee9b-02/source-map.json'
assert sha(canonical) == '4795228610799bdca2aae9bfa3de43bcecebddada99dbc5f4ffadfa07c12a3b1'
mapping_ref = dict(path='/mnt/c/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108/source-map-97d3ee9b-02/source-map.json',
                  sha256=sha(canonical))
plan = load(HERE/'plan.json')
assert plan['status'] == 'prepared' and plan['timing_authorized'] is False
plan['publication'] = dict(head=PUBLICATION,tree=mapping['publication_tree'],map=mapping_ref,
    basis='explicit metadata additions allowlist; source/native/harness are the frozen measurement snapshot')
plan['build'] = dict(path=LINUX_BUILD,sha256=EXPECTED,identity_receipt_sha256=IDENTITY)
for row in plan['windows']['F1']['runs']:
    row['linux_argv'][row['linux_argv'].index('--build')+1] = LINUX_BUILD
plan['support_sha256'] = {name:sha(HERE/name) for name in ('timing_host.ps1','preflight.py','test_restore.ps1','test_plan.py','test_grant.ps1')}
plan['pending'] = ['independent actual-gate and control/codegen Astra Max review bound to this actual build',
    'final timing-eligibility receipt artifact and SHA256',
    'root accepts explicit source/publication map, freezes plan, and obtains all fresh worker ACKs and root GO']
save('plan.json',plan)
request = load(HERE/'request-F1.json')
request.update(plan_sha256=sha(HERE/'plan.json'),build_sha256=EXPECTED,identity_receipt_sha256=IDENTITY,
               publication_map_sha256=mapping_ref['sha256'],publication_map_accepted=False)
save('request-F1.json',request)
eligibility = load(HERE/'timing-eligibility.template.json')
eligibility.update(build_sha256=EXPECTED,identity_receipt_sha256=IDENTITY,
    control_identity_sha256='22b4a942cbb1fd89bb70daf54b3d642ec36dd305dab7436024fe077fddf59630')
save('timing-eligibility.template.json',eligibility)
print(json.dumps(dict(status='prepared',timing_authorized=False,build_sha256=EXPECTED,
    publication_map=mapping_ref,publication_delta_files=len(delta),plan_sha256=sha(HERE/'plan.json')),indent=2))

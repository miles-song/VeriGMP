$ErrorActionPreference='Stop'
$tokens=$null;$parseErrors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseFile((Join-Path $PSScriptRoot 'timing_host.ps1'),[ref]$tokens,[ref]$parseErrors)
if ($parseErrors.Count -gt 0) { throw 'Host script parse failed' }
$try=$ast.EndBlock.Statements | Where-Object { $_ -is [System.Management.Automation.Language.TryStatementAst] } | Select-Object -Last 1
$finallyText=$try.Finally.Extent.Text
$restore=[scriptblock]::Create($finallyText.Substring(1,$finallyText.Length-2))
# A pure stub owns these fake handles. No ntdll entry, process API, ADB,
# measurement, filesystem mutation or real emulator is used by the fixture.
Add-Type @'
using System;using System.Collections.Generic;
public static class VeriGMPWindowNative {
  public static List<long> Resumed = new List<long>();
  public static bool FailSecond = false;
  public static int NtResumeProcess(IntPtr handle) {
    Resumed.Add(handle.ToInt64());return FailSecond && handle.ToInt64()==12 ? -1 : 0;
  }
}
'@
function Read-Identity($Process) { @{pid=$Process.Id;start_ticks=[string]$Process.Id} }
function Check-Identity($Target,$Actual) {
  if ($Actual.pid -ne $Target.pid -or $Actual.start_ticks -ne $Target.start_ticks) { throw 'Fake identity mismatch' }
}
function Adb([string[]]$Arguments,[string]$Name) { $script:adbCalls+=,$Arguments;return 'virtual device is running' }
function Observe([string]$Phase) { $script:observed+=$Phase;return @{} }
function Preflight([string]$Name) { $script:postflight+=$Name;return 'fixture' }
function Save-Report { $script:saved=$true }
$cases=@()
foreach ($case in @('adb-only','both-handles-benchmark-failed','partial-suspension','no-owned-pause','resume-error',
                    'metadata-error-still-restores-owned-handle','originally-stopped-no-change')) {
  [VeriGMPWindowNative]::Resumed.Clear();[VeriGMPWindowNative]::FailSecond=($case -eq 'resume-error')
  $script:adbCalls=@();$script:observed=@();$script:postflight=@();$script:saved=$false
  $held=@{};$targets=@()
  foreach ($id in 11,12) {
    $p=[pscustomobject]@{Id=$id;Handle=[IntPtr]$id;HasExited=$false;disposed=$false}
    $p | Add-Member ScriptMethod Dispose { $this.disposed=$true }
    $held[$id]=$p;$targets+=@{pid=$id;start_ticks=[string]$id}
  }
  $plan=@{emulator=@{targets=$targets}}
  $paused=@()
  if ($case -in @('both-handles-benchmark-failed','partial-suspension','resume-error','metadata-error-still-restores-owned-handle')) {
    $paused+=@{target=$targets[0];suspended_by_this_window=$true}
    $paused+=@{target=$targets[1];suspended_by_this_window=($case -ne 'partial-suspension')}
  }
  if ($case -eq 'metadata-error-still-restores-owned-handle') { $targets[0].start_ticks='changed' }
  $adbPauseAttempted=($case -notin @('no-owned-pause','originally-stopped-no-change'))
  $initialRunning=($case -ne 'originally-stopped-no-change')
  $pauseStart=[DateTime]::UtcNow.AddSeconds(-3)
  $pauseClock=[pscustomobject]@{Elapsed=[TimeSpan]::FromSeconds(3)}
  $report=@{status='failed_owned_benchmark_timeout_fixture';resume=@()}
  . $restore
  $expectedCount=switch($case) {'adb-only'{0};'both-handles-benchmark-failed'{2};'partial-suspension'{1};'no-owned-pause'{0};'resume-error'{2};'metadata-error-still-restores-owned-handle'{2};'originally-stopped-no-change'{0}}
  if ([VeriGMPWindowNative]::Resumed.Count -ne $expectedCount) { throw ('Wrong owned resume count: '+$case) }
  $expectedAdb=if ($adbPauseAttempted) {2}else{0}
  if ($script:adbCalls.Count -ne $expectedAdb) { throw ('Wrong ADB restoration calls: '+$case) }
  if ($case -eq 'resume-error' -and $report.status -ne 'restoration_failed') { throw 'Resume error was hidden' }
  if ($adbPauseAttempted -and $report.avd_restored -ne $true) { throw 'AVD was not restored in fixture' }
  if ($case -eq 'metadata-error-still-restores-owned-handle' -and $report.status -ne 'final_provenance_failed') { throw 'Metadata error was hidden' }
  if (@($held.Values | Where-Object {-not $_.disposed}).Count -gt 0 -or -not $script:saved) { throw 'Restore receipt/disposal missing' }
  $cases+=@{case=$case;status='pass';fake_handles_resumed=@([VeriGMPWindowNative]::Resumed);adb_calls=$script:adbCalls.Count}
}
[ordered]@{status='pass';real_emulator_affected=$false;real_process_calls=$false;host_script_parsed=$true;cases=$cases} | ConvertTo-Json -Depth 7

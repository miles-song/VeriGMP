#!/usr/bin/env python3
"""Read-only fused build/source/tool/host provenance; never runs an arithmetic binary."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import subprocess
import sys

sys.dont_write_bytecode = True
FEATURE = 'experiments/fused-interpolation-20261108/'
MEASURE = 'experiments/arithmetic-precondition-checks-20261108/measure.py'
HEAD = '3a836713adbb0a6632f5131e8d57c97296d22f62'
TREE = '96bd28b9bc45702e1d7f6c8e9a60d7653f2cd941'
NATIVE = '212dd5d00d4b2159abd4627a6aaec8b16a1157e5'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def checked(path, expected):
    require(isinstance(expected, str) and re.fullmatch('[0-9a-f]{64}', expected), 'missing frozen digest')
    actual = digest(path)
    require(actual == expected, 'frozen identity drift: '+str(path))
    return actual


def check_plan(plan, folder, frozen=True):
    require(plan['schema'] == 'fused-interpolation-host-window-v1', 'wrong plan schema')
    require(plan['cpu'] == 8, 'registered CPU changed')
    require((plan['source']['head'], plan['source']['tree'], plan['source']['native_tree']) ==
            (HEAD, TREE, NATIVE), 'registered candidate changed')
    require(set(plan['windows']) == {'F1'}, 'wrong experiment windows')
    spec = plan['windows']['F1']
    require(spec['experiment'] == 'fused-interpolation' and spec['pause_budget_seconds'] == 480 and
            spec['restore_reserve_seconds'] == 75 and spec['command_teardown_seconds'] == 15,
            'registered window bound changed')
    require(spec['total_cells_per_run'] == 86 and spec['paths_per_cell'] == 3 and
            spec['samples_per_path_cell'] == 7 and spec['minimum_accepted_sample_ns'] == 10_000_000 and
            spec['calibration_threshold_ns'] == 20_000_000 and
            spec['whole_run_retry'] is False, 'registered measurement policy changed')
    require(len(spec['runs']) == 2, 'exactly two independent runs required')
    build_path = plan['build']['path'] or '<PENDING_FROZEN_BENCH_BUILD_ABSOLUTE_LINUX_PATH>'
    for index, run in enumerate(spec['runs'], 1):
        name = 'fused-run-'+str(index)
        run_id = 'fused-interpolation-cpu8-20261109-run-'+str(index)
        expected = [plan['execution_tools']['python']['path'], '-B',
                    str(PurePosixPath(plan['source']['repo'])/MEASURE),
                    '--build', build_path, '--output', spec['linux_output']+'/'+name,
                    '--run-id', run_id, '--cpu', '8']
        require(run['name'] == name and run['run_id'] == run_id and run['linux_argv'] == expected and
                run['minimum_remaining_seconds'] == 140, 'registered run command changed')
    for name, value in plan['support_sha256'].items():
        require(Path(name).name == name, 'support path must be local')
        checked(Path(folder)/name, value)
    if frozen:
        require(plan['status'] == 'frozen' and plan['timing_authorized'] is False and
                plan['timing_eligibility'] == 'READY',
                'frozen eligibility is required; the plan itself never authorizes a quiet window')
        require(not plan['pending'], 'unresolved frozen-plan fields')
        for value in (plan['build']['sha256'], plan['build']['identity_receipt_sha256'],
                      plan['reviews']['timing_eligibility']['sha256']):
            require(isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value), 'pending build/review digest')
        require(isinstance(plan['build']['path'], str) and PurePosixPath(plan['build']['path']).is_absolute(),
                'pending build path')
    else:
        require(plan['status'] == 'prepared' and plan['timing_authorized'] is False and plan['pending'],
                'template must remain explicitly pending')
    return spec


def run(argv, timeout=30):
    result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout, check=True)
    return result.stdout.decode(), result.stderr.decode()


def optional(path):
    try:
        return Path(path).read_text().strip()
    except OSError as error:
        return {'unavailable': repr(error)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--check-template', action='store_true')
    parser.add_argument('--check-build-only', action='store_true', help='prepared read-only artifact gate; never grants timing')
    parser.add_argument('--check-eligibility', action='store_true', help='frozen read-only provenance; root grant still required')
    args = parser.parse_args()
    require(sum((args.check_template,args.check_build_only,args.check_eligibility)) <= 1, 'choose one static check')
    require(not args.output.exists(), 'use a fresh provenance receipt')
    plan = load(args.plan)
    report = dict(status='running', utc=datetime.now(timezone.utc).isoformat(),
                  plan_sha256=digest(args.plan), benchmark_executed=False,
                  calibration_executed=False, verifier_executed=False, native_build_executed=False)
    try:
        check_plan(plan, args.plan.parent, frozen=not (args.check_template or args.check_build_only))
        if args.check_template:
            report.update(status='prepared', timing_authorized=False, pending=plan['pending'])
            return
        source = plan['source']
        repo = Path(source['repo'])
        git = plan['execution_tools']['git']['path']
        checked(repo/'.git', source['dot_git_sha256'])
        require((repo/'.git').read_text().strip() == source['dot_git_identity'], 'linked-worktree pointer changed')
        git_command = [git, '--no-optional-locks', '--git-dir='+source['wsl_git_dir'], '--work-tree='+str(repo)]
        for name, row in plan['execution_tools'].items():
            checked(row['path'], row['sha256'])
        for key, ref in (('head', source['head']), ('tree', source['head']+'^{tree}'),
                         ('native_tree', source['head']+':native')):
            text, _ = run(git_command+['rev-parse', ref])
            require(text.strip() == source[key], 'immutable measurement source changed: '+key)
        for key, ref in (('head','HEAD'), ('tree','HEAD^{tree}')):
            text, _ = run(git_command+['rev-parse', ref])
            require(text.strip() == plan['publication'][key], 'frozen publication mapping changed: '+key)
        text, _ = run(git_command+['rev-parse', 'HEAD:native'])
        require(text.strip() == source['native_tree'], 'publication changed measured native files')
        run(git_command+['merge-base', '--is-ancestor', source['head'], plan['publication']['head']])
        mapping_ref = plan['publication']['map']
        checked(mapping_ref['path'], mapping_ref['sha256'])
        mapping = load(mapping_ref['path'])
        require(mapping['schema'] == 'fused-interpolation-source-publication-map-v1' and
                mapping['status'] == 'source_publication_map_pass' and
                mapping['source_head'] == HEAD and mapping['source_tree'] == TREE and mapping['native_tree_both'] == NATIVE and
                mapping['publication_head'] == plan['publication']['head'] and
                mapping['publication_tree'] == plan['publication']['tree'] and mapping['working_tree_clean'] is True and
                mapping['build']['sha256'] == plan['build']['sha256'] and
                mapping['identity']['sha256'] == plan['build']['identity_receipt_sha256'], 'publication source map differs')
        checked(mapping['driver']['path'], mapping['driver']['sha256'])
        text, _ = run(git_command+['diff', '--name-status', '-z', HEAD, plan['publication']['head']])
        fields = text.split('\0')[:-1] if text else []
        require(len(fields) % 2 == 0, 'unsupported publication change record')
        delta = list(zip(fields[::2], fields[1::2]))
        require(delta == [('A',name) for name in mapping['publication_delta']] and
                all(status == 'A' and path.startswith('experiments/acceptance/fused-interpolation-20261108/static-3a83671/')
                    for status,path in delta), 'publication changed paths outside the explicit metadata allowlist')
        for name, row in mapping['publication_delta'].items():
            text, _ = run(git_command+['rev-parse', plan['publication']['head']+':'+name])
            require(text.strip() == row['blob'], 'publication blob changed')
        text, _ = run(git_command+['status', '--porcelain'])
        require(not text.strip(), 'public checkout is not clean')
        for relative, expected in source['inputs_sha256'].items():
            checked(repo/relative, expected)
        validator_path = repo/FEATURE/'raw_validate.py'
        spec = importlib.util.spec_from_file_location('frozen_fused_raw_validate', validator_path)
        validator = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(validator)
        build_row = plan['build']
        build, identity = validator.validate_build(Path(build_row['path']).read_bytes(), build_row['sha256'])
        require(build['source_head'] == HEAD and build['source_tree'] == TREE, 'build belongs to another candidate')
        require(build['identity_receipt']['sha256'] == build_row['identity_receipt_sha256'], 'identity receipt differs')
        require(identity['producers']['candidate']['verified_items'] == 369, 'candidate producer summary changed')
        for relative, row in identity['sources']['candidate']['files'].items():
            checked(repo/relative, row['sha256'])
        for relative, row in identity['inputs'].items():
            checked(repo/relative, row['sha256'])
        checked(Path(sys.executable).resolve(), identity['tools']['python']['sha256'])
        require(identity['inputs'][MEASURE]['sha256'] == source['inputs_sha256'][MEASURE], 'runner differs from build')
        # This is the real, unstubbed artifact validation above, not its synthetic self-check.
        report['unstubbed_validate_build'] = dict(status='pass', build_sha256=build_row['sha256'],
            identity_receipt_sha256=build_row['identity_receipt_sha256'],
            native_trees={name:row['native_tree'] for name,row in identity['sources'].items()},
            verified_items={name:row['verified_items'] for name,row in identity['producers'].items()})
        if args.check_build_only:
            report.update(status='prepared_build_validated_timing_pending', timing_authorized=False,
                          source=source, publication=plan['publication'], pending=plan['pending'])
            return
        raw_review = plan['reviews']['raw_protocol']
        validator.artifact(raw_review)
        eligibility = validator.strict_json(validator.artifact(plan['reviews']['timing_eligibility']))
        ready = 'READY_FOR_REGISTERED_TIMING_SUBJECT_TO_ROOT_QUIET_WINDOW_GRANT'
        require(eligibility['schema'] == 'independent-review-seal-v1' and eligibility['verdict'] == ready and
                (eligibility['source'],eligibility['tree'],eligibility['native_tree']) == (HEAD,TREE,NATIVE) and
                eligibility['publication'] == plan['publication']['head'] and
                eligibility['publication_tree'] == plan['publication']['tree'] and
                eligibility['source_publication_map_sha256'] == mapping_ref['sha256'] and
                eligibility['build_sha256'] == build_row['sha256'] and
                eligibility['identity_sha256'] == build_row['identity_receipt_sha256'] and
                eligibility['raw_protocol'] == 'READY' and eligibility['actual_gates_codegen'] == 'READY',
                'actual-build independent timing review is pending or mismatched')
        review = validator.strict_json(validator.artifact(plan['reviews']['timing_review']))
        require(plan['reviews']['timing_review']['sha256'] == eligibility['review_sha256'] and
                review['schema'] == 'independent-fused-timing-eligibility-review-v1' and review['verdict'] == ready and
                review['arithmetic_proof_runtime_source'] == dict(head=HEAD,tree=TREE,native_tree=NATIVE) and
                review['build_sha256'] == build_row['sha256'] and review['identity_sha256'] == build_row['identity_receipt_sha256'] and
                review['prior_raw_review_receipt_sha256'] == raw_review['sha256'] and
                review['actual_unstubbed_build_validation'] == 'PASS' and review['actual_untimed_gates'] == 'READY' and
                review['actual_codegen_review'] == 'READY_WITH_DISCLOSED_LAYOUT_CONFOUND', 'review conclusions do not match this build')
        manifest = validator.strict_json(validator.artifact(plan['reviews']['timing_manifest']))
        require(plan['reviews']['timing_manifest']['sha256'] == eligibility['manifest_sha256'] and
                plan['reviews']['timing_archive']['sha256'] == eligibility['archive_sha256'], 'independent review seal differs')
        validator.artifact(plan['reviews']['timing_archive'])
        review_folder = Path(plan['reviews']['timing_manifest']['path']).parent
        for name,row in manifest['files'].items():
            require(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts, 'invalid review member path')
            checked(review_folder/name, row['sha256'])
        report['independent_review'] = dict(verdict=ready,receipt_sha256=plan['reviews']['timing_eligibility']['sha256'],
            review_sha256=plan['reviews']['timing_review']['sha256'],
            causal_scope=review['causal_scope'],registered_conditions=review['registered_conditions'],
            performance_acceptance=review['performance_acceptance'])
        linked = []
        for label, row in build['binaries'].items():
            text, error = run([plan['execution_tools']['ldd']['path'], row['path']])
            match = re.search(r'libgmp\.so\.10\s*=>\s*(\S+)', text)
            require(match is not None and match[1] == row['gmp_path'] == plan['loaded_gmp']['path'],
                    'resolved GMP path drift: '+label)
            value = checked(match[1], row['gmp_sha256'])
            require(value == plan['loaded_gmp']['sha256'], 'resolved GMP hash drift')
            linked.append(dict(cell=label, binary_sha256=row['sha256'], gmp_path=match[1],
                gmp_realpath=str(Path(match[1]).resolve()), gmp_sha256=value, ldd_stdout=text, ldd_stderr=error))
        cpu = plan['cpu']
        affinity = sorted(os.sched_getaffinity(0))
        require(affinity == plan['linux_host']['available_affinity'] and cpu in affinity, 'available CPU affinity drift')
        require(optional(f'/sys/devices/system/cpu/cpu{cpu}/online') == '1', 'registered CPU is offline')
        siblings = optional(f'/sys/devices/system/cpu/cpu{cpu}/topology/thread_siblings_list')
        require(siblings == plan['linux_host']['cpu_siblings'], 'registered SMT topology changed')
        require(list(platform.uname()) == plan['linux_host']['uname'], 'WSL host/kernel identity changed')
        ps, ps_error = run([plan['execution_tools']['ps']['path'], '-eo', 'pid,ppid,stat,pcpu,comm,args'])
        report.update(status='pass', build_sha256=build_row['sha256'], source=source, publication=plan['publication'],
            binaries=linked, cpu=cpu, affinity=affinity, cpu_siblings=siblings,
            uname=list(platform.uname()), python=sys.version, python_executable=str(Path(sys.executable).resolve()),
            python_sha256=digest(Path(sys.executable).resolve()), linux_process_snapshot=ps, linux_ps_stderr=ps_error,
            proc_stat=optional('/proc/stat'), proc_loadavg=optional('/proc/loadavg'),
            proc_cpuinfo=optional('/proc/cpuinfo'), self_status=optional('/proc/self/status'),
            frequency={name:optional(f'/sys/devices/system/cpu/cpu{cpu}/cpufreq/'+name) for name in
                ('scaling_governor','scaling_cur_freq','scaling_min_freq','scaling_max_freq')},
            thermal={str(path):optional(path) for path in sorted(Path('/sys/class/thermal').glob('thermal_zone*/temp'))},
            dynamic_loader_environment={name:os.environ.get(name) for name in ('LD_LIBRARY_PATH','LD_PRELOAD','LD_AUDIT')},
            runner_affinity_policy='frozen original measure.invoke sets each child affinity to {8}; no runner changes')
        if args.check_eligibility:
            report.update(status='frozen_eligible_pending_root_grant', timing_authorized=False)
    except BaseException as error:
        report.update(status='fail', failure=repr(error))
        raise
    finally:
        with args.output.open('x', encoding='utf-8') as stream:
            json.dump(report, stream, indent=2)
            stream.write('\n')
        print(json.dumps(dict(status=report['status'], output=str(args.output),
                              benchmark_executed=False, calibration_executed=False)))


if __name__ == '__main__':
    main()

# Fused interpolation measurement window

Status: **frozen; independent static timing eligibility READY; timing_authorized=false;
fresh root quiet-window grant pending; measured performance pending.**

This directory prepares one CPU-8 host quiet window, F1, containing two independent
86-cell runs. The static plan itself never authorizes a quiet window;
`request-F1.json` remains ungranted and is rejected. The frozen build's own `timing_authorized=false` and
`independent_review_pending=true` remain historical static-receipt facts; its
bytes are never rewritten to grant timing.

The measurement source is commit `3a836713adbb0a6632f5131e8d57c97296d22f62`,
tree `96bd28b9bc45702e1d7f6c8e9a60d7653f2cd941`, native tree
`212dd5d00d4b2159abd4627a6aaec8b16a1157e5`. The separately recorded publication is
`97d3ee9b281b5c65d3b4c84caadb51cb79b550c0`, tree
`639356e5233cc1456ad4de2cfe728a3b3894e1f3`. Its only allowed delta is the eleven
added files under `experiments/acceptance/fused-interpolation-20261108/static-3a83671/`.
The source/publication map is the external author receipt
`source-map-97d3ee9b-02/source-map.json`, SHA-256
`4795228610799bdca2aae9bfa3de43bcecebddada99dbc5f4ffadfa07c12a3b1`.
Root acceptance of that exact map is a separate required grant field.

The build is
`C:/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108/gates-3a83671-01/build-identity-01/bench-build.json`,
SHA-256 `bac446bdf52f2a9ce6babb653019427d3f65ec36c90de68b5a8459ae945a62c4`.
Its identity receipt SHA-256 is
`2ef03539dfb28375a6de5ff09a7fad03245fcc9cd5c26447d775a73900c5ff01`.
The preflight uses the actual `fused-interpolation-bench-build-v1` and
`fused-interpolation-identity-v1` schemas and the frozen source's unstubbed
`raw_validate.validate_build`. It rechecks the two source inventories, 358-item
baseline and 369-item candidate producer logs/exports, tools, inputs, gate
artifacts, library and executable hashes. The existing raw/protocol review
receipt is separately pinned; it cannot stand in for the actual-build review.

The independent timing-eligibility seal is
`E:/3sat/VeriGMP-fused-timing-eligibility-astra-v2-20261109/receipt.json`, SHA-256
`b1d5eab025137690ab99dde178253431c27cc9c0b6ad6072d77bf8ff23b5cdb7`.
Its review SHA-256 is
`4f6768e1acf1db8f2ad0accf0e824afab0f85c43b53dd3cc14c1430a1d08a243`.
The live preflight consumes these actual seal/review schemas and rehashes the
review's complete manifest and archive. The review permits the disclosed
whole-build compiler/layout confound; it permits no attribution solely to
deleted loop visits. It does not grant performance acceptance or promotion.

Remaining operational fields are root's explicit acceptance of the exact
source/publication map and a fresh root quiet-window grant with all workers
quiescent. `timing-eligibility.template.json` references the independent seal;
no replacement review receipt needs to be synthesized. Root's
`timing_review_sha256` field binds the seal SHA-256 `b1d5eab0...`; the plan and
that seal also bind the review, manifest and archive hashes.

The root grant must use schema `fused-interpolation-root-grant-v1`, identify
F1 and CPU 8, set `explicit_root_go=true`, and bind the exact plan, source,
build, identity, timing-review and publication-map hashes. It must list the
complete active-worker roster and one distinct fresh `quiescent` acknowledgment
for every worker, each bound to the same plan hash. The grant and acknowledgments
expire after at most fifteen minutes. `request-F1.json` is an ungranted template.

The planned commands use the unchanged original runner:

```sh
/usr/bin/python3.12 -B /mnt/c/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108/VeriGMP-negative-experiments-20261108/experiments/arithmetic-precondition-checks-20261108/measure.py \
  --build /mnt/c/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108/gates-3a83671-01/build-identity-01/bench-build.json \
  --output /mnt/e/3sat/VeriGMP-fused-measurement-window-20261109-01/measurement-F1-01/fused-run-1 \
  --run-id fused-interpolation-cpu8-20261109-run-1 --cpu 8

/usr/bin/python3.12 -B /mnt/c/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108/VeriGMP-negative-experiments-20261108/experiments/arithmetic-precondition-checks-20261108/measure.py \
  --build /mnt/c/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108/gates-3a83671-01/build-identity-01/bench-build.json \
  --output /mnt/e/3sat/VeriGMP-fused-measurement-window-20261109-01/measurement-F1-01/fused-run-2 \
  --run-id fused-interpolation-cpu8-20261109-run-2 --cpu 8
```

Each complete run retains the fixed 34 forced-full, 26 default-mul and 26
default-square cells, 258 calibrations, 1,806 accepted samples and every short
sample/retry. Original seed, order, seven repetitions, 20 ms calibration and
10 ms accepted-sample thresholds remain fixed. All raw outputs and command
stdout/stderr are retained. A failed or unfavorable whole run is never
automatically retried. Partial/timeout evidence remains incomplete evidence.

F1's combined pause cap is 480 seconds. A monotonic stopwatch limits paused
work to 405 seconds and reserves the full remaining 75 seconds for restoration.
The additional fifteen seconds allowed for relay/GNU-timeout teardown fit
inside the 405-second work budget. The wrapper refuses a next full run when
its registered minimum budget will not fit. It never extends the window or
reduces the registered matrix, sample counts or thresholds. An exceeded cap
is recorded as infrastructure failure.

The only target is the existing `opc_toolchain_api36` AVD, serial
`emulator-5554`, with the freshly captured emulator/QEMU identities in
`identity-read-only.json`. At execution, original process handles are held
and every PID, start time, executable path/hash, parent and command line is
rechecked before mutation. Supported ADB `emu avd pause` is used first. Only
when exact CPU counters still advance is the held-handle NtSuspend/NtResume
fallback used. No ADB process or unrelated process is suspended or stopped.

An originally stopped AVD or already suspended target is preserved by refusing
the window. The `finally` block resumes only successful suspensions owned by
this window, restores its initially running AVD, and records restoration
errors. A metadata observation failure cannot prevent resuming an owned
held handle; it remains a visible provenance failure. No visible background
windows are opened. No power, authentication or security settings are changed.

Before and after each run the preflight rehashes the frozen source/build/tool
artifacts and records resolved GMP, available affinity, CPU-8 SMT topology,
WSL/kernel identity, `/proc/stat`, load, frequency/thermal availability and Linux
process state. Windows observations record process CPU counters, raw host CPU
observations and wrapper affinity outside the benchmark command. The original
runner pins each arithmetic child to CPU 8; its raw `cpu` field is a registered
request, not a new per-child OS-affinity observation. `ldd` records dependency
resolution without executing an arithmetic binary.

`--check-template` and `--check-build-only` are read-only checks of a prepared
plan; `--check-eligibility` checks the final frozen plan. None authorizes timing
or calls ADB, a benchmark, compiler or Verus.
The cross-OS Git pointer is explicitly frozen and converted to a WSL path;
the preflight uses `--no-optional-locks`, an explicit git directory and worktree
instead of changing repository configuration.

After root freezes its exact fresh grant against this plan,
the only host entry point is the pinned PowerShell 7 executable running:

```powershell
& 'E:/3sat/VeriGMP-fused-measurement-window-20261109-01/timing_host.ps1' `
  -Window F1 -RootGrant 'E:/3sat/VeriGMP-fused-measurement-window-20261109-01/root-go-F1.json'
```

Collection status is not performance acceptance. Raw adjudication remains
separate and must independently apply both runs' 15-cell primary and 86-cell
regression gates, as well as the registered cross-run baseline-drift rules.

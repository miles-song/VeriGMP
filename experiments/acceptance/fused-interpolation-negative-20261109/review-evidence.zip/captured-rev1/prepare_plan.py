#!/usr/bin/env python3
"""Create the pending external plan from read-only captured identities; never authorizes timing."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path('C:/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108/VeriGMP-negative-experiments-20261108')
LINUX_REPO = '/mnt/c/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108/VeriGMP-negative-experiments-20261108'
LINUX_HERE = '/mnt/e/3sat/'+HERE.name


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(name):
    return json.loads((HERE/name).read_text(encoding='utf-8-sig'))


def write(name, value):
    with (HERE/name).open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


identity = load('identity-read-only.json')
linux = load('linux-read-only.json')
inputs = [*REPO.glob('experiments/fused-interpolation-20261108/*')]
inputs += [REPO/'experiments/arithmetic-precondition-checks-20261108'/name for name in ('bench.rs','measure.py')]
inputs += [REPO/'AGENTS.md']
input_hashes = {path.relative_to(REPO).as_posix():sha(path) for path in sorted(inputs)
                if path.is_file() and path.suffix in ('.py','.rs','.md')}
support = {name:sha(HERE/name) for name in ('timing_host.ps1','preflight.py','test_restore.ps1','test_plan.py','test_grant.ps1')}
tools = dict(linux['tools'])
tools['python'] = tools.pop('python3')
output = LINUX_HERE+'/measurement-F1-01'
runs = []
for index in (1,2):
    name = 'fused-run-'+str(index)
    run_id = 'fused-interpolation-cpu8-20261109-run-'+str(index)
    runs.append(dict(name=name,run_id=run_id,minimum_remaining_seconds=140,
        linux_argv=[tools['python']['path'],'-B',LINUX_REPO+'/experiments/arithmetic-precondition-checks-20261108/measure.py',
                    '--build','<PENDING_FROZEN_BENCH_BUILD_ABSOLUTE_LINUX_PATH>',
                    '--output',output+'/'+name,'--run-id',run_id,'--cpu','8']))
plan = dict(schema='fused-interpolation-host-window-v1',status='prepared',timing_authorized=False,timing_eligibility='pending',
    cpu=8,wsl_distribution='Ubuntu',
    source=dict(windows_repo=str(REPO),repo=LINUX_REPO,head='3a836713adbb0a6632f5131e8d57c97296d22f62',
        dot_git_sha256=sha(REPO/'.git'),dot_git_identity=(REPO/'.git').read_text().strip(),
        wsl_git_dir='/mnt/e/3sat/VeriGMP/.git/worktrees/VeriGMP-negative-experiments-202611081',
        tree='96bd28b9bc45702e1d7f6c8e9a60d7653f2cd941',native_tree='212dd5d00d4b2159abd4627a6aaec8b16a1157e5',
        baseline_head='4510b46e4010dd287c9cf760f0195f2edc32e1f7',baseline_tree='d8bb9a0f95160a2e260f7b9f276cb4fd0a867778',
        baseline_native_tree='72dc8a5da2cbb7eddcdd26c219d50770e8b73b06',
        baseline_full_producer_items=358,candidate_full_producer_items=369,inputs_sha256=input_hashes),
    publication=dict(head='3a836713adbb0a6632f5131e8d57c97296d22f62',tree='96bd28b9bc45702e1d7f6c8e9a60d7653f2cd941',
        basis='public metadata may be separately frozen; measurement source and native/input bytes stay fixed'),
    build=dict(path=None,sha256=None,identity_receipt_sha256=None),
    reviews=dict(raw_protocol=dict(path='/mnt/e/3sat/VeriGMP-fused-raw-validator-astra-v2-20261109/receipt.json',
        sha256='155451ff4e198e4ef0647399d9fa6af8e905ea12b6605cadef6fceb2b1e0342a'),
        timing_eligibility=dict(path=None,sha256=None)),
    execution_tools=tools,host_tools=load('host-tools-read-only.json'),support_sha256=support,
    loaded_gmp=linux['gmp'],
    linux_host=dict(uname=linux['uname'],available_affinity=linux['affinity'],cpu_siblings=linux['cpu8_siblings']),
    emulator=dict(targets=identity['targets'],identity_captured_utc=identity['utc'],
        adb_path='E:/aigc_plat/.local/mobile-sdk/android/platform-tools/adb.exe',
        adb_sha256=sha('E:/aigc_plat/.local/mobile-sdk/android/platform-tools/adb.exe'),
        serial='emulator-5554',avd='opc_toolchain_api36',
        preferred_method='supported adb emu avd pause; require stopped status and unchanged exact CPU counters',
        fallback_method='only original identity held handles NtSuspendProcess/NtResumeProcess if CPU still advances',
        restoration='finally resume only suspensions owned by this window, then restore the initially running AVD'),
    windows=dict(F1=dict(experiment='fused-interpolation',pause_budget_seconds=480,restore_reserve_seconds=75,
        command_teardown_seconds=15,
        windows_output=str(HERE/'measurement-F1-01'),linux_output=output,runs=runs,
        paths_per_cell=3,total_cells_per_run=86,independent_run_count=2,samples_per_path_cell=7,
        minimum_accepted_sample_ns=10_000_000,calibration_threshold_ns=20_000_000,
        calibrations_per_run=258,accepted_samples_per_run=1806,whole_run_retry=False)),
    pending=['frozen actual bench-build.json absolute Linux path and SHA256',
        'actual identity_receipt SHA256 from that build',
        'real unstubbed validate_build + actual gates + control/codegen independent Astra Max review',
        'final timing-eligibility receipt artifact and SHA256, bound to actual source/build/control identity',
        'freeze plan, update both --build argv values, fresh complete worker acknowledgments and explicit root grant'])
write('plan.json',plan)
request = dict(schema='fused-interpolation-root-grant-v1',status='pending',explicit_root_go=False,
    window='F1',plan_sha256=sha(HERE/'plan.json'),source_head=plan['source']['head'],source_tree=plan['source']['tree'],
    native_tree=plan['source']['native_tree'],build_sha256=None,identity_receipt_sha256=None,timing_review_sha256=None,
    cpu=8,maximum_pause_seconds=480,independent_prereviews='pending',all_active_workers_quiescent=False,
    active_worker_roster=[],worker_acknowledgements=[],timing_authorized=False,
    granted_by=None,granted_utc=None,expires_utc=None)
write('request-F1.json',request)
write('timing-eligibility.template.json',dict(schema='fused-interpolation-timing-eligibility-v1',status='pending',
    source_head=plan['source']['head'],source_tree=plan['source']['tree'],native_tree=plan['source']['native_tree'],
    build_sha256=None,identity_receipt_sha256=None,raw_protocol_review=plan['reviews']['raw_protocol'],
    independent_model='gpt-6-astra',independent_effort='max',unstubbed_validate_build_verdict='pending',
    actual_gate_review='pending',control_codegen_review='pending',control_identity_sha256=None,review_artifacts=[]))
print(json.dumps(dict(status='prepared',timing_authorized=False,plan_sha256=sha(HERE/'plan.json'),support_sha256=support),indent=2))

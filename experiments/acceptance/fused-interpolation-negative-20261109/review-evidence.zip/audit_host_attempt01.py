"""Audit frozen host/provenance records and capture them; no process APIs or command execution."""
from pathlib import Path
from datetime import datetime, timedelta
import hashlib
import json
import re

OUT=Path(__file__).resolve().parent
ROOT=Path(r'E:\3sat\VeriGMP-fused-measurement-window-20261109-02')
DATA=ROOT/'measurement-F1-02'
PRIOR=Path(r'E:\3sat\VeriGMP-fused-timing-eligibility-astra-v2-20261109')
PLAN='60832089950628d291458eabd6e5424c549714f5a8842f837a15041608de8242'
GRANT='8761ad80973677ceaa5b7524c8eacd1be4abb8314f9c92eb9f67daf238dce891'
HOST='66974bfa218ab35442d3d0006fc15d9b412e1104fe62d803bb72c12f8fcef6a1'
FREEZE='29946c99d968c26b8216b34040d7769578db1d9d716690699b33228a1a965b27'
BUILD='bac446bdf52f2a9ce6babb653019427d3f65ec36c90de68b5a8459ae945a62c4'
IDENTITY='2ef03539dfb28375a6de5ff09a7fad03245fcc9cd5c26447d775a73900c5ff01'
READY='b1d5eab025137690ab99dde178253431c27cc9c0b6ad6072d77bf8ff23b5cdb7'
MAP='4795228610799bdca2aae9bfa3de43bcecebddada99dbc5f4ffadfa07c12a3b1'
SOURCE='3a836713adbb0a6632f5131e8d57c97296d22f62'
PUBLICATION='97d3ee9b281b5c65d3b4c84caadb51cb79b550c0'
capture={}
def sha(data): return hashlib.sha256(data).hexdigest()
def checked(path,digest=None):
    data=path.read_bytes()
    if digest: assert sha(data)==digest,str(path)
    capture[str(path)]=dict(sha256=sha(data),bytes=len(data))
    return data
def read(path,digest=None): return json.loads(checked(path,digest))
def save(name,data): (OUT/name).write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
def utc(value): return datetime.fromisoformat(value.replace('Z','+00:00'))
def win(path):
    if path.startswith('/mnt/'):
        assert path[6]=='/'
        return Path(path[5].upper()+':/'+path[7:])
    return Path(path)
def copy(source,target):
    data=checked(source); target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(data)
    assert sha(target.read_bytes())==sha(data)
def differences(a,b,path=()):
    if isinstance(a,dict) and isinstance(b,dict):
        return sum((differences(a.get(k),b.get(k),path+(k,)) for k in sorted(set(a)|set(b))),[])
    if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
        return sum((differences(x,y,path+(str(i),)) for i,(x,y) in enumerate(zip(a,b))),[])
    return [] if a==b else ['.'.join(path)]

plan=read(ROOT/'plan.json',PLAN); grant=read(ROOT/'root-go-F1.json',GRANT)
host=read(DATA/'host-receipt.json',HOST); freeze=read(DATA/'root-measurement-freeze.json',FREEZE)
ready=read(PRIOR/'receipt.json',READY)
assert plan['source']['head']==SOURCE and plan['publication']['head']==PUBLICATION
assert ready['source']==SOURCE and ready['publication']==PUBLICATION
assert plan['publication']['map']['sha256']==MAP==ready['source_publication_map_sha256']
assert host['source_head']==SOURCE and host['publication_head']==PUBLICATION
for key,value in dict(plan_sha256=PLAN,root_grant_sha256=GRANT,build_sha256=BUILD).items():
    assert host[key]==value and freeze[key]==value
assert host['identity_receipt_sha256']==IDENTITY and host['timing_review_sha256']==READY
assert host['cpu']==plan['cpu']==grant['cpu']==8
assert host['status']=='registered_runs_collected_performance_pending_analysis'
assert host['benchmark_launched'] is True and host['avd_restored'] is True
assert host['pause_seconds']==freeze['pause_seconds']==342.2724186 and host['pause_seconds']<=480
assert not any('error' in k or k=='failure' for k in host)
assert grant['explicit_root_go'] and grant['timing_authorized'] and grant['granted_by']=='/root'
assert grant['plan_sha256']==PLAN and grant['build_sha256']==BUILD
assert grant['identity_receipt_sha256']==IDENTITY and grant['timing_review_sha256']==READY
assert grant['publication_map_sha256']==MAP and grant['publication_map_accepted']
assert grant['maximum_pause_seconds']==480 and grant['all_active_workers_quiescent']
assert utc(grant['granted_utc'])<=utc(host['start_utc'])<utc(host['stop_utc'])<utc(grant['expires_utc'])
assert utc(host['start_utc'])-utc(grant['granted_utc'])<timedelta(minutes=15)
assert set(grant['active_worker_roster'])=={r['worker'] for r in grant['worker_acknowledgements']}
assert len(grant['active_worker_roster'])==len(set(grant['active_worker_roster']))==len(grant['worker_acknowledgements'])==3
for ack in grant['worker_acknowledgements']:
    assert ack['status']=='quiescent' and ack['plan_sha256']==PLAN
    assert timedelta()<=utc(grant['granted_utc'])-utc(ack['acknowledged_utc'])<timedelta(minutes=15)
for name,digest in plan['support_sha256'].items(): checked(ROOT/name,digest)
for row in plan['host_tools'].values(): checked(Path(row['path']),row['sha256'])
for row in plan['reviews'].values(): checked(win(row['path']),row['sha256'])
checked(win(plan['publication']['map']['path']),MAP)
build=read(win(plan['build']['path']),BUILD)
checked(win(build['identity_receipt']['path']),IDENTITY)
for row in build['binaries'].values(): checked(win(row['path']),row['sha256'])

expected_names=['avd-name-before','avd-status-before','initial-provenance','avd-pause','avd-status-paused',
    'fused-run-1-provenance-before','fused-run-1','fused-run-1-provenance-after',
    'fused-run-2-provenance-before','fused-run-2','fused-run-2-provenance-after',
    'avd-resume-finally','avd-status-after-finally','final-provenance-after-restore']
assert [r['name'] for r in host['commands']]==expected_names
commands={r['name']:r for r in host['commands']}
previous=utc(host['start_utc'])
for row in host['commands']:
    assert row['returncode']==0 and not row.get('timed_out',False)
    assert previous<=utc(row['start_utc'])<=utc(row['stop_utc'])
    assert (utc(row['stop_utc'])-utc(row['start_utc'])).total_seconds()<row['timeout_seconds']
    previous=utc(row['stop_utc'])
    checked(DATA/(row['name']+'.stdout.log'),row['stdout_sha256'])
    assert checked(DATA/(row['name']+'.stderr.log'),row['stderr_sha256'])==b''
for n in (1,2):
    spec=plan['windows']['F1']['runs'][n-1]; cmd=commands[f'fused-run-{n}']
    prefix=[plan['host_tools']['wsl']['path'],'--distribution','Ubuntu','--exec',
            plan['execution_tools']['timeout']['path'],'--signal=TERM','--kill-after=5s']
    assert cmd['argv'][:7]==prefix and cmd['argv'][8:]==spec['linux_argv']
    assert cmd['argv'][7].endswith('s') and int(cmd['argv'][7][:-1])+15==cmd['timeout_seconds']
    assert utc(commands[f'fused-run-{n}-provenance-before']['stop_utc'])<utc(cmd['start_utc'])
    assert utc(cmd['stop_utc'])<utc(commands[f'fused-run-{n}-provenance-after']['start_utc'])
    result=read(DATA/(f'fused-run-{n}.stdout.log'))
    assert result['status']=='pass' and result['cells']==86 and result['run']==spec['run_id']
    checked(DATA/f'fused-run-{n}/measurement.json',result['report_sha256'])
assert commands['fused-run-1']['windows_pid']!=commands['fused-run-2']['windows_pid']
assert utc(commands['fused-run-1']['stop_utc'])<utc(commands['fused-run-2']['start_utc'])
assert utc(commands['avd-pause']['start_utc'])<utc(commands['fused-run-1']['start_utc'])
assert utc(commands['fused-run-2-provenance-after']['stop_utc'])<utc(commands['avd-resume-finally']['start_utc'])
assert b'virtual device is running' in checked(DATA/'avd-status-before.stdout.log')
assert b'virtual device is stopped' in checked(DATA/'avd-status-paused.stdout.log')
assert b'virtual device is running' in checked(DATA/'avd-status-after-finally.stdout.log')

provenance=[]
assert len(host['preflight_receipts'])==6
for ref in host['preflight_receipts']:
    p=read(Path(ref['path']),ref['sha256']); name=ref['name']
    assert p['status']=='pass' and p['plan_sha256']==PLAN and p['build_sha256']==BUILD
    assert p['source']==plan['source'] and p['publication']==plan['publication']
    assert all(p[k] is False for k in ('benchmark_executed','calibration_executed','verifier_executed','native_build_executed'))
    assert p['unstubbed_validate_build']['status']=='pass'
    assert p['unstubbed_validate_build']['build_sha256']==BUILD
    assert p['unstubbed_validate_build']['identity_receipt_sha256']==IDENTITY
    assert p['unstubbed_validate_build']['verified_items']==dict(baseline=358,candidate=369)
    assert p['independent_review']['receipt_sha256']==READY
    assert p['affinity']==plan['linux_host']['available_affinity'] and p['cpu']==8
    assert p['cpu_siblings']==plan['linux_host']['cpu_siblings']=='8-9'
    assert p['uname']==plan['linux_host']['uname']
    assert p['python_sha256']==plan['execution_tools']['python']['sha256']
    assert p['dynamic_loader_environment']==dict(LD_LIBRARY_PATH=None,LD_PRELOAD=None,LD_AUDIT=None)
    assert p['linux_ps_stderr']=='' and len(p['binaries'])==2
    heavy=[line for line in p['linux_process_snapshot'].splitlines() if re.search(r'(^|[ /])(verus|rust_verify|rustc|cargo|z3|baseline-bench|candidate-bench)([ /]|$)',line)]
    assert not heavy,heavy
    for binary in p['binaries']:
        frozen=build['binaries'][binary['cell']]
        assert binary['binary_sha256']==frozen['sha256']
        assert binary['gmp_sha256']==frozen['gmp_sha256']==plan['loaded_gmp']['sha256']
        assert binary['gmp_path']==frozen['gmp_path']==plan['loaded_gmp']['path']
        assert re.search(r'libgmp\.so\.10\s*=>\s*(\S+)',binary['ldd_stdout'])[1]==binary['gmp_path']
        assert binary['gmp_realpath']=='/usr/lib/x86_64-linux-gnu/libgmp.so.10.5.0'
        assert binary['ldd_stderr']==''
    provenance.append(dict(name=name,sha256=ref['sha256'],source_binary_tool_gmp_checks='pass',
        no_recorded_proof_build_or_other_benchmark_process=True,frequency=p['frequency'],thermal=p['thermal']))

targets={t['pid']:t for t in plan['emulator']['targets']}
observations={}
for row in host['observations']:
    p=row['process']; target=targets[p['pid']]
    for key in ('pid','name','start_ticks','path','executable_sha256','parent_pid','command_line'):
        assert p[key]==target[key],key
    assert utc(p['start_utc'])==utc(target['start_utc'])
    observations.setdefault(row['phase'],{})[p['pid']]=p
assert len(observations)==8 and all(set(v)==set(targets) for v in observations.values())
for pid in targets:
    assert not observations['before-pause'][pid]['all_threads_suspended']
    quiet=observations['quiet-observation-1'][pid]['cpu_seconds']
    for phase in ('quiet-observation-1','quiet-observation-2','after-fused-run-1','after-fused-run-2'):
        assert observations[phase][pid]['all_threads_suspended'] and observations[phase][pid]['cpu_seconds']==quiet
    assert not observations['after-finally-restore'][pid]['all_threads_suspended']
assert len(host['resume'])==2 and {r['pid'] for r in host['resume']}==set(targets)
for row in host['resume']:
    assert row['status']=='resumed' and row['nt_status']==0 and row['start_ticks']==targets[row['pid']]['start_ticks']
    assert 'identity_error' not in row
host_obs={r['phase']:r for r in host['host_observations']}
cpu_deltas=[]
for n in (1,2):
    a,b=host_obs[f'fused-run-{n}-before'],host_obs[f'fused-run-{n}-after']
    old={(p['pid'],p['start_utc']):p for p in a['processes']}
    values=[dict(name=p['name'],pid=p['pid'],cpu_seconds=p['cpu_seconds']-old[(p['pid'],p['start_utc'])]['cpu_seconds'])
            for p in b['processes'] if (p['pid'],p['start_utc']) in old]
    assert not any(re.search(r'^(verus|rust_verify|rustc|cargo|z3|baseline-bench|candidate-bench)$',p['name'],re.I) for p in a['processes']+b['processes'])
    cpu_deltas.append(dict(run=n,elapsed_seconds=(utc(b['utc'])-utc(a['utc'])).total_seconds(),
                           top_cpu_deltas=sorted(values,key=lambda p:p['cpu_seconds'],reverse=True)[:12]))

original=read(ROOT/'original-evidence.json')
assert len(original['files_sha256'])==86 and original['benchmark_launched'] is False
assert original['commands']==[] and original['resume']==[]
for path,digest in original['files_sha256'].items(): checked(Path(path),digest)
oldroot=Path(original['original_directory'])
failed=read(Path(original['failed_receipt']),original['failed_receipt_sha256'])
assert failed['benchmark_launched'] is False and failed['commands']==[] and failed['resume']==[]
assert failed['failure']=='Authorized emulator identity changed: 17360/start_utc'
old=(oldroot/'timing_host.ps1').read_text(); new=(ROOT/'timing_host.ps1').read_text()
before="    if ($Actual[$key] -ne $Target.$key) { throw ('Authorized emulator identity changed: '+$Target.pid+'/'+$key) }"
after="    $different=if ($key -eq 'start_utc') {\n      [DateTimeOffset]::Compare([DateTimeOffset](Utc-Time $Actual[$key]),[DateTimeOffset](Utc-Time $Target.$key)) -ne 0\n    } else { $Actual[$key] -ne $Target.$key }\n    if ($different) { throw ('Authorized emulator identity changed: '+$Target.pid+'/'+$key) }"
assert old.count(before)==1 and old.replace(before,after)==new
delta=differences(read(oldroot/'plan.json'),plan)
assert set(delta)=={'support_sha256.timing_host.ps1','support_sha256.test_identity.ps1','windows.F1.windows_output',
                    'windows.F1.linux_output','windows.F1.runs.0.linux_argv.6','windows.F1.runs.1.linux_argv.6'}
regression=read(ROOT/'checks/identity-regression.json')
assert regression['status']=='pass' and len(regression['cases'])==20 and all(r['status']=='pass' for r in regression['cases'])
prep=read(ROOT/'preparation-seal.json')
for name,digest in prep['files_sha256'].items(): checked(ROOT/name,digest)

for path in sorted(ROOT.rglob('*')):
    if path.is_file(): copy(path,OUT/'captured-window'/path.relative_to(ROOT))
for path in original['files_sha256']:
    copy(Path(path),OUT/'captured-rev1'/Path(path).relative_to(oldroot))
for name in ('receipt.json','review.json','manifest.json','evidence.zip','REVIEW.md'):
    copy(PRIOR/name,OUT/'prior-timing-eligibility'/name)
for name in ('raw_validate.py','summarize.py','PROTOCOL.md','RAW_FORMAT.md'):
    row=plan['source']['inputs_sha256']['experiments/fused-interpolation-20261108/'+name]
    path=win(plan['source']['repo'])/'experiments/fused-interpolation-20261108'/name
    checked(path,row); copy(path,OUT/'frozen-protocol'/name)
save('input-capture.json',capture)
result=dict(schema='independent-fused-host-audit-v1',status='pass',source=SOURCE,publication=PUBLICATION,
    build_sha256=BUILD,identity_sha256=IDENTITY,prior_timing_ready_sha256=READY,
    root_freeze_sha256=FREEZE,host_sha256=HOST,plan_sha256=PLAN,root_grant_sha256=GRANT,
    ordered_successful_host_commands=14,distinct_ordered_measurement_processes=2,provenance_checks=provenance,
    source_binary_tool_affinity_and_resolved_gmp_binding='pass',
    gmp_evidence='ldd resolution, canonical path/realpath and SHA before and after each run; LD_LIBRARY_PATH, LD_PRELOAD and LD_AUDIT absent',
    grant_fresh_and_roster_complete=True,emulator_identity_observations=16,emulator_cpu_unchanged_during_window=True,
    pause_seconds=host['pause_seconds'],cap_seconds=480,emulator_restored=True,exact_process_resumes=2,
    prior_failed_before_adb_and_timing=True,prior_files_hash_checked=86,
    rev2_only_canonical_time_fix_and_output_path=True,rev2_plan_changed_fields=delta,identity_fixture_cases=20,
    host_activity=cpu_deltas,
    scope='Quiet means root-coordinated absence of concurrent proof/build/other benchmarks and suspended exact emulator processes; ordinary host-service activity remains recorded, not post-hoc excluded.',
    performance_verdict_not_overridden_by_host_observations=True,
    benchmark_executed=False,calibration_executed=False,compiler_executed=False,verifier_executed=False,process_management=False)
save('host-and-provenance-audit.json',result)
print(json.dumps({k:v for k,v in result.items() if k not in ('provenance_checks','host_activity')},indent=2))

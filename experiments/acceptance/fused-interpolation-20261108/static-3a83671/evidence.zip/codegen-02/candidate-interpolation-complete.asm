   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	50                   	push   %rax
   b:	48 39 ce             	cmp    %rcx,%rsi
   e:	0f 85 79 04 00 00    	jne    48d <verigmp::toom_interpolate::interpolate+0x48d>
  14:	4c 39 ce             	cmp    %r9,%rsi
  17:	0f 85 70 04 00 00    	jne    48d <verigmp::toom_interpolate::interpolate+0x48d>
  1d:	48 39 74 24 70       	cmp    %rsi,0x70(%rsp)
  22:	0f 85 65 04 00 00    	jne    48d <verigmp::toom_interpolate::interpolate+0x48d>
  28:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  2d:	48 39 f1             	cmp    %rsi,%rcx
  30:	0f 87 70 04 00 00    	ja     4a6 <verigmp::toom_interpolate::interpolate+0x4a6>
  36:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  3b:	48 39 f0             	cmp    %rsi,%rax
  3e:	0f 87 62 04 00 00    	ja     4a6 <verigmp::toom_interpolate::interpolate+0x4a6>
  44:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
  49:	74 17                	je     62 <verigmp::toom_interpolate::interpolate+0x62>
  4b:	48 85 f6             	test   %rsi,%rsi
  4e:	0f 84 2a 04 00 00    	je     47e <verigmp::toom_interpolate::interpolate+0x47e>
  54:	48 83 fe 01          	cmp    $0x1,%rsi
  58:	75 22                	jne    7c <verigmp::toom_interpolate::interpolate+0x7c>
  5a:	45 31 db             	xor    %r11d,%r11d
  5d:	45 31 c9             	xor    %r9d,%r9d
  60:	eb 7c                	jmp    de <verigmp::toom_interpolate::interpolate+0xde>
  62:	48 85 f6             	test   %rsi,%rsi
  65:	0f 84 13 04 00 00    	je     47e <verigmp::toom_interpolate::interpolate+0x47e>
  6b:	48 83 fe 01          	cmp    $0x1,%rsi
  6f:	75 7e                	jne    ef <verigmp::toom_interpolate::interpolate+0xef>
  71:	45 31 c9             	xor    %r9d,%r9d
  74:	45 31 d2             	xor    %r10d,%r10d
  77:	e9 cf 00 00 00       	jmp    14b <verigmp::toom_interpolate::interpolate+0x14b>
  7c:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
  83:	ff ff 0f 
  86:	49 21 f2             	and    %rsi,%r10
  89:	45 31 db             	xor    %r11d,%r11d
  8c:	45 31 c9             	xor    %r9d,%r9d
  8f:	90                   	nop
  90:	4a 8b 1c cf          	mov    (%rdi,%r9,8),%rbx
  94:	4a 2b 1c ca          	sub    (%rdx,%r9,8),%rbx
  98:	40 0f 92 c5          	setb   %bpl
  9c:	4c 29 db             	sub    %r11,%rbx
  9f:	41 0f 92 c3          	setb   %r11b
  a3:	41 08 eb             	or     %bpl,%r11b
  a6:	45 0f b6 db          	movzbl %r11b,%r11d
  aa:	4a 89 1c ca          	mov    %rbx,(%rdx,%r9,8)
  ae:	4a 8b 5c cf 08       	mov    0x8(%rdi,%r9,8),%rbx
  b3:	4a 2b 5c ca 08       	sub    0x8(%rdx,%r9,8),%rbx
  b8:	40 0f 92 c5          	setb   %bpl
  bc:	4c 29 db             	sub    %r11,%rbx
  bf:	41 0f 92 c3          	setb   %r11b
  c3:	41 08 eb             	or     %bpl,%r11b
  c6:	45 0f b6 db          	movzbl %r11b,%r11d
  ca:	4a 89 5c ca 08       	mov    %rbx,0x8(%rdx,%r9,8)
  cf:	49 83 c1 02          	add    $0x2,%r9
  d3:	4d 39 ca             	cmp    %r9,%r10
  d6:	75 b8                	jne    90 <verigmp::toom_interpolate::interpolate+0x90>
  d8:	40 f6 c6 01          	test   $0x1,%sil
  dc:	74 79                	je     157 <verigmp::toom_interpolate::interpolate+0x157>
  de:	4e 8b 14 cf          	mov    (%rdi,%r9,8),%r10
  e2:	4e 03 1c ca          	add    (%rdx,%r9,8),%r11
  e6:	4d 29 da             	sub    %r11,%r10
  e9:	4e 89 14 ca          	mov    %r10,(%rdx,%r9,8)
  ed:	eb 68                	jmp    157 <verigmp::toom_interpolate::interpolate+0x157>
  ef:	49 bb fe ff ff ff ff 	movabs $0xffffffffffffffe,%r11
  f6:	ff ff 0f 
  f9:	49 21 f3             	and    %rsi,%r11
  fc:	45 31 c9             	xor    %r9d,%r9d
  ff:	45 31 d2             	xor    %r10d,%r10d
 102:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 109:	1f 84 00 00 00 00 00 
 110:	31 db                	xor    %ebx,%ebx
 112:	4e 03 0c d2          	add    (%rdx,%r10,8),%r9
 116:	0f 92 c3             	setb   %bl
 119:	4e 03 0c d7          	add    (%rdi,%r10,8),%r9
 11d:	4e 89 0c d2          	mov    %r9,(%rdx,%r10,8)
 121:	4a 13 5c d2 08       	adc    0x8(%rdx,%r10,8),%rbx
 126:	41 0f 92 c1          	setb   %r9b
 12a:	45 0f b6 c9          	movzbl %r9b,%r9d
 12e:	4a 03 5c d7 08       	add    0x8(%rdi,%r10,8),%rbx
 133:	49 83 d1 00          	adc    $0x0,%r9
 137:	4a 89 5c d2 08       	mov    %rbx,0x8(%rdx,%r10,8)
 13c:	49 83 c2 02          	add    $0x2,%r10
 140:	4d 39 d3             	cmp    %r10,%r11
 143:	75 cb                	jne    110 <verigmp::toom_interpolate::interpolate+0x110>
 145:	40 f6 c6 01          	test   $0x1,%sil
 149:	74 0c                	je     157 <verigmp::toom_interpolate::interpolate+0x157>
 14b:	4e 03 0c d2          	add    (%rdx,%r10,8),%r9
 14f:	4e 03 0c d7          	add    (%rdi,%r10,8),%r9
 153:	4e 89 0c d2          	mov    %r9,(%rdx,%r10,8)
 157:	49 b9 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r9
 15e:	ff ff 0f 
 161:	49 89 f2             	mov    %rsi,%r10
 164:	49 ff ca             	dec    %r10
 167:	74 4e                	je     1b7 <verigmp::toom_interpolate::interpolate+0x1b7>
 169:	49 89 f6             	mov    %rsi,%r14
 16c:	4d 21 ce             	and    %r9,%r14
 16f:	45 31 db             	xor    %r11d,%r11d
 172:	48 89 f3             	mov    %rsi,%rbx
 175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 17c:	00 00 00 00 
 180:	4c 8b 7c da f0       	mov    -0x10(%rdx,%rbx,8),%r15
 185:	4c 8b 64 da f8       	mov    -0x8(%rdx,%rbx,8),%r12
 18a:	4d 0f a4 e3 3f       	shld   $0x3f,%r12,%r11
 18f:	4c 89 5c da f8       	mov    %r11,-0x8(%rdx,%rbx,8)
 194:	45 89 fb             	mov    %r15d,%r11d
 197:	4d 0f ac e7 01       	shrd   $0x1,%r12,%r15
 19c:	41 83 e3 01          	and    $0x1,%r11d
 1a0:	4c 89 7c da f0       	mov    %r15,-0x10(%rdx,%rbx,8)
 1a5:	48 83 c3 fe          	add    $0xfffffffffffffffe,%rbx
 1a9:	49 83 c6 fe          	add    $0xfffffffffffffffe,%r14
 1ad:	75 d1                	jne    180 <verigmp::toom_interpolate::interpolate+0x180>
 1af:	40 f6 c6 01          	test   $0x1,%sil
 1b3:	75 08                	jne    1bd <verigmp::toom_interpolate::interpolate+0x1bd>
 1b5:	eb 0d                	jmp    1c4 <verigmp::toom_interpolate::interpolate+0x1c4>
 1b7:	45 31 db             	xor    %r11d,%r11d
 1ba:	48 89 f3             	mov    %rsi,%rbx
 1bd:	4c 0f ac 5c da f8 01 	shrd   $0x1,%r11,-0x8(%rdx,%rbx,8)
 1c4:	4c 8b 5c 24 50       	mov    0x50(%rsp),%r11
 1c9:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
 1ce:	45 31 ff             	xor    %r15d,%r15d
 1d1:	45 31 f6             	xor    %r14d,%r14d
 1d4:	eb 33                	jmp    209 <verigmp::toom_interpolate::interpolate+0x209>
 1d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 1dd:	00 00 00 
 1e0:	4e 8b 24 f2          	mov    (%rdx,%r14,8),%r12
 1e4:	4e 8b 2c f7          	mov    (%rdi,%r14,8),%r13
 1e8:	4d 29 e5             	sub    %r12,%r13
 1eb:	40 0f 92 c5          	setb   %bpl
 1ef:	4d 29 fd             	sub    %r15,%r13
 1f2:	41 0f 92 c7          	setb   %r15b
 1f6:	41 08 ef             	or     %bpl,%r15b
 1f9:	45 0f b6 ff          	movzbl %r15b,%r15d
 1fd:	4e 89 2c f7          	mov    %r13,(%rdi,%r14,8)
 201:	49 ff c6             	inc    %r14
 204:	4c 39 f6             	cmp    %r14,%rsi
 207:	74 0a                	je     213 <verigmp::toom_interpolate::interpolate+0x213>
 209:	49 39 f6             	cmp    %rsi,%r14
 20c:	72 d2                	jb     1e0 <verigmp::toom_interpolate::interpolate+0x1e0>
 20e:	45 31 e4             	xor    %r12d,%r12d
 211:	eb d1                	jmp    1e4 <verigmp::toom_interpolate::interpolate+0x1e4>
 213:	45 31 ff             	xor    %r15d,%r15d
 216:	45 31 f6             	xor    %r14d,%r14d
 219:	eb 2e                	jmp    249 <verigmp::toom_interpolate::interpolate+0x249>
 21b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 220:	4e 8b 24 f3          	mov    (%rbx,%r14,8),%r12
 224:	4e 8b 2c f2          	mov    (%rdx,%r14,8),%r13
 228:	4d 29 e5             	sub    %r12,%r13
 22b:	40 0f 92 c5          	setb   %bpl
 22f:	4d 29 fd             	sub    %r15,%r13
 232:	41 0f 92 c7          	setb   %r15b
 236:	41 08 ef             	or     %bpl,%r15b
 239:	45 0f b6 ff          	movzbl %r15b,%r15d
 23d:	4e 89 2c f2          	mov    %r13,(%rdx,%r14,8)
 241:	49 ff c6             	inc    %r14
 244:	4c 39 f6             	cmp    %r14,%rsi
 247:	74 0a                	je     253 <verigmp::toom_interpolate::interpolate+0x253>
 249:	49 39 ce             	cmp    %rcx,%r14
 24c:	72 d2                	jb     220 <verigmp::toom_interpolate::interpolate+0x220>
 24e:	45 31 e4             	xor    %r12d,%r12d
 251:	eb d1                	jmp    224 <verigmp::toom_interpolate::interpolate+0x224>
 253:	45 31 ff             	xor    %r15d,%r15d
 256:	45 31 f6             	xor    %r14d,%r14d
 259:	eb 2e                	jmp    289 <verigmp::toom_interpolate::interpolate+0x289>
 25b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 260:	4f 8b 24 f3          	mov    (%r11,%r14,8),%r12
 264:	4e 8b 2c f2          	mov    (%rdx,%r14,8),%r13
 268:	4d 29 e5             	sub    %r12,%r13
 26b:	40 0f 92 c5          	setb   %bpl
 26f:	4d 29 fd             	sub    %r15,%r13
 272:	41 0f 92 c7          	setb   %r15b
 276:	41 08 ef             	or     %bpl,%r15b
 279:	45 0f b6 ff          	movzbl %r15b,%r15d
 27d:	4e 89 2c f2          	mov    %r13,(%rdx,%r14,8)
 281:	49 ff c6             	inc    %r14
 284:	4c 39 f6             	cmp    %r14,%rsi
 287:	74 0a                	je     293 <verigmp::toom_interpolate::interpolate+0x293>
 289:	49 39 c6             	cmp    %rax,%r14
 28c:	72 d2                	jb     260 <verigmp::toom_interpolate::interpolate+0x260>
 28e:	45 31 e4             	xor    %r12d,%r12d
 291:	eb d1                	jmp    264 <verigmp::toom_interpolate::interpolate+0x264>
 293:	45 31 ff             	xor    %r15d,%r15d
 296:	45 31 f6             	xor    %r14d,%r14d
 299:	eb 2e                	jmp    2c9 <verigmp::toom_interpolate::interpolate+0x2c9>
 29b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 2a0:	4e 8b 24 f3          	mov    (%rbx,%r14,8),%r12
 2a4:	4f 8b 2c f0          	mov    (%r8,%r14,8),%r13
 2a8:	4d 29 e5             	sub    %r12,%r13
 2ab:	40 0f 92 c5          	setb   %bpl
 2af:	4d 29 fd             	sub    %r15,%r13
 2b2:	41 0f 92 c7          	setb   %r15b
 2b6:	41 08 ef             	or     %bpl,%r15b
 2b9:	45 0f b6 ff          	movzbl %r15b,%r15d
 2bd:	4f 89 2c f0          	mov    %r13,(%r8,%r14,8)
 2c1:	49 ff c6             	inc    %r14
 2c4:	4c 39 f6             	cmp    %r14,%rsi
 2c7:	74 0a                	je     2d3 <verigmp::toom_interpolate::interpolate+0x2d3>
 2c9:	49 39 ce             	cmp    %rcx,%r14
 2cc:	72 d2                	jb     2a0 <verigmp::toom_interpolate::interpolate+0x2a0>
 2ce:	45 31 e4             	xor    %r12d,%r12d
 2d1:	eb d1                	jmp    2a4 <verigmp::toom_interpolate::interpolate+0x2a4>
 2d3:	45 31 f6             	xor    %r14d,%r14d
 2d6:	31 c9                	xor    %ecx,%ecx
 2d8:	31 db                	xor    %ebx,%ebx
 2da:	eb 3c                	jmp    318 <verigmp::toom_interpolate::interpolate+0x318>
 2dc:	0f 1f 40 00          	nopl   0x0(%rax)
 2e0:	4d 8b 3c cb          	mov    (%r11,%rcx,8),%r15
 2e4:	4d 8b 24 c8          	mov    (%r8,%rcx,8),%r12
 2e8:	4d 89 fd             	mov    %r15,%r13
 2eb:	49 c1 e5 04          	shl    $0x4,%r13
 2ef:	4d 09 f5             	or     %r14,%r13
 2f2:	4d 29 ec             	sub    %r13,%r12
 2f5:	40 0f 92 c5          	setb   %bpl
 2f9:	49 29 dc             	sub    %rbx,%r12
 2fc:	0f 92 c3             	setb   %bl
 2ff:	40 08 eb             	or     %bpl,%bl
 302:	0f b6 db             	movzbl %bl,%ebx
 305:	49 c1 ef 3c          	shr    $0x3c,%r15
 309:	4d 89 24 c8          	mov    %r12,(%r8,%rcx,8)
 30d:	48 ff c1             	inc    %rcx
 310:	4d 89 fe             	mov    %r15,%r14
 313:	48 39 ce             	cmp    %rcx,%rsi
 316:	74 0a                	je     322 <verigmp::toom_interpolate::interpolate+0x322>
 318:	48 39 c1             	cmp    %rax,%rcx
 31b:	72 c3                	jb     2e0 <verigmp::toom_interpolate::interpolate+0x2e0>
 31d:	45 31 ff             	xor    %r15d,%r15d
 320:	eb c2                	jmp    2e4 <verigmp::toom_interpolate::interpolate+0x2e4>
 322:	4d 85 d2             	test   %r10,%r10
 325:	74 3f                	je     366 <verigmp::toom_interpolate::interpolate+0x366>
 327:	49 21 f1             	and    %rsi,%r9
 32a:	31 c0                	xor    %eax,%eax
 32c:	48 89 f1             	mov    %rsi,%rcx
 32f:	90                   	nop
 330:	4d 8b 54 c8 f0       	mov    -0x10(%r8,%rcx,8),%r10
 335:	4d 8b 5c c8 f8       	mov    -0x8(%r8,%rcx,8),%r11
 33a:	4c 0f a4 d8 3f       	shld   $0x3f,%r11,%rax
 33f:	49 89 44 c8 f8       	mov    %rax,-0x8(%r8,%rcx,8)
 344:	44 89 d0             	mov    %r10d,%eax
 347:	4d 0f ac da 01       	shrd   $0x1,%r11,%r10
 34c:	83 e0 01             	and    $0x1,%eax
 34f:	4d 89 54 c8 f0       	mov    %r10,-0x10(%r8,%rcx,8)
 354:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
 358:	49 83 c1 fe          	add    $0xfffffffffffffffe,%r9
 35c:	75 d2                	jne    330 <verigmp::toom_interpolate::interpolate+0x330>
 35e:	40 f6 c6 01          	test   $0x1,%sil
 362:	75 07                	jne    36b <verigmp::toom_interpolate::interpolate+0x36b>
 364:	eb 0c                	jmp    372 <verigmp::toom_interpolate::interpolate+0x372>
 366:	31 c0                	xor    %eax,%eax
 368:	48 89 f1             	mov    %rsi,%rcx
 36b:	49 0f ac 44 c8 f8 01 	shrd   $0x1,%rax,-0x8(%r8,%rcx,8)
 372:	31 c9                	xor    %ecx,%ecx
 374:	31 c0                	xor    %eax,%eax
 376:	eb 2f                	jmp    3a7 <verigmp::toom_interpolate::interpolate+0x3a7>
 378:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 37f:	00 
 380:	4c 8b 0c c7          	mov    (%rdi,%rax,8),%r9
 384:	4d 8b 14 c0          	mov    (%r8,%rax,8),%r10
 388:	4d 29 ca             	sub    %r9,%r10
 38b:	41 0f 92 c1          	setb   %r9b
 38f:	49 29 ca             	sub    %rcx,%r10
 392:	0f 92 c1             	setb   %cl
 395:	44 08 c9             	or     %r9b,%cl
 398:	0f b6 c9             	movzbl %cl,%ecx
 39b:	4d 89 14 c0          	mov    %r10,(%r8,%rax,8)
 39f:	48 ff c0             	inc    %rax
 3a2:	48 39 c6             	cmp    %rax,%rsi
 3a5:	74 0a                	je     3b1 <verigmp::toom_interpolate::interpolate+0x3b1>
 3a7:	48 39 f0             	cmp    %rsi,%rax
 3aa:	72 d4                	jb     380 <verigmp::toom_interpolate::interpolate+0x380>
 3ac:	45 31 c9             	xor    %r9d,%r9d
 3af:	eb d3                	jmp    384 <verigmp::toom_interpolate::interpolate+0x384>
 3b1:	45 31 c9             	xor    %r9d,%r9d
 3b4:	31 c0                	xor    %eax,%eax
 3b6:	31 c9                	xor    %ecx,%ecx
 3b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 3bf:	00 
 3c0:	4c 8b 14 c2          	mov    (%rdx,%rax,8),%r10
 3c4:	4d 8b 1c c0          	mov    (%r8,%rax,8),%r11
 3c8:	4f 8d 0c 51          	lea    (%r9,%r10,2),%r9
 3cc:	4d 29 cb             	sub    %r9,%r11
 3cf:	41 0f 92 c1          	setb   %r9b
 3d3:	49 29 cb             	sub    %rcx,%r11
 3d6:	0f 92 c1             	setb   %cl
 3d9:	44 08 c9             	or     %r9b,%cl
 3dc:	0f b6 c9             	movzbl %cl,%ecx
 3df:	49 c1 ea 3f          	shr    $0x3f,%r10
 3e3:	4d 89 1c c0          	mov    %r11,(%r8,%rax,8)
 3e7:	48 ff c0             	inc    %rax
 3ea:	4d 89 d1             	mov    %r10,%r9
 3ed:	48 39 c6             	cmp    %rax,%rsi
 3f0:	75 ce                	jne    3c0 <verigmp::toom_interpolate::interpolate+0x3c0>
 3f2:	31 c9                	xor    %ecx,%ecx
 3f4:	49 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r9
 3fb:	aa aa aa 
 3fe:	49 89 f2             	mov    %rsi,%r10
 401:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 408:	0f 1f 84 00 00 00 00 
 40f:	00 
 410:	4f 8b 5c d0 f8       	mov    -0x8(%r8,%r10,8),%r11
 415:	4c 01 d9             	add    %r11,%rcx
 418:	48 83 d1 00          	adc    $0x0,%rcx
 41c:	48 89 c8             	mov    %rcx,%rax
 41f:	49 f7 e1             	mul    %r9
 422:	48 d1 ea             	shr    $1,%rdx
 425:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
 429:	48 29 c1             	sub    %rax,%rcx
 42c:	49 29 cb             	sub    %rcx,%r11
 42f:	4d 0f af d9          	imul   %r9,%r11
 433:	4f 89 5c d0 f8       	mov    %r11,-0x8(%r8,%r10,8)
 438:	49 ff ca             	dec    %r10
 43b:	75 d3                	jne    410 <verigmp::toom_interpolate::interpolate+0x410>
 43d:	31 c9                	xor    %ecx,%ecx
 43f:	31 c0                	xor    %eax,%eax
 441:	eb 32                	jmp    475 <verigmp::toom_interpolate::interpolate+0x475>
 443:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 44a:	84 00 00 00 00 00 
 450:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
 454:	4c 8b 0c c7          	mov    (%rdi,%rax,8),%r9
 458:	49 29 d1             	sub    %rdx,%r9
 45b:	0f 92 c2             	setb   %dl
 45e:	49 29 c9             	sub    %rcx,%r9
 461:	0f 92 c1             	setb   %cl
 464:	08 d1                	or     %dl,%cl
 466:	0f b6 c9             	movzbl %cl,%ecx
 469:	4c 89 0c c7          	mov    %r9,(%rdi,%rax,8)
 46d:	48 ff c0             	inc    %rax
 470:	48 39 c6             	cmp    %rax,%rsi
 473:	74 09                	je     47e <verigmp::toom_interpolate::interpolate+0x47e>
 475:	48 39 f0             	cmp    %rsi,%rax
 478:	72 d6                	jb     450 <verigmp::toom_interpolate::interpolate+0x450>
 47a:	31 d2                	xor    %edx,%edx
 47c:	eb d6                	jmp    454 <verigmp::toom_interpolate::interpolate+0x454>
 47e:	48 83 c4 08          	add    $0x8,%rsp
 482:	5b                   	pop    %rbx
 483:	41 5c                	pop    %r12
 485:	41 5d                	pop    %r13
 487:	41 5e                	pop    %r14
 489:	41 5f                	pop    %r15
 48b:	5d                   	pop    %rbp
 48c:	c3                   	ret
 48d:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 494 <verigmp::toom_interpolate::interpolate+0x494>
			490: R_X86_64_PC32	.rodata..Lanon.96723427fcafaee9300d173899c4142e.147-0x4
 494:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 49b <verigmp::toom_interpolate::interpolate+0x49b>
			497: R_X86_64_PC32	.data.rel.ro..Lanon.96723427fcafaee9300d173899c4142e.149-0x4
 49b:	be 5b 00 00 00       	mov    $0x5b,%esi
 4a0:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4a6 <verigmp::toom_interpolate::interpolate+0x4a6>
			4a2: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 4a6:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 4ad <verigmp::toom_interpolate::interpolate+0x4ad>
			4a9: R_X86_64_PC32	.rodata..Lanon.96723427fcafaee9300d173899c4142e.150-0x4
 4ad:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 4b4 <verigmp::toom_interpolate::interpolate+0x4b4>
			4b0: R_X86_64_PC32	.data.rel.ro..Lanon.96723427fcafaee9300d173899c4142e.151-0x4
 4b4:	be 3e 00 00 00       	mov    $0x3e,%esi
 4b9:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4bf <verigmp::toom_interpolate::interpolate+0x4bf>
			4bb: R_X86_64_GOTPCREL	core::panicking::panic-0x4


#!/usr/bin/env python3
"""Finish metadata from retained complete codegen-02 artifacts; never recompiles."""
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import re,subprocess,sys

WORK=Path(__file__).resolve().parent
GATE=WORK/'gates-3a83671-01'
PRIOR=GATE/'codegen-02'
OUT=GATE/'codegen-04'
def now():return datetime.now(timezone.utc).isoformat()
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def artifact(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def write(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
def main():
    OUT.mkdir(exist_ok=False)
    old=json.loads((PRIOR/'verification.json').read_text())
    assert old['status']=='fail' and old['failure']=='''ModuleNotFoundError("No module named 'layout_mutations'")'''
    for command in old['commands']:
        assert command['returncode']==0
        for stream in ('stdout','stderr'):assert sha(Path(command[stream]['path']))==command[stream+'_sha256']
    comparison=json.loads((PRIOR/'library-comparison/comparison.json').read_text())
    assert sha(PRIOR/'library-comparison/comparison.json')==old['library_comparison']['sha256']
    for label,row in old['binaries'].items():assert sha(row['path'])==row['sha256']
    report=dict(status='running',source_head=old['source_head'],source_tree=old['source_tree'],native_tree=old['native_tree'],
        native_manifest_sha256=old['native_manifest_sha256'],start_utc=now(),driver_pid=os.getpid(),driver_sha256=sha(__file__),
        retained_prior=artifact(PRIOR/'verification.json'),reuse='all successful complete codegen/compile artifacts; only metadata import failed',
        compile_executed=False,benchmark_executed=False,timing=False,commands=[])
    def save():write(OUT/'verification.json',report)
    try:
        functions=comparison['functions']
        graphs={}
        for label,rows in functions.items():
            graphs[label]={name:sorted({target.split('+')[0].split('-0x')[0] for _,_,target in row['normalized_relocations']
                if target.split('+')[0].split('-0x')[0] in rows}) for name,row in rows.items()}
        write(OUT/'library-callgraphs.json',graphs)
        def reach(edges,root,blocked=()):
            seen=set();todo=[root]
            while todo:
                name=todo.pop()
                if name in seen or name in blocked:continue
                seen.add(name);todo.extend(edges.get(name,[]))
            return sorted(seen)
        final={}
        for label in ('baseline','candidate'):
            section_text=(PRIOR/(label+'-final-sections.stdout.log')).read_text()
            fields=next(line.split() for line in section_text.splitlines() if re.match(r'^\s*\d+\s+\.text\s',line))
            section=dict(size=int(fields[2],16),address=int(fields[3],16),file_offset=int(fields[5],16),alignment=fields[6])
            data=(PRIOR/(label+'-final-text.bin')).read_bytes();assert len(data)==section['size']
            table=(PRIOR/(label+'-final-symbols.stdout.log')).read_text()
            symbols={};folder=OUT/(label+'-final-arithmetic-bodies');folder.mkdir()
            for line in table.splitlines():
                fields=line.split(None,5)
                if len(fields)!=6 or fields[2]!='F' or fields[3]!='.text' or not fields[5].startswith('verigmp::'):continue
                address=int(fields[0],16);size=int(fields[4],16);offset=address-section['address']
                assert 0<=offset and offset+size<=len(data)
                path=folder/(str(len(symbols))+'.bin');path.write_bytes(data[offset:offset+size])
                symbols[fields[5]]=dict(address=address,address_hex=hex(address),size=size,section='.text',
                    section_alignment=section['alignment'],body=artifact(path),relative_offset=offset)
            final[label]=dict(text=artifact(PRIOR/(label+'-final-text.bin')),section=section,arithmetic_symbols=symbols,
                complete_symbols=artifact(PRIOR/(label+'-final-symbols.stdout.log')),
                complete_disassembly=artifact(PRIOR/(label+'-final-complete-assembly.stdout.log')),
                complete_dynamic_relocations_and_sections=artifact(PRIOR/(label+'-final-readelf.stdout.log')))
        write(OUT/'final-layout.json',final)
        layouts={label:{name:{key:value for key,value in row.items() if key not in ('body',)}
                   for name,row in value['arithmetic_symbols'].items()} for label,value in final.items()}
        preflight=json.loads((GATE/'preflight.json').read_text())
        schedule={tuple(row['cell']):row for row in preflight['analytic_schedule']['rows']}
        control=[]
        for key,analytic in schedule.items():
            if analytic['primary']:continue
            if key[0]==0:root='verigmp::fast_multiply::full';blocked=()
            elif key[0]==1:root='verigmp::arithmetic::mul_mod';blocked=('verigmp::toom_low::modular',)
            else:root='verigmp::arithmetic::square_mod';blocked=('verigmp::toom_interpolate::interpolate',)
            footprint={label:reach(graphs[label],root,blocked) for label in functions}
            union=sorted(set(footprint['baseline'])|set(footprint['candidate']))
            rows=[]
            for name in union:
                a=functions['baseline'].get(name);b=functions['candidate'].get(name)
                x=final['baseline']['arithmetic_symbols'].get(name);y=final['candidate']['arithmetic_symbols'].get(name)
                rows.append(dict(function=name,library_body_identical=bool(a and b and a['sha256']==b['sha256']),
                    library_relocations_identical=bool(a and b and a['normalized_relocations']==b['normalized_relocations']),
                    final_both_present=bool(x and y),
                    final_body_identical=bool(x and y and x['body']['sha256']==y['body']['sha256']),
                    final_address_size_identical=bool(x and y and (x['address'],x['size'])==(y['address'],y['size']))))
            control.append(dict(cell=list(key),source_interpolation_visits=0,library_footprint=footprint,
                footprint_basis='conservative native whole-function callgraph; only source-proven inactive Toom branch excluded; no executed-instruction trace claim',
                functions=rows,library_body_identity=all(row['library_body_identical'] for row in rows),
                library_relocation_identity=all(row['library_relocations_identical'] for row in rows),
                final_body_identity=all(row['final_body_identical'] for row in rows),
                final_layout_identity=all(row['final_address_size_identical'] for row in rows)))
        assert len(control)==71
        stub=functions['candidate']['verigmp::toom_words::shift_factor']
        stub_bytes=Path(stub['file']).read_bytes()
        reachable={label:{root:reach(graphs[label],root) for root in
            ('verigmp::arithmetic::mul_mod','verigmp::arithmetic::square_mod')} for label in functions}
        assert all('verigmp::toom_interpolate::interpolate' in names for rows in reachable.values() for names in rows.values())
        assert stub['size']==26 and stub['normalized_relocations'][-1][2].startswith('core::panicking::panic')
        assert all('verigmp::toom_words::shift_factor' not in names for rows in reachable.values() for names in rows.values())
        assert not any('verigmp::toom_words::shift_factor' in targets for targets in graphs['candidate'].values())
        assert 'verigmp::toom_words::shift_factor' not in final['candidate']['arithmetic_symbols']
        identity=dict(status='audited',timing_eligible=False,
            reason='requires independent/root pre-timing acceptance of disclosed nonlocal arithmetic/layout differences',
            source_head=old['source_head'],source_tree=old['source_tree'],native_tree=old['native_tree'],
            preflight_sha256=sha(GATE/'preflight.json'),library_comparison=artifact(PRIOR/'library-comparison/comparison.json'),
            library_function_counts=old['library_comparison']['function_counts'],library_changed=old['library_comparison']['changed'],
            spec_marker=dict(symbol='verigmp::toom_words::shift_factor',bytes=stub['size'],raw_hex=stub_bytes.hex(),
                relocations=stub['normalized_relocations'],library_callgraph_reachable=False,
                incoming_library_references=0,present_in_final_benchmark=False,
                meaning='Verus spec-only cold panic stub with no arithmetic; no executable integer model'),
            final_layout=artifact(OUT/'final-layout.json'),default_callgraphs=reachable,
            final_text_layout_identity=final['baseline']['text']['sha256']==final['candidate']['text']['sha256'],
            control_cells=71,controls=control,
            counts={key:sum(row[key] for row in control) for key in
                ('library_body_identity','library_relocation_identity','final_body_identity','final_layout_identity')},
            fused_interpolation=old['fused_interpolation'],benchmark_executed=False)
        write(OUT/'control-identity.json',identity);report['control_identity']=artifact(OUT/'control-identity.json')
        host={}
        for name,argv in (('lscpu',['lscpu']),('uname',['uname','-a']),('cpuinfo',['cat','/proc/cpuinfo']),
                          ('stat',['cat','/proc/stat']),('loadavg',['cat','/proc/loadavg']),('meminfo',['cat','/proc/meminfo'])):
            result=subprocess.run(argv,capture_output=True,timeout=30);assert result.returncode==0
            stdout=OUT/('host-'+name+'.stdout.log');stderr=OUT/('host-'+name+'.stderr.log')
            stdout.write_bytes(result.stdout);stderr.write_bytes(result.stderr)
            report['commands'].append(dict(argv=argv,returncode=result.returncode,stdout=artifact(stdout),stderr=artifact(stderr)))
            host[name]=result.stdout.decode()
        host.update(status='read_only_observation',python=sys.version,process_affinity=sorted(os.sched_getaffinity(0)),
            cpu8_available=8 in os.sched_getaffinity(0),utc=now(),frequency_thermal='WSL observations are metadata, no post-outcome exclusion rule')
        write(OUT/'host.json',host);report['host']=artifact(OUT/'host.json')
        report.update(status='pass',stop_utc=now(),control_identity_counts=identity['counts']);save()
    except BaseException as error:
        report.update(status='fail',failure=repr(error),stop_utc=now());save();raise
    print(json.dumps(dict(status='pass',control_identity_counts=identity['counts'],
        final_layout_identity=identity['final_text_layout_identity'],report_sha256=sha(OUT/'verification.json'),
        control_identity_sha256=sha(OUT/'control-identity.json'),benchmark_executed=False)),flush=True)

if __name__=='__main__':main()

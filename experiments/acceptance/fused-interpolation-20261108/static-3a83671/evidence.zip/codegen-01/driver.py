#!/usr/bin/env python3
"""Complete release object/final layout audit and compile-only benchmark build."""
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import re,shutil,subprocess,sys

WORK=Path(__file__).resolve().parent
GATE=WORK/'gates-3a83671-01'
SOURCE=GATE/'source'
OUT=GATE/'codegen-01'
DEPS=Path('/mnt/e/3sat/VeriCount/deps')
BASELINE=Path('/mnt/e/3sat/VeriGMP-precondition-evidence-20261108/baseline-binding')
def now():return datetime.now(timezone.utc).isoformat()
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def artifact(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def write(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
def main():
    OUT.mkdir(exist_ok=False)
    full=json.loads((GATE/'full-native.json').read_text());assert full['status']=='pass'
    correct=json.loads((GATE/'untimed-01/verification.json').read_text());assert correct['status']=='pass'
    report=dict(status='running',source_head=full['head'],source_tree=full['tree'],native_tree=full['native_tree'],
        native_manifest_sha256=full['native_manifest_sha256'],full_native_sha256=sha(GATE/'full-native.json'),
        correctness_sha256=sha(GATE/'untimed-01/verification.json'),driver_sha256=sha(__file__),
        driver_pid=os.getpid(),start_utc=now(),timing=False,benchmark_executed=False,commands=[])
    def save():write(OUT/'verification.json',report)
    env=dict(os.environ,CARGO_HOME=str(DEPS/'cargo'),RUSTUP_HOME=str(DEPS/'rustup'),
             RUSTUP_TOOLCHAIN='1.99.1-x86_64-unknown-linux-gnu',PYTHONDONTWRITEBYTECODE='1')
    env['PATH']=str(DEPS/'cargo/bin')+os.pathsep+env['PATH']
    def run(argv,name,cwd=OUT,timeout=300):
        argv=list(map(str,argv));command=dict(name=name,argv=argv,cwd=str(cwd),start_utc=now(),timeout_seconds=timeout)
        result=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=timeout)
        a=OUT/(name+'.stdout.log');b=OUT/(name+'.stderr.log');a.write_bytes(result.stdout);b.write_bytes(result.stderr)
        command.update(returncode=result.returncode,stop_utc=now(),stdout_sha256=sha(a),stderr_sha256=sha(b),
                       stdout=artifact(a),stderr=artifact(b));report['commands'].append(command);save()
        if result.returncode:raise RuntimeError('command failed: '+name)
        return command,result.stdout.decode()
    try:
        objects=OUT/'objects';objects.mkdir()
        libraries={'baseline':BASELINE,'candidate':GATE}
        for label,folder in libraries.items():
            command,text=run(['ar','t',folder/'libverigmp.rlib'],label+'-ar-members')
            members=[name for name in text.splitlines() if name.endswith('.o')]
            assert len(members)==1,'complete multi-object audit required; never select one object'
            command,text=run(['ar','p',folder/'libverigmp.rlib',members[0]],label+'-object')
            # stdout is an ELF byte stream, retained exactly rather than its decoded display.
            obj=objects/(label+'.o');shutil.copyfile(OUT/(label+'-object.stdout.log'),obj)
        run([sys.executable,SOURCE/'experiments/combination-20261108/codegen.py',
             '--objects',objects,'--output',OUT/'library-comparison'],'complete-library-codegen')
        comparison=json.loads((OUT/'library-comparison/comparison.json').read_text())
        report['library_comparison']=dict(path=str(OUT/'library-comparison/comparison.json'),
            sha256=sha(OUT/'library-comparison/comparison.json'),added=comparison['added'],removed=comparison['removed'],
            changed=comparison['changed'],function_counts={k:len(v) for k,v in comparison['functions'].items()})
        changed={row['function'] for row in comparison['changed']}|set(comparison['added'])|set(comparison['removed'])
        report['non_interpolation_body_drift']=sorted(name for name in changed if not name.startswith('verigmp::toom_interpolate::'))
        bench_folder=OUT/'bench-build';bench_folder.mkdir();binaries={}
        verifier=DEPS/'verus/verus-x86-linux/verus'
        rustc=[DEPS/'cargo/bin/rustup','run','1.99.1-x86_64-unknown-linux-gnu','rustc']
        bench=SOURCE/'experiments/arithmetic-precondition-checks-20261108/bench.rs'
        for label,folder in libraries.items():
            binary=bench_folder/(label+'-bench')
            argv=rustc+[bench,'-O','--edition=2024','-L','dependency='+str(verifier.parent),
                        '-L','dependency='+str(folder),'--extern',f'verigmp={folder}/libverigmp.rlib','-o',binary]
            command,text=run(argv,label+'-bench-build')
            build_command=dict(argv=command['argv'],returncode=command['returncode'],
                               stdout=command['stdout'],stderr=command['stderr'])
            command,linked=run(['ldd',binary],label+'-bench-ldd')
            gmp=next(line.split('=>',1)[1].split('(',1)[0].strip() for line in linked.splitlines() if 'libgmp.so' in line)
            binaries[label]=dict(path=str(binary),sha256=sha(binary),library_sha256=sha(folder/'libverigmp.rlib'),
                gmp_path=gmp,gmp_sha256=sha(gmp),argv=list(map(str,argv)),build_command=build_command,ldd=linked)
            run(['objdump','-h',binary],label+'-final-sections')
            run(['objdump','-t','-C',binary],label+'-final-symbols')
            run(['objdump','-d','-r','-C',binary],label+'-final-complete-assembly')
            run(['readelf','-aW',binary],label+'-final-readelf')
            run(['objcopy','--dump-section','.text='+str(OUT/(label+'-final-text.bin')),binary,
                 OUT/(label+'-final-dump-output')],label+'-final-text')
        write(OUT/'binaries.json',binaries);report['binaries']=binaries
        def graph(label):
            functions=comparison['functions'][label]
            edges={name:[] for name in functions}
            for name,row in functions.items():
                edges[name]=sorted({target.split('+')[0].split('-0x')[0]
                    for _,_,target in row['normalized_relocations'] if target.split('+')[0].split('-0x')[0] in functions})
            return edges
        graphs={label:graph(label) for label in libraries};write(OUT/'library-callgraphs.json',graphs)
        def reach(edges,root,blocked=()):
            seen=set();todo=[root]
            while todo:
                name=todo.pop()
                if name in seen or name in blocked:continue
                seen.add(name);todo.extend(edges.get(name,[]))
            return sorted(seen)
        roots=('verigmp::arithmetic::mul_mod','verigmp::arithmetic::square_mod')
        default={label:{root:reach(edges,root) for root in roots} for label,edges in graphs.items()}
        report['default_callgraphs']=default
        for label in libraries:
            for root in roots:assert 'verigmp::toom_interpolate::interpolate' in default[label][root]
        original=comparison['functions']['baseline']['verigmp::toom_interpolate::interpolate']
        fused=comparison['functions']['candidate']['verigmp::toom_interpolate::interpolate']
        candidate_assembly=(OUT/'library-comparison/candidate-complete.asm').read_text()
        match=re.search(r'(?ms)^\s*[0-9a-f]+ <verigmp::toom_interpolate::interpolate>:\n(.*?)(?=^Disassembly of section|\Z)',candidate_assembly)
        assert match
        body=match[1];(OUT/'candidate-interpolation-complete.asm').write_text(body)
        assert not re.search(r'sub_shifted_exact|shift_word|copy_pad|scale_exact|toom_words::scale\b',body)
        assert not re.search(r'__rust_(?:alloc|realloc)|malloc|calloc|Seq|radix::value|__gmp',body)
        assert re.search(r'\b(?:shl|shr|sal|shld)\b',body)
        report['fused_interpolation']=dict(baseline_bytes=original['size'],candidate_bytes=fused['size'],
            complete_candidate_body_sha256=sha(OUT/'candidate-interpolation-complete.asm'),
            fused_helpers_inlined=True,no_old_copy_scale_pipeline=True,no_allocator_ffi_or_spec_materialization=True,
            source_loop_count=2,loop_count_basis='two constant-shift subtractions in unchanged interpolation sequence; source preflight',
            dynamic_instruction_count_measured=False)
        sys.path.insert(0,str(SOURCE/'experiments/fused-interpolation-20261108'))
        from raw_validate import CELLS
        from preflight import schedule
        functions=comparison['functions']
        control=[]
        for key in CELLS:
            if schedule(key[0],key[1]):continue
            if key[0]==0:root='verigmp::fast_multiply::full';blocked=()
            elif key[0]==1:
                root='verigmp::arithmetic::mul_mod';blocked=('verigmp::toom_low::modular',)
            else:
                root='verigmp::arithmetic::square_mod';blocked=('verigmp::toom_interpolate::interpolate',)
            footprint={label:reach(graphs[label],root,blocked) for label in libraries}
            union=sorted(set(footprint['baseline'])|set(footprint['candidate']))
            rows=[]
            for name in union:
                a=functions['baseline'].get(name);b=functions['candidate'].get(name)
                rows.append(dict(function=name,baseline_present=a is not None,candidate_present=b is not None,
                    body_identical=bool(a and b and a['sha256']==b['sha256']),
                    relocation_identical=bool(a and b and a['normalized_relocations']==b['normalized_relocations'])))
            control.append(dict(cell=list(key),source_interpolation_visits=0,library_footprint=footprint,
                footprint_basis='conservative native whole-function callgraph with source-proven inactive Toom branch excluded; no executed-instruction trace claim',
                bodies=rows,body_identity=all(row['body_identical'] for row in rows),
                relocation_identity=all(row['relocation_identical'] for row in rows)))
        assert len(control)==71
        text_hash={label:sha(OUT/(label+'-final-text.bin')) for label in libraries}
        control_identity=dict(status='audited',timing_eligible=False,reason='independent/root review of disclosed final layout and any control footprint differences required',
            source_head=full['head'],library_comparison_sha256=sha(OUT/'library-comparison/comparison.json'),
            whole_function_footprint_caveat=True,final_text_sha256=text_hash,final_text_layout_identity=text_hash['baseline']==text_hash['candidate'],
            controls=control,all_71_body_identity=all(row['body_identity'] for row in control),
            all_71_relocation_identity=all(row['relocation_identity'] for row in control),
            library_non_interpolation_drift=report['non_interpolation_body_drift'])
        write(OUT/'control-identity.json',control_identity);report['control_identity']=artifact(OUT/'control-identity.json')
        host={}
        for name,argv in (('lscpu',['lscpu']),('uname',['uname','-a']),('cpuinfo',['cat','/proc/cpuinfo']),
                          ('stat',['cat','/proc/stat']),('loadavg',['cat','/proc/loadavg']),('meminfo',['cat','/proc/meminfo'])):
            command,text=run(argv,'host-'+name);host[name]=text
        host.update(status='read_only_observation',python=sys.version,process_affinity=sorted(os.sched_getaffinity(0)),
                    cpu8_available=8 in os.sched_getaffinity(0),start_utc=now())
        write(OUT/'host.json',host);report['host']=artifact(OUT/'host.json')
        report.update(status='pass',stop_utc=now());save()
    except BaseException as error:
        report.update(status='fail',failure=repr(error),stop_utc=now());save();raise
    print(json.dumps(dict(status=report['status'],changed=report['library_comparison']['changed'],
        non_interpolation_body_drift=report['non_interpolation_body_drift'],fused_interpolation=report['fused_interpolation'],
        control_identity=report['control_identity'],report_sha256=sha(OUT/'verification.json'),benchmark_executed=False)),flush=True)

if __name__=='__main__':main()

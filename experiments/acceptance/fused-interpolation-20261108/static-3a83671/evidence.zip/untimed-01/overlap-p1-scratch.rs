fn main(){let mut p=[0u64;2];let mut q=[0u64;2];let mut t=[0u64;2];let z=[0u64;2];
fused_bridge::interpolate(&mut p,&mut q,&mut t,&z,&z,false,&mut p,&[],&[],&[]);}

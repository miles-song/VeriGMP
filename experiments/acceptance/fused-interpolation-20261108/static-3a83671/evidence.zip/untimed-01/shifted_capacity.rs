mod shifted_capacity { use vstd::prelude::*; verus! {
pub fn client(){let mut dst=[u64::MAX];let rhs=[u64::MAX];
verigmp::toom_words::sub_shifted_exact(&mut dst,&rhs,4);}
}}

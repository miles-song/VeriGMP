fn main(){let mut words=[1u64;2];
verigmp::toom_words::sub_shifted_exact(&mut words,&words,1);}

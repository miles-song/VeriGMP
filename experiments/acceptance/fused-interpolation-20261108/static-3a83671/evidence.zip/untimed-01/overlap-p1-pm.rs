fn main(){let mut p=[0u64;2];let mut q=[0u64;2];let mut w=[0u64;2];let z=[0u64;2];
fused_bridge::interpolate(&mut p,&mut p,&mut q,&z,&z,false,&mut w,&[],&[],&[]);}

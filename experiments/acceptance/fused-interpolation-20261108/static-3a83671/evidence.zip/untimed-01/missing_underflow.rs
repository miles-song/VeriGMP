mod missing_underflow { use vstd::prelude::*; verus! {
pub fn client(dst:&mut[u64],rhs:&[u64])
requires old(dst)@.len()>=rhs@.len(),
{verigmp::toom_words::sub_shifted_exact(dst,rhs,1);}
}}

from pathlib import Path
import hashlib,json,shutil,zipfile

WORK=Path(__file__).resolve().parent
ROOT=WORK/'VeriGMP-negative-experiments-20261108'
GATE=WORK/'gates-3a83671-01'
TARGET=ROOT/'experiments/acceptance/fused-interpolation-20261108/static-3a83671'
BASELINE=Path('E:/3sat/VeriGMP-precondition-evidence-20261108/baseline-binding')
def sha(data):return hashlib.sha256(data).hexdigest()
TARGET.mkdir(exist_ok=False)
operational=GATE/'operational';operational.mkdir(exist_ok=False)
for name in ('prepare_full_native_3a83671.py','full_native_driver_3a83671.py','untimed_driver_3a83671.py',
             'codegen_driver_3a83671.py','finish_codegen_3a83671.py','build_identity_3a83671.py',Path(__file__).name):
    shutil.copyfile(WORK/name,operational/name)
aliases=GATE/'baseline-exports';aliases.mkdir(exist_ok=False)
for name in ('libverigmp.rlib','verigmp.vir','verification.json'):
    shutil.copyfile(BASELINE/name,aliases/name)
files={path.relative_to(GATE).as_posix():path for path in sorted(GATE.rglob('*')) if path.is_file()}
manifest=dict(schema='fused-interpolation-static-package-v1',status='static-gates-only-review-pending',
    source_head='3a836713adbb0a6632f5131e8d57c97296d22f62',
    source_tree='96bd28b9bc45702e1d7f6c8e9a60d7653f2cd941',
    native_tree='212dd5d00d4b2159abd4627a6aaec8b16a1157e5',benchmark_executed=False,timing_authorized=False,
    canonical=dict(full_native='full-native.json',correctness='untimed-01/verification.json',
        codegen='codegen-05/verification.json',control_identity='codegen-05/control-identity.json',
        final_layout='codegen-05/final-layout.json',identity='build-identity-01/identity.json',
        bench_build='build-identity-01/bench-build.json',binding='build-identity-01/verification.json'),
    files={name:dict(sha256=sha(path.read_bytes()),bytes=path.stat().st_size) for name,path in files.items()})
archive=TARGET/'evidence.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as bundle:
    for name,path in files.items():bundle.write(path,name)
manifest['archive']=dict(path='evidence.zip',sha256=sha(archive.read_bytes()),bytes=archive.stat().st_size)
(TARGET/'manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode())
for name in ('full-native.json','untimed-01/verification.json','codegen-05/verification.json',
             'codegen-05/control-identity.json','codegen-05/final-layout.json',
             'build-identity-01/identity.json','build-identity-01/bench-build.json','build-identity-01/verification.json'):
    target=TARGET/'receipts'/name;target.parent.mkdir(exist_ok=True,parents=True);shutil.copyfile(GATE/name,target)
with zipfile.ZipFile(archive) as bundle:
    assert len(bundle.namelist())==len(set(bundle.namelist()))==len(files)
    assert set(bundle.namelist())==set(manifest['files'])
    for name,row in manifest['files'].items():
        data=bundle.read(name);assert len(data)==row['bytes'] and sha(data)==row['sha256']
print(json.dumps(dict(status='packaged-and-byte-checked',files=len(files),archive=manifest['archive'],
    manifest_sha256=sha((TARGET/'manifest.json').read_bytes()),benchmark_executed=False),indent=2))

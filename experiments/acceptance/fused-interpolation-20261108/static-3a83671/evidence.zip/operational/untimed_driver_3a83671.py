#!/usr/bin/env python3
"""Sequential untimed oracle/domain/alias/mutant gates of source 3a83671."""
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import re,subprocess,sys

WORK=Path(__file__).resolve().parent
GATE=WORK/'gates-3a83671-01'
SOURCE=GATE/'source'
FEATURE=SOURCE/'experiments/fused-interpolation-20261108'
OUT=GATE/'untimed-01'
DEPS=Path('/mnt/e/3sat/VeriCount/deps')
BASELINE=Path('/mnt/e/3sat/VeriGMP-precondition-evidence-20261108/baseline-binding')
sys.dont_write_bytecode=True
sys.path.insert(0,str(FEATURE))
sys.path.insert(0,str(SOURCE/'experiments/packed-convolution'))
from oracle import generate
from mutations import prepare
from verus_logs import strict_semantic_rejection,self_check

def now():return datetime.now(timezone.utc).isoformat()
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def write(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
def main():
    OUT.mkdir(exist_ok=False)
    full=json.loads((GATE/'full-native.json').read_text())
    bound=json.loads((GATE/'binding.json').read_text())
    assert full['status']=='pass' and full['head']=='3a836713adbb0a6632f5131e8d57c97296d22f62'
    report=dict(status='running',source_head=full['head'],source_tree=full['tree'],native_tree=full['native_tree'],
        native_manifest_sha256=full['native_manifest_sha256'],full_native_sha256=sha(GATE/'full-native.json'),
        driver_sha256=sha(__file__),driver_pid=os.getpid(),start_utc=now(),timing=False,
        terminal=dict(stdin_isatty=sys.stdin.isatty(),stdout_isatty=sys.stdout.isatty(),tty_name=None),
        commands=[],runtime={},ownership=[],negative_clients=[],mutants=[],strict_classifier_self_check=self_check())
    def save():write(OUT/'verification.json',report)
    env=dict(os.environ,CARGO_HOME=str(DEPS/'cargo'),RUSTUP_HOME=str(DEPS/'rustup'),
             RUSTUP_TOOLCHAIN='1.99.1-x86_64-unknown-linux-gnu',PYTHONDONTWRITEBYTECODE='1')
    env['PATH']=str(DEPS/'cargo/bin')+os.pathsep+env['PATH']
    def run(argv,name,cwd=OUT,timeout=900,success=True):
        argv=list(map(str,argv))
        command=dict(name=name,argv=argv,cwd=str(cwd),start_utc=now(),timeout_seconds=timeout)
        stdout=OUT/(name+'.stdout.log');stderr=OUT/(name+'.stderr.log')
        with stdout.open('wb') as a,stderr.open('wb') as b:
            process=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=a,stderr=b)
            command['pid']=process.pid;report['commands'].append(command);save()
            print(json.dumps(dict(status='launched',name=name,pid=process.pid,driver_pid=os.getpid())),flush=True)
            try:command['returncode']=process.wait(timeout=timeout);command['timed_out']=False
            except subprocess.TimeoutExpired:
                process.terminate();process.wait(timeout=30);command.update(returncode=process.returncode,timed_out=True)
        command.update(stop_utc=now(),stdout_sha256=sha(stdout),stderr_sha256=sha(stderr))
        save()
        if command['timed_out'] or success and command['returncode']!=0:
            raise RuntimeError('command failed: '+name)
        return command,stdout.read_text()+stderr.read_text()
    try:
        libraries={'baseline':BASELINE,'candidate':GATE}
        for label,folder in libraries.items():
            expected=bound['baseline']['exports_sha256'] if label=='baseline' else full['exports_sha256']
            for name in ('libverigmp.rlib','verigmp.vir'):assert sha(folder/name)==expected[name]
        for name,digest in bound['source']['source_sha256'].items():assert sha(SOURCE/name)==digest
        shapes=json.loads((SOURCE/'native/performance-target.json').read_text())['key_shapes']['shapes']
        report['oracle']=generate(OUT/'oracle',shapes);save()
        verifier=DEPS/'verus/verus-x86-linux/verus'
        rustc=[DEPS/'cargo/bin/rustup','run','1.99.1-x86_64-unknown-linux-gnu','rustc']
        flags=['-O','--edition=2024','-L','dependency='+str(verifier.parent)]
        for label,folder in libraries.items():
            bridge=OUT/label;bridge.mkdir()
            argv=[verifier,FEATURE/'bridge.rs','--crate-type','lib','--crate-name','fused_bridge',
                  '--no-cheating','--compile','-O','--num-threads','2','--extern',f'verigmp={folder}/libverigmp.rlib',
                  '--import',f'verigmp={folder}/verigmp.vir','-L',f'dependency={folder}',
                  '-o',bridge/'libfused_bridge.rlib']
            command,text=run(argv,label+'-bridge')
            summary=re.findall(r'(?m)^verification results:: (\d+) verified, 0 errors$',text)
            assert len(summary)==1
            report['runtime'][label]=dict(bridge_verified_items=int(summary[0]),bridge_sha256=sha(bridge/'libfused_bridge.rlib'))
            binary=bridge/'runtime'
            extra=['--cfg','baseline'] if label=='baseline' else []
            run(rustc+[FEATURE/'runtime.rs',*flags,'-L',f'dependency={folder}',
                       '--extern',f'verigmp={folder}/libverigmp.rlib','--extern',f'fused_bridge={bridge}/libfused_bridge.rlib',
                       *extra,'-o',binary],label+'-runtime-build')
            command,text=run([binary,OUT/'oracle/cases.bin'],label+'-oracle',timeout=300)
            assert text.strip()==f"passed {report['oracle']['cases']} independent Python integer fixtures, input preservation, capacity and canary boundaries"
            report['runtime'][label].update(status='pass',binary_sha256=sha(binary),cases=report['oracle']['cases'],
                                            exact_stdout=text);save()
        folder=GATE;bridge=OUT/'candidate'
        clients={
            'overlap-dst-rhs':('E0502','''fn main(){let mut words=[1u64;2];
verigmp::toom_words::sub_shifted_exact(&mut words,&words,1);}'''),
            'overlap-p1-pm':('E0499','''fn main(){let mut p=[0u64;2];let mut q=[0u64;2];let mut w=[0u64;2];let z=[0u64;2];
fused_bridge::interpolate(&mut p,&mut p,&mut q,&z,&z,false,&mut w,&[],&[],&[]);}'''),
            'overlap-p1-scratch':('E0499','''fn main(){let mut p=[0u64;2];let mut q=[0u64;2];let mut t=[0u64;2];let z=[0u64;2];
fused_bridge::interpolate(&mut p,&mut q,&mut t,&z,&z,false,&mut p,&[],&[],&[]);}'''),
        }
        for name,(diagnostic,source) in clients.items():
            path=OUT/(name+'.rs');path.write_text(source+'\n')
            command,text=run(rustc+[path,*flags,'-L',f'dependency={folder}',
                '--extern',f'verigmp={folder}/libverigmp.rlib','--extern',f'fused_bridge={bridge}/libfused_bridge.rlib',
                '-o',OUT/name],name,success=False)
            errors=re.findall(r'(?m)^error\[([^\]]+)\]:',text)
            assert command['returncode']==1 and errors==[diagnostic],(name,errors)
            report['ownership'].append(dict(name=name,status='pass',diagnostic=diagnostic,source_sha256=sha(path)));save()
        negative={
            'missing_underflow':'''pub fn client(dst:&mut[u64],rhs:&[u64])
requires old(dst)@.len()>=rhs@.len(),
{verigmp::toom_words::sub_shifted_exact(dst,rhs,1);}''',
            'shifted_capacity':'''pub fn client(){let mut dst=[u64::MAX];let rhs=[u64::MAX];
verigmp::toom_words::sub_shifted_exact(&mut dst,&rhs,4);}''',
        }
        for module,body in negative.items():
            path=OUT/(module+'.rs')
            path.write_text('mod '+module+' { use vstd::prelude::*; verus! {\n'+body+'\n}}\n')
            command,text=run([verifier,path,'--crate-type','lib','--crate-name','negative_client',
                '--extern',f'verigmp={folder}/libverigmp.rlib','--import',f'verigmp={folder}/verigmp.vir',
                '-L',f'dependency={folder}','--verify-module',module,'--no-cheating','--multiple-errors','0',
                '--num-threads','2'],module,success=False)
            rejected=strict_semantic_rejection(text,command['returncode'],module)
            report['negative_clients'].append(dict(name=module,status='pass' if rejected else 'fail',
                                                  strict_logical_rejection=rejected,source_sha256=sha(path)));save()
            assert rejected,module
        mutants=prepare(SOURCE/'native',OUT/'mutants')
        for mutant in mutants:
            cwd=Path(mutant['source']).parents[2]
            command,text=run([verifier,*mutant['verifier_arguments']],'mutant-'+mutant['name'],cwd,success=False)
            rejected=strict_semantic_rejection(text,command['returncode'],mutant['module'])
            report['mutants'].append(dict(mutant,strict_logical_rejection=rejected));save()
            assert rejected,mutant['name']
        for name,digest in bound['source']['source_sha256'].items():assert sha(SOURCE/name)==digest
        report.update(status='pass',stop_utc=now());save()
    except BaseException as error:
        report.update(status='fail',failure=repr(error),stop_utc=now());save();raise
    print(json.dumps(dict(status=report['status'],source_head=full['head'],runtime_cases_per_build=report['oracle']['cases'],
        ownership=len(report['ownership']),negative_clients=len(report['negative_clients']),mutants=len(report['mutants']),
        report_sha256=sha(OUT/'verification.json'),timing=False)),flush=True)

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Freeze untimed source/tool/producer/binary evidence and test its read-only binding."""
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import shutil,subprocess,sys

WORK=Path(__file__).resolve().parent
ROOT=WORK/'VeriGMP-negative-experiments-20261108'
GATE=WORK/'gates-3a83671-01'
OUT=GATE/'build-identity-01'
SOURCE=GATE/'source'
BASELINE=Path('/mnt/e/3sat/VeriGMP-precondition-evidence-20261108/baseline-binding')
DEPS=Path('/mnt/e/3sat/VeriCount/deps')
GIT=['/mnt/c/Program Files/Git/cmd/git.exe','-C','C:/Users/23247/.codex/worktrees/gmp-fused-interpolation-20261108/VeriGMP-negative-experiments-20261108']
BASE='4510b46e4010dd287c9cf760f0195f2edc32e1f7'
def sha(path):
    with Path(path).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def artifact(path):return dict(path=str(Path(path).resolve()),sha256=sha(path))
def write(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
def git(*args):return subprocess.check_output(GIT+list(args),timeout=60)
def mapping_sha(mapping):return hashlib.sha256(json.dumps(mapping,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def main():
    OUT.mkdir(exist_ok=False)
    full=json.loads((GATE/'full-native.json').read_text());assert full['status']=='pass'
    bound=json.loads((GATE/'binding.json').read_text());assert bound['status']=='binding_pass'
    preflight=json.loads((GATE/'preflight.json').read_text());assert preflight['status']=='source_ready'
    correctness=json.loads((GATE/'untimed-01/verification.json').read_text());assert correctness['status']=='pass'
    codegen=json.loads((GATE/'codegen-05/verification.json').read_text());assert codegen['status']=='pass'
    prior=json.loads((GATE/'codegen-02/verification.json').read_text())
    report=dict(status='running',driver_sha256=sha(__file__),source_head=full['head'],source_tree=full['tree'],
        native_tree=full['native_tree'],driver_pid=os.getpid(),start_utc=datetime.now(timezone.utc).isoformat(),
        native_reproved=False,bench_recompiled=False,benchmark_executed=False,timing_authorized=False)
    def save():write(OUT/'verification.json',report)
    try:
        sources={}
        for label in ('baseline','candidate'):
            folder=OUT/'baseline-source' if label=='baseline' else SOURCE
            mapping=bound['source']['baseline_sha256'] if label=='baseline' else bound['source']['source_sha256']
            for name,digest in mapping.items():
                target=folder/name
                if label=='baseline':
                    data=git('show',BASE+':'+name);assert hashlib.sha256(data).hexdigest()==digest
                    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
                assert sha(target)==digest
            sources[label]=dict(head=BASE if label=='baseline' else full['head'],
                tree=git('rev-parse',BASE+'^{tree}').decode().strip() if label=='baseline' else full['tree'],
                root=str(folder),native_tree='72dc8a5da2cbbeddcdd26c219d50770e8b73b06' if label=='baseline' else full['native_tree'],
                native_manifest_sha256=mapping_sha(mapping),files={name:artifact(folder/name) for name in mapping})
        # Keep the exact baseline tree from the already checked Git binding, not a typed abbreviation.
        sources['baseline']['native_tree']=bound['source']['baseline_native_tree']
        verifier=DEPS/'verus/verus-x86-linux/verus'
        sysroot=DEPS/'rustup/toolchains/1.99.1-x86_64-unknown-linux-gnu'
        pin=json.loads((SOURCE/'native/toolchain.json').read_text())
        tools={name:artifact(verifier.parent/name) for name in
            ('verus','rust_verify','z3','vstd.vir','libvstd.rlib','libverus_builtin.rlib',
             'libverus_builtin_macros.so','libverus_state_machines_macros.so')}
        tools.update(rustup=artifact(DEPS/'cargo/bin/rustup'),rustc=artifact(sysroot/'bin/rustc'),
            llvm=artifact(next((sysroot/'lib').glob('libLLVM-*.so'))),
            rustc_driver=artifact(next((sysroot/'lib').glob('librustc_driver*.so'))),
            archive=artifact(DEPS/'verus-download'/pin['archive']),python=artifact(sys.executable),git=artifact(GIT[0]))
        for name in ('ar','objdump','objcopy'):tools[name]=artifact(shutil.which(name))
        tools['gmp']=artifact(prior['binaries']['baseline']['gmp_path'])
        inputs={name:artifact(SOURCE/name) for name in preflight['source']['inputs_sha256']}
        for name,row in inputs.items():assert row['sha256']==preflight['source']['inputs_sha256'][name]
        accepted=json.loads((BASELINE/'verification.json').read_text())
        old=accepted['producer_reuse']['original_complete_build_command']
        original=Path(accepted['producer_reuse']['source'])
        sys.path.insert(0,str(ROOT/'experiments/fused-interpolation-20261108'))
        from raw_validate import PROOF_TOOLS,KEY_SHAPES,validate_build
        common_tools={name:tools[name]['sha256'] for name in PROOF_TOOLS}
        producers={
            'baseline':dict(native_tree=sources['baseline']['native_tree'],
                native_manifest_sha256=sources['baseline']['native_manifest_sha256'],tools_sha256=common_tools,
                receipt=artifact(BASELINE/'verification.json'),rlib=artifact(BASELINE/'libverigmp.rlib'),vir=artifact(BASELINE/'verigmp.vir'),
                verified_items=358,proof=dict(argv=old['argv'],cwd=old['cwd'],returncode=old['returncode'],
                    stdout=artifact(original/'library-proof-release.stdout.log'),stderr=artifact(original/'library-proof-release.stderr.log'))),
            'candidate':dict(native_tree=sources['candidate']['native_tree'],
                native_manifest_sha256=sources['candidate']['native_manifest_sha256'],tools_sha256=common_tools,
                receipt=artifact(GATE/'full-native.json'),rlib=artifact(GATE/'libverigmp.rlib'),vir=artifact(GATE/'verigmp.vir'),
                verified_items=int(full['summary'][0][0]),proof=dict(argv=full['argv'],cwd=full['cwd'],returncode=full['returncode'],
                    stdout=artifact(GATE/'full-native.stdout.log'),stderr=artifact(GATE/'full-native.stderr.log')))
        }
        identity=dict(schema='fused-interpolation-identity-v1',status='static_pass',sources=sources,tools=tools,inputs=inputs,
            producers=producers,gate_receipts=dict(correctness=artifact(GATE/'untimed-01/verification.json'),
                semantic_mutants=artifact(GATE/'untimed-01/verification.json'),domain_alias_capacity=artifact(GATE/'untimed-01/verification.json'),
                control_identity=artifact(GATE/'codegen-05/control-identity.json'),host=artifact(GATE/'codegen-05/host.json')),
            independent_review_pending=True,timing_authorized=False,scope='same-source static identities only; root/Astra review remains required')
        write(OUT/'identity.json',identity)
        build=dict(schema='fused-interpolation-bench-build-v1',status='static_pass',seed=20261108,cell_count=86,
            key_shapes=[list(pair) for pair in KEY_SHAPES],source_head=full['head'],source_tree=full['tree'],
            identity_receipt=artifact(OUT/'identity.json'),binaries=prior['binaries'],benchmark_executed=False,
            timing_authorized=False,independent_review_pending=True)
        write(OUT/'bench-build.json',build)
        validated,_=validate_build((OUT/'bench-build.json').read_bytes(),sha(OUT/'bench-build.json'))
        assert validated==build
        report.update(status='static_binding_pass',bench_build=artifact(OUT/'bench-build.json'),identity=artifact(OUT/'identity.json'),
            normalized_producer_items={label:row['verified_items'] for label,row in producers.items()},
            stop_utc=datetime.now(timezone.utc).isoformat());save()
    except BaseException as error:
        report.update(status='fail',failure=repr(error));save();raise
    print(json.dumps(dict(status=report['status'],bench_build_sha256=report['bench_build']['sha256'],
        identity_sha256=report['identity']['sha256'],report_sha256=sha(OUT/'verification.json'),
        benchmark_executed=False,timing_authorized=False)),flush=True)

if __name__=='__main__':main()

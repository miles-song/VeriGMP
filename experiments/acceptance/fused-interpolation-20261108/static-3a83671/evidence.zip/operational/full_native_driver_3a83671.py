from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import re,subprocess,sys

OUT=Path(__file__).resolve().parent/'gates-3a83671-01'
sys.path.insert(0,str(OUT))
import binding_driver as binding

def save(value):
    (OUT/'full-native.json').write_text(json.dumps(value,indent=2)+'\n')
def now():return datetime.now(timezone.utc).isoformat()
def main():
    binding.bind()
    bound=json.loads((OUT/'binding.json').read_text())
    preflight=json.loads((OUT/'preflight.json').read_text())
    assert preflight['source']['head']==binding.HEAD
    assert preflight['source']['tree']==bound['source']['tree']
    assert preflight['source']['native_manifest_sha256']==bound['source']['manifest_sha256']
    assert binding.git('rev-parse','HEAD:native').decode().strip()=='212dd5d00d4b2159abd4627a6aaec8b16a1157e5'
    for name,digest in preflight['source']['inputs_sha256'].items():
        data=binding.git('show',binding.HEAD+':'+name)
        assert hashlib.sha256(data).hexdigest()==digest
        target=OUT/'source'/name;target.parent.mkdir(exist_ok=True,parents=True);target.write_bytes(data)
    env=dict(os.environ,CARGO_HOME=str(binding.DEPS/'cargo'),RUSTUP_HOME=str(binding.DEPS/'rustup'),
             RUSTUP_TOOLCHAIN='1.99.1-x86_64-unknown-linux-gnu',PYTHONDONTWRITEBYTECODE='1')
    env['PATH']=str(binding.DEPS/'cargo/bin')+os.pathsep+env['PATH']
    argv=[str(binding.DEPS/'verus/verus-x86-linux/verus'),'native/lib.rs','--crate-type','lib','--crate-name','verigmp',
          '--no-cheating','--compile','-O','--num-threads','2','--export',str(OUT/'verigmp.vir'),'-o',str(OUT/'libverigmp.rlib')]
    report=dict(status='running',phase='complete-native-proof-and-optimized-build',head=binding.HEAD,
        tree=bound['source']['tree'],native_tree='212dd5d00d4b2159abd4627a6aaec8b16a1157e5',
        native_manifest_sha256=bound['source']['manifest_sha256'],binding_sha256=binding.file_sha(OUT/'binding.json'),
        preflight_sha256=binding.file_sha(OUT/'preflight.json'),driver_sha256=binding.file_sha(__file__),
        argv=argv,cwd=str(OUT/'source'),driver_pid=os.getpid(),start_utc=now(),timeout_seconds=900,
        terminal=dict(stdin_isatty=sys.stdin.isatty(),stdout_isatty=sys.stdout.isatty(),tty_name=None),
        selected_environment={key:env[key] for key in ('CARGO_HOME','RUSTUP_HOME','RUSTUP_TOOLCHAIN','PATH')},
        process_affinity=sorted(os.sched_getaffinity(0)),focused_scope_reused=False,timing=False)
    with (OUT/'full-native.stdout.log').open('wb') as stdout,(OUT/'full-native.stderr.log').open('wb') as stderr:
        process=subprocess.Popen(argv,cwd=OUT/'source',env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr)
        report['verus_launcher_pid']=process.pid;save(report)
        print(json.dumps(dict(status='launched',driver_pid=os.getpid(),verus_launcher_pid=process.pid,
                             argv=argv,terminal=report['terminal'],timeout_seconds=900)),flush=True)
        try:report['returncode']=process.wait(timeout=900);report['timed_out']=False
        except subprocess.TimeoutExpired:
            process.terminate();process.wait(timeout=30);report.update(returncode=process.returncode,timed_out=True)
    text=(OUT/'full-native.stdout.log').read_text()+(OUT/'full-native.stderr.log').read_text()
    summary=re.findall(r'(?m)^verification results:: (\d+) verified, (\d+) errors$',text)
    report.update(stop_utc=now(),summary=summary,stdout_sha256=binding.file_sha(OUT/'full-native.stdout.log'),
                  stderr_sha256=binding.file_sha(OUT/'full-native.stderr.log'))
    report['status']='pass' if report['returncode']==0 and not report['timed_out'] and len(summary)==1 and summary[0][1]=='0' else 'fail'
    assert binding.manifest(OUT/'source')==bound['source']['source_sha256']
    if report['status']=='pass':
        report['exports_sha256']={name:binding.file_sha(OUT/name) for name in ('libverigmp.rlib','verigmp.vir')}
    save(report)
    print(json.dumps(dict(status=report['status'],returncode=report['returncode'],summary=summary,
                         report_sha256=binding.file_sha(OUT/'full-native.json'))),flush=True)
    if report['status']!='pass':raise SystemExit(1)

if __name__=='__main__':main()

from pathlib import Path
import shutil

workspace=Path(__file__).resolve().parent
out=workspace/'gates-3a83671-01'
out.mkdir(exist_ok=False)
driver=(workspace/'focused-cb9f268-01/focus_driver.py').read_text()
driver=driver.replace("HEAD='cb9f26860accdfb3471e5e668b42a6a732da3608'",
                      "HEAD='3a836713adbb0a6632f5131e8d57c97296d22f62'")
(out/'binding_driver.py').write_bytes(driver.encode())
shutil.copyfile(workspace/'source-ready-3a83671/preflight.json',out/'preflight.json')
print(out)

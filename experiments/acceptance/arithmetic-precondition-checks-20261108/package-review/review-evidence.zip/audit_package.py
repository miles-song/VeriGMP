"""Independent staged-tree and archive audit; all outputs stay outside the repo."""
import argparse
import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import zipfile

REPO = Path('E:/3sat/VeriGMP-arithmetic-precondition-checks-20261108')
BASELINE = 'de9ca4562c0c9c7d34f1a6a65cbaf48e48c7e1f9'
CANDIDATE = '905edec767a9e5eeee838e083cad93e027d73c51'
FEATURE = 'experiments/acceptance/arithmetic-precondition-checks-20261108'
HISTORICAL = 'experiments/arithmetic-precondition-checks-20261108'
ROOT = Path(__file__).resolve().parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args])

def save(path,data):
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')

def entries(tree,prefix=None):
    args=['ls-tree','-r','-z',tree]
    if prefix:
        args.append(prefix)
    result={}
    for item in git(*args).split(b'\0'):
        if not item:
            continue
        metadata,name=item.split(b'\t')
        mode,kind,oid=metadata.decode().split()
        result[name.decode()]={'mode':mode,'kind':kind,'oid':oid}
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tree',required=True)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    out=args.output.resolve();out.mkdir(exist_ok=False)
    snapshot=out/'snapshot';snapshot.mkdir()
    baseline=entries(BASELINE);candidate=entries(CANDIDATE);proposed=entries(args.tree)
    native={k:v for k,v in proposed.items() if k.startswith('native/')}
    assert native=={k:v for k,v in baseline.items() if k.startswith('native/')}
    assert len(native)==57
    for name in ('README.md','README.zh-CN.md'):
        assert proposed[name]==baseline[name]
    delta={k for k in set(proposed)|set(baseline) if proposed.get(k)!=baseline.get(k)}
    assert all(k in ('docs/benchmarks.md','docs/verification.md') or k.startswith(FEATURE+'/') or k.startswith(HISTORICAL+'/') for k in delta)
    for name in delta:
        assert name in proposed
        if name.startswith(HISTORICAL+'/'):
            assert proposed[name]==candidate[name]
    # Snapshot bytes from the immutable tree, never from a changing worktree.
    wanted=delta|set(native)|{'README.md','README.zh-CN.md','AGENTS.md','.gitattributes'}
    snapshot_hashes={}
    for name in sorted(wanted):
        data=git('show',args.tree+':'+name)
        target=snapshot/name;target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
        snapshot_hashes[name]=dict(git_blob=proposed[name]['oid'],sha256=sha(data),bytes=len(data))
    save(out/'staged-source-identities.json',snapshot_hashes)
    (out/'baseline-delta.patch').write_bytes(git('diff','--no-ext-diff',BASELINE,args.tree,'--',':(exclude)'+FEATURE+'/evidence.zip'))
    (out/'candidate-delta.patch').write_bytes(git('diff','--no-ext-diff',CANDIDATE,args.tree,'--',':(exclude)'+FEATURE+'/evidence.zip'))
    feature=snapshot/FEATURE
    manifest=json.loads((feature/'manifest.json').read_text(encoding='utf-8'))
    payloads=manifest['payload_sha256'];objects=manifest['object_bytes']
    archive_audits=[]
    with zipfile.ZipFile(feature/'evidence.zip') as z:
        assert len(z.namelist())==len(set(z.namelist()))==len(objects)
        assert set(z.namelist())=={'objects/'+x for x in objects}
        assert z.testzip() is None
        blob={digest:z.read('objects/'+digest) for digest in objects}
        for digest,data in blob.items():
            assert len(data)==objects[digest] and sha(data)==digest
        assert set(payloads.values())==set(objects)
        assert sha((feature/'evidence.zip').read_bytes())==manifest['evidence_zip_sha256']
        assert (feature/'evidence.zip').stat().st_size==manifest['evidence_zip_bytes']
        def logical(name):
            return blob[payloads[name]]
        original_archives={
            'author-static':Path('E:/3sat/VeriGMP-precondition-evidence-20261108/prereview-raw.zip'),
            'author-harness':Path('E:/3sat/VeriGMP-precondition-evidence-20261108/harness-prereview-raw.zip'),
            'independent-static':Path('E:/3sat/VeriGMP-precondition-astra-20261108/review-evidence.zip'),
            'independent-final/review-evidence.zip!':Path('E:/3sat/VeriGMP-precondition-performance-astra-20261108/review-evidence.zip'),
        }
        archive_meta={r['prefix']:r for r in manifest['archives']}
        assert set(archive_meta)==set(original_archives)
        for prefix,path in original_archives.items():
            metadata=archive_meta[prefix]
            assert sha(path.read_bytes())==metadata['archive_sha256']
            assert path.stat().st_size==metadata['bytes']
            with zipfile.ZipFile(path) as original:
                infos=original.infolist()
                assert len(infos)==metadata['members']
                names=[i.filename for i in infos if not i.is_dir()]
                assert len(names)==metadata['payload_files']
                assert {name[len(prefix)+1:] for name in payloads if name.startswith(prefix+'/')}==set(names)
                for name in names:
                    assert original.read(name)==logical(prefix+'/'+name),prefix+'/'+name
            archive_audits.append(dict(prefix=prefix,sha256=metadata['archive_sha256'],members=len(infos),
                                       payloads_verified=len(names)))
        # Bind all staged feature payload copies to exact Git-export bytes.
        feature_checks=[]
        for name in payloads:
            if name.startswith('feature/'):
                relative=name[len('feature/'):]
                assert (feature/relative).read_bytes()==logical(name),name
                feature_checks.append(relative)
        for name in ('native-restoration.json','historical-candidate.patch'):
            assert (feature/name).read_bytes()==logical(name)
        restored=json.loads(logical('native-restoration.json'))
        assert set(restored['native_sha256'])==set(native)
        for name,digest in restored['native_sha256'].items():
            assert snapshot_hashes[name]['sha256']==digest
        prior=Path('E:/3sat/VeriGMP-precondition-performance-astra-20261108')
        assert logical('independent-final/review.json')==(prior/'review.json').read_bytes()
        assert logical('independent-final/REVIEW.md')==(prior/'REVIEW.md').read_bytes()
        for n in (1,2):
            for name in ('measurement.json','raw.jsonl'):
                assert logical(f'measurement/run-{n}/{name}')==(prior/f'inputs/measurement-host-1/run-{n}/{name}').read_bytes()
        assert logical('measurement/host-receipt.json')==(prior/'inputs/measurement-host-1/host-receipt.json').read_bytes()
        # Recreate the independent, previously accepted offline replay package from its logical members.
        replay=out/'independent-final';replay.mkdir()
        prefix='independent-final/review-evidence.zip!/'
        for name in payloads:
            if name.startswith(prefix):
                relative=name[len(prefix):]
                assert not relative.startswith('/') and '..' not in PurePosixPath(relative).parts
                target=replay/relative;target.parent.mkdir(exist_ok=True,parents=True)
                target.write_bytes(logical(name))
    # The checker is limited to stdlib I/O and numeric replay; no compiled payload runs.
    checker_source=(feature/'check_evidence.py').read_text(encoding='utf-8')
    syntax=ast.parse(checker_source)
    imports=[]
    for node in ast.walk(syntax):
        if isinstance(node,ast.Import):
            imports.extend(alias.name for alias in node.names)
        if isinstance(node,ast.ImportFrom):
            imports.append(node.module)
    assert set(imports)<=set(('csv','fractions','hashlib','io','json','math','pathlib','statistics','zipfile'))
    commands=[('author-checker',[sys.executable,str(feature/'check_evidence.py')]),
              ('independent-replay',[sys.executable,str(replay/'replay_audit.py'),'--output',str(out/'independent-replay-output')])]
    executions=[]
    for name,argv in commands:
        result=subprocess.run(argv,capture_output=True)
        (out/(name+'.stdout.log')).write_bytes(result.stdout)
        (out/(name+'.stderr.log')).write_bytes(result.stderr)
        executions.append(dict(name=name,argv=argv,returncode=result.returncode,
            stdout_sha256=sha(result.stdout),stderr_sha256=sha(result.stderr)))
        assert result.returncode==0,(name,result.stderr)
    author_report=json.loads((out/'author-checker.stdout.log').read_text(encoding='utf-8'))
    assert author_report['status']=='pass_no_go_evidence_verified'
    assert author_report['performance_accepted'] is False
    assert author_report['native_files']==57
    replay_checks={}
    for path in (prior/'audit-output').iterdir():
        replay_checks[path.name]=(out/'independent-replay-output'/path.name).read_bytes()==path.read_bytes()
    assert all(replay_checks.values())
    # Validate relative links in the current result/usage/docs against the staged Git tree.
    link_checks=[]
    for name in [FEATURE+'/RESULTS.md',FEATURE+'/CHECKER_USAGE.md','docs/benchmarks.md','docs/verification.md']:
        content=(snapshot/name).read_text(encoding='utf-8')
        for destination in re.findall(r'\]\(([^)]+)\)',content):
            if destination.startswith(('https:','http:','#','mailto:')):
                continue
            path=destination.split('#',1)[0]
            parts=[]
            for part in (PurePosixPath(name).parent/PurePosixPath(path)).parts:
                if part=='..':
                    parts.pop()
                elif part!='.':
                    parts.append(part)
            target='/'.join(parts)
            assert target in proposed or any(p.startswith(target+'/') for p in proposed),(name,destination,target)
            link_checks.append(dict(source=name,target=target))
    report=dict(status='PASS',reviewed_tree=args.tree,baseline=BASELINE,historical_candidate=CANDIDATE,
        native_exact_baseline_files=len(native),baseline_delta_paths=sorted(delta),
        historical_sources_unchanged=True,readmes_exact_baseline=True,
        archive_sha256=sha((feature/'evidence.zip').read_bytes()),archive_bytes=(feature/'evidence.zip').stat().st_size,
        manifest_sha256=sha((feature/'manifest.json').read_bytes()),checker_sha256=sha((feature/'check_evidence.py').read_bytes()),
        logical_payloads=len(payloads),unique_objects=len(objects),original_archives=archive_audits,
        feature_copies_verified=feature_checks,executions=executions,
        independent_replay_outputs_identical=replay_checks,relative_markdown_links_checked=link_checks,
        benchmarks_executed=False,source_mutations=False)
    save(out/'audit.json',report)
    print(json.dumps({k:report[k] for k in ('status','reviewed_tree','native_exact_baseline_files',
          'archive_sha256','manifest_sha256','checker_sha256','logical_payloads','unique_objects',
          'independent_replay_outputs_identical')},indent=2))

if __name__=='__main__':
    main()

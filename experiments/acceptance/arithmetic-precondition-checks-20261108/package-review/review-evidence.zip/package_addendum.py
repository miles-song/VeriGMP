"""Create a compact addendum receipt; do not duplicate large evidence archives."""
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
FINAL=ROOT/'final-audit'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,data):
    path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
audit=json.loads((FINAL/'audit.json').read_text(encoding='utf-8'))
receipt=dict(verdict='ACCEPT EVIDENCE-ONLY PACKAGE / NO-GO NATIVE OPTIMIZATION',
    accepted_tree=audit['reviewed_tree'],head='905edec767a9e5eeee838e083cad93e027d73c51',
    baseline=audit['baseline'],native_exact_baseline_files=57,performance_acceptance=False,
    native_promotion_accepted=False,evidence_package_accepted=True,unresolved_findings=[],
    package_sha256=audit['archive_sha256'],package_bytes=audit['archive_bytes'],
    manifest_sha256=audit['manifest_sha256'],checker_sha256=audit['checker_sha256'],
    logical_payloads=audit['logical_payloads'],unique_objects=audit['unique_objects'],
    historical_archive_members_independently_matched=2349,
    final_audit_sha256=sha(FINAL/'audit.json'),review_text_sha256=sha(ROOT/'REVIEW.md'),
    source_identities_sha256=sha(FINAL/'staged-source-identities.json'),
    independent_performance_review_sha256='66e24fc5271103691001d1d7992691f0ece0a6fd1b489462f58190aecfa9480c',
    checker_results=audit['executions'],independent_replay_outputs_identical=audit['independent_replay_outputs_identical'],
    source_mutations=False,benchmark_executed=False,process_changes=False,reviewer_commit=None,merge_or_push=False,
    scope='VeriGMP evidence-only restoration and negative-result preservation; excludes all M6 claims')
save(ROOT/'review.json',receipt)
files=[ROOT/name for name in ('REVIEW.md','review.json','audit_package.py','package_addendum.py')]
files += [p for p in FINAL.iterdir() if p.is_file()]
files += [ROOT/name/'audit-failure.json' for name in ('attempt-1','attempt-2','accepted-tree-audit','accepted-tree-audit-2')]
files += [p for p in (FINAL/'snapshot').rglob('*') if p.is_file() and p.name!='evidence.zip']
manifest={p.relative_to(ROOT).as_posix():dict(bytes=p.stat().st_size,sha256=sha(p)) for p in files}
save(ROOT/'review-evidence-members.json',manifest)
with zipfile.ZipFile(ROOT/'review-evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[ROOT/'review-evidence-members.json']:
        info=zipfile.ZipInfo(p.relative_to(ROOT).as_posix(),date_time=(2026,11,8,8,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,p.read_bytes(),compresslevel=9)
with zipfile.ZipFile(ROOT/'review-evidence.zip') as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(manifest)+1
    for name,row in manifest.items():
        data=z.read(name)
        assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
save(ROOT/'review-package.json',dict(verdict=receipt['verdict'],accepted_tree=audit['reviewed_tree'],
    receipt_sha256=sha(ROOT/'review.json'),review_sha256=sha(ROOT/'REVIEW.md'),archive_sha256=sha(ROOT/'review-evidence.zip'),
    archive_bytes=(ROOT/'review-evidence.zip').stat().st_size,manifest_sha256=sha(ROOT/'review-evidence-members.json'),
    manifest_listed_payload_files=len(manifest),archive_members=len(manifest)+1,
    large_author_evidence_archive_is_separately_bound_not_duplicated=audit['archive_sha256']))
print((ROOT/'review-package.json').read_text(encoding='utf-8'))

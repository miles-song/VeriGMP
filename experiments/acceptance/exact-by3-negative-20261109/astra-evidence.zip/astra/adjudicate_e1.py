"""Independent, read-only adjudication of the frozen exact-by3 E1 window."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
WINDOW = Path(r"E:\3sat\VeriGMP-exact-by3-measurement-window-20261109-01")
OUTPUT = WINDOW / "measurement-E1-01"
PLAN_PATH = WINDOW / "plan.json"
GRANT_PATH = WINDOW / "root-go-E1.json"
BUILD_PATH = Path(r"E:\3sat\gmp-exact-by3-gates-20261109-01\caller\performance-freeze\bench-build.json")
TIMING_CANDIDATE_PATH = BUILD_PATH.parent / "timing-candidate.json"
IDENTITY_PATH = BUILD_PATH.parent / "identity.json"
HOST_RECEIPT = OUTPUT / "host-receipt.json"
EXPECTED = {
    "plan": "f02d186a51fd0560f2d6d18f88b086cc5394215285bc72ee3adae46c9a50b7ea",
    "grant": "9dda301b188c436d6750641c9b0cb3f61f625237735657d960d93ad5f3815367",
    "build": "05130a2af31db678ff77f5a8dc2c4f6cb0fab9a927d07b451b1bd62182e3a9a3",
    "identity": "9562b2ebdb7c8da4aa59f2ebf139144dc49b710b8dfbd8458e26c8196f69e7ae",
    "timing_candidate": "7fea94cbae8bdc0acb11e59b2abca9f658299141dbceb4b3be4eba1bddf39211",
    "protocol": "0e8dc6f90f46ef7bef129ecdc3ea4ae038ba0a09d921affa37ca36ee0af0ca0b",
    "source_head": "d5acf5ba17b32993ea0272aa9b17669412cd688b",
    "source_tree": "988c46ae554a1e10a0a356f3018d2568e9f2ff85",
    "native_tree": "1b1d99e2d9b7eee8b8e4ee7083bdf93344ab7fc4",
    "publication_head": "2010bd4a025d7cdf22e153a5e198f2f33b43cf77",
    "publication_tree": "3cc25bdec266408e012ffff9641e767d854474bd",
}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def check(ok, message, failures):
    if not ok:
        failures.append(message)


def load_validator():
    path = HERE / "validate_future_raw.py"
    spec = importlib.util.spec_from_file_location("e1_raw_validator", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    failures = []
    checks = []
    for label, path, expected in (
        ("plan", PLAN_PATH, EXPECTED["plan"]),
        ("grant", GRANT_PATH, EXPECTED["grant"]),
        ("build", BUILD_PATH, EXPECTED["build"]),
        ("identity", IDENTITY_PATH, EXPECTED["identity"]),
        ("timing_candidate", TIMING_CANDIDATE_PATH, EXPECTED["timing_candidate"]),
    ):
        actual = digest(path)
        checks.append({"check": label + "_sha256", "pass": actual == expected, "actual": actual, "expected": expected})
        check(actual == expected, label + " hash mismatch", failures)
    plan = load(PLAN_PATH)
    grant = load(GRANT_PATH)
    host = load(HOST_RECEIPT)
    check(host.get("status") == "registered_runs_collected_performance_pending_analysis", "host did not finish registered runs", failures)
    check(host.get("window") == "E1" and host.get("cpu") == 8 and host.get("benchmark_launched") is True, "host window/cpu/launch state mismatch", failures)
    expected_host = {
        "source_head": EXPECTED["source_head"], "source_tree": EXPECTED["source_tree"], "native_tree": EXPECTED["native_tree"],
        "publication_head": EXPECTED["publication_head"], "publication_tree": EXPECTED["publication_tree"],
        "build_sha256": EXPECTED["build"], "identity_receipt_sha256": EXPECTED["identity"],
        "timing_candidate_sha256": EXPECTED["timing_candidate"], "authoritative_protocol_sha256": EXPECTED["protocol"],
    }
    for key, expected in expected_host.items():
        check(host.get(key) == expected, "host receipt identity mismatch: " + key, failures)
    expected_grant = {
        "schema": "exact-by3-root-grant-v1", "status": "granted", "explicit_root_go": True,
        "granted_by": "/root", "timing_authorized": True, "window": "E1", "plan_sha256": EXPECTED["plan"],
        "cpu": 8, "source_head": EXPECTED["source_head"], "source_tree": EXPECTED["source_tree"],
        "native_tree": EXPECTED["native_tree"], "build_sha256": EXPECTED["build"],
        "identity_receipt_sha256": EXPECTED["identity"], "timing_candidate_sha256": EXPECTED["timing_candidate"],
        "authoritative_protocol_sha256": EXPECTED["protocol"], "publication_head": EXPECTED["publication_head"],
        "publication_tree": EXPECTED["publication_tree"], "publication_map_accepted": True,
        "independent_prereviews": "READY", "all_active_workers_quiescent": True,
    }
    for key, expected in expected_grant.items():
        check(grant.get(key) == expected, "root grant mismatch: " + key, failures)
    roster = list(grant.get("active_worker_roster", []))
    acks = list(grant.get("worker_acknowledgements", []))
    check(len(roster) > 0 and len(roster) == len(set(roster)), "root grant worker roster missing/duplicated", failures)
    check(sorted(roster) == sorted({row.get("worker") for row in acks}), "root grant worker acknowledgements do not cover roster", failures)
    check(all(row.get("status") == "quiescent" and row.get("plan_sha256") == EXPECTED["plan"] for row in acks), "root grant has non-quiescent or unbound acknowledgement", failures)
    spec = plan["windows"]["E1"]
    check((spec["pause_budget_seconds"], spec["restore_reserve_seconds"], spec["command_teardown_seconds"]) == (480, 75, 15), "window budget changed", failures)
    check(host.get("pause_seconds", 10**9) <= 480, "host pause exceeded 480 seconds", failures)
    check(host.get("avd_restored") is True and not host.get("restore_error") and not host.get("final_identity_error") and not host.get("final_provenance_error"), "host restoration/provenance failed", failures)
    resumes = list(host.get("resume", []))
    check(len(resumes) == 2 and all(row.get("status") == "resumed" and row.get("nt_status") == 0 for row in resumes), "owned emulator handles were not both restored", failures)
    commands = list(host.get("commands", []))
    expected_commands = ["avd-name-before", "avd-status-before", "initial-provenance", "avd-pause", "avd-status-paused",
                        "exact-by3-run-1-provenance-before", "exact-by3-run-1", "exact-by3-run-1-provenance-after",
                        "exact-by3-run-2-provenance-before", "exact-by3-run-2", "exact-by3-run-2-provenance-after",
                        "avd-resume-finally", "avd-status-after-finally", "final-provenance-after-restore"]
    check([row.get("name") for row in commands] == expected_commands, "host command sequence changed", failures)
    check(all(row.get("returncode") == 0 and not row.get("timed_out") for row in commands), "host command failure or timeout recorded", failures)
    command_log_hashes = []
    for row in commands:
        for suffix in (".stdout.log", ".stderr.log"):
            path = OUTPUT / (row["name"] + suffix)
            check(path.exists() and digest(path) == row.get("stdout_sha256" if suffix.startswith(".stdout") else "stderr_sha256"), "command log hash mismatch: " + row["name"] + suffix, failures)
            command_log_hashes.append({"path": str(path), "sha256": digest(path) if path.exists() else None})
    preflights = list(host.get("preflight_receipts", []))
    preflight_results = []
    for row in preflights:
        path = Path(row["path"])
        check(path.exists() and digest(path) == row.get("sha256"), "preflight receipt hash mismatch: " + row.get("name", "?"), failures)
        if path.exists():
            value = load(path)
            preflight_results.append({"name": row.get("name"), "path": str(path), "sha256": digest(path), "status": value.get("status"), "benchmark_executed": value.get("benchmark_executed"), "calibration_executed": value.get("calibration_executed")})
            check(value.get("status") == "pass" and value.get("benchmark_executed") is False and value.get("calibration_executed") is False and value.get("native_build_executed") is False and value.get("verus_executed") is False, "preflight status/side-effect flags failed: " + row.get("name", "?"), failures)
    check(len(preflights) == 6, "expected six provenance preflights", failures)
    validator = load_validator()
    run1 = OUTPUT / "exact-by3-run-1"
    run2 = OUTPUT / "exact-by3-run-2"
    try:
        build, candidate, identity, cells, primary = validator.frozen(BUILD_PATH, TIMING_CANDIDATE_PATH, IDENTITY_PATH)
        first = validator.one_run(run1, build, candidate, cells, primary)
        second = validator.one_run(run2, build, candidate, cells, primary)
        controls = set(cells) - primary
        drift = {cell: second["cells"][cell]["medians"]["baseline"] / first["cells"][cell]["medians"]["baseline"] for cell in controls}
        drift_gm = validator.geomean(list(drift.values()))
        drift_range = [min(drift.values()), max(drift.values())]
        raw_result = {
            "raw_integrity": "pass", "run1": {k: v for k, v in first.items() if k != "cells"},
            "run2": {k: v for k, v in second.items() if k != "cells"}, "control_drift_geomean": drift_gm,
            "control_drift_range": drift_range, "control_drift_pass": 0.95 <= drift_gm <= 1.05 and 0.9 <= drift_range[0] and drift_range[1] <= 1.1,
        }
        for label, value in (("run1", first), ("run2", second)):
            report = load((run1 if label == "run1" else run2) / "measurement.json")
            check(report.get("status") == "pass" and report.get("build_sha256") == EXPECTED["build"] and report.get("cpu") == 8 and report.get("seed") == 20261108 and report.get("repetitions") == 7 and report.get("minimum_sample_ns") == 10_000_000, label + " report binding failed", failures)
            check(len(report.get("summaries", [])) == 86, label + " summary count failed", failures)
            check(value["invocations"] == 2064 and value["retries"] >= 0, label + " raw invocation count failed", failures)
            check(digest((run1 if label == "run1" else run2) / "raw.jsonl") == report.get("raw_sha256"), label + " raw report hash failed", failures)
        performance_decision = "ACCEPT" if first["primary_pass"] and second["primary_pass"] and first["all_cell_pass"] and second["all_cell_pass"] and raw_result["control_drift_pass"] else "NO-GO"
        worst = {
            "run1_primary_geomean": first["primary_geomean"], "run2_primary_geomean": second["primary_geomean"],
            "run1_all_cell_max": first["all_cell_max"], "run2_all_cell_max": second["all_cell_max"],
            "control_drift_geomean": drift_gm, "control_drift_min": drift_range[0], "control_drift_max": drift_range[1],
            "run1_worst_all_cell": max(first["cells"].items(), key=lambda item: item[1]["candidate_over_baseline"])[0],
            "run2_worst_all_cell": max(second["cells"].items(), key=lambda item: item[1]["candidate_over_baseline"])[0],
            "worst_control_drift_cell": max(drift.items(), key=lambda item: item[1])[0],
        }
    except Exception as error:
        raw_result = {"raw_integrity": "fail", "error": repr(error)}
        performance_decision = "NO-GO"
        worst = {}
        failures.append("raw validator exception: " + repr(error))
    check(performance_decision == "NO-GO", "unexpected performance decision", failures)
    report = {
        "schema": "exact-by3-independent-e1-adjudication-v1", "verdict": "NO-GO",
        "decision_basis": "The raw streams and provenance are structurally valid, but the registered performance and drift thresholds fail.",
        "plan_sha256": digest(PLAN_PATH), "root_grant_sha256": digest(GRANT_PATH), "host_receipt_sha256": digest(HOST_RECEIPT),
        "build_sha256": digest(BUILD_PATH), "timing_candidate_sha256": digest(TIMING_CANDIDATE_PATH), "identity_sha256": digest(IDENTITY_PATH),
        "source_head": EXPECTED["source_head"], "source_tree": EXPECTED["source_tree"], "native_tree": EXPECTED["native_tree"],
        "publication_head": EXPECTED["publication_head"], "publication_tree": EXPECTED["publication_tree"],
        "host": {"status": host.get("status"), "pause_method": host.get("pause_method"), "pause_seconds": host.get("pause_seconds"), "avd_restored": host.get("avd_restored"), "resumes": resumes, "command_count": len(commands), "preflight_count": len(preflights), "preflight_results": preflight_results},
        "runs": {"run1_raw_sha256": digest(run1 / "raw.jsonl"), "run2_raw_sha256": digest(run2 / "raw.jsonl"), "run1_raw_records": sum(1 for _ in (run1 / "raw.jsonl").open("rb")), "run2_raw_records": sum(1 for _ in (run2 / "raw.jsonl").open("rb"))},
        "raw_gate": raw_result, "worst_cells": worst, "checks_failed": failures, "check_count": len(checks),
        "reviewer_executed_timing": False, "reviewer_executed_calibration": False,
    }
    out = HERE / "e1-adjudication.json"
    out.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    receipt_sha = digest(out)
    sidecar = HERE / "e1-adjudication.sha256"
    sidecar.write_text(receipt_sha + "  e1-adjudication.json\n", encoding="ascii")
    print(json.dumps({"verdict": report["verdict"], "receipt": str(out), "receipt_sha256": receipt_sha, "sha256_sidecar": str(sidecar), "failures": failures, "raw_gate": raw_result, "worst_cells": worst}, indent=2))


if __name__ == "__main__":
    main()

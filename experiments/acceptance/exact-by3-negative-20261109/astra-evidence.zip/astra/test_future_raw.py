"""Offline schema tests: synthetic fixtures and historical unrelated raw records only."""
import copy
import hashlib
import json
from pathlib import Path
import statistics
import tempfile
import zipfile

import validate_future_raw as v

HERE = Path(__file__).resolve().parent
ROOT = Path(r'E:\3sat\gmp-exact-by3-gates-20261109-01\caller\performance-freeze')
ARCHIVE = Path(r'E:\3sat\VeriGMP-negative-experiments-20261108\experiments\acceptance\fused-interpolation-negative-20261109\review-evidence.zip')
build, plan, ident, cells, primary = v.frozen(ROOT/'bench-build.json', ROOT/'timing-candidate.json', ROOT/'identity.json')
bins = {k: (row['path'], row['sha256']) for k, row in build['binaries'].items()}


def save(directory, records, report):
    directory.mkdir(exist_ok=True)
    raw = b''.join((json.dumps(row, sort_keys=True)+'\n').encode() for row in records)
    (directory/'raw.jsonl').write_bytes(raw)
    report['raw_sha256'] = hashlib.sha256(raw).hexdigest()
    (directory/'measurement.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8')


def synthetic(run_id, variant=0, altered_cell=None, altered_path=None, factor=1.0):
    rows, summaries = [], []
    for index, (op, n, top) in enumerate(cells):
        cell = (op, n, top)
        groups = {p: [] for p in ('baseline', 'candidate', 'gmp')}
        counts = {p: 1 for p in groups}
        def call(path, kind, rep, count, ns):
            fields = dict(op=op, n=n, top=top, path=path, kind=kind, repetition=rep)
            arg = [bins['baseline' if path in ('baseline', 'gmp') else 'candidate'][0], str(op), str(n), str(top), '20261108', str(path=='gmp').lower(), str(count), 'registered']
            payload = dict(iterations=1 if kind=='calibration' else count, ns=ns, checksum=index+1,
                           calibration=[[1, ns]] if kind=='calibration' else [])
            stdout = json.dumps(payload, separators=(',', ':'))+'\n'
            rows.extend([dict(fields, argv=arg, record='invocation', cpu=8, timeout_seconds=180),
                         dict(fields, argv=arg, record='outcome', returncode=0, timed_out=False, stdout=stdout,
                              stdout_hex=stdout.encode().hex(), stderr='', stderr_hex=''),
                         dict(fields, argv=arg, record='result', **payload)])
        for path in groups:
            call(path, 'calibration', -1, 0, 20_000_000)
        for rep in range(7):
            for path in v.order(index, rep):
                ns_per_count = {'baseline':20_000_000, 'candidate':19_000_000, 'gmp':21_000_000}[path] + variant
                selected = (cell == altered_cell or
                            altered_cell == 'primary' and cell in primary or
                            altered_cell == 'controls' and cell not in primary)
                if selected and path == altered_path:
                    ns_per_count = int(ns_per_count*factor)
                if index == 0 and rep == 0 and path == 'baseline':
                    call(path, 'sample', rep, 1, 5_000_000)
                    counts[path] = 2
                    call(path, 'sample-retry', rep, 2, ns_per_count*2)
                else:
                    call(path, 'sample', rep, counts[path], ns_per_count*counts[path])
                groups[path].append(ns_per_count)
        medians = {p: statistics.median(x) for p, x in groups.items()}
        summaries.append(dict(op=op, n=n, top=top, median_ns=medians,
                              candidate_over_baseline=medians['candidate']/medians['baseline'],
                              candidate_over_gmp=medians['candidate']/medians['gmp']))
    report = dict(status='pass', run_id=run_id, seed=20261108, cpu=8, build_sha256=v.EXPECTED_BUILD,
                  build=build, minimum_sample_ns=10_000_000, repetitions=7, summaries=summaries)
    return rows, report


def reject(label, function):
    try:
        function()
    except (ValueError, KeyError, TypeError, IndexError, OverflowError):
        return label
    raise AssertionError('accepted malformed fixture: '+label)


def change_payload(rows, pos, **changes):
    parsed = json.loads(rows[pos+1]['stdout'])
    parsed.update(changes)
    stdout = json.dumps(parsed, separators=(',', ':'))+'\n'
    rows[pos+1]['stdout'] = stdout
    rows[pos+1]['stdout_hex'] = stdout.encode().hex()
    rows[pos+2].update(parsed)


def retry_wrong_count(rows):
    for row in rows[15:18]:
        row['argv'][6] = '3'
    change_payload(rows, 15, iterations=3)


def historical_triples():
    with zipfile.ZipFile(ARCHIVE) as archive:
        name = 'captured-window/measurement-F1-02/fused-run-1/raw.jsonl'
        rows = [json.loads(line) for line in archive.read(name).splitlines()]
    # Old fused experiment's real producer paths; this tests schema only, not this candidate.
    old_bins = {'baseline': (rows[0]['argv'][0], 'historical'), 'candidate': (rows[3]['argv'][0], 'historical')}
    for position in range(0, len(rows), 3):
        fields = {key: rows[position][key] for key in ('op','n','top','path','kind','repetition')}
        _, next_position = v.expect_triplet(rows, position, fields, old_bins)
        assert next_position == position + 3
    return len(rows)//3


def main():
    negatives = []
    with tempfile.TemporaryDirectory(dir=HERE, prefix='schema-test-') as name:
        base = Path(name)
        a, ar = synthetic('synthetic-1')
        b, br = synthetic('synthetic-2', 10)
        save(base/'a', a, ar); save(base/'b', b, br)
        result = v.validate(ROOT/'bench-build.json', ROOT/'timing-candidate.json', ROOT/'identity.json', base/'a', base/'b')
        assert result['timing_decision'] == 'eligible_for_later_independent_performance_review'
        assert [x['retries'] for x in result['launches']] == [1, 1]
        checks = [
            ('missing_record', lambda r: r.pop(1)),
            ('duplicate_record', lambda r: r.append(copy.deepcopy(r[-1]))),
            ('wrong_cpu', lambda r: r[0].update(cpu=7)),
            ('wrong_argv', lambda r: r[0]['argv'].__setitem__(0, '/wrong/binary')),
            ('nonzero_exit', lambda r: r[1].update(returncode=1)),
            ('timeout', lambda r: r[1].update(timed_out=True)),
            ('stdout_bytes_tamper', lambda r: r[1].update(stdout_hex='00')),
            ('result_mismatch', lambda r: r[2].update(checksum=999)),
            ('calibration_doubling', lambda r: change_payload(r, 0, calibration=[[2,20_000_000]])),
            ('calibration_stop_rule', lambda r: change_payload(r, 0, iterations=2, calibration=[[1,20_000_000],[2,20_000_000]])),
            ('omitted_retry', lambda r: r.__delitem__(slice(15,18))),
            ('incorrect_retry_doubling', retry_wrong_count),
        ]
        for label, edit in checks:
            broken = copy.deepcopy(a); edit(broken); save(base/'bad', broken, copy.deepcopy(ar))
            negatives.append(reject(label, lambda: v.one_run(base/'bad', build, plan, cells, primary)))
        bad_report = copy.deepcopy(ar);bad_report['summaries'][0]['candidate_over_baseline'] = 0.1
        save(base/'bad', a, bad_report)
        negatives.append(reject('forged_summary', lambda: v.one_run(base/'bad', build, plan, cells, primary)))
        br_duplicate = copy.deepcopy(ar);br_duplicate['run_id'] = 'synthetic-copy'
        save(base/'duplicate', a, br_duplicate)
        negatives.append(reject('copied_raw', lambda: v.validate(ROOT/'bench-build.json', ROOT/'timing-candidate.json', ROOT/'identity.json', base/'a', base/'duplicate')))
        control = next(x for x in cells if x not in primary)
        drift, dr = synthetic('synthetic-drift', 10, control, 'baseline', 1.15)
        save(base/'drift', drift, dr)
        decision = v.validate(ROOT/'bench-build.json', ROOT/'timing-candidate.json', ROOT/'identity.json', base/'a', base/'drift')
        assert decision['timing_decision'] == 'NO_GO_OR_BASELINE_DRIFT' and not decision['control_drift_pass']
        slow, sr = synthetic('synthetic-slow', 10, control, 'candidate', 1.15)
        save(base/'slow', slow, sr)
        decision = v.validate(ROOT/'bench-build.json', ROOT/'timing-candidate.json', ROOT/'identity.json', base/'a', base/'slow')
        assert decision['timing_decision'] == 'NO_GO_OR_BASELINE_DRIFT' and not decision['launches'][1]['all_cell_pass']
        primary_slow, psr = synthetic('synthetic-primary-slow', 10, 'primary', 'candidate', 1.04)
        save(base/'primary-slow', primary_slow, psr)
        decision = v.validate(ROOT/'bench-build.json', ROOT/'timing-candidate.json', ROOT/'identity.json', base/'a', base/'primary-slow')
        assert decision['timing_decision'] == 'NO_GO_OR_BASELINE_DRIFT'
        assert not decision['launches'][1]['primary_pass'] and decision['launches'][1]['all_cell_pass']
        control_mean, cmr = synthetic('synthetic-control-mean', 10, 'controls', 'baseline', 1.06)
        save(base/'control-mean', control_mean, cmr)
        decision = v.validate(ROOT/'bench-build.json', ROOT/'timing-candidate.json', ROOT/'identity.json', base/'a', base/'control-mean')
        assert decision['timing_decision'] == 'NO_GO_OR_BASELINE_DRIFT' and not decision['control_drift_pass']
        assert 0.9 <= decision['control_drift_range'][0] <= decision['control_drift_range'][1] <= 1.1
    result = dict(status='pass', synthetic_only=True, synthetic_complete_cells=86,
                  synthetic_launches=2, retry_tested=True, negative_cases=negatives,
                  individual_control_drift_rejected=True, control_geomean_drift_rejected=True,
                  primary_geomean_rejected=True, all_cell_regression_rejected=True,
                  historical_unrelated_raw_triples=historical_triples(),
                  historical_raw_is_candidate_evidence=False)
    output = json.dumps(result, indent=2) + '\n'
    (HERE/'raw-validator-test-result.json').write_text(output, encoding='utf-8')
    print(output, end='')


if __name__ == '__main__':
    main()

"""Offline E1 identity and fixture review. Does not run preflight.main or benchmarks."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
E1 = Path(r'E:\3sat\VeriGMP-exact-by3-measurement-window-20261109-01')
EXPECTED = {
    'plan.json': 'f02d186a51fd0560f2d6d18f88b086cc5394215285bc72ee3adae46c9a50b7ea',
    'timing_host.ps1': 'bab5a2ac1ab59dee88cdf0f38b0fdd08bec73dddb5473050de9bc126375a08a4',
    'preflight.py': '29c47b4acd481464315fc4402b0da3e863bc8af030273595d9399c432b133120',
}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_fixture(argv):
    result = subprocess.run(argv, cwd=E1, capture_output=True, text=True, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(f'fixture failed: {argv!r}\n{result.stdout}\n{result.stderr}')
    data = json.loads(result.stdout)
    assert data['status'] == 'pass'
    return {'argv': argv, 'exit_code': result.returncode, 'result': data, 'stderr': result.stderr}


def main():
    for name, expected in EXPECTED.items():
        assert digest(E1/name) == expected, name
    plan = json.loads((E1/'plan.json').read_text(encoding='utf-8'))
    for name, expected in plan['support_sha256'].items():
        assert digest(E1/name) == expected, name
    spec = importlib.util.spec_from_file_location('e1_preflight', E1/'preflight.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.check_plan(plan)
    window = plan['windows']['E1']
    assert (window['calibration_threshold_ns'], window['calibrations_per_run'],
            window['accepted_samples_per_run']) == (20_000_000, 258, 1806)
    assert (plan['publication']['head'], plan['publication']['tree']) == (
        '2010bd4a025d7cdf22e153a5e198f2f33b43cf77', '3cc25bdec266408e012ffff9641e767d854474bd')
    candidate_path = Path(r'E:\3sat\gmp-exact-by3-gates-20261109-01\caller\performance-freeze\timing-candidate.json')
    assert digest(candidate_path) == plan['build']['timing_candidate']['sha256']
    candidate = json.loads(candidate_path.read_text(encoding='utf-8'))
    assert candidate['control_cell_count'] == 71
    assert candidate['control_baseline_each_ratio_range'] == [0.9, 1.1]
    assert candidate['control_baseline_run2_over_run1_geomean_range'] == [0.95, 1.05]
    assert candidate['primary_geomean_max'] == 0.98 and candidate['all_cell_regression_max'] == 1.05
    pwsh = Path(plan['host_tools']['pwsh']['path'])
    assert digest(pwsh) == plan['host_tools']['pwsh']['sha256']
    plan_fixture = run_fixture([sys.executable, '-B', str(E1/'test_plan.py')])
    grant_fixture = run_fixture([str(pwsh), '-NoLogo', '-NoProfile', '-NonInteractive', '-File', str(E1/'test_grant.ps1')])
    assert not plan_fixture['result']['real_process_calls'] and not plan_fixture['result']['benchmark_executed']
    assert not grant_fixture['result']['real_process_calls'] and not grant_fixture['result']['real_emulator_affected']
    seal_path = HERE/'eligibility.json'
    seal = json.loads(seal_path.read_text(encoding='utf-8'))
    keys = ['source_head', 'source_tree', 'native_tree', 'publication_head', 'publication_tree',
            'build_sha256', 'identity_sha256', 'timing_candidate_sha256', 'authoritative_protocol_sha256',
            'plan_sha256', 'executor_sha256', 'verdict']
    grant = {'timing_review_path': str(seal_path), 'timing_review_sha256': digest(seal_path),
             'timing_review_verdict': seal['verdict'], 'timing_review_pointers': {k: '/'+k for k in keys}}
    matched = module.check_review(plan, E1/'plan.json', grant)
    rejected = []
    for key in keys:
        mutated = copy.deepcopy(seal)
        mutated[key] = 'drift'
        with patch.object(module, 'load', return_value=mutated):
            try:
                module.check_review(plan, E1/'plan.json', grant)
            except (ValueError, KeyError, TypeError):
                rejected.append(key)
            else:
                raise AssertionError('drift accepted: ' + key)
    out = {'status': 'pass', 'plan': {'path': str(E1/'plan.json'), 'sha256': EXPECTED['plan.json']},
           'executor': {'path': str(E1/'timing_host.ps1'), 'sha256': EXPECTED['timing_host.ps1']},
           'preflight': {'path': str(E1/'preflight.py'), 'sha256': EXPECTED['preflight.py']},
           'support_sha256_checked': plan['support_sha256'], 'eligibility_sha256': digest(seal_path),
           'real_seal_pointer_match': matched, 'real_seal_mutation_rejections': rejected,
           'plan_fixture': plan_fixture, 'grant_fixture': grant_fixture,
           'timing_executed': False, 'calibration_executed': False, 'emulator_affected': False}
    (HERE/'e1-audit-result.json').write_text(json.dumps(out, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'status': out['status'], 'seal_sha256': out['eligibility_sha256'],
                      'seal_mutants_rejected': len(rejected), 'plan_cases': len(plan_fixture['result']['cases']),
                      'grant_cases': len(grant_fixture['result']['cases']),
                      'budget_cases': len(grant_fixture['result']['budget_cases'])}, indent=2))


if __name__ == '__main__':
    main()

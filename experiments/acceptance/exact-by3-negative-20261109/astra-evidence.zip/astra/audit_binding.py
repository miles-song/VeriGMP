"""Read-only Git/source and frozen artifact identity audit; does not launch measurements."""
import hashlib
import json
from pathlib import Path
import subprocess

REPO = Path(r'C:\Users\23247\.codex\worktrees\gmp-exact-by3-20261109\VeriGMP-negative-experiments-20261108')
GATE = Path(r'E:\3sat\gmp-exact-by3-gates-20261109-01')
HERE = Path(__file__).resolve().parent
PUBLIC = '2010bd4a025d7cdf22e153a5e198f2f33b43cf77'
CALLER = 'd5acf5ba17b32993ea0272aa9b17669412cd688b'
HELPER = 'c28039e165e082fdcff7ab3ed72eb32252d0153e'
BASE = '4510b46e4010dd287c9cf760f0195f2edc32e1f7'
MAIN = '338632fef7f0cbe5b442cc6b00b7161bebded647'
PACKAGE = REPO/'experiments/acceptance/exact-by3-20261109/static-d5acf5b'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def filehash(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1024*1024):
            h.update(chunk)
    return h.hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def git_blobs(commit, paths):
    result = subprocess.run(
        ['git', 'cat-file', '--batch'], cwd=REPO, input=''.join(commit+':'+p+'\n' for p in paths).encode(),
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True).stdout
    out, pos = {}, 0
    for path in paths:
        end = result.index(b'\n', pos)
        header = result[pos:end].decode().split()
        assert len(header) == 3 and header[1] == 'blob', (path, header)
        size = int(header[2]); pos = end+1
        out[path] = result[pos:pos+size]; pos += size
        assert result[pos:pos+1] == b'\n'; pos += 1
    assert pos == len(result)
    return out


def tree(commit):
    entries = {}
    for item in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if item:
            metadata, path = item.split(b'\t', 1)
            entries[path.decode('utf-8')] = metadata.decode('ascii')
    return entries


def main():
    assert git('rev-parse', 'HEAD').decode().strip() == PUBLIC
    assert git('rev-parse', 'HEAD^{tree}').decode().strip() == '3cc25bdec266408e012ffff9641e767d854474bd'
    assert not git('status', '--porcelain=v1')
    for older, newer in ((HELPER,CALLER),(CALLER,PUBLIC),(BASE,MAIN)):
        assert subprocess.run(['git','merge-base','--is-ancestor',older,newer],cwd=REPO).returncode == 0
    frozen = {}
    for name, commit, native in [('helper',HELPER,'abab6414b759c2cd02046fc68c22f8ada20543d8'),
                                 ('caller',CALLER,'1b1d99e2d9b7eee8b8e4ee7083bdf93344ab7fc4')]:
        snapshot = json.loads((GATE/name/'freeze.json').read_bytes())
        assert snapshot['source_commit']==commit and snapshot['native_tree']==native
        assert git('rev-parse',commit+'^{tree}').decode().strip()==snapshot['source_tree']
        assert git('rev-parse',commit+':native').decode().strip()==native
        paths = sorted(snapshot['files_sha256']); contents = git_blobs(commit, paths)
        for path in paths:
            assert sha(contents[path]) == snapshot['files_sha256'][path], ('Git input',name,path)
            assert filehash(GATE/name/'source'/path) == snapshot['files_sha256'][path], ('live capture',name,path)
        frozen[name] = dict(commit=commit,tree=snapshot['source_tree'],native_tree=native,files_verified=len(paths),
                            freeze_sha256=filehash(GATE/name/'freeze.json'))
    old,new = tree(BASE),tree(MAIN)
    assert len(old)==4565 and all(new.get(k)==value for k,value in old.items())
    added=sorted(set(new)-set(old)); mapping=json.loads((PACKAGE/'production-baseline-map.json').read_bytes())
    assert len(added)==14 and added==mapping['added_paths']
    assert git('rev-parse',BASE+':native')==git('rev-parse',MAIN+':native')
    assert git('rev-parse',BASE+':native').decode().strip()=='72dc8a5da2cbb7eddcdd26c219d50770e8b73b06'
    native_count=len([x for x in old if x.startswith('native/')]);assert native_count==57
    consumed=mapping['consumed_inputs']; blobs=git_blobs(BASE,sorted(consumed))
    for path, data in blobs.items():
        assert sha(data)==consumed[path]['sha256'] and old[path].split()[2]==consumed[path]['blob']
    allowed={'experiments/exact-by3-20261109/PROTOCOL.md','experiments/exact-by3-20261109/README.md',
             'experiments/exact-by3-20261109/STATUS.json','native/proof-status.json'}
    changes=set(git('diff','--name-only',CALLER,PUBLIC).decode().splitlines())
    assert all(x in allowed or x.startswith('experiments/acceptance/exact-by3-20261109/static-d5acf5b/') for x in changes)
    proto='experiments/exact-by3-20261109/PROTOCOL.md'
    historical=sha(git_blobs(CALLER,[proto])[proto]); current=sha(git_blobs(PUBLIC,[proto])[proto])
    assert historical=='536a4e79ad20ae07a528e65cefc0a71a52d9f74ab2d1ca7d9bc005af6836c1ab'
    assert current=='0e8dc6f90f46ef7bef129ecdc3ea4ae038ba0a09d921affa37ca36ee0af0ca0b'
    files = {
        'helper_rlib': ('helper/libverigmp.rlib','cde19331bc1828f9d9acc0c480afa39420c04ffcf8eb4c6b90f7e13605a2f38c'),
        'helper_vir': ('helper/verigmp.vir','504ece512958911ceae9bde8462dfc30ed383ab6a90e95c698688f4fb245eefd'),
        'caller_rlib': ('caller/libverigmp.rlib','bec3f74f58537c2d8807bcb7273444f9f3b24592aee2b9897741b9006c355202'),
        'caller_vir': ('caller/verigmp.vir','d19fd47d9f610d95de9e9746ec79abc1d5711fe7900a5415fe6802de59a60559'),
        'benchmark_baseline': ('caller/performance-freeze/bench-baseline','a47a2e5b445be236bb0bd84d0a62d63c541dd30dc8c7a5ea8422f679b26712d4'),
        'benchmark_candidate': ('caller/performance-freeze/bench-candidate','26e59850368f23b93478fe0e8c09520b72b9bcb5bea3e23fdefcd7b2dae40229'),
        'build': ('caller/performance-freeze/bench-build.json','05130a2af31db678ff77f5a8dc2c4f6cb0fab9a927d07b451b1bd62182e3a9a3'),
        'identity': ('caller/performance-freeze/identity.json','9562b2ebdb7c8da4aa59f2ebf139144dc49b710b8dfbd8458e26c8196f69e7ae'),
        'timing_candidate': ('caller/performance-freeze/timing-candidate.json','7fea94cbae8bdc0acb11e59b2abca9f658299141dbceb4b3be4eba1bddf39211')}
    for label,(path,want) in files.items():
        assert filehash(GATE/path)==want, label
    baseline = Path(r'E:\3sat\VeriGMP-precondition-evidence-20261108\baseline-binding')
    assert filehash(baseline/'libverigmp.rlib')=='02dabb57ecbee4b82fe99b4ed555cbd892160b999b47d01d9ac0ab9788372d28'
    assert filehash(baseline/'verigmp.vir')=='9890ff7d0d62f53101b41089017f913ecd6495421e54c79e2819735c3769ed41'
    assert filehash(PACKAGE/'evidence.zip')=='69ff54aa4c8e56979e1d6936efa8dad15c424e210e20d6b4693e851d6f5e2348'
    result=dict(status='pass',publication_head=PUBLIC,publication_tree='3cc25bdec266408e012ffff9641e767d854474bd',
                clean=True, frozen_sources=frozen, all_frozen_file_bytes_match_git=True,
                baseline_commit=BASE,current_public_main=MAIN,old_entries_preserved=len(old),
                added_entries=len(added), native_entries=native_count, consumed_inputs=len(consumed),
                baseline_native_tree='72dc8a5da2cbb7eddcdd26c219d50770e8b73b06',
                publication_changes=sorted(changes), historical_protocol_sha256=historical,
                authoritative_text_protocol_sha256=current, artifacts={k:w for k,(_,w) in files.items()},
                benchmark_executed_by_reviewer=False, calibration_executed_by_reviewer=False)
    (HERE/'binding-result.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()

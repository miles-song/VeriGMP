# Independent exact-by3 timing-eligibility review

Status: READY for the frozen prospective E1 timing plan, subject to a fresh
independent root grant, complete worker quiescence and the conditions below.
This is not performance acceptance or authorization to run a benchmark.

## Bound identities

- Public feature publication: `2010bd4a025d7cdf22e153a5e198f2f33b43cf77`, tree `3cc25bdec266408e012ffff9641e767d854474bd`.
- Compiled interpolation caller: `d5acf5ba17b32993ea0272aa9b17669412cd688b`, tree `988c46ae554a1e10a0a356f3018d2568e9f2ff85`, native tree `1b1d99e2d9b7eee8b8e4ee7083bdf93344ab7fc4`.
- Verified helper: `c28039e165e082fdcff7ab3ed72eb32252d0153e`, tree `eec8663782d01d4bd61cd1b0f6622aceccd37899`, native tree `abab6414b759c2cd02046fc68c22f8ada20543d8`.
- Baseline `4510b46e4010dd287c9cf760f0195f2edc32e1f7` and public main `338632fef7f0cbe5b442cc6b00b7161bebded647` share native tree `72dc8a5da2cbb7eddcdd26c219d50770e8b73b06`.
- Candidate rlib / vir SHA-256: `bec3f74f58537c2d8807bcb7273444f9f3b24592aee2b9897741b9006c355202` / `d19fd47d9f610d95de9e9746ec79abc1d5711fe7900a5415fe6802de59a60559`.
- Baseline rlib / vir SHA-256: `02dabb57ecbee4b82fe99b4ed555cbd892160b999b47d01d9ac0ab9788372d28` / `9890ff7d0d62f53101b41089017f913ecd6495421e54c79e2819735c3769ed41`.
- Baseline / candidate benchmark SHA-256: `a47a2e5b445be236bb0bd84d0a62d63c541dd30dc8c7a5ea8422f679b26712d4` / `26e59850368f23b93478fe0e8c09520b72b9bcb5bea3e23fdefcd7b2dae40229`.
- Build / identity / prospective timing-candidate SHA-256: `05130a2af31db678ff77f5a8dc2c4f6cb0fab9a927d07b451b1bd62182e3a9a3` / `9562b2ebdb7c8da4aa59f2ebf139144dc49b710b8dfbd8458e26c8196f69e7ae` / `7fea94cbae8bdc0acb11e59b2abca9f658299141dbceb4b3be4eba1bddf39211`.
- Current authoritative protocol text SHA-256: `0e8dc6f90f46ef7bef129ecdc3ea4ae038ba0a09d921affa37ca36ee0af0ca0b`. Static evidence archive SHA-256: `69ff54aa4c8e56979e1d6936efa8dad15c424e210e20d6b4693e851d6f5e2348`.
- Frozen E1 plan / host executor / preflight SHA-256: `f02d186a51fd0560f2d6d18f88b086cc5394215285bc72ee3adae46c9a50b7ea` / `bab5a2ac1ab59dee88cdf0f38b0fdd08bec73dddb5473050de9bc126375a08a4` / `29c47b4acd481464315fc4402b0da3e863bc8af030273595d9399c432b133120`.

## Scope and evidence

The actual interpolation caller changes only its exact division by three to the
verified specialized helper. The helper processes low to high, preserves the
slice frame and requires the input integer to be divisible by three; the actual
caller proves that precondition. Generic division by two, generic thresholds,
scratch contracts and the excluded fused experiment are outside this change.
This review does not claim a full solver proof or GMP performance parity.

The retained helper and actual-caller full-native proof logs each report 373
verified and zero errors under `--no-cheating --compile -O --num-threads 2`;
the previously accepted 358-item baseline producer is reused. The helper's
1,022 independent cases produce 1,237 actual Rust requests per tested producer.
Each actual caller has 1,084 independently input-defined expected-value cases,
including interpolation, multiply, square, alias-compatible shared input and
forced full Toom paths. Canary, invalid-call, borrow and strict logical-negative
evidence was inspected with its stated valid-domain limits. Parse, tool, timeout
or resource errors were not counted as semantic rejections. These are retained
author-gate results, not newly rerun proof or arithmetic-oracle results.

The original arithmetic function whose code changes is the interpolation body;
its measured object size changes from 1,679 to 1,695 bytes. In its `/3` loop,
the reported two multiplies become one, but comparisons, register allocation,
carry dependencies and layout still matter. Eight new 26-byte spec/proof panic
stubs remain in the rlib without incoming arithmetic relocations and are absent
from the final linked benchmark after garbage collection. This supports the
stated proof-erasure boundary, not a universal absence claim or a speed claim.

The independent binding audit matched all 74 helper and 76 caller frozen inputs
against both their Git blobs and retained captured files. All 4,565 old baseline
entries remain unchanged on the listed public main; its 14 additions are
evidence-only, with 57 unchanged native entries and ten consumed-input blobs
also checked. The clean publication's caller-to-publication delta is confined to
four named metadata files and the acceptance package. Exact bytes, paired
artifacts and results are recorded in `binding-result.json` and its audit script.
The author package's read-only checker passed its publication check with 1,209
archive members; no native proof, benchmark, or calibration was run by this
reviewer.

## Protocol provenance and preconditions

The identity's historical protocol hash `536a4e79ad20ae07a528e65cefc0a71a52d9f74ab2d1ca7d9bc005af6836c1ab`
matches the caller Git snapshot and retained source. Commit `27f0e42188e3ecbcb6263ee9a4278e763e0da3a1`
revises the status text and adds control-cell drift gates; the published text has
the current `0e8dc6f9...` hash above. The prospective candidate JSON binds the
new text, old identity and frozen build, and explicitly supersedes the older
preparation-state reference before timing. Original 86-cell, two-launch, 0.98
primary and 1.05 all-cell limits are unchanged; the 71 control-cell drift limits
add constraints. The inherited W2 protocol, SHA-256
`9d0ff9f3eb847c3a8002497e585e4084d1145653181bcaa029aeeccbcbe65f09`,
clarifies that accepted samples must be at least 10 ms and shorter attempts
are retained with a doubled-count retry. A Git commit or hash by itself cannot
prove no earlier run.
The controller has separately attested, from the author, gate receipts, old
session and controller records, that this candidate has not been timed or
calibrated. That attestation is a required factual premise of this eligibility.

E1 binds the fixed plan, executor, source, publication, build, protocol,
benchmark binaries and loaded GMP. Static review and offline fixtures checked
26 plan/seal cases, 17 grant cases and five budget cases; the real eligibility
file passed the preflight's JSON-pointer check, and all 12 individual binding
mutations were rejected. Fixture runs did not invoke the live preflight,
emulator, benchmark, calibration, compiler or Verus. Raw fixture outcomes and
the exact support hashes are in `e1-audit-result.json`.

Execution conditions before timing:

1. Bind the fresh grant to the frozen plan, this eligibility receipt and the
   exact source, publication, build and protocol. Check the binary, loaded-GMP,
   driver, argv, seed and output identities at live preflight and immediately
   before and after each launch.
2. Obtain root's separate quiet-window grant and record a live CPU 8 affinity
   and environment preflight. The host reserves 75 seconds within the
   480-second pause budget, and reserves another 15 seconds of work time for
   command teardown. It records a failure for overrun or unsuccessful restore.
   OS or hardware failure can defeat a software deadline or restoration;
   these operations are best effort rather than an absolute physical guarantee.
   Preserve incomplete runs, failures, timeouts and raw output without selection.
3. Perform exactly two distinct, complete 86-cell launches, each with seven
   retained samples per cell and all calibration/retry records. The registered
   sequence, minimum 10 ms retained batches, count doubling, no discretionary
   retry or selection, and full raw invocation/outcome/result triples apply.
4. Each launch must satisfy the 15-primary-cell candidate/baseline geometric
   mean <= 0.98 and every one of the 86 candidate/baseline ratios <= 1.05. Across
   launches, all 71 baseline control ratios must lie in [0.90, 1.10] and their
   geometric mean in [0.95, 1.05]. Record baseline/GMP drift. Any failure,
   incomplete run, violated deadline or missing evidence yields no-go, not a
   selected or relaxed result. Passing permits later independent performance
   review only.

The separately compiled direct-kernel diagnostic remains frozen, with build
receipt SHA-256 `cc28c7db0fa3ab96d9f6650b6e403d3567dea2042fda22245923323ccfb95aec`.
Its registered per-length medians and dependency-chain discussion remain future
performance-review work. The 86-cell end-to-end gate alone cannot complete
feature acceptance.

The existing measurement driver enforces neither the aggregate wall deadline
nor the cross-launch thresholds by itself. Controller/executor evidence and an
independent post-run validator are therefore necessary. The included future-raw
validator does not execute benchmarks. Its offline tests cover two synthetic
86-cell streams, count-doubling retry, 14 malformed cases, individual and
geometric-mean control drift, primary geometric mean, and all-cell regression;
2,064 records from an unrelated historical run
were checked for raw-triple schema compatibility only. No synthetic or prior
experiment data is candidate performance evidence. Distinct run IDs or raw
hashes alone cannot prove independent launches or a quiet host.

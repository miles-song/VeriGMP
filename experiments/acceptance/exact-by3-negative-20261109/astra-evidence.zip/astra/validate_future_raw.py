"""Fail-closed validation of two future exact-by3 runs; never launches benchmarks."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

FULL=(1,2,7,8,9,23,24,25,31,32,33,47,48,49,63,64,65,127,128,129,
      191,192,193,255,256,257,511,512,513,1023,1024,1025,2048,4096)
EXPECTED_BUILD='05130a2af31db678ff77f5a8dc2c4f6cb0fab9a927d07b451b1bd62182e3a9a3'
EXPECTED_PROTOCOL='7fea94cbae8bdc0acb11e59b2abca9f658299141dbceb4b3be4eba1bddf39211'
EXPECTED_IDENTITY='9562b2ebdb7c8da4aa59f2ebf139144dc49b710b8dfbd8458e26c8196f69e7ae'

def digest(raw):return hashlib.sha256(raw).hexdigest()
def require(ok,message):
    if not ok:raise ValueError(message)
def median(values):return statistics.median(values)
def geomean(values):return math.exp(sum(math.log(x) for x in values)/len(values))
def order(cell_index,rep):
    paths=['baseline','candidate'] if rep%2==0 else ['candidate','baseline']
    paths.insert((cell_index+rep)%3,'gmp')
    return paths

def frozen(build_path,protocol_path,identity_path):
    paths=[Path(x) for x in (build_path,protocol_path,identity_path)]
    for path,want in zip(paths,(EXPECTED_BUILD,EXPECTED_PROTOCOL,EXPECTED_IDENTITY)):
        require(digest(path.read_bytes())==want,'frozen receipt identity: '+str(path))
    build,plan,ident=[json.loads(path.read_bytes()) for path in paths]
    require(plan['bench_build']['sha256']==EXPECTED_BUILD
            and plan['identity']['sha256']==EXPECTED_IDENTITY, 'protocol dependency binding')
    require(build['identity_receipt']['sha256']==EXPECTED_IDENTITY, 'build identity binding')
    require(plan['authoritative_protocol']['sha256']=='0e8dc6f90f46ef7bef129ecdc3ea4ae038ba0a09d921affa37ca36ee0af0ca0b', 'current textual protocol binding')
    require(build['source_head']==plan['compiled_source']==ident['source_commit']
            =='d5acf5ba17b32993ea0272aa9b17669412cd688b', 'compiled source')
    require(build['native_tree']==plan['native_tree']==ident['native_tree']
            =='1b1d99e2d9b7eee8b8e4ee7083bdf93344ab7fc4', 'compiled native tree')
    require(build['complete_cell_count']==plan['complete_cell_count']==86
            and plan['control_cell_count']==71 and plan['complete_launches']==build['complete_runs']==2
            and build['repetitions']==plan['repetitions']==7
            and build['minimum_sample_ns']==plan['minimum_sample_ns']==10_000_000
            and build['prospective_cpu']==plan['prospective_cpu']==8
            and build['seed']==plan['seed']==20261108, 'frozen cell/repetition/cpu/seed contract')
    require(not any((build['timing_authorized'],build['calibration_authorized'],plan['timing_authorized'],
                     plan['benchmark_executed'],plan['calibration_executed'],ident['benchmark_executed'],
                     ident['calibration_executed'])), 'frozen premeasurement state')
    require(build['primary_cells']==plan['primary_cells'] and len(plan['primary_cells'])==15, 'primary-cell registration')
    key_shapes=[tuple(x) for x in build['key_shapes']]
    require(len(key_shapes)==26 and len(set(key_shapes))==26, 'registered key shapes')
    cells=[(0,n,64) for n in FULL]+[(op,n,top) for op in (1,2) for n,top in key_shapes]
    require(len(cells)==86 and len(set(cells))==86, 'complete fixed matrix')
    primary={(x['op'],x['n'],x['top']) for x in plan['primary_cells']}
    require(len(primary)==15 and primary<=set(cells) and all(op in (1,2) for op,n,top in primary), 'primary-cell subset')
    require(plan['primary_geomean_max']==build['primary_geomean_max']==0.98
            and plan['all_cell_regression_max']==build['all_cell_regression_max']==1.05
            and plan['control_baseline_run2_over_run1_geomean_range']==[0.95,1.05]
            and plan['control_baseline_each_ratio_range']==[0.9,1.1], 'frozen decision thresholds')
    for label in ('baseline','candidate'):
        require(build['binaries'][label]['sha256']==ident['binaries'][label]['sha256'], 'frozen binary hash: '+label)
    require(ident['baseline_commit']==plan['production_baseline']
            =='4510b46e4010dd287c9cf760f0195f2edc32e1f7', 'baseline source')
    return build,plan,ident,cells,primary

def expect_triplet(records,pos,fields,binary_sha):
    require(pos+2<len(records), 'truncated invocation/outcome/result')
    call,out,result=records[pos:pos+3]
    require([row.get('record') for row in (call,out,result)]==['invocation','outcome','result'], 'raw triple order')
    keys=('op','n','top','path','kind','repetition')
    for key,value in fields.items():
        require(all(row.get(key)==value for row in (call,out,result)), 'raw field: '+key)
    path=fields['path']
    expected=[binary_sha['baseline' if path in ('baseline','gmp') else 'candidate'],
              fields['op'],fields['n'],fields['top'],20261108,str(path=='gmp').lower()]
    argv=call.get('argv')
    require(isinstance(argv,list) and len(argv)==8 and Path(argv[0]).name==Path(expected[0][0]).name
            and argv[0]==expected[0][0], 'frozen executable argv')
    require(argv[1:6]==[str(x) for x in expected[1:]], 'frozen operation/input argv')
    require(argv[7]=='registered' and argv[6].isdigit(), 'frozen count mode')
    count=int(argv[6])
    require(count>=0 and count<2**64 and (count==0)==(fields['kind']=='calibration'), 'calibration/sample count')
    require(all(row.get('argv')==argv for row in (call,out,result))
            and call.get('cpu')==8 and call.get('timeout_seconds')==180,
            'argv/cpu/timeout fidelity')
    require(out.get('returncode')==0 and out.get('timed_out') is False
            and out.get('stderr')=='' and out.get('stderr_hex')=='', 'successful raw process outcome')
    stdout=out.get('stdout');require(isinstance(stdout,str) and out.get('stdout_hex')==stdout.encode().hex(), 'raw stdout bytes')
    parsed=json.loads(stdout)
    require(set(parsed)=={'iterations','ns','checksum','calibration'}, 'native response schema')
    require(all(isinstance(parsed[x],int) and not isinstance(parsed[x],bool) for x in ('iterations','ns','checksum')),
            'integer timing response')
    require(0<parsed['iterations']<2**64 and parsed['ns']>0 and 0<=parsed['checksum']<2**64, 'valid measured values')
    require(isinstance(parsed['calibration'],list), 'calibration array')
    if fields['kind']=='calibration':
        require(parsed['calibration'] and parsed['calibration'][-1]==[parsed['iterations'],parsed['ns']]
                and parsed['ns']>=20_000_000, 'calibration terminates at 20ms')
        for i,(iters,ns) in enumerate(parsed['calibration']):
            require(type(iters)==type(ns)==int and iters==2**i and ns>0, 'calibration doubling')
            if i<len(parsed['calibration'])-1:require(ns<20_000_000,'calibration stop rule')
    else:
        require(parsed['calibration']==[] and parsed['iterations']==count, 'sample count execution')
    for key,value in parsed.items():require(result.get(key)==value, 'result matches native stdout: '+key)
    require(result.get('argv')==argv and result.get('record')=='result', 'result invocation fidelity')
    return parsed,pos+3

def one_run(run_dir,build,plan,cells,primary):
    run_dir=Path(run_dir);raw=(run_dir/'raw.jsonl').read_bytes();report=json.loads((run_dir/'measurement.json').read_bytes())
    require(digest(raw)==report.get('raw_sha256'), 'raw hash binding')
    require(report.get('status')=='pass' and not report.get('failure') and report.get('run_id'), 'completed unique launch')
    require(report.get('seed')==20261108 and report.get('cpu')==8
            and report.get('build_sha256')==EXPECTED_BUILD
            and report.get('minimum_sample_ns')==10_000_000
            and report.get('repetitions')==7 and report.get('build')==build, 'report frozen build/seed/cpu')
    records=[json.loads(line) for line in raw.splitlines()]
    require(all(isinstance(row,dict) for row in records), 'object raw records')
    require(len(report.get('summaries',[]))==86, 'all summary cells')
    binaries={label:(row['path'],row['sha256']) for label,row in build['binaries'].items()}
    pos=0;all_rows={};all_checksum=[];invocations=0;retries=0
    for index,cell in enumerate(cells):
        op,n,top=cell;counts={};samples={path:[] for path in ('baseline','candidate','gmp')}
        checksums=[]
        for path in samples:
            row,pos=expect_triplet(records,pos,dict(op=op,n=n,top=top,path=path,kind='calibration',repetition=-1),binaries)
            counts[path]=row['iterations'];checksums.append(row['checksum']);invocations+=1
        for rep in range(7):
            for path in order(index,rep):
                row,pos=expect_triplet(records,pos,dict(op=op,n=n,top=top,path=path,kind='sample',repetition=rep),binaries)
                require(row['iterations']==counts[path], 'initial sample uses calibration count')
                checksums.append(row['checksum']);invocations+=1
                while row['ns']<10_000_000:
                    counts[path]*=2
                    require(counts[path]<2**64, 'count doubling overflow')
                    row,pos=expect_triplet(records,pos,dict(op=op,n=n,top=top,path=path,kind='sample-retry',repetition=rep),binaries)
                    require(row['iterations']==counts[path], 'exact retry doubling')
                    checksums.append(row['checksum']);invocations+=1;retries+=1
                samples[path].append(row['ns']/row['iterations'])
        require(len(set(checksums))==1, 'same exact answer all three arms/retries')
        all_checksum.append(checksums[0])
        medians={path:median(values) for path,values in samples.items()}
        summary=report['summaries'][index]
        require((summary.get('op'),summary.get('n'),summary.get('top'))==cell, 'registered summary cell order')
        require(set(summary.get('median_ns',{}))==set(samples), 'all arm medians')
        for path in samples:
            require(math.isclose(summary['median_ns'][path],medians[path],rel_tol=1e-12), 'median from raw')
        cb=medians['candidate']/medians['baseline'];cg=medians['candidate']/medians['gmp']
        require(math.isclose(summary['candidate_over_baseline'],cb,rel_tol=1e-12)
                and math.isclose(summary['candidate_over_gmp'],cg,rel_tol=1e-12), 'summary ratios from raw')
        all_rows[cell]=dict(medians=medians,candidate_over_baseline=cb,candidate_over_gmp=cg)
    require(pos==len(records), 'no trailing or omitted raw records')
    primary_gm=geomean([all_rows[cell]['candidate_over_baseline'] for cell in sorted(primary)])
    all_cell_max=max(row['candidate_over_baseline'] for row in all_rows.values())
    controls=set(cells)-primary
    require(len(controls)==71, '71 independent control cells')
    return dict(run_id=report['run_id'],raw_sha256=digest(raw),report_sha256=digest((run_dir/'measurement.json').read_bytes()),
                cells=all_rows,primary_geomean=primary_gm,all_cell_max=all_cell_max,
                primary_pass=primary_gm<=0.98,all_cell_pass=all_cell_max<=1.05,
                invocations=invocations,retries=retries)

def validate(build_path,protocol_path,identity_path,run1,run2):
    build,plan,ident,cells,primary=frozen(build_path,protocol_path,identity_path)
    a=one_run(run1,build,plan,cells,primary);b=one_run(run2,build,plan,cells,primary)
    require(a['run_id']!=b['run_id'] and Path(run1).resolve()!=Path(run2).resolve()
            and a['raw_sha256']!=b['raw_sha256'], 'two independent distinct launches and raw streams')
    controls=set(cells)-primary
    drift={cell:b['cells'][cell]['medians']['baseline']/a['cells'][cell]['medians']['baseline'] for cell in controls}
    drift_gm=geomean(list(drift.values()))
    drift_each=min(drift.values()),max(drift.values())
    drift_pass=0.95<=drift_gm<=1.05 and all(0.9<=x<=1.1 for x in drift.values())
    baseline_gmp_drift={cell:b['cells'][cell]['medians']['baseline']/b['cells'][cell]['medians']['gmp'] /
                        (a['cells'][cell]['medians']['baseline']/a['cells'][cell]['medians']['gmp']) for cell in cells}
    return dict(raw_integrity='pass',timing_decision='eligible_for_later_independent_performance_review' if
                all(x['primary_pass'] and x['all_cell_pass'] for x in (a,b)) and drift_pass else 'NO_GO_OR_BASELINE_DRIFT',
                build_sha256=EXPECTED_BUILD,protocol_sha256=EXPECTED_PROTOCOL,identity_sha256=EXPECTED_IDENTITY,
                launches=[{k:v for k,v in x.items() if k!='cells'} for x in (a,b)],
                control_drift_geomean=drift_gm,control_drift_range=drift_each,
                control_drift_pass=drift_pass,baseline_gmp_drift_range=[min(baseline_gmp_drift.values()),max(baseline_gmp_drift.values())],
                primary_cell_count=15,control_cell_count=71,complete_cell_count=86,
                performance_promoted=False,solver_backend_replaced=False)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for flag in ('build','protocol','identity','run1','run2'):parser.add_argument('--'+flag,required=True)
    args=parser.parse_args()
    print(json.dumps(validate(args.build,args.protocol,args.identity,args.run1,args.run2),indent=2))

if __name__=='__main__':main()

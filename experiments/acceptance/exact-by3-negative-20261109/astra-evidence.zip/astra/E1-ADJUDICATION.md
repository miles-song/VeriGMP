# Exact-by3 E1 independent adjudication

Verdict: **NO-GO** for performance promotion.

This review is bound to the frozen E1 plan (`f02d186a51fd0560f2d6d18f88b086cc5394215285bc72ee3adae46c9a50b7ea`), root grant (`9dda301b188c436d6750641c9b0cb3f61f625237735657d960d93ad5f3815367`), host receipt (`24bdf28b63e32be249bd2c723464282db9fb7383a1e4e8f9289c1f4b68944cba`), build (`05130a2af31db678ff77f5a8dc2c4f6cb0fab9a927d07b451b1bd62182e3a9a3`), identity (`9562b2ebdb7c8da4aa59f2ebf139144dc49b710b8dfbd8458e26c8196f69e7ae`), timing candidate (`7fea94cbae8bdc0acb11e59b2abca9f658299141dbceb4b3be4eba1bddf39211`), source head/tree (`d5acf5ba17b32993ea0272aa9b17669412cd688b` / `988c46ae554a1e10a0a356f3018d2568e9f2ff85`), native tree (`1b1d99e2d9b7eee8b8e4ee7083bdf93344ab7fc4`), and publication head/tree (`2010bd4a025d7cdf22e153a5e198f2f33b43cf77` / `3cc25bdec266408e012ffff9641e767d854474bd`).

The two registered streams contain 6,192 records each (2,064 invocations, seven repetitions, no retries). Their raw SHA-256 values are `2ed363fce6e012ccbc119e4a1714ef45f6a828d16a08982dcb486c01a41b95c7` and `428e6fc5b749a005a496a5960e6d5d2a7586add01e06361c66a98a9d0fa606c7`. Independent structural validation reports `raw_integrity=pass`.

The registered performance gate fails in three independent ways:

- Run 1 primary geometric mean: `1.003475113457792` (`> 0.98`).
- Run 2 primary geometric mean: `0.999232749796327` (`> 0.98`).
- Run 1 all-cell maximum: `1.0569454258446673` (`> 1.05`). Run 2 is `1.043576927224447`.
- Cross-run control drift geometric mean is `0.9940665863937836`, but its per-cell range is `[0.9115531242710423, 1.1238331700636073]`, exceeding the permitted `[0.9, 1.1]` range.

The host receipt records six passing no-side-effect preflights, 14 successful commands, a 218.8228747-second pause, and successful restoration of both owned handles (`nt_status=0`). Final provenance and identity checks pass. This review executed no timing, calibration, benchmark, compiler, Verus, or process-control operation; it only read the frozen evidence and ran the raw-stream validator.

The machine-readable adjudication is [e1-adjudication.json](E:\\3sat\\VeriGMP-exact-by3-timing-eligibility-astra-v2-20261109\\e1-adjudication.json), SHA-256 `2927663e58e3904008d5aea6f8b33f83865cdf2707b19b2dff3df389c4bcd156`, with its sidecar in [e1-adjudication.sha256](E:\\3sat\\VeriGMP-exact-by3-timing-eligibility-astra-v2-20261109\\e1-adjudication.sha256).

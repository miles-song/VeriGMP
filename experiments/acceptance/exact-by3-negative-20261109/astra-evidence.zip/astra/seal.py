"""Seal this review and the independently inspected, frozen E1 inputs."""
import hashlib
import json
from pathlib import Path
import zipfile

HERE = Path(__file__).resolve().parent
OWN_FILES = ('REVIEW.md', 'eligibility.json', 'audit_binding.py', 'binding-result.json',
             'validate_future_raw.py', 'test_future_raw.py',
             'raw-validator-test-result.json', 'audit_e1.py', 'e1-audit-result.json', 'seal.py')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    e1 = json.loads((HERE/'e1-audit-result.json').read_bytes())
    assert e1['status'] == 'pass'
    inputs = {name: (HERE/name).read_bytes() for name in OWN_FILES}
    eligibility = json.loads(inputs['eligibility.json'])
    assert eligibility['verdict'].startswith('READY')
    assert digest(inputs['eligibility.json']) == e1['eligibility_sha256']
    for role in ('plan', 'executor', 'preflight'):
        captured = Path(e1[role]['path']).read_bytes()
        assert digest(captured) == e1[role]['sha256'], role
        assert eligibility[role+'_sha256'] == e1[role]['sha256'], role
        inputs['frozen-e1/'+role+'-'+Path(e1[role]['path']).name] = captured
    binding = json.loads(inputs['binding-result.json'])
    raw = json.loads(inputs['raw-validator-test-result.json'])
    assert binding['status'] == raw['status'] == 'pass'
    assert eligibility['source_head'] == binding['frozen_sources']['caller']['commit']
    assert eligibility['publication_head'] == binding['publication_head']
    assert eligibility['publication_tree'] == binding['publication_tree']
    assert eligibility['build_sha256'] == binding['artifacts']['build']
    assert eligibility['identity_sha256'] == binding['artifacts']['identity']
    assert eligibility['timing_candidate_sha256'] == binding['artifacts']['timing_candidate']
    manifest = dict(schema=1, status=e1['status'], scope='prospective_timing_eligibility_only',
                    publication_head=binding['publication_head'], publication_tree=binding['publication_tree'],
                    compiled_source=binding['frozen_sources']['caller']['commit'],
                    build_sha256=binding['artifacts']['build'],
                    identity_sha256=binding['artifacts']['identity'],
                    timing_candidate_sha256=binding['artifacts']['timing_candidate'],
                    benchmark_executed_by_reviewer=False, calibration_executed_by_reviewer=False,
                    entries={name: dict(sha256=digest(data), size=len(data))
                             for name, data in sorted(inputs.items())})
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True)+'\n').encode()
    (HERE/'manifest.json').write_bytes(manifest_bytes)
    with zipfile.ZipFile(HERE/'review-evidence.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(inputs.items()):
            archive.writestr(name, data)
        archive.writestr('manifest.json', manifest_bytes)
    with zipfile.ZipFile(HERE/'review-evidence.zip') as archive:
        assert archive.testzip() is None
        assert {name: archive.read(name) for name in inputs} == inputs
        assert archive.read('manifest.json') == manifest_bytes
    print(json.dumps(dict(status=e1['status'], review_sha256=digest(inputs['REVIEW.md']),
                          eligibility_sha256=digest(inputs['eligibility.json']),
                          manifest_sha256=digest(manifest_bytes),
                          archive_sha256=digest((HERE/'review-evidence.zip').read_bytes()),
                          members=len(inputs)+1), indent=2))


if __name__ == '__main__':
    main()

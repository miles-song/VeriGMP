#!/usr/bin/env python3
"""Read-only E1 source, frozen-build, review, and host provenance checks."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys

HEAD = 'd5acf5ba17b32993ea0272aa9b17669412cd688b'
TREE = '988c46ae554a1e10a0a356f3018d2568e9f2ff85'
NATIVE = '1b1d99e2d9b7eee8b8e4ee7083bdf93344ab7fc4'
BASELINE = '4510b46e4010dd287c9cf760f0195f2edc32e1f7'
BUILD_SHA = '05130a2af31db678ff77f5a8dc2c4f6cb0fab9a927d07b451b1bd62182e3a9a3'
IDENTITY_SHA = '9562b2ebdb7c8da4aa59f2ebf139144dc49b710b8dfbd8458e26c8196f69e7ae'
CANDIDATE_SHA = '7fea94cbae8bdc0acb11e59b2abca9f658299141dbceb4b3be4eba1bddf39211'
PROTOCOL_SHA = '0e8dc6f90f46ef7bef129ecdc3ea4ae038ba0a09d921affa37ca36ee0af0ca0b'
OLD_PROTOCOL_SHA = '536a4e79ad20ae07a528e65cefc0a71a52d9f74ab2d1ca7d9bc005af6836c1ab'
RUNNER_SHA = '137d3b5607954f1fd3670220f73cd299d4f16bacb068a5a0981a30127137bcfa'
ROOT = '/mnt/e/3sat/gmp-exact-by3-gates-20261109-01/caller'
BUILD = ROOT + '/performance-freeze/bench-build.json'
RUNNER = ROOT + '/source/experiments/arithmetic-precondition-checks-20261108/measure.py'
OUTPUT = '/mnt/e/3sat/VeriGMP-exact-by3-measurement-window-20261109-01/measurement-E1-01'
DELTA = [
    ('A', 'experiments/acceptance/exact-by3-20261109/static-d5acf5b/RECEIPT.md'),
    ('A', 'experiments/acceptance/exact-by3-20261109/static-d5acf5b/check_evidence.py'),
    ('A', 'experiments/acceptance/exact-by3-20261109/static-d5acf5b/evidence.zip'),
    ('A', 'experiments/acceptance/exact-by3-20261109/static-d5acf5b/manifest.json'),
    ('A', 'experiments/acceptance/exact-by3-20261109/static-d5acf5b/production-baseline-map.json'),
    ('A', 'experiments/acceptance/exact-by3-20261109/static-d5acf5b/validation.json'),
    ('M', 'experiments/exact-by3-20261109/PROTOCOL.md'),
    ('M', 'experiments/exact-by3-20261109/README.md'),
    ('M', 'experiments/exact-by3-20261109/STATUS.json'),
    ('M', 'native/proof-status.json'),
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def checked(path, expected):
    value = digest(path)
    require(value == expected, 'hash mismatch: ' + str(path))
    return value


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def run(argv):
    result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    return result.stdout.decode(), result.stderr.decode()


def optional(path):
    try:
        return Path(path).read_text().strip()
    except OSError:
        return None


def pointer(value, path):
    require(isinstance(path, str) and path.startswith('/'), 'review JSON pointer missing')
    for part in path[1:].split('/'):
        part = part.replace('~1', '/').replace('~0', '~')
        value = value[int(part)] if isinstance(value, list) else value[part]
    return value


def check_plan(plan):
    require(plan['schema'] == 'exact-by3-host-window-v1' and plan['timing_authorized'] is False,
            'wrong plan schema or plan attempts to grant timing')
    require(plan['status'] == 'prepared' and plan['timing_eligibility'] == 'pending_independent_seal',
            'the immutable plan must not grant timing')
    source = plan['source']
    require((source['head'], source['tree'], source['native_tree'], source['baseline_head']) ==
            (HEAD, TREE, NATIVE, BASELINE), 'wrong measurement source or baseline')
    require(plan['build']['path'] == BUILD and plan['build']['sha256'] == BUILD_SHA and
            plan['build']['identity_receipt_sha256'] == IDENTITY_SHA and
            plan['build']['timing_candidate']['sha256'] == CANDIDATE_SHA and
            plan['protocol']['authoritative']['sha256'] == PROTOCOL_SHA and
            plan['protocol']['historical_build_snapshot']['sha256'] == OLD_PROTOCOL_SHA,
            'wrong frozen build, timing candidate or protocol')
    require(plan['cpu'] == 8 and list(plan['windows']) == ['E1'], 'wrong CPU or window')
    spec = plan['windows']['E1']
    require((spec['experiment'], spec['pause_budget_seconds'], spec['restore_reserve_seconds'],
             spec['command_teardown_seconds']) == ('exact-by3', 480, 75, 15), 'window boundary changed')
    require(spec['linux_output'] == OUTPUT and
            spec['windows_output'] == r'E:\3sat\VeriGMP-exact-by3-measurement-window-20261109-01\measurement-E1-01' and
            not spec['whole_run_retry'] and
            (spec['total_cells_per_run'], spec['independent_run_count'], spec['paths_per_cell'],
             spec['samples_per_path_cell'], spec['minimum_accepted_sample_ns']) == (86, 2, 3, 7, 10_000_000),
            'registered run shape changed')
    require(len(spec['runs']) == 2, 'both registered launches are required')
    for index, row in enumerate(spec['runs'], 1):
        name = 'exact-by3-run-' + str(index)
        run_id = 'exact-by3-cpu8-20261109-run-' + str(index)
        expected = ['/usr/bin/python3.12', '-B', RUNNER, '--build', BUILD, '--output', OUTPUT + '/' + name,
                    '--run-id', run_id, '--cpu', '8']
        require(row['name'] == name and row['run_id'] == run_id and row['linux_argv'] == expected and
                row['minimum_remaining_seconds'] == 140, 'registered runner argv changed')
    require([(x['status'], x['path']) for x in plan['publication']['delta']] == DELTA,
            'publication allowlist changed')


def check_review(plan, plan_path, grant):
    checked(grant['timing_review_path'], grant['timing_review_sha256'])
    seal = load(grant['timing_review_path'])
    fields = grant['timing_review_pointers']
    expected = {'source_head': HEAD, 'source_tree': TREE, 'native_tree': NATIVE,
                'publication_head': plan['publication']['head'], 'publication_tree': plan['publication']['tree'],
                'build_sha256': BUILD_SHA, 'identity_sha256': IDENTITY_SHA,
                'timing_candidate_sha256': CANDIDATE_SHA, 'authoritative_protocol_sha256': PROTOCOL_SHA,
                'plan_sha256': digest(plan_path), 'executor_sha256': plan['support_sha256']['timing_host.ps1']}
    for key, value in expected.items():
        require(pointer(seal, fields[key]) == value, 'independent review binding mismatch: ' + key)
    verdict = pointer(seal, fields['verdict'])
    require(isinstance(verdict, str) and verdict.startswith('READY') and verdict == grant['timing_review_verdict'],
            'independent review is not the accepted READY verdict')
    return {'path': grant['timing_review_path'], 'sha256': grant['timing_review_sha256'], 'verdict': verdict}


def provenance(plan):
    source, publication = plan['source'], plan['publication']
    git = [plan['execution_tools']['git']['path'], '--git-dir=' + source['wsl_git_dir'], '--work-tree=' + source['repo']]
    for revision, expected in [(HEAD + '^{tree}', TREE), (HEAD + ':native', NATIVE),
                               ('HEAD', publication['head']), ('HEAD^{tree}', publication['tree']),
                               ('HEAD:native', publication['native_tree'])]:
        text, _ = run(git + ['rev-parse', revision])
        require(text.strip() == expected, 'git revision drift: ' + revision)
    run(git + ['merge-base', '--is-ancestor', HEAD, publication['head']])
    status, _ = run(git + ['status', '--porcelain'])
    require(not status.strip(), 'publication worktree is not clean')
    raw, _ = run(git + ['diff', '--no-renames', '--name-status', '-z', HEAD, publication['head']])
    parts = raw.split('\0')[:-1]
    require(len(parts) % 2 == 0 and list(zip(parts[::2], parts[1::2])) == DELTA,
            'publication delta differs from the explicit allowlist')
    checked(plan['build']['path'], BUILD_SHA)
    checked(plan['build']['identity_receipt']['path'], IDENTITY_SHA)
    checked(plan['build']['timing_candidate']['path'], CANDIDATE_SHA)
    checked(plan['protocol']['authoritative']['path'], PROTOCOL_SHA)
    checked(plan['protocol']['historical_build_snapshot']['path'], OLD_PROTOCOL_SHA)
    checked(RUNNER, RUNNER_SHA)
    old_git, _ = run(git + ['show', HEAD + ':experiments/exact-by3-20261109/PROTOCOL.md'])
    new_git, _ = run(git + ['show', publication['head'] + ':experiments/exact-by3-20261109/PROTOCOL.md'])
    require(hashlib.sha256(old_git.encode()).hexdigest() == OLD_PROTOCOL_SHA and
            hashlib.sha256(new_git.encode()).hexdigest() == PROTOCOL_SHA, 'protocol version mapping changed')
    build, identity, candidate = (load(plan['build']['path']), load(plan['build']['identity_receipt']['path']),
                                  load(plan['build']['timing_candidate']['path']))
    require(build['source_head'] == identity['source_commit'] == candidate['compiled_source'] == HEAD and
            build['native_tree'] == identity['native_tree'] == candidate['native_tree'] == NATIVE and
            build['baseline_head'] == identity['baseline_commit'] == candidate['production_baseline'] == BASELINE,
            'frozen source identities disagree')
    require(build['identity_receipt']['sha256'] == IDENTITY_SHA and candidate['bench_build']['sha256'] == BUILD_SHA and
            candidate['identity']['sha256'] == IDENTITY_SHA and
            candidate['authoritative_protocol'] == plan['protocol']['authoritative'] and
            identity['protocol'] == plan['protocol']['historical_build_snapshot'] and
            identity['measurement_source']['sha256'] == RUNNER_SHA and
            identity['measurement_source']['path'] == RUNNER, 'receipt references disagree')
    require(build['timing_authorized'] is False and identity['timing_authorized'] is False and
            candidate['timing_authorized'] is False and candidate['benchmark_executed'] is False and
            candidate['calibration_executed'] is False and build['binaries'] == identity['binaries'],
            'historical freeze status or binary binding changed')
    require((build['complete_cell_count'], build['complete_runs'], build['prospective_cpu'], build['repetitions'],
             build['minimum_sample_ns']) == (86, 2, 8, 7, 10_000_000) and
            candidate['control_cell_count'] == 71 and candidate['control_baseline_each_ratio_range'] == [0.9, 1.1] and
            candidate['control_baseline_run2_over_run1_geomean_range'] == [0.95, 1.05] and
            build['primary_cells'] == candidate['primary_cells'] and
            build['primary_geomean_max'] == candidate['primary_geomean_max'] == 0.98 and
            build['all_cell_regression_max'] == candidate['all_cell_regression_max'] == 1.05,
            'registered frozen matrix or gates changed')
    linked = []
    for label, row in build['binaries'].items():
        checked(row['path'], row['sha256'])
        ldd, error = run([plan['execution_tools']['ldd']['path'], row['path']])
        match = re.search(r'libgmp\.so\.10\s*=>\s*(\S+)', ldd)
        require(match and match[1] == plan['loaded_gmp']['path'], 'resolved GMP path changed: ' + label)
        checked(match[1], plan['loaded_gmp']['sha256'])
        require(plan['loaded_gmp']['sha256'] == identity['gmp_loaded']['sha256'], 'loaded GMP hash differs from identity')
        linked.append(dict(label=label, binary_sha256=row['sha256'], gmp_path=match[1],
                           gmp_realpath=str(Path(match[1]).resolve()), ldd_stdout=ldd, ldd_stderr=error))
    for row in plan['execution_tools'].values():
        checked(row['path'], row['sha256'])
    checked(Path(sys.executable).resolve(), plan['execution_tools']['python']['sha256'])
    affinity = sorted(os.sched_getaffinity(0))
    require(affinity == plan['linux_host']['available_affinity'] and 8 in affinity and
            optional('/sys/devices/system/cpu/cpu8/online') == '1' and
            optional('/sys/devices/system/cpu/cpu8/topology/thread_siblings_list') == plan['linux_host']['cpu_siblings'] and
            list(platform.uname()) == plan['linux_host']['uname'], 'host CPU, affinity or kernel changed')
    environment = {name: os.environ.get(name) for name in ('LD_LIBRARY_PATH', 'LD_PRELOAD', 'LD_AUDIT')}
    require(not any(environment.values()), 'dynamic loader environment is nonempty')
    ps, ps_error = run([plan['execution_tools']['ps']['path'], '-eo', 'pid,ppid,stat,pcpu,comm,args'])
    return dict(source=source, publication=publication, binaries=linked, cpu=8, affinity=affinity,
                cpu_siblings=plan['linux_host']['cpu_siblings'], uname=list(platform.uname()),
                python=sys.version, python_executable=str(Path(sys.executable).resolve()),
                linux_process_snapshot=ps, linux_ps_stderr=ps_error,
                proc_stat=optional('/proc/stat'), proc_loadavg=optional('/proc/loadavg'),
                proc_cpuinfo=optional('/proc/cpuinfo'), self_status=optional('/proc/self/status'),
                frequency={name: optional('/sys/devices/system/cpu/cpu8/cpufreq/' + name) for name in
                           ('scaling_governor', 'scaling_cur_freq', 'scaling_min_freq', 'scaling_max_freq')},
                thermal={str(path): optional(path) for path in sorted(Path('/sys/class/thermal').glob('thermal_zone*/temp'))},
                dynamic_loader_environment=environment)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', required=True, type=Path)
    parser.add_argument('--grant', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    report = dict(schema='exact-by3-preflight-receipt-v1', status='fail', benchmark_executed=False,
                  calibration_executed=False, native_build_executed=False, verus_executed=False)
    try:
        plan = load(args.plan)
        check_plan(plan)
        grant = load(args.grant)
        require(grant['plan_sha256'] == digest(args.plan), 'root grant plan hash mismatch')
        report['independent_review'] = check_review(plan, args.plan, grant)
        report.update(provenance(plan))
        report['status'] = 'pass'
    except BaseException as error:
        report['failure'] = repr(error)
        raise
    finally:
        with args.output.open('x', encoding='utf-8') as stream:
            json.dump(report, stream, indent=2)
            stream.write('\n')
        print(json.dumps({'status': report['status'], 'output': str(args.output),
                          'benchmark_executed': False, 'calibration_executed': False}))


if __name__ == '__main__':
    main()

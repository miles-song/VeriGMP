#!/usr/bin/env python3
"""Pure E1 plan and review-binding fixtures; no process, ADB, or timing calls."""
import copy
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
import preflight

plan = preflight.load(Path(__file__).resolve().parent / 'plan.json')
preflight.check_plan(plan)
cases = ['prepared-plan-is-valid-but-not-a-grant']


def rejected(name, mutate):
    value = copy.deepcopy(plan)
    mutate(value)
    try:
        preflight.check_plan(value)
    except (ValueError, KeyError, TypeError):
        cases.append(name)
    else:
        raise AssertionError('unsafe plan accepted: ' + name)


rejected('plan-cannot-grant-timing', lambda p: p.update(timing_authorized=True))
rejected('wrong-experiment', lambda p: p['windows']['E1'].update(experiment='fused-interpolation'))
rejected('wrong-build', lambda p: p['build'].update(sha256='0' * 64))
rejected('wrong-protocol-role', lambda p: p['protocol']['authoritative'].update(sha256=preflight.CANDIDATE_SHA))
rejected('wrong-cpu', lambda p: p.update(cpu=9))
rejected('extended-cap', lambda p: p['windows']['E1'].update(pause_budget_seconds=481))
rejected('reduced-reserve', lambda p: p['windows']['E1'].update(restore_reserve_seconds=74))
rejected('whole-run-retry', lambda p: p['windows']['E1'].update(whole_run_retry=True))
rejected('incomplete-matrix', lambda p: p['windows']['E1'].update(total_cells_per_run=85))
rejected('missing-run', lambda p: p['windows']['E1']['runs'].pop())
rejected('changed-runner', lambda p: p['windows']['E1']['runs'][0]['linux_argv'].append('--phase'))
rejected('publication-allowlist-drift', lambda p: p['publication']['delta'].pop())

expected = {'source_head': preflight.HEAD, 'source_tree': preflight.TREE, 'native_tree': preflight.NATIVE,
            'publication_head': plan['publication']['head'], 'publication_tree': plan['publication']['tree'],
            'build_sha256': preflight.BUILD_SHA, 'identity_sha256': preflight.IDENTITY_SHA,
            'timing_candidate_sha256': preflight.CANDIDATE_SHA,
            'authoritative_protocol_sha256': preflight.PROTOCOL_SHA,
            'plan_sha256': 'a' * 64, 'executor_sha256': plan['support_sha256']['timing_host.ps1'],
            'verdict': 'READY_FIXTURE'}
grant = {'timing_review_path': 'stub', 'timing_review_sha256': 'b' * 64,
         'timing_review_verdict': 'READY_FIXTURE',
         'timing_review_pointers': {name: '/' + name for name in expected}}
preflight.checked = lambda *_: None
preflight.digest = lambda *_: 'a' * 64
preflight.load = lambda _: expected
preflight.check_review(plan, 'stub-plan', grant)
cases.append('independent-seal-bindings-match')
for name in expected:
    altered = copy.deepcopy(expected)
    altered[name] = 'drift'
    preflight.load = lambda _, value=altered: value
    try:
        preflight.check_review(plan, 'stub-plan', grant)
    except ValueError:
        cases.append('seal-rejects-' + name)
    else:
        raise AssertionError('seal drift accepted: ' + name)
print(json.dumps({'status': 'pass', 'cases': cases, 'real_process_calls': False,
                  'live_adb_executed': False, 'benchmark_executed': False}, indent=2))

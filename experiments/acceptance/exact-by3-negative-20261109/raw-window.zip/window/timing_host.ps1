param(
  [Parameter(Mandatory=$true)][ValidateSet('E1')][string]$Window,
  [Parameter(Mandatory=$true)][string]$RootGrant
)
$ErrorActionPreference='Stop'
$planPath=Join-Path $PSScriptRoot 'plan.json'
function Hash-File([string]$Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLower() }
function Wsl-Path([string]$Path) {
  $full=[System.IO.Path]::GetFullPath($Path)
  if ($full -notmatch '^([A-Za-z]):\\(.*)$') { throw 'Expected mounted drive path' }
  '/mnt/'+$Matches[1].ToLower()+'/'+$Matches[2].Replace('\','/')
}
function Utc-Time($Value) {
  if ($Value -is [DateTime]) { return $Value.ToUniversalTime() }
  return [DateTimeOffset]::Parse([string]$Value).UtcDateTime
}
$plan=Get-Content -LiteralPath $planPath -Raw | ConvertFrom-Json
if ($plan.schema -ne 'exact-by3-host-window-v1' -or $plan.status -ne 'prepared' -or
    $plan.timing_authorized -ne $false -or $plan.timing_eligibility -ne 'pending_independent_seal') {
  throw 'The immutable prepared plan itself never grants the root quiet window'
}
$grant=Get-Content -LiteralPath $RootGrant -Raw | ConvertFrom-Json
if ($grant.schema -ne 'exact-by3-root-grant-v1' -or $grant.status -ne 'granted' -or
    $grant.explicit_root_go -ne $true -or $grant.granted_by -ne '/root' -or
    $grant.timing_authorized -ne $true -or $grant.window -ne $Window -or
    $grant.plan_sha256 -ne (Hash-File $planPath) -or $grant.cpu -ne 8 -or
    $grant.source_head -ne $plan.source.head -or $grant.source_tree -ne $plan.source.tree -or
    $grant.native_tree -ne $plan.source.native_tree -or
    $grant.build_sha256 -ne $plan.build.sha256 -or
    $grant.identity_receipt_sha256 -ne $plan.build.identity_receipt_sha256 -or
    $grant.timing_candidate_sha256 -ne $plan.build.timing_candidate.sha256 -or
    $grant.authoritative_protocol_sha256 -ne $plan.protocol.authoritative.sha256 -or
    $grant.timing_review_sha256 -notmatch '^[a-f0-9]{64}$' -or
    -not $grant.timing_review_path -or -not $grant.timing_review_pointers -or -not $grant.timing_review_verdict -or
    $grant.publication_map_accepted -ne $true -or
    $grant.publication_head -ne $plan.publication.head -or $grant.publication_tree -ne $plan.publication.tree -or
    $grant.independent_prereviews -ne 'READY' -or $grant.all_active_workers_quiescent -ne $true -or
    $grant.worker_acknowledgements.Count -eq 0 -or $grant.active_worker_roster.Count -eq 0 -or
    @($grant.worker_acknowledgements | Where-Object {$_.status -ne 'quiescent' -or $_.plan_sha256 -ne $grant.plan_sha256}).Count -gt 0) {
  throw 'Explicit root grant must bind the exact-by3 source/build/protocol/review and every fresh quiescent worker acknowledgment'
}
$roster=@($grant.active_worker_roster | Sort-Object -Unique)
$acks=@($grant.worker_acknowledgements.worker | Sort-Object -Unique)
if ($roster.Count -ne $grant.active_worker_roster.Count -or $acks.Count -ne $grant.worker_acknowledgements.Count -or
    @(Compare-Object $roster $acks).Count -ne 0) { throw 'Incomplete or duplicate active-worker acknowledgments' }
$now=[DateTime]::UtcNow
$grantedAt=Utc-Time $grant.granted_utc
$expiresAt=Utc-Time $grant.expires_utc
if ($grantedAt -gt $now -or ($now-$grantedAt).TotalMinutes -gt 15 -or $expiresAt -le $now -or
    ($expiresAt-$grantedAt).TotalMinutes -gt 15) { throw 'Root quiet-window grant is not fresh' }
foreach ($ack in $grant.worker_acknowledgements) {
  $ackAt=Utc-Time $ack.acknowledged_utc
  if ($ackAt -gt $grantedAt -or ($grantedAt-$ackAt).TotalMinutes -gt 15) { throw 'Worker acknowledgment is not fresh' }
}
$spec=$plan.windows.$Window
if ($spec.experiment -ne 'exact-by3' -or $spec.pause_budget_seconds -ne 480 -or
    $spec.restore_reserve_seconds -ne 75 -or $spec.command_teardown_seconds -ne 15 -or
    $grant.maximum_pause_seconds -ne 480 -or $plan.cpu -ne 8) {
  throw 'Only the registered 480-second exact-by3 CPU-8 window with 75-second restore reserve is allowed'
}
foreach ($property in $plan.support_sha256.PSObject.Properties) {
  if ((Hash-File (Join-Path $PSScriptRoot $property.Name)) -ne $property.Value) { throw 'Prepared host support changed' }
}
foreach ($property in $plan.host_tools.PSObject.Properties) {
  if ((Hash-File $property.Value.path) -ne $property.Value.sha256) { throw 'Windows host tool changed' }
}
if ($PSVersionTable.PSVersion.Major -lt 7 -or
    (Hash-File ([Diagnostics.Process]::GetCurrentProcess().MainModule.FileName)) -ne $plan.host_tools.pwsh.sha256) {
  throw 'Run the wrapper with the pinned PowerShell 7 executable'
}
$repo=$plan.source.windows_repo
$git=$plan.host_tools.git.path
if ((& $git -C $repo rev-parse HEAD).Trim() -ne $plan.publication.head -or
    (& $git -C $repo rev-parse 'HEAD^{tree}').Trim() -ne $plan.publication.tree -or
    (& $git -C $repo rev-parse 'HEAD:native').Trim() -ne $plan.publication.native_tree -or
    (& $git -C $repo rev-parse ($plan.source.head+':native')).Trim() -ne $plan.source.native_tree -or
    (& $git -C $repo rev-parse ($plan.source.head+'^{tree}')).Trim() -ne $plan.source.tree -or
    (& $git -C $repo status --porcelain)) { throw 'Clean public publication mapping or frozen measurement source changed' }
& $git -C $repo merge-base --is-ancestor $plan.source.head $plan.publication.head
if ($LASTEXITCODE -ne 0) { throw 'Publication does not descend from the frozen measurement source' }
$output=$spec.windows_output
if (Test-Path -LiteralPath $output) { throw 'Refusing to replace any prior exact-by3 window evidence' }
New-Item -ItemType Directory -Path $output | Out-Null
$held=@{};$paused=@();$adbPauseAttempted=$false;$initialRunning=$false;$pauseStart=$null;$pauseClock=$null;$restoring=$false
$report=[ordered]@{schema='exact-by3-host-receipt-v1';status='preflight';window=$Window;
  start_utc=[DateTime]::UtcNow.ToString('o');plan_sha256=(Hash-File $planPath);root_grant_sha256=(Hash-File $RootGrant);
  cpu=$plan.cpu;source_head=$plan.source.head;source_tree=$plan.source.tree;native_tree=$plan.source.native_tree;
  publication_head=$plan.publication.head;publication_tree=$plan.publication.tree;
  build_sha256=$plan.build.sha256;identity_receipt_sha256=$plan.build.identity_receipt_sha256;
  timing_candidate_sha256=$plan.build.timing_candidate.sha256;authoritative_protocol_sha256=$plan.protocol.authoritative.sha256;
  timing_review_sha256=$grant.timing_review_sha256;benchmark_launched=$false;
  commands=@();observations=@();host_observations=@();resume=@();preflight_receipts=@()}
function Save-Report { $report | ConvertTo-Json -Depth 16 | Set-Content -LiteralPath (Join-Path $output 'host-receipt.json') -Encoding utf8NoBOM }
function Window-Remaining {
  if (-not $pauseClock) { return 405 }
  $remaining=[int][Math]::Floor(480-$pauseClock.Elapsed.TotalSeconds-75)
  if ($remaining -le 0) { throw 'Measurement budget exhausted; restore reserve starts now' }
  return $remaining
}
function Read-Identity($Process) {
  $Process.Refresh();$cim=Get-CimInstance Win32_Process -Filter ('ProcessId='+$Process.Id)
  $threads=@($Process.Threads | ForEach-Object {
    $state=$_.ThreadState.ToString();$reason=$null
    if ($state -eq 'Wait') { $reason=$_.WaitReason.ToString() }
    @{id=$_.Id;state=$state;wait_reason=$reason}
  })
  @{pid=$Process.Id;name=$Process.ProcessName;start_ticks=$Process.StartTime.ToUniversalTime().Ticks.ToString();
    start_utc=$Process.StartTime.ToUniversalTime().ToString('o');path=$Process.Path;
    executable_sha256=(Hash-File $Process.Path);parent_pid=$cim.ParentProcessId;
    command_line=$cim.CommandLine;cpu_seconds=$Process.TotalProcessorTime.TotalSeconds;threads=$threads;
    all_threads_suspended=($threads.Count -gt 0 -and @($threads | Where-Object {$_.state -ne 'Wait' -or $_.wait_reason -ne 'Suspended'}).Count -eq 0)}
}
function Check-Identity($Target,$Actual) {
  foreach ($key in @('pid','name','start_ticks','start_utc','path','executable_sha256','parent_pid','command_line')) {
    $different=if ($key -eq 'start_utc') {
      [DateTimeOffset]::Compare([DateTimeOffset](Utc-Time $Actual[$key]),[DateTimeOffset](Utc-Time $Target.$key)) -ne 0
    } else { $Actual[$key] -ne $Target.$key }
    if ($different) { throw ('Authorized emulator identity changed: '+$Target.pid+'/'+$key) }
  }
}
function Observe([string]$Phase) {
  $now=@{}
  foreach ($target in $plan.emulator.targets) {
    $identity=Read-Identity $held[[int]$target.pid];Check-Identity $target $identity
    $now[[int]$target.pid]=$identity
    $report.observations+=@{phase=$Phase;utc=[DateTime]::UtcNow.ToString('o');process=$identity}
  }
  Save-Report;return $now
}
function Host-Observation([string]$Phase) {
  $sample=[ordered]@{phase=$Phase;utc=[DateTime]::UtcNow.ToString('o');wrapper_pid=$PID;
    wrapper_affinity=[Diagnostics.Process]::GetCurrentProcess().ProcessorAffinity.ToInt64()}
  $sample.processor=@(Get-CimInstance Win32_Processor | Select-Object Name,NumberOfCores,NumberOfLogicalProcessors,MaxClockSpeed,CurrentClockSpeed)
  $sample.cpu_raw=@(Get-CimInstance Win32_PerfRawData_PerfOS_Processor | Select-Object Name,PercentProcessorTime,PercentIdleTime,Timestamp_Sys100NS,Frequency_Sys100NS)
  $sample.processes=@(Get-Process | ForEach-Object {
    try { @{pid=$_.Id;name=$_.ProcessName;start_utc=$_.StartTime.ToUniversalTime().ToString('o');cpu_seconds=$_.TotalProcessorTime.TotalSeconds} } catch { }
  })
  $report.host_observations+=$sample;Save-Report
}
function Run-Command([string]$Executable,[string[]]$Arguments,[string]$Name,[int]$TimeoutSeconds=60) {
  $info=[System.Diagnostics.ProcessStartInfo]::new();$info.FileName=$Executable
  $info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  foreach ($argument in $Arguments) { $info.ArgumentList.Add($argument) }
  $process=[System.Diagnostics.Process]::new();$process.StartInfo=$info
  $entry=@{name=$Name;argv=@($Executable)+$Arguments;timeout_seconds=$TimeoutSeconds;start_utc=[DateTime]::UtcNow.ToString('o')}
  $report.commands+=$entry;Save-Report
  try {
    [void]$process.Start();$entry.windows_pid=$process.Id
    $stdout=$process.StandardOutput.ReadToEndAsync();$stderr=$process.StandardError.ReadToEndAsync()
    if (-not $process.WaitForExit($TimeoutSeconds*1000)) {
      # Only this exact newly started relay/client is stopped. GNU timeout owns its Linux group.
      $entry.timed_out=$true;$process.Kill();$process.WaitForExit()
    }
    $outPath=Join-Path $output ($Name+'.stdout.log');$errPath=Join-Path $output ($Name+'.stderr.log')
    [IO.File]::WriteAllText($outPath,$stdout.Result);[IO.File]::WriteAllText($errPath,$stderr.Result)
    $entry.returncode=$process.ExitCode;$entry.stop_utc=[DateTime]::UtcNow.ToString('o')
    $entry.stdout_sha256=Hash-File $outPath;$entry.stderr_sha256=Hash-File $errPath;Save-Report
    if ($entry.returncode -ne 0 -or $entry.timed_out) { throw ('Owned command failed: '+$Name) }
    return $stdout.Result
  } finally { $process.Dispose() }
}
function Adb([string[]]$Arguments,[string]$Name) {
  $limit=if ($restoring) {10} elseif ($pauseClock) {[Math]::Min(30,(Window-Remaining))} else {30}
  Run-Command $plan.emulator.adb_path (@('-s',$plan.emulator.serial,'emu')+$Arguments) $Name $limit
}
function Preflight([string]$Name) {
  $receipt=Join-Path $output ($Name+'.json')
  $limit=if ($pauseClock -and -not $restoring) {[Math]::Min(90,(Window-Remaining))} else {90}
  $null=Run-Command $plan.host_tools.wsl.path @('--distribution',$plan.wsl_distribution,'--exec',
    $plan.execution_tools.python.path,'-B',(Wsl-Path (Join-Path $PSScriptRoot 'preflight.py')),
    '--plan',(Wsl-Path $planPath),'--grant',(Wsl-Path $RootGrant),'--output',(Wsl-Path $receipt)) $Name $limit
  $result=Get-Content -LiteralPath $receipt -Raw | ConvertFrom-Json
  if ($result.status -ne 'pass') { throw 'Exact-by3 source/build/tool/resolved-GMP provenance failed' }
  $report.preflight_receipts+=@{name=$Name;path=$receipt;sha256=(Hash-File $receipt)};Save-Report
  return $receipt
}
try {
  if ($plan.emulator.serial -ne 'emulator-5554' -or $plan.emulator.avd -ne 'opc_toolchain_api36' -or
      $plan.emulator.targets.Count -ne 2 -or
      (Hash-File $plan.emulator.adb_path) -ne $plan.emulator.adb_sha256) { throw 'Authorized emulator/ADB changed' }
  foreach ($target in $plan.emulator.targets) {
    $process=Get-Process -Id $target.pid;$null=$process.Handle;$held[[int]$target.pid]=$process
    $identity=Read-Identity $process;Check-Identity $target $identity
    if ($identity.all_threads_suspended) { throw 'Emulator was already suspended; preserve its original state' }
  }
  $avd=Adb @('avd','name') 'avd-name-before'
  if ($avd -notmatch '(?m)^opc_toolchain_api36\s*$') { throw 'Wrong AVD behind emulator-5554' }
  $status=Adb @('avd','status') 'avd-status-before'
  if ($status -notmatch 'virtual device is running') { throw 'AVD was not initially running; preserve its state' }
  $initialRunning=$true
  $null=Preflight 'initial-provenance';Host-Observation 'before-pause';$null=Observe 'before-pause'
  $adbPauseAttempted=$true;$pauseStart=[DateTime]::UtcNow;$pauseClock=[Diagnostics.Stopwatch]::StartNew()
  $null=Adb @('avd','pause') 'avd-pause'
  $pausedStatus=Adb @('avd','status') 'avd-status-paused'
  if ($pausedStatus -notmatch 'virtual device is stopped') { throw 'Supported AVD pause was not confirmed' }
  $a=Observe 'adb-paused-observation-1';Start-Sleep -Seconds 2;$b=Observe 'adb-paused-observation-2'
  $spinning=@($plan.emulator.targets | Where-Object {$a[[int]$_.pid].cpu_seconds -ne $b[[int]$_.pid].cpu_seconds}).Count -gt 0
  $report.pause_method='supported_adb_avd_pause'
  if ($spinning) {
    Add-Type @'
using System;using System.Runtime.InteropServices;
public static class VeriGMPWindowNative {
  [DllImport("ntdll.dll")] public static extern int NtSuspendProcess(IntPtr handle);
  [DllImport("ntdll.dll")] public static extern int NtResumeProcess(IntPtr handle);
}
'@
    foreach ($target in $plan.emulator.targets) {
      $process=$held[[int]$target.pid];$identity=Read-Identity $process;Check-Identity $target $identity
      $saved=@{target=$target;suspended_by_this_window=$false;before=$identity};$paused+=$saved
      if ($identity.all_threads_suspended) { throw 'Unexpected prior process suspension' }
      $saved.nt_status=[VeriGMPWindowNative]::NtSuspendProcess($process.Handle)
      if ($saved.nt_status -ne 0) { throw 'Exact authorized held-handle suspension failed' }
      $saved.suspended_by_this_window=$true
    }
    $report.pause_method='adb_pause_plus_authorized_exact_held_handle_ntsuspend'
  }
  $quietA=Observe 'quiet-observation-1';Start-Sleep -Seconds 2;$quietB=Observe 'quiet-observation-2'
  foreach ($target in $plan.emulator.targets) {
    if ($quietA[[int]$target.pid].cpu_seconds -ne $quietB[[int]$target.pid].cpu_seconds) { throw 'Authorized emulator remains CPU-active' }
  }
  foreach ($run in $spec.runs) {
    if ((Window-Remaining) -lt ($run.minimum_remaining_seconds+15)) { throw 'Insufficient bounded window for the next full run' }
    $null=Preflight ($run.name+'-provenance-before');Host-Observation ($run.name+'-before')
    # Keep relay/GNU-timeout teardown inside the work budget, before the full
    # 75-second restoration reserve begins.
    $remaining=(Window-Remaining)-15
    if ($remaining -lt $run.minimum_remaining_seconds) { throw 'Insufficient bounded window after provenance checks' }
    $arguments=@('--distribution',$plan.wsl_distribution,'--exec',$plan.execution_tools.timeout.path,
      '--signal=TERM','--kill-after=5s',([string]$remaining+'s'))+@($run.linux_argv)
    $report.benchmark_launched=$true;$report.status='measuring';Save-Report
    $null=Run-Command $plan.host_tools.wsl.path $arguments $run.name ($remaining+15)
    $now=Observe ('after-'+$run.name)
    foreach ($target in $plan.emulator.targets) {
      if ($now[[int]$target.pid].cpu_seconds -ne $quietB[[int]$target.pid].cpu_seconds) { throw 'Emulator CPU advanced during measurements' }
    }
    Host-Observation ($run.name+'-after');$null=Preflight ($run.name+'-provenance-after')
  }
  $report.status='registered_runs_collected_performance_pending_analysis'
} catch {
  $report.status='failed';$report.failure=$_.Exception.Message;throw
} finally {
  $restoring=$true
  foreach ($saved in $paused) {
    if (-not $saved.suspended_by_this_window) { continue }
    $entry=@{pid=$saved.target.pid;start_ticks=$saved.target.start_ticks;utc=[DateTime]::UtcNow.ToString('o')}
    try {
      $process=$held[[int]$saved.target.pid]
      if ($process.HasExited) { throw 'Original emulator process exited' }
      # A held handle remains bound to the originally suspended process. Restore
      # that owned suspension even if a metadata observation now fails.
      try { Check-Identity $saved.target (Read-Identity $process) }
      catch { $entry.identity_error=$_.Exception.Message;$report.final_identity_error=$_.Exception.Message }
      $entry.nt_status=[VeriGMPWindowNative]::NtResumeProcess($process.Handle)
      if ($entry.nt_status -ne 0) { throw 'Resume failed' }
      $entry.status='resumed'
    } catch { $entry.status='restore_error';$entry.error=$_.Exception.Message }
    $report.resume+=$entry
  }
  if ($adbPauseAttempted -and $initialRunning) {
    try {
      $null=Adb @('avd','resume') 'avd-resume-finally'
      $after=Adb @('avd','status') 'avd-status-after-finally'
      if ($after -notmatch 'virtual device is running') { throw 'AVD did not return to running' }
      $report.avd_restored=$true
      $report.pause_end_utc=[DateTime]::UtcNow.ToString('o')
      $report.pause_seconds=$pauseClock.Elapsed.TotalSeconds
    } catch { $report.avd_restored=$false;$report.restore_error=$_.Exception.Message }
  }
  if ($held.Count -eq $plan.emulator.targets.Count) {
    try { $null=Observe 'after-finally-restore' } catch { $report.final_identity_error=$_.Exception.Message }
  }
  if ($report.avd_restored -eq $true) {
    try { $null=Preflight 'final-provenance-after-restore' } catch { $report.final_provenance_error=$_.Exception.Message }
  }
  $report.stop_utc=[DateTime]::UtcNow.ToString('o')
  if ($pauseClock -and -not $report.pause_seconds) { $report.pause_seconds=$pauseClock.Elapsed.TotalSeconds }
  if ($report.restore_error -or @($report.resume | Where-Object {$_.status -eq 'restore_error'}).Count -gt 0) {
    $report.status='restoration_failed'
  } elseif ($report.final_identity_error -or $report.final_provenance_error) { $report.status='final_provenance_failed' }
  elseif ($report.pause_seconds -gt 480) { $report.status='window_cap_exceeded' }
  Save-Report
  foreach ($process in $held.Values) { $process.Dispose() }
}
if ($report.status -ne 'registered_runs_collected_performance_pending_analysis') { throw ('Exact-by3 window did not complete: '+$report.status) }

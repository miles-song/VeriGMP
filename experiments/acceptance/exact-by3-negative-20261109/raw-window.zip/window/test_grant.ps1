$ErrorActionPreference='Stop'
$text=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'timing_host.ps1'))
$tokens=$null;$errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseInput($text,[ref]$tokens,[ref]$errors)
$utcFunction=$ast.Find({param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Utc-Time'},$true)
. ([scriptblock]::Create($utcFunction.Extent.Text))
$begin=$text.IndexOf('$grant=Get-Content')
$end=$text.IndexOf('$spec=$plan.windows.$Window')
if ($begin -lt 0 -or $end -le $begin) { throw 'Grant gate boundaries changed' }
$gate=[scriptblock]::Create($text.Substring($begin,$end-$begin))
# Execute only the grant-validation block. All data comes from pure stubs;
# the source/build/process/ADB/measurement sections are never evaluated.
function Get-Content { param($LiteralPath,[switch]$Raw); return $script:grantJson }
function Hash-File([string]$Path) { return ('a'*64) }
$planPath='fixture';$RootGrant='fixture';$Window='E1'
$plan=[pscustomobject]@{source=@{head='h';tree='t';native_tree='n'};
  build=@{sha256='b';identity_receipt_sha256='i';timing_candidate=@{sha256='c'}};
  protocol=@{authoritative=@{sha256='p'}};publication=@{head='ph';tree='pt'}}
$now=[DateTime]::UtcNow
$sample=[ordered]@{schema='exact-by3-root-grant-v1';status='granted';explicit_root_go=$true;
  granted_by='/root';timing_authorized=$true;window='E1';plan_sha256=('a'*64);cpu=8;
  source_head='h';source_tree='t';native_tree='n';build_sha256='b';identity_receipt_sha256='i';
  timing_review_sha256=('b'*64);timing_review_path='/fixture/receipt.json';timing_review_verdict='READY_FIXTURE';
  timing_review_pointers=@{verdict='/verdict'};
  timing_candidate_sha256='c';authoritative_protocol_sha256='p';publication_head='ph';publication_tree='pt';publication_map_accepted=$true;
  independent_prereviews='READY';all_active_workers_quiescent=$true;active_worker_roster=@('/root','/root/leaf');
  granted_utc=$now.AddSeconds(-1).ToString('o');expires_utc=$now.AddMinutes(10).ToString('o');
  worker_acknowledgements=@(
    @{worker='/root';status='quiescent';plan_sha256=('a'*64);acknowledged_utc=$now.AddSeconds(-2).ToString('o')},
    @{worker='/root/leaf';status='quiescent';plan_sha256=('a'*64);acknowledged_utc=$now.AddSeconds(-2).ToString('o')})}
$cases=@()
foreach ($case in @('valid-bound-grant','missing-explicit-go','historical-schema','plan-drift','source-drift','build-drift',
                    'protocol-drift','candidate-receipt-drift','publication-drift','review-drift','unaccepted-publication-map',
                    'no-acks','missing-worker','duplicate-acks','worker-active','expired-grant','stale-ack')) {
  $value=$sample | ConvertTo-Json -Depth 8 | ConvertFrom-Json
  switch ($case) {
    'missing-explicit-go' {$value.explicit_root_go=$false}
    'historical-schema' {$value.schema='old-window-grant'}
    'plan-drift' {$value.plan_sha256='x'}
    'source-drift' {$value.source_head='x'}
    'build-drift' {$value.build_sha256='x'}
    'protocol-drift' {$value.authoritative_protocol_sha256='x'}
    'candidate-receipt-drift' {$value.timing_candidate_sha256='x'}
    'publication-drift' {$value.publication_head='x'}
    'review-drift' {$value.timing_review_sha256='x'}
    'unaccepted-publication-map' {$value.publication_map_accepted=$false}
    'no-acks' {$value.worker_acknowledgements=@()}
    'missing-worker' {$value.worker_acknowledgements=@($value.worker_acknowledgements[0])}
    'duplicate-acks' {$value.worker_acknowledgements=@($value.worker_acknowledgements[0],$value.worker_acknowledgements[0])}
    'worker-active' {$value.worker_acknowledgements[0].status='active'}
    'expired-grant' {$value.expires_utc=$now.AddSeconds(-2).ToString('o')}
    'stale-ack' {$value.worker_acknowledgements[0].acknowledged_utc=$now.AddHours(-1).ToString('o')}
  }
  $script:grantJson=$value | ConvertTo-Json -Depth 8
  $rejection=$null
  try { . $gate } catch { $rejection=$_.Exception.Message }
  if (($case -eq 'valid-bound-grant' -and $rejection) -or ($case -ne 'valid-bound-grant' -and -not $rejection)) {
    throw ('Grant fixture failed: '+$case+' / '+$rejection)
  }
  $cases+=@{case=$case;status='pass';rejection=$rejection}
}
$tokens=$null;$errors=$null
$ast=[System.Management.Automation.Language.Parser]::ParseInput($text,[ref]$tokens,[ref]$errors)
$budgetFunction=$ast.Find({param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Window-Remaining'},$true)
. ([scriptblock]::Create($budgetFunction.Extent.Text))
$budgets=@()
foreach ($elapsed in @(0,265,266,405,480)) {
  $pauseClock=[pscustomobject]@{Elapsed=[TimeSpan]::FromSeconds($elapsed)}
  $actual=$null;$budgetRejection=$null
  try { $actual=Window-Remaining } catch { $budgetRejection=$_.Exception.Message }
  if ($elapsed -lt 405 -and $actual -ne (405-$elapsed)) { throw 'Restore reserve was not retained' }
  if ($elapsed -ge 405 -and -not $budgetRejection) { throw 'Expired measurement budget was not rejected' }
  $budgets+=@{elapsed=$elapsed;remaining=$actual;rejected=([bool]$budgetRejection);status='pass'}
}
[ordered]@{status='pass';cases=$cases;budget_cases=$budgets;real_process_calls=$false;real_emulator_affected=$false;benchmark_executed=$false} | ConvertTo-Json -Depth 7

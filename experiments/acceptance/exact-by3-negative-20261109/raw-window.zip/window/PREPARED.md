# Exact-by-3 E1 host window

Status: prepared. Timing eligibility and the fresh root grant are pending. This directory has not launched timing or changed the emulator.

The immutable `plan.json` has `timing_authorized: false`. Its SHA-256 is `f02d186a51fd0560f2d6d18f88b086cc5394215285bc72ee3adae46c9a50b7ea`. It binds `timing_host.ps1` (`bab5a2ac1ab59dee88cdf0f38b0fdd08bec73dddb5473050de9bc126375a08a4`), `preflight.py` (`29c47b4acd481464315fc4402b0da3e863bc8af030273595d9399c432b133120`) and the other support hashes.

The independent review seal must be external to the plan and bind the plan and executor hashes. Its JSON must expose the exact values for source head/tree/native tree, publication head/tree, build, identity, timing-candidate, authoritative protocol, plan and executor SHA-256, and a verdict beginning with `READY`. The root grant specifies the seal's WSL absolute path, SHA-256, exact verdict and JSON pointers for those fields. A missing or mismatched field fails closed.

`root-grant-template.json` is deliberately invalid as a grant. After independent review and fresh worker acknowledgments, root must create a separate `root-go-E1.json`, populate the seal details and pointers, explicitly accept the publication mapping, set the authorization fields and `independent_prereviews` to `READY`, and list every active worker exactly once in both the roster and acknowledgments. Every acknowledgment binds the plan SHA and is no more than 15 minutes before the grant; the grant and expiration are derived from a single UTC instant, with expiration no more than 15 minutes later. The plan and template remain unchanged.

Only after those conditions and an explicit fresh root GO, root may run:

```powershell
& 'C:\Users\23247\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe' -NoLogo -NoProfile -NonInteractive -File 'E:\3sat\VeriGMP-exact-by3-measurement-window-20261109-01\timing_host.ps1' -Window E1 -RootGrant 'E:\3sat\VeriGMP-exact-by3-measurement-window-20261109-01\root-go-E1.json'
```

The wrapper validates grant freshness, worker acknowledgments, pinned script and tool bytes, the clean publication mapping, and the captured emulator PID/start time/start ticks/path/hash/parent/command line. It requires the named AVD to be initially running and the processes not to be already suspended. It checks the external review, frozen build and identities, source and publication trees, exact publication delta, both protocol versions, runner and binary hashes, resolved GMP, Linux tools, host CPU/affinity and environment. Provenance and host/process observations are captured before and after runs and after restore. Initial and final provenance run outside the paused interval. Each provenance command has at most 90 seconds, bounded by remaining work time during the pause.

The wrapper first requests AVD pause and checks its status and CPU progress. If process CPU still advances, it suspends only the two exact, previously verified processes via their held handles. The `finally` path resumes each suspension owned by this window, requests AVD resume only when its pause was attempted from an initially running state, checks status and records restoration errors. A failure keeps its output; no whole-run retry or output overwrite occurs. Observed restoration failures or a pause exceeding 480 seconds are reported as failures; a reserve cannot guarantee recovery if the host or emulator fails.

The pause clock allows at most 405 seconds of work before a 75-second restoration reserve; command teardown has an additional 15-second allowance within that work budget. Each complete run requires at least 140 seconds remaining after its before-run provenance check, so a later run is skipped if the bound cannot be met. Each of the two runs invokes the frozen original `measure.py` with CPU 8 and the frozen `bench-build.json`; the registered run has 86 cells, three paths and seven accepted samples per path/cell, retaining complete raw output and short-sample retries. No measurement duration is asserted before execution.

The timing-candidate JSON SHA-256 is `7fea94cbae8bdc0acb11e59b2abca9f658299141dbceb4b3be4eba1bddf39211`; the current authoritative `PROTOCOL.md` SHA-256 is `0e8dc6f90f46ef7bef129ecdc3ea4ae038ba0a09d921affa37ca36ee0af0ca0b`. The immutable build identity's older protocol snapshot SHA-256 `536a4e79ad20ae07a528e65cefc0a71a52d9f74ab2d1ca7d9bc005af6836c1ab` identifies its historical preparation state. The plan explicitly records the source-to-publication delta and checks both protocol versions.

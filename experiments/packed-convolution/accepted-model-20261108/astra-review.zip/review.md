# Independent Astra Max Review: Packed Convolution Acceptance08

## Verdict

**ACCEPT**, limited to the universal packed-convolution mathematical model and the focused model-proof evidence represented by acceptance08.

## Source binding

The reviewed checkout is `E:\3sat\VeriGMP-packed-convolution-20261107`, branch `codex/packed-convolution-foundation-20261107`. Its clean HEAD is `1dc2781e29ba56a44bd81257342f9d17d76a9513`, tree `28ce6f963094461b498061e90416963af2b25438`, with parent `a8e1a2215b325685d56c49a18923872a385df96a`. The author and committer are both `miles-song <2324715854@qq.com>`.

The exact diff from the previously accepted source is one deletion in `experiments/packed-convolution/oracle.py`: its final blank line is removed. No executable or proof text changed, and independent Python AST dumps of the two oracle files are identical. All 17 acceptance08 source inputs matched the live worktree, the exact HEAD blobs, and the archived acceptance08 source snapshot.

## Acceptance08 evidence

The frozen acceptance08 receipt has SHA-256 `d853632a07a008b77bdc9ba2024414b35691b4d1ee8c9da7bbe29ca950869010`. Its report records a pass for the scope `universal packed convolution model`, with runtime refinement, bit-cost proof, peak-space proof, benchmarking, and GMP parity all false. The 62 reported non-receipt artifacts matched their recorded hashes. The pinned Verus archive and all eight installed verifier components matched the source-bound tool identities; version logs bind Verus `0.2026.10.26.d17fbd0` and Rust `1.99.1` for `x86_64-unknown-linux-gnu`.

The captured WSL run completed without timeout or owned live children: the model gate reported 73 verified and 0 errors, the imported fixture gate reported 16 verified and 0 errors, and the erasure client reported 2 verified and 0 errors. Four semantic mutants each exited with a completed logical verification failure; none was accepted from a timeout, parser failure, resource limit, or solver-unknown result. I inspected these receipts and independently checked their source substitutions and rejection messages rather than treating the report counters as sufficient.

I independently recomputed all 10,134 canonical/truncated oracle rows, all 15 signed-identity cases, all 16 imported fixture coefficient/product pairs, and the concrete undersized-radix carry counterexample. Empty inputs and zero truncation were included in the row checks.

## Erasure regression check

The earlier erasure-selector defect remains fixed. Acceptance08 invokes `objdump -d` with the exact `.text.packed_model_identity` or `.text.ordinary_identity` section selector together with the matching `--disassemble` symbol selector. The captured logs contain exactly one expected section and label per command, and exactly `mov` followed by `ret`.

I additionally parsed `erasure-client.o` directly: both symbols are global text symbols of size four at offset zero in their respective sections, have machine bytes `48 89 f8 c3`, and have no relocation entries. The packed and ordinary identities therefore have the same actual erased body while retaining distinct section and symbol bindings.

## Scope and documentation

`docs/packed-convolution.md`, `README.md`, `README.zh-CN.md`, and `native/proof-status.json` consistently retain `model_proved` scope. They state that executable packing, extraction, multiplication, runtime refinement, machine-capacity/ownership contracts, composed bit-cost and space bounds, and performance remain pending. The global complete-library and GMP-parity flags remain false. No native runtime implementation, dispatch change, FFI, benchmark, speedup, or full VeriGMP acceptance is implied by this review.

Acceptance05, acceptance06, and acceptance07 were byte-inventoried before and after the audit and remained unchanged. Acceptance06 remains the preserved failed pre-fix attempt; its existence does not weaken the acceptance08 result because the repaired selectors and fresh receipt are independently bound to the reviewed source.

The reviewer did not rerun Verus inside this Windows read-only audit; acceptance08's fresh WSL command receipts were inspected and independently cross-checked. This is sufficient for the requested acceptance08 evidence review and is not a new broad proof gate.

"""Read-only acceptance08 audit. Writes results only beside this review script."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess
import sys
import zipfile

ROOT = Path(r'E:\3sat\VeriGMP-packed-convolution-20261107')
EVIDENCE_ROOT = Path(r'E:\3sat\VeriGMP-packed-convolution-evidence-20261107')
EVIDENCE = EVIDENCE_ROOT / 'acceptance08'
OUT = Path(__file__).resolve().parent
GIT = Path(r'C:\Program Files\Git\cmd\git.exe')
HEAD = '1dc2781e29ba56a44bd81257342f9d17d76a9513'
TREE = '28ce6f963094461b498061e90416963af2b25438'
BASE = 'a8e1a2215b325685d56c49a18923872a385df96a'
REPORT_SHA = 'd853632a07a008b77bdc9ba2024414b35691b4d1ee8c9da7bbe29ca950869010'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def need(ok, message):
    if not ok:
        raise AssertionError(message)


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def git(*args):
    return subprocess.run([str(GIT), '-C', str(ROOT), *args], capture_output=True,
                          check=True, timeout=30).stdout


def win(path):
    need(path.startswith('/mnt/e/'), 'Unexpected Linux source/tool path: ' + path)
    return Path('E:/' + path[len('/mnt/e/'):])


def inventory(root):
    return {p.relative_to(root).as_posix(): {'sha256': sha(p.read_bytes()), 'bytes': p.stat().st_size}
            for p in sorted(root.rglob('*')) if p.is_file()}


started = datetime.now(timezone.utc).isoformat()
before = {n: inventory(EVIDENCE_ROOT / n) for n in
          ('acceptance05', 'acceptance06', 'acceptance07', 'acceptance08')}
report_bytes = (EVIDENCE / 'verification.json').read_bytes()
report = json.loads(report_bytes)
need(sha(report_bytes) == REPORT_SHA, 'Unexpected receipt bytes')
need(git('rev-parse', 'HEAD').decode().strip() == HEAD == report['source_git']['head'], 'HEAD mismatch')
need(git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE, 'Tree mismatch')
need(git('status', '--porcelain=v1', '--untracked-files=all') == b'', 'Dirty worktree')
need(git('rev-parse', 'HEAD^').decode().strip() == BASE, 'Unexpected parent')
need(git('branch', '--show-current').decode().strip() == report['source_git']['branch'], 'Branch mismatch')
identity = git('show', '-s', '--format=%an <%ae>%n%cn <%ce>%n%B', HEAD).decode()
need(identity.splitlines()[:2] == ['miles-song <2324715854@qq.com>'] * 2, 'Author or committer mismatch')
need('co-authored-by:' not in identity.lower(), 'Unexpected coauthor trailer')
need(git('diff', '--name-only', BASE, HEAD).decode().splitlines() == ['experiments/packed-convolution/oracle.py'], 'Unexpected changed file')
previous_oracle = git('show', BASE + ':experiments/packed-convolution/oracle.py')
current_oracle = git('show', HEAD + ':experiments/packed-convolution/oracle.py')
need(previous_oracle == current_oracle + b'\n', 'Delta is not exactly one trailing LF')
need(ast.dump(ast.parse(previous_oracle)) == ast.dump(ast.parse(current_oracle)), 'Oracle syntax tree changed')
diff = git('diff', '--no-ext-diff', '--binary', BASE, HEAD)
(OUT / 'source-diff.patch').write_bytes(diff)
need(report['source_git']['git_command'] == ['/mnt/c/Program Files/Git/cmd/git.exe', '-C', 'E:/3sat/VeriGMP-packed-convolution-20261107'], 'Git producer binding differs')
need(win(report['source_git']['root']) == ROOT, 'Wrong producer worktree')

sources = report['source_git']['source_sha256']
need(len(sources) == 17, 'Wrong source count')
for name, digest in sources.items():
    need(not Path(name).is_absolute() and '..' not in Path(name).parts, 'Unsafe source path')
    working = (ROOT / name).read_bytes()
    need(sha(working) == digest and working == git('show', HEAD + ':' + name), 'Live/commit source mismatch: ' + name)
    need((EVIDENCE / 'source' / name).read_bytes() == working, 'Snapshot source mismatch: ' + name)
need(set(inventory(EVIDENCE / 'source')) == set(sources), 'Unreported snapshot source')
artifacts = report['artifact_sha256']
need(len(artifacts) == 62, 'Wrong artifact count')
need(set(before['acceptance08']) == set(artifacts) | {'verification.json'}, 'Unreported or missing evidence')
for name, digest in artifacts.items():
    need(before['acceptance08'][name]['sha256'] == digest, 'Artifact hash mismatch: ' + name)

pin = json.loads((ROOT / 'native/toolchain.json').read_bytes())
archive = Path(r'E:\3sat\VeriCount\deps\verus-download') / pin['archive']
need(sha(archive.read_bytes()) == pin['sha256'] == report['toolchain']['archive_sha256'], 'Tool archive mismatch')
need(len(report['toolchain']['actual_file_sha256']) == 8, 'Wrong verifier component count')
with zipfile.ZipFile(archive) as bundle:
    for path, digest in report['toolchain']['actual_file_sha256'].items():
        p = win(path)
        need(sha(p.read_bytes()) == digest == sha(bundle.read('verus-x86-linux/' + p.name)), 'Verifier component mismatch: ' + path)
need(pin['verus_version'] in report['toolchain']['verus_version'], 'Verus version mismatch')
need(pin['rust_toolchain'] in report['toolchain']['verus_version'], 'Rust toolchain mismatch')
need('release: 1.99.1' in report['toolchain']['rustc_version'] and 'host: x86_64-unknown-linux-gnu' in report['toolchain']['rustc_version'], 'Wrong Rust version or target')

commands = report['commands']
names = ['verus-version', 'rustc-version', 'model-proof-release', 'oracle-model-import',
         'erasure-client-build', 'proof-erasure-symbols', 'erasure-packed_model_identity',
         'erasure-ordinary_identity', 'mutant-undersized-radix', 'mutant-extract-next-slot',
         'mutant-omit-last-summand', 'mutant-truncate-one-too-soon']
need(len(commands) == len(names), 'Unexpected command count')
for name, c in zip(names, commands):
    need(c['timeout'] is False and c['owned_live_children'] == [], 'Incomplete producer: ' + name)
    need(c['returncode'] == (1 if name.startswith('mutant-') else 0), 'Wrong command exit: ' + name)
    for stream in ('stdout', 'stderr'):
        data = (EVIDENCE / (name + '.' + stream + '.log')).read_bytes()
        need(sha(data) == c[stream + '_sha256'], 'Command/log binding mismatch: ' + name)
    expected_cwd = EVIDENCE / ('mutants/' + name[7:] if name.startswith('mutant-') else 'source')
    need(win(c['cwd']) == expected_cwd, 'Wrong producer cwd: ' + name)
    if c['command'][0].endswith('/verus') and '--version' not in c['command']:
        need('--no-cheating' in c['command'] and '--no-verify' not in c['command'], 'Verification disabled')
for name, count, key in [('model-proof-release', 73, 'model_verified_items'),
                         ('oracle-model-import', 16, 'oracle_fixture_verified_items'),
                         ('erasure-client-build', 2, 'erasure_client_verified_items')]:
    need((EVIDENCE / (name + '.stdout.log')).read_text().strip() == f'verification results:: {count} verified, 0 errors', 'Wrong positive summary')
    need((EVIDENCE / (name + '.stderr.log')).read_bytes() == b'' and report[key] == count, 'Positive summary metadata mismatch')
for name, key in [('verus-version', 'verus_version'), ('rustc-version', 'rustc_version')]:
    need((EVIDENCE / (name + '.stdout.log')).read_text() == report['toolchain'][key], 'Version log mismatch')
compile_command = commands[2]['command']
need(compile_command[1] == 'experiments/packed-convolution/model.rs' and '--compile' in compile_command and '-O' in compile_command, 'Wrong model build')
for flag, name in [('--export', 'packed_model.vir'), ('-o', 'libpacked_model.rlib')]:
    target = compile_command[compile_command.index(flag) + 1]
    need(win(target) == EVIDENCE / name and sha(win(target).read_bytes()) == report['exports_sha256'][target], 'Export producer mismatch')
for c in commands[3:5]:
    for flag, name in [('--import', 'packed_model.vir'), ('--extern', 'libpacked_model.rlib')]:
        target = c['command'][c['command'].index(flag) + 1]
        need(target.startswith('packed_model=') and win(target.split('=', 1)[1]) == EVIDENCE / name, 'Wrong imported artifact')

# Independently inspect actual ELF symbol-to-section bindings and machine bytes.
obj = (EVIDENCE / 'erasure-client.o').read_bytes()
eh = struct.unpack_from('<16sHHIQQQIHHHHHH', obj)
need(eh[0][:6] == b'\x7fELF\x02\x01' and eh[1:3] == (1, 62), 'Expected x86-64 ELF relocatable')
sh = [struct.unpack_from('<IIQQQQIIQQ', obj, eh[6] + i * eh[11]) for i in range(eh[12])]
def contents(section):
    return obj[section[4]:section[4] + section[5]]
def cstring(data, offset):
    return data[offset:data.index(b'\0', offset)].decode()
section_names = [cstring(contents(sh[eh[13]]), s[0]) for s in sh]
symtab = sh[section_names.index('.symtab')]
symbol_strings = contents(sh[symtab[6]])
symbol_records = {}
for pos in range(symtab[4], symtab[4] + symtab[5], symtab[9]):
    sym = struct.unpack_from('<IBBHQQ', obj, pos)
    name = cstring(symbol_strings, sym[0])
    if name in ('packed_model_identity', 'ordinary_identity'):
        need(name not in symbol_records, 'Duplicate target ELF symbol')
        section = sh[sym[3]]
        need(section_names[sym[3]] == '.text.' + name and sym[1] == 0x12 and sym[4:] == (0, 4), 'Wrong identity symbol binding')
        need(section[2] & 4 and contents(section) == bytes.fromhex('4889f8c3'), 'Identity body contains unexpected work')
        need(not any(s[1] in (4, 9) and s[7] == sym[3] and s[5] for s in sh), 'Identity has relocations')
        symbol_records[name] = {'section': section_names[sym[3]], 'value': sym[4], 'size': sym[5], 'machine_hex': contents(section).hex()}
need(len(symbol_records) == 2, 'Missing ELF identity symbol')
for i, name in enumerate(('packed_model_identity', 'ordinary_identity'), start=6):
    need(commands[i]['command'][:4] == ['objdump', '-d', '--section=.text.' + name, '--disassemble=' + name], 'Wrong disassembly selectors')
    need(win(commands[i]['command'][4]) == EVIDENCE / 'erasure-client.o', 'Wrong disassembly object')
    log = (EVIDENCE / ('erasure-' + name + '.stdout.log')).read_text()
    need(re.findall(r'^Disassembly of section ([^:]+):$', log, re.M) == ['.text.' + name], 'Wrong disassembly section')
    need(re.findall(r'^\s*[0-9a-f]+ <([^>]+)>:$', log, re.M) == [name], 'Wrong disassembly symbol')
    instructions = re.findall(r'^\s*[0-9a-f]+:\s+((?:[0-9a-f]{2}\s+)+)(.+)$', log, re.M)
    need(bytes.fromhex(' '.join(x[0] for x in instructions)) == bytes.fromhex('4889f8c3'), 'Disassembly differs from object bytes')
    need([x[1].split()[0] for x in instructions] == ['mov', 'ret'], 'Wrong disassembled mnemonics')
    need(report['erasure_disassemblies'][i - 6] == {'symbol': name, 'section': '.text.' + name, 'labels': [name], 'instructions': 2}, 'Disassembly receipt mismatch')

# A coefficient-at-k sum and Horner evaluation are independent of the generator loops.
def conv(a, b):
    return [sum(a[i] * b[k - i] for i in range(len(a)) if 0 <= k - i < len(b))
            for k in range(len(a) + len(b))]
def packed(a, b):
    acc = 0
    for value in reversed(a):
        acc = acc * b + value
    return acc
rows = 0
for line in (EVIDENCE / 'oracle-cases.jsonl').read_text().splitlines():
    c = json.loads(line)
    m = 2 ** c['p']
    full_a, full_b = [v % m for v in c['a']], [v % m for v in c['b']]
    a, b = full_a[:c['d']], full_b[:c['d']]
    length = min(len(a), len(b))
    width = 2 * c['p'] + ((length - 1).bit_length() if length else 0)
    if c['word_aligned']:
        width = 64 * ((width + 63) // 64)
    radix = 2 ** width
    coeffs = conv(a, b)
    product = packed(a, radix) * packed(b, radix)
    need(c['w'] == width and c['coefficients'] == coeffs, 'Oracle coefficient/width mismatch')
    need(all(0 <= v < radix for v in coeffs) and packed(coeffs, radix) == product, 'Carry or product identity failure')
    expected = conv(full_a, full_b)[:c['d']]
    expected += [0] * (c['d'] - len(expected))
    slots = [(product // radix ** k) % m for k in range(c['d'])]
    need(slots == c['extracted'] == [v % m for v in expected] and c['packed_product_hex'] == hex(product), 'Oracle extraction mismatch')
    need(bool(a and b and c['d']) or product == 0, 'Empty/D=0 failure')
    rows += 1
need(rows == report['oracle']['canonical_cases'] == 10134, 'Wrong oracle count')
for radix in (-3, 0, 1, 3, 17):
    for a, b in (([-3, 4], [5, -7, 2]), ([], [-1]), ([1], [2])):
        need(packed(conv(a, b), radix) == packed(a, radix) * packed(b, radix), 'Signed identity failure')
wrong = packed([3, 3], 16) ** 2
need(conv([3, 3], [3, 3])[1] == 18 and (wrong // 16 ** 2) % 4 != 9 % 4, 'Missing carry counterexample')
fixtures = (EVIDENCE / 'oracle-fixtures.rs').read_text()
coeff_pattern = r'assert\(coefficient\(seq!\[([^]]*)\],seq!\[([^]]*)\],(\d+)\)==(-?\d+)int\) by\(compute\);'
product_pattern = r'assert\(packed\(seq!\[([^]]*)\],(-?\d+)int\)\*packed\(seq!\[([^]]*)\],(-?\d+)int\)==(-?\d+)int\) by\(compute\);'
parse_seq = lambda s: [int(v[:-3]) for v in s.split(',')] if s else []
coeff_matches = re.findall(coeff_pattern, fixtures)
product_matches = re.findall(product_pattern, fixtures)
need(len(coeff_matches) == len(product_matches) == 16, 'Wrong imported fixture shape')
for a, b, k, value in coeff_matches:
    need(conv(parse_seq(a), parse_seq(b))[int(k)] == int(value), 'Incorrect imported coefficient fixture')
for a, radix_a, b, radix_b, value in product_matches:
    need(radix_a == radix_b and packed(parse_seq(a), int(radix_a)) * packed(parse_seq(b), int(radix_b)) == int(value), 'Incorrect imported product fixture')

model = (ROOT / 'native/specs/packed_convolution.rs').read_text()
mutation_ast = ast.parse((ROOT / 'experiments/packed-convolution/mutations.py').read_text())
mutations = ast.literal_eval(next(n.value for n in mutation_ast.body if isinstance(n, ast.Assign)))
need({m['name'] for m in report['mutants']} == set(mutations) and len(mutations) == 4, 'Wrong mutant set')
mutant_results = []
for m in report['mutants']:
    name = m['name']
    old, new = mutations[name]
    need(model.count(old) == 1, 'Nonunique mutation anchor')
    mutant = EVIDENCE / 'mutants' / name
    mutated = (mutant / 'native/specs/packed_convolution.rs').read_bytes()
    need(mutated == model.replace(old, new).encode() and sha(mutated) == m['source_sha256'], 'Mutant source mismatch')
    for source in ['native/specs/radix.rs', 'native/specs/product.rs', 'experiments/packed-convolution/model.rs']:
        need((mutant / source).read_bytes() == (ROOT / source).read_bytes(), 'Mutant changed dependencies')
    log = (EVIDENCE / ('mutant-' + name + '.stdout.log')).read_text() + (EVIDENCE / ('mutant-' + name + '.stderr.log')).read_text()
    need(m['rejected_by_logic'] and re.search(r'^verification results:: \d+ verified, [1-9]\d* errors$', log, re.M), 'No logical rejection summary')
    need(re.search(r'error: (postcondition not satisfied|assertion failed|precondition not satisfied|requires not satisfied)', log), 'No semantic VC rejection')
    need(not re.search(r'(?i)resource limit|rlimit.*exceeded|timed out|panic|unexpected token|could not compile|solver.*unknown', log), 'Resource/tool failure counted')
    mutant_results.append({'name': name, 'summary': re.search(r'verification results::[^\n]+', log)[0]})

need(report['status'] == 'pass' and report['scope'] == 'universal packed convolution model', 'Wrong claim')
for flag in ['runtime_refinement', 'bit_cost_proved', 'peak_space_proved', 'benchmark_run', 'gmp_parity']:
    need(report[flag] is False, 'Unaccepted scope flag: ' + flag)
need(report['oracle']['runtime_implementation_tested'] is False, 'Oracle claimed runtime coverage')
status = json.loads((ROOT / 'native/proof-status.json').read_bytes())
entry = [x for x in status['modules'] if x['files'] == ['specs/packed_convolution.rs']]
need(len(entry) == 1 and entry[0]['status'] == 'model_proved', 'Wrong proof status')
need('No runtime implementation or performance claim' in entry[0]['cost'], 'Missing scope limitation')
need(status['complete_multiprecision_api'] is False and status['gmp_performance_parity_established'] is False, 'Global flag changed')
need(not re.search(r'\b(?:assume|admit|axiom)\s*\(|external_body|external_fn_specification|verifier::trusted|verify\s*=\s*false|\bunsafe\b|extern\s+"C"', model), 'Core proof escape')

after = {n: inventory(EVIDENCE_ROOT / n) for n in before}
need(after == before, 'Original evidence changed during review')
need(git('rev-parse', 'HEAD').decode().strip() == HEAD and git('status', '--porcelain=v1', '--untracked-files=all') == b'', 'Candidate moved during review')
for name, digest in sources.items():
    need(sha((ROOT / name).read_bytes()) == digest, 'Source moved during review')
(OUT / 'acceptance08-verification.json').write_bytes(report_bytes)
write('evidence-inventories.json', before)
result = {
    'status': 'pass', 'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
    'candidate_head': HEAD, 'candidate_tree': TREE, 'previous_accepted_commit': BASE,
    'candidate_clean_before_after': True, 'delta': 'Exactly one final LF removed from oracle.py; AST identical',
    'receipt_sha256': REPORT_SHA, 'source_inputs_checked': 17, 'artifact_hashes_checked': 62,
    'pinned_verifier_components_checked_against_archive': 8, 'command_log_pairs_checked': 12,
    'focused_verus_total_including_dependencies': 73, 'fixture_verified': 16, 'identity_client_verified': 2,
    'independent_oracle_rows': rows, 'independent_signed_cases': 15,
    'independent_fixture_coefficients': len(coeff_matches), 'independent_fixture_products': len(product_matches),
    'undersized_radix_counterexample': True, 'elf_symbols_checked': symbol_records,
    'mutant_results': mutant_results, 'evidence_05_06_07_08_unchanged_during_review': True,
    'fresh_verus_run_by_reviewer': False, 'review_method': 'Inspect fresh acceptance08 WSL results; independent Windows read-only hashes, ELF and integer checks',
    'runtime_performance_acceptance': False, 'python': {'executable': sys.executable, 'version': sys.version, 'sha256': sha(Path(sys.executable).read_bytes())},
    'git': {'path': str(GIT), 'sha256': sha(GIT.read_bytes()), 'version': git('--version').decode().strip()},
}
write('audit-result.json', result)
print(json.dumps(result, indent=2))

extern crate verigmp;
use verigmp::packed_layout::{extract_coefficients, pack_coefficients, PackedLayoutError};
fn main() {
    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 1, 1);
        assert!(matches!(result, Ok(())), "pack case 0");
        assert_eq!(packed, expected_packed, "packed words case 0");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 1, 1);
        assert!(matches!(result, Ok(())), "extract case 0");
        assert_eq!(recovered, expected_recovered, "recovered words case 0");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 1, 2);
        assert!(matches!(result, Ok(())), "pack case 1");
        assert_eq!(packed, expected_packed, "packed words case 1");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 1, 2);
        assert!(matches!(result, Ok(())), "extract case 1");
        assert_eq!(recovered, expected_recovered, "recovered words case 1");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 1, 4);
        assert!(matches!(result, Ok(())), "pack case 2");
        assert_eq!(packed, expected_packed, "packed words case 2");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 1, 4);
        assert!(matches!(result, Ok(())), "extract case 2");
        assert_eq!(recovered, expected_recovered, "recovered words case 2");
    }

    {
        let src: [u64; 1] = [1u64];
        let mut packed: [u64; 1] = [u64::MAX; 1];
        let expected_packed: [u64; 1] = [1u64];
        let result = pack_coefficients(&mut packed, &src, 1, 1, 1);
        assert!(matches!(result, Ok(())), "pack case 3");
        assert_eq!(packed, expected_packed, "packed words case 3");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [1u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 1, 1);
        assert!(matches!(result, Ok(())), "extract case 3");
        assert_eq!(recovered, expected_recovered, "recovered words case 3");
    }

    {
        let src: [u64; 1] = [1u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 1, 2);
        assert!(matches!(result, Ok(())), "pack case 4");
        assert_eq!(packed, expected_packed, "packed words case 4");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [1u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 1, 2);
        assert!(matches!(result, Ok(())), "extract case 4");
        assert_eq!(recovered, expected_recovered, "recovered words case 4");
    }

    {
        let src: [u64; 1] = [1u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 1, 4);
        assert!(matches!(result, Ok(())), "pack case 5");
        assert_eq!(packed, expected_packed, "packed words case 5");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [1u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 1, 4);
        assert!(matches!(result, Ok(())), "extract case 5");
        assert_eq!(recovered, expected_recovered, "recovered words case 5");
    }

    {
        let src: [u64; 2] = [1u64, 1u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [1u64, 1u64];
        let result = pack_coefficients(&mut packed, &src, 2, 1, 1);
        assert!(matches!(result, Ok(())), "pack case 6");
        assert_eq!(packed, expected_packed, "packed words case 6");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [1u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 1, 1);
        assert!(matches!(result, Ok(())), "extract case 6");
        assert_eq!(recovered, expected_recovered, "recovered words case 6");
    }

    {
        let src: [u64; 2] = [1u64, 1u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [1u64, 0u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 1, 2);
        assert!(matches!(result, Ok(())), "pack case 7");
        assert_eq!(packed, expected_packed, "packed words case 7");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [1u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 1, 2);
        assert!(matches!(result, Ok(())), "extract case 7");
        assert_eq!(recovered, expected_recovered, "recovered words case 7");
    }

    {
        let src: [u64; 2] = [1u64, 1u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [1u64, 0u64, 0u64, 0u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 1, 4);
        assert!(matches!(result, Ok(())), "pack case 8");
        assert_eq!(packed, expected_packed, "packed words case 8");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [1u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 1, 4);
        assert!(matches!(result, Ok(())), "extract case 8");
        assert_eq!(recovered, expected_recovered, "recovered words case 8");
    }

    {
        let src: [u64; 5] = [1u64, 1u64, 0u64, 0u64, 1u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [1u64, 1u64, 0u64, 0u64, 1u64];
        let result = pack_coefficients(&mut packed, &src, 5, 1, 1);
        assert!(matches!(result, Ok(())), "pack case 9");
        assert_eq!(packed, expected_packed, "packed words case 9");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [1u64, 1u64, 0u64, 0u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 1, 1);
        assert!(matches!(result, Ok(())), "extract case 9");
        assert_eq!(recovered, expected_recovered, "recovered words case 9");
    }

    {
        let src: [u64; 5] = [1u64, 1u64, 0u64, 0u64, 1u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [1u64, 0u64, 1u64, 0u64, 0u64, 0u64, 0u64, 0u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 1, 2);
        assert!(matches!(result, Ok(())), "pack case 10");
        assert_eq!(packed, expected_packed, "packed words case 10");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [1u64, 1u64, 0u64, 0u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 1, 2);
        assert!(matches!(result, Ok(())), "extract case 10");
        assert_eq!(recovered, expected_recovered, "recovered words case 10");
    }

    {
        let src: [u64; 5] = [1u64, 1u64, 0u64, 0u64, 1u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [1u64, 0u64, 0u64, 0u64, 1u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 1, 4);
        assert!(matches!(result, Ok(())), "pack case 11");
        assert_eq!(packed, expected_packed, "packed words case 11");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [1u64, 1u64, 0u64, 0u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 1, 4);
        assert!(matches!(result, Ok(())), "extract case 11");
        assert_eq!(recovered, expected_recovered, "recovered words case 11");
    }

    {
        let src: [u64; 3] = [1u64, 0u64, 1u64];
        let mut packed: [u64; 9] = [u64::MAX; 9];
        let expected_packed: [u64; 9] = [1u64, 0u64, 0u64, 0u64, 0u64, 0u64, 1u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 1, 3);
        assert!(matches!(result, Ok(())), "pack case 12");
        assert_eq!(packed, expected_packed, "packed words case 12");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [1u64, 0u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 1, 3);
        assert!(matches!(result, Ok(())), "extract case 12");
        assert_eq!(recovered, expected_recovered, "recovered words case 12");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 2, 1);
        assert!(matches!(result, Ok(())), "pack case 13");
        assert_eq!(packed, expected_packed, "packed words case 13");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 2, 1);
        assert!(matches!(result, Ok(())), "extract case 13");
        assert_eq!(recovered, expected_recovered, "recovered words case 13");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 2, 2);
        assert!(matches!(result, Ok(())), "pack case 14");
        assert_eq!(packed, expected_packed, "packed words case 14");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 2, 2);
        assert!(matches!(result, Ok(())), "extract case 14");
        assert_eq!(recovered, expected_recovered, "recovered words case 14");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 2, 4);
        assert!(matches!(result, Ok(())), "pack case 15");
        assert_eq!(packed, expected_packed, "packed words case 15");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 2, 4);
        assert!(matches!(result, Ok(())), "extract case 15");
        assert_eq!(recovered, expected_recovered, "recovered words case 15");
    }

    {
        let src: [u64; 1] = [3u64];
        let mut packed: [u64; 1] = [u64::MAX; 1];
        let expected_packed: [u64; 1] = [3u64];
        let result = pack_coefficients(&mut packed, &src, 1, 2, 1);
        assert!(matches!(result, Ok(())), "pack case 16");
        assert_eq!(packed, expected_packed, "packed words case 16");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [3u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 2, 1);
        assert!(matches!(result, Ok(())), "extract case 16");
        assert_eq!(recovered, expected_recovered, "recovered words case 16");
    }

    {
        let src: [u64; 1] = [3u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [3u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 2, 2);
        assert!(matches!(result, Ok(())), "pack case 17");
        assert_eq!(packed, expected_packed, "packed words case 17");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [3u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 2, 2);
        assert!(matches!(result, Ok(())), "extract case 17");
        assert_eq!(recovered, expected_recovered, "recovered words case 17");
    }

    {
        let src: [u64; 1] = [3u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [3u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 2, 4);
        assert!(matches!(result, Ok(())), "pack case 18");
        assert_eq!(packed, expected_packed, "packed words case 18");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [3u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 2, 4);
        assert!(matches!(result, Ok(())), "extract case 18");
        assert_eq!(recovered, expected_recovered, "recovered words case 18");
    }

    {
        let src: [u64; 2] = [3u64, 3u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [3u64, 3u64];
        let result = pack_coefficients(&mut packed, &src, 2, 2, 1);
        assert!(matches!(result, Ok(())), "pack case 19");
        assert_eq!(packed, expected_packed, "packed words case 19");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [3u64, 3u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 2, 1);
        assert!(matches!(result, Ok(())), "extract case 19");
        assert_eq!(recovered, expected_recovered, "recovered words case 19");
    }

    {
        let src: [u64; 2] = [3u64, 3u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [3u64, 0u64, 3u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 2, 2);
        assert!(matches!(result, Ok(())), "pack case 20");
        assert_eq!(packed, expected_packed, "packed words case 20");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [3u64, 3u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 2, 2);
        assert!(matches!(result, Ok(())), "extract case 20");
        assert_eq!(recovered, expected_recovered, "recovered words case 20");
    }

    {
        let src: [u64; 2] = [3u64, 3u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [3u64, 0u64, 0u64, 0u64, 3u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 2, 4);
        assert!(matches!(result, Ok(())), "pack case 21");
        assert_eq!(packed, expected_packed, "packed words case 21");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [3u64, 3u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 2, 4);
        assert!(matches!(result, Ok(())), "extract case 21");
        assert_eq!(recovered, expected_recovered, "recovered words case 21");
    }

    {
        let src: [u64; 5] = [3u64, 3u64, 1u64, 1u64, 0u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [3u64, 3u64, 1u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 2, 1);
        assert!(matches!(result, Ok(())), "pack case 22");
        assert_eq!(packed, expected_packed, "packed words case 22");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [3u64, 3u64, 1u64, 1u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 2, 1);
        assert!(matches!(result, Ok(())), "extract case 22");
        assert_eq!(recovered, expected_recovered, "recovered words case 22");
    }

    {
        let src: [u64; 5] = [3u64, 3u64, 1u64, 1u64, 0u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [3u64, 0u64, 3u64, 0u64, 1u64, 0u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 2, 2);
        assert!(matches!(result, Ok(())), "pack case 23");
        assert_eq!(packed, expected_packed, "packed words case 23");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [3u64, 3u64, 1u64, 1u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 2, 2);
        assert!(matches!(result, Ok(())), "extract case 23");
        assert_eq!(recovered, expected_recovered, "recovered words case 23");
    }

    {
        let src: [u64; 5] = [3u64, 3u64, 1u64, 1u64, 0u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [3u64, 0u64, 0u64, 0u64, 3u64, 0u64, 0u64, 0u64, 1u64, 0u64, 0u64, 0u64, 1u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 2, 4);
        assert!(matches!(result, Ok(())), "pack case 24");
        assert_eq!(packed, expected_packed, "packed words case 24");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [3u64, 3u64, 1u64, 1u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 2, 4);
        assert!(matches!(result, Ok(())), "extract case 24");
        assert_eq!(recovered, expected_recovered, "recovered words case 24");
    }

    {
        let src: [u64; 3] = [3u64, 0u64, 3u64];
        let mut packed: [u64; 9] = [u64::MAX; 9];
        let expected_packed: [u64; 9] = [3u64, 0u64, 0u64, 0u64, 0u64, 0u64, 3u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 2, 3);
        assert!(matches!(result, Ok(())), "pack case 25");
        assert_eq!(packed, expected_packed, "packed words case 25");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [3u64, 0u64, 3u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 2, 3);
        assert!(matches!(result, Ok(())), "extract case 25");
        assert_eq!(recovered, expected_recovered, "recovered words case 25");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 31, 1);
        assert!(matches!(result, Ok(())), "pack case 26");
        assert_eq!(packed, expected_packed, "packed words case 26");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 31, 1);
        assert!(matches!(result, Ok(())), "extract case 26");
        assert_eq!(recovered, expected_recovered, "recovered words case 26");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 31, 2);
        assert!(matches!(result, Ok(())), "pack case 27");
        assert_eq!(packed, expected_packed, "packed words case 27");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 31, 2);
        assert!(matches!(result, Ok(())), "extract case 27");
        assert_eq!(recovered, expected_recovered, "recovered words case 27");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 31, 4);
        assert!(matches!(result, Ok(())), "pack case 28");
        assert_eq!(packed, expected_packed, "packed words case 28");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 31, 4);
        assert!(matches!(result, Ok(())), "extract case 28");
        assert_eq!(recovered, expected_recovered, "recovered words case 28");
    }

    {
        let src: [u64; 1] = [427253162u64];
        let mut packed: [u64; 1] = [u64::MAX; 1];
        let expected_packed: [u64; 1] = [427253162u64];
        let result = pack_coefficients(&mut packed, &src, 1, 31, 1);
        assert!(matches!(result, Ok(())), "pack case 29");
        assert_eq!(packed, expected_packed, "packed words case 29");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [427253162u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 31, 1);
        assert!(matches!(result, Ok(())), "extract case 29");
        assert_eq!(recovered, expected_recovered, "recovered words case 29");
    }

    {
        let src: [u64; 1] = [427253162u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [427253162u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 31, 2);
        assert!(matches!(result, Ok(())), "pack case 30");
        assert_eq!(packed, expected_packed, "packed words case 30");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [427253162u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 31, 2);
        assert!(matches!(result, Ok(())), "extract case 30");
        assert_eq!(recovered, expected_recovered, "recovered words case 30");
    }

    {
        let src: [u64; 1] = [427253162u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [427253162u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 31, 4);
        assert!(matches!(result, Ok(())), "pack case 31");
        assert_eq!(packed, expected_packed, "packed words case 31");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [427253162u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 31, 4);
        assert!(matches!(result, Ok(())), "extract case 31");
        assert_eq!(recovered, expected_recovered, "recovered words case 31");
    }

    {
        let src: [u64; 2] = [365285585u64, 838632508u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [365285585u64, 838632508u64];
        let result = pack_coefficients(&mut packed, &src, 2, 31, 1);
        assert!(matches!(result, Ok(())), "pack case 32");
        assert_eq!(packed, expected_packed, "packed words case 32");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [365285585u64, 838632508u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 31, 1);
        assert!(matches!(result, Ok(())), "extract case 32");
        assert_eq!(recovered, expected_recovered, "recovered words case 32");
    }

    {
        let src: [u64; 2] = [365285585u64, 838632508u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [365285585u64, 0u64, 838632508u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 31, 2);
        assert!(matches!(result, Ok(())), "pack case 33");
        assert_eq!(packed, expected_packed, "packed words case 33");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [365285585u64, 838632508u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 31, 2);
        assert!(matches!(result, Ok(())), "extract case 33");
        assert_eq!(recovered, expected_recovered, "recovered words case 33");
    }

    {
        let src: [u64; 2] = [365285585u64, 838632508u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [365285585u64, 0u64, 0u64, 0u64, 838632508u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 31, 4);
        assert!(matches!(result, Ok(())), "pack case 34");
        assert_eq!(packed, expected_packed, "packed words case 34");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [365285585u64, 838632508u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 31, 4);
        assert!(matches!(result, Ok(())), "extract case 34");
        assert_eq!(recovered, expected_recovered, "recovered words case 34");
    }

    {
        let src: [u64; 5] = [598742991u64, 774297555u64, 1608087888u64, 1795627424u64, 1861109440u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [598742991u64, 774297555u64, 1608087888u64, 1795627424u64, 1861109440u64];
        let result = pack_coefficients(&mut packed, &src, 5, 31, 1);
        assert!(matches!(result, Ok(())), "pack case 35");
        assert_eq!(packed, expected_packed, "packed words case 35");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [598742991u64, 774297555u64, 1608087888u64, 1795627424u64, 1861109440u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 31, 1);
        assert!(matches!(result, Ok(())), "extract case 35");
        assert_eq!(recovered, expected_recovered, "recovered words case 35");
    }

    {
        let src: [u64; 5] = [598742991u64, 774297555u64, 1608087888u64, 1795627424u64, 1861109440u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [598742991u64, 0u64, 774297555u64, 0u64, 1608087888u64, 0u64, 1795627424u64, 0u64, 1861109440u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 31, 2);
        assert!(matches!(result, Ok(())), "pack case 36");
        assert_eq!(packed, expected_packed, "packed words case 36");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [598742991u64, 774297555u64, 1608087888u64, 1795627424u64, 1861109440u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 31, 2);
        assert!(matches!(result, Ok(())), "extract case 36");
        assert_eq!(recovered, expected_recovered, "recovered words case 36");
    }

    {
        let src: [u64; 5] = [598742991u64, 774297555u64, 1608087888u64, 1795627424u64, 1861109440u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [598742991u64, 0u64, 0u64, 0u64, 774297555u64, 0u64, 0u64, 0u64, 1608087888u64, 0u64, 0u64, 0u64, 1795627424u64, 0u64, 0u64, 0u64, 1861109440u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 31, 4);
        assert!(matches!(result, Ok(())), "pack case 37");
        assert_eq!(packed, expected_packed, "packed words case 37");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [598742991u64, 774297555u64, 1608087888u64, 1795627424u64, 1861109440u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 31, 4);
        assert!(matches!(result, Ok(())), "extract case 37");
        assert_eq!(recovered, expected_recovered, "recovered words case 37");
    }

    {
        let src: [u64; 3] = [2147483647u64, 0u64, 2147483647u64];
        let mut packed: [u64; 9] = [u64::MAX; 9];
        let expected_packed: [u64; 9] = [2147483647u64, 0u64, 0u64, 0u64, 0u64, 0u64, 2147483647u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 31, 3);
        assert!(matches!(result, Ok(())), "pack case 38");
        assert_eq!(packed, expected_packed, "packed words case 38");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [2147483647u64, 0u64, 2147483647u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 31, 3);
        assert!(matches!(result, Ok(())), "extract case 38");
        assert_eq!(recovered, expected_recovered, "recovered words case 38");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 32, 1);
        assert!(matches!(result, Ok(())), "pack case 39");
        assert_eq!(packed, expected_packed, "packed words case 39");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 32, 1);
        assert!(matches!(result, Ok(())), "extract case 39");
        assert_eq!(recovered, expected_recovered, "recovered words case 39");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 32, 2);
        assert!(matches!(result, Ok(())), "pack case 40");
        assert_eq!(packed, expected_packed, "packed words case 40");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 32, 2);
        assert!(matches!(result, Ok(())), "extract case 40");
        assert_eq!(recovered, expected_recovered, "recovered words case 40");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 32, 4);
        assert!(matches!(result, Ok(())), "pack case 41");
        assert_eq!(packed, expected_packed, "packed words case 41");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 32, 4);
        assert!(matches!(result, Ok(())), "extract case 41");
        assert_eq!(recovered, expected_recovered, "recovered words case 41");
    }

    {
        let src: [u64; 1] = [751577712u64];
        let mut packed: [u64; 1] = [u64::MAX; 1];
        let expected_packed: [u64; 1] = [751577712u64];
        let result = pack_coefficients(&mut packed, &src, 1, 32, 1);
        assert!(matches!(result, Ok(())), "pack case 42");
        assert_eq!(packed, expected_packed, "packed words case 42");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [751577712u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 32, 1);
        assert!(matches!(result, Ok(())), "extract case 42");
        assert_eq!(recovered, expected_recovered, "recovered words case 42");
    }

    {
        let src: [u64; 1] = [751577712u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [751577712u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 32, 2);
        assert!(matches!(result, Ok(())), "pack case 43");
        assert_eq!(packed, expected_packed, "packed words case 43");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [751577712u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 32, 2);
        assert!(matches!(result, Ok(())), "extract case 43");
        assert_eq!(recovered, expected_recovered, "recovered words case 43");
    }

    {
        let src: [u64; 1] = [751577712u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [751577712u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 32, 4);
        assert!(matches!(result, Ok(())), "pack case 44");
        assert_eq!(packed, expected_packed, "packed words case 44");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [751577712u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 32, 4);
        assert!(matches!(result, Ok(())), "extract case 44");
        assert_eq!(recovered, expected_recovered, "recovered words case 44");
    }

    {
        let src: [u64; 2] = [2991471353u64, 3301294329u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [2991471353u64, 3301294329u64];
        let result = pack_coefficients(&mut packed, &src, 2, 32, 1);
        assert!(matches!(result, Ok(())), "pack case 45");
        assert_eq!(packed, expected_packed, "packed words case 45");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [2991471353u64, 3301294329u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 32, 1);
        assert!(matches!(result, Ok(())), "extract case 45");
        assert_eq!(recovered, expected_recovered, "recovered words case 45");
    }

    {
        let src: [u64; 2] = [2991471353u64, 3301294329u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [2991471353u64, 0u64, 3301294329u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 32, 2);
        assert!(matches!(result, Ok(())), "pack case 46");
        assert_eq!(packed, expected_packed, "packed words case 46");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [2991471353u64, 3301294329u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 32, 2);
        assert!(matches!(result, Ok(())), "extract case 46");
        assert_eq!(recovered, expected_recovered, "recovered words case 46");
    }

    {
        let src: [u64; 2] = [2991471353u64, 3301294329u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [2991471353u64, 0u64, 0u64, 0u64, 3301294329u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 32, 4);
        assert!(matches!(result, Ok(())), "pack case 47");
        assert_eq!(packed, expected_packed, "packed words case 47");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [2991471353u64, 3301294329u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 32, 4);
        assert!(matches!(result, Ok(())), "extract case 47");
        assert_eq!(recovered, expected_recovered, "recovered words case 47");
    }

    {
        let src: [u64; 5] = [1501026038u64, 439067902u64, 1671618366u64, 976156457u64, 653311048u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [1501026038u64, 439067902u64, 1671618366u64, 976156457u64, 653311048u64];
        let result = pack_coefficients(&mut packed, &src, 5, 32, 1);
        assert!(matches!(result, Ok(())), "pack case 48");
        assert_eq!(packed, expected_packed, "packed words case 48");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [1501026038u64, 439067902u64, 1671618366u64, 976156457u64, 653311048u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 32, 1);
        assert!(matches!(result, Ok(())), "extract case 48");
        assert_eq!(recovered, expected_recovered, "recovered words case 48");
    }

    {
        let src: [u64; 5] = [1501026038u64, 439067902u64, 1671618366u64, 976156457u64, 653311048u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [1501026038u64, 0u64, 439067902u64, 0u64, 1671618366u64, 0u64, 976156457u64, 0u64, 653311048u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 32, 2);
        assert!(matches!(result, Ok(())), "pack case 49");
        assert_eq!(packed, expected_packed, "packed words case 49");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [1501026038u64, 439067902u64, 1671618366u64, 976156457u64, 653311048u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 32, 2);
        assert!(matches!(result, Ok(())), "extract case 49");
        assert_eq!(recovered, expected_recovered, "recovered words case 49");
    }

    {
        let src: [u64; 5] = [1501026038u64, 439067902u64, 1671618366u64, 976156457u64, 653311048u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [1501026038u64, 0u64, 0u64, 0u64, 439067902u64, 0u64, 0u64, 0u64, 1671618366u64, 0u64, 0u64, 0u64, 976156457u64, 0u64, 0u64, 0u64, 653311048u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 32, 4);
        assert!(matches!(result, Ok(())), "pack case 50");
        assert_eq!(packed, expected_packed, "packed words case 50");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [1501026038u64, 439067902u64, 1671618366u64, 976156457u64, 653311048u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 32, 4);
        assert!(matches!(result, Ok(())), "extract case 50");
        assert_eq!(recovered, expected_recovered, "recovered words case 50");
    }

    {
        let src: [u64; 3] = [4294967295u64, 0u64, 4294967295u64];
        let mut packed: [u64; 9] = [u64::MAX; 9];
        let expected_packed: [u64; 9] = [4294967295u64, 0u64, 0u64, 0u64, 0u64, 0u64, 4294967295u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 32, 3);
        assert!(matches!(result, Ok(())), "pack case 51");
        assert_eq!(packed, expected_packed, "packed words case 51");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [4294967295u64, 0u64, 4294967295u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 32, 3);
        assert!(matches!(result, Ok(())), "extract case 51");
        assert_eq!(recovered, expected_recovered, "recovered words case 51");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 33, 1);
        assert!(matches!(result, Ok(())), "pack case 52");
        assert_eq!(packed, expected_packed, "packed words case 52");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 33, 1);
        assert!(matches!(result, Ok(())), "extract case 52");
        assert_eq!(recovered, expected_recovered, "recovered words case 52");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 33, 2);
        assert!(matches!(result, Ok(())), "pack case 53");
        assert_eq!(packed, expected_packed, "packed words case 53");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 33, 2);
        assert!(matches!(result, Ok(())), "extract case 53");
        assert_eq!(recovered, expected_recovered, "recovered words case 53");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 33, 4);
        assert!(matches!(result, Ok(())), "pack case 54");
        assert_eq!(packed, expected_packed, "packed words case 54");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 33, 4);
        assert!(matches!(result, Ok(())), "extract case 54");
        assert_eq!(recovered, expected_recovered, "recovered words case 54");
    }

    {
        let src: [u64; 1] = [837787803u64];
        let mut packed: [u64; 1] = [u64::MAX; 1];
        let expected_packed: [u64; 1] = [837787803u64];
        let result = pack_coefficients(&mut packed, &src, 1, 33, 1);
        assert!(matches!(result, Ok(())), "pack case 55");
        assert_eq!(packed, expected_packed, "packed words case 55");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [837787803u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 33, 1);
        assert!(matches!(result, Ok(())), "extract case 55");
        assert_eq!(recovered, expected_recovered, "recovered words case 55");
    }

    {
        let src: [u64; 1] = [837787803u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [837787803u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 33, 2);
        assert!(matches!(result, Ok(())), "pack case 56");
        assert_eq!(packed, expected_packed, "packed words case 56");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [837787803u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 33, 2);
        assert!(matches!(result, Ok(())), "extract case 56");
        assert_eq!(recovered, expected_recovered, "recovered words case 56");
    }

    {
        let src: [u64; 1] = [837787803u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [837787803u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 33, 4);
        assert!(matches!(result, Ok(())), "pack case 57");
        assert_eq!(packed, expected_packed, "packed words case 57");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [837787803u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 33, 4);
        assert!(matches!(result, Ok(())), "extract case 57");
        assert_eq!(recovered, expected_recovered, "recovered words case 57");
    }

    {
        let src: [u64; 2] = [2420360149u64, 963158281u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [2420360149u64, 963158281u64];
        let result = pack_coefficients(&mut packed, &src, 2, 33, 1);
        assert!(matches!(result, Ok(())), "pack case 58");
        assert_eq!(packed, expected_packed, "packed words case 58");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [2420360149u64, 963158281u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 33, 1);
        assert!(matches!(result, Ok(())), "extract case 58");
        assert_eq!(recovered, expected_recovered, "recovered words case 58");
    }

    {
        let src: [u64; 2] = [2420360149u64, 963158281u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [2420360149u64, 0u64, 963158281u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 33, 2);
        assert!(matches!(result, Ok(())), "pack case 59");
        assert_eq!(packed, expected_packed, "packed words case 59");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [2420360149u64, 963158281u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 33, 2);
        assert!(matches!(result, Ok(())), "extract case 59");
        assert_eq!(recovered, expected_recovered, "recovered words case 59");
    }

    {
        let src: [u64; 2] = [2420360149u64, 963158281u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [2420360149u64, 0u64, 0u64, 0u64, 963158281u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 33, 4);
        assert!(matches!(result, Ok(())), "pack case 60");
        assert_eq!(packed, expected_packed, "packed words case 60");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [2420360149u64, 963158281u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 33, 4);
        assert!(matches!(result, Ok(())), "extract case 60");
        assert_eq!(recovered, expected_recovered, "recovered words case 60");
    }

    {
        let src: [u64; 5] = [2312603506u64, 1675139769u64, 5532508333u64, 668919265u64, 2873056438u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [2312603506u64, 1675139769u64, 5532508333u64, 668919265u64, 2873056438u64];
        let result = pack_coefficients(&mut packed, &src, 5, 33, 1);
        assert!(matches!(result, Ok(())), "pack case 61");
        assert_eq!(packed, expected_packed, "packed words case 61");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [2312603506u64, 1675139769u64, 5532508333u64, 668919265u64, 2873056438u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 33, 1);
        assert!(matches!(result, Ok(())), "extract case 61");
        assert_eq!(recovered, expected_recovered, "recovered words case 61");
    }

    {
        let src: [u64; 5] = [2312603506u64, 1675139769u64, 5532508333u64, 668919265u64, 2873056438u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [2312603506u64, 0u64, 1675139769u64, 0u64, 5532508333u64, 0u64, 668919265u64, 0u64, 2873056438u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 33, 2);
        assert!(matches!(result, Ok(())), "pack case 62");
        assert_eq!(packed, expected_packed, "packed words case 62");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [2312603506u64, 1675139769u64, 5532508333u64, 668919265u64, 2873056438u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 33, 2);
        assert!(matches!(result, Ok(())), "extract case 62");
        assert_eq!(recovered, expected_recovered, "recovered words case 62");
    }

    {
        let src: [u64; 5] = [2312603506u64, 1675139769u64, 5532508333u64, 668919265u64, 2873056438u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [2312603506u64, 0u64, 0u64, 0u64, 1675139769u64, 0u64, 0u64, 0u64, 5532508333u64, 0u64, 0u64, 0u64, 668919265u64, 0u64, 0u64, 0u64, 2873056438u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 33, 4);
        assert!(matches!(result, Ok(())), "pack case 63");
        assert_eq!(packed, expected_packed, "packed words case 63");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [2312603506u64, 1675139769u64, 5532508333u64, 668919265u64, 2873056438u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 33, 4);
        assert!(matches!(result, Ok(())), "extract case 63");
        assert_eq!(recovered, expected_recovered, "recovered words case 63");
    }

    {
        let src: [u64; 3] = [8589934591u64, 0u64, 8589934591u64];
        let mut packed: [u64; 9] = [u64::MAX; 9];
        let expected_packed: [u64; 9] = [8589934591u64, 0u64, 0u64, 0u64, 0u64, 0u64, 8589934591u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 33, 3);
        assert!(matches!(result, Ok(())), "pack case 64");
        assert_eq!(packed, expected_packed, "packed words case 64");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [8589934591u64, 0u64, 8589934591u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 33, 3);
        assert!(matches!(result, Ok(())), "extract case 64");
        assert_eq!(recovered, expected_recovered, "recovered words case 64");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 63, 1);
        assert!(matches!(result, Ok(())), "pack case 65");
        assert_eq!(packed, expected_packed, "packed words case 65");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 63, 1);
        assert!(matches!(result, Ok(())), "extract case 65");
        assert_eq!(recovered, expected_recovered, "recovered words case 65");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 63, 2);
        assert!(matches!(result, Ok(())), "pack case 66");
        assert_eq!(packed, expected_packed, "packed words case 66");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 63, 2);
        assert!(matches!(result, Ok(())), "extract case 66");
        assert_eq!(recovered, expected_recovered, "recovered words case 66");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 63, 4);
        assert!(matches!(result, Ok(())), "pack case 67");
        assert_eq!(packed, expected_packed, "packed words case 67");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 63, 4);
        assert!(matches!(result, Ok(())), "extract case 67");
        assert_eq!(recovered, expected_recovered, "recovered words case 67");
    }

    {
        let src: [u64; 1] = [5444575000468303452u64];
        let mut packed: [u64; 1] = [u64::MAX; 1];
        let expected_packed: [u64; 1] = [5444575000468303452u64];
        let result = pack_coefficients(&mut packed, &src, 1, 63, 1);
        assert!(matches!(result, Ok(())), "pack case 68");
        assert_eq!(packed, expected_packed, "packed words case 68");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [5444575000468303452u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 63, 1);
        assert!(matches!(result, Ok(())), "extract case 68");
        assert_eq!(recovered, expected_recovered, "recovered words case 68");
    }

    {
        let src: [u64; 1] = [5444575000468303452u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [5444575000468303452u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 63, 2);
        assert!(matches!(result, Ok(())), "pack case 69");
        assert_eq!(packed, expected_packed, "packed words case 69");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [5444575000468303452u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 63, 2);
        assert!(matches!(result, Ok(())), "extract case 69");
        assert_eq!(recovered, expected_recovered, "recovered words case 69");
    }

    {
        let src: [u64; 1] = [5444575000468303452u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [5444575000468303452u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 63, 4);
        assert!(matches!(result, Ok(())), "pack case 70");
        assert_eq!(packed, expected_packed, "packed words case 70");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [5444575000468303452u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 63, 4);
        assert!(matches!(result, Ok(())), "extract case 70");
        assert_eq!(recovered, expected_recovered, "recovered words case 70");
    }

    {
        let src: [u64; 2] = [8117029951116851151u64, 3360886615948146157u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [8117029951116851151u64, 3360886615948146157u64];
        let result = pack_coefficients(&mut packed, &src, 2, 63, 1);
        assert!(matches!(result, Ok(())), "pack case 71");
        assert_eq!(packed, expected_packed, "packed words case 71");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [8117029951116851151u64, 3360886615948146157u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 63, 1);
        assert!(matches!(result, Ok(())), "extract case 71");
        assert_eq!(recovered, expected_recovered, "recovered words case 71");
    }

    {
        let src: [u64; 2] = [8117029951116851151u64, 3360886615948146157u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [8117029951116851151u64, 0u64, 3360886615948146157u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 63, 2);
        assert!(matches!(result, Ok(())), "pack case 72");
        assert_eq!(packed, expected_packed, "packed words case 72");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [8117029951116851151u64, 3360886615948146157u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 63, 2);
        assert!(matches!(result, Ok(())), "extract case 72");
        assert_eq!(recovered, expected_recovered, "recovered words case 72");
    }

    {
        let src: [u64; 2] = [8117029951116851151u64, 3360886615948146157u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [8117029951116851151u64, 0u64, 0u64, 0u64, 3360886615948146157u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 63, 4);
        assert!(matches!(result, Ok(())), "pack case 73");
        assert_eq!(packed, expected_packed, "packed words case 73");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [8117029951116851151u64, 3360886615948146157u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 63, 4);
        assert!(matches!(result, Ok(())), "extract case 73");
        assert_eq!(recovered, expected_recovered, "recovered words case 73");
    }

    {
        let src: [u64; 5] = [6419213360355028480u64, 3660013233329980219u64, 9032993058088032455u64, 4363269197273301331u64, 4682765335396827395u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [6419213360355028480u64, 3660013233329980219u64, 9032993058088032455u64, 4363269197273301331u64, 4682765335396827395u64];
        let result = pack_coefficients(&mut packed, &src, 5, 63, 1);
        assert!(matches!(result, Ok(())), "pack case 74");
        assert_eq!(packed, expected_packed, "packed words case 74");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [6419213360355028480u64, 3660013233329980219u64, 9032993058088032455u64, 4363269197273301331u64, 4682765335396827395u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 63, 1);
        assert!(matches!(result, Ok(())), "extract case 74");
        assert_eq!(recovered, expected_recovered, "recovered words case 74");
    }

    {
        let src: [u64; 5] = [6419213360355028480u64, 3660013233329980219u64, 9032993058088032455u64, 4363269197273301331u64, 4682765335396827395u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [6419213360355028480u64, 0u64, 3660013233329980219u64, 0u64, 9032993058088032455u64, 0u64, 4363269197273301331u64, 0u64, 4682765335396827395u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 63, 2);
        assert!(matches!(result, Ok(())), "pack case 75");
        assert_eq!(packed, expected_packed, "packed words case 75");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [6419213360355028480u64, 3660013233329980219u64, 9032993058088032455u64, 4363269197273301331u64, 4682765335396827395u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 63, 2);
        assert!(matches!(result, Ok(())), "extract case 75");
        assert_eq!(recovered, expected_recovered, "recovered words case 75");
    }

    {
        let src: [u64; 5] = [6419213360355028480u64, 3660013233329980219u64, 9032993058088032455u64, 4363269197273301331u64, 4682765335396827395u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [6419213360355028480u64, 0u64, 0u64, 0u64, 3660013233329980219u64, 0u64, 0u64, 0u64, 9032993058088032455u64, 0u64, 0u64, 0u64, 4363269197273301331u64, 0u64, 0u64, 0u64, 4682765335396827395u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 63, 4);
        assert!(matches!(result, Ok(())), "pack case 76");
        assert_eq!(packed, expected_packed, "packed words case 76");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [6419213360355028480u64, 3660013233329980219u64, 9032993058088032455u64, 4363269197273301331u64, 4682765335396827395u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 63, 4);
        assert!(matches!(result, Ok(())), "extract case 76");
        assert_eq!(recovered, expected_recovered, "recovered words case 76");
    }

    {
        let src: [u64; 3] = [9223372036854775807u64, 0u64, 9223372036854775807u64];
        let mut packed: [u64; 9] = [u64::MAX; 9];
        let expected_packed: [u64; 9] = [9223372036854775807u64, 0u64, 0u64, 0u64, 0u64, 0u64, 9223372036854775807u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 63, 3);
        assert!(matches!(result, Ok(())), "pack case 77");
        assert_eq!(packed, expected_packed, "packed words case 77");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [9223372036854775807u64, 0u64, 9223372036854775807u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 63, 3);
        assert!(matches!(result, Ok(())), "extract case 77");
        assert_eq!(recovered, expected_recovered, "recovered words case 77");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 64, 1);
        assert!(matches!(result, Ok(())), "pack case 78");
        assert_eq!(packed, expected_packed, "packed words case 78");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 64, 1);
        assert!(matches!(result, Ok(())), "extract case 78");
        assert_eq!(recovered, expected_recovered, "recovered words case 78");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 64, 2);
        assert!(matches!(result, Ok(())), "pack case 79");
        assert_eq!(packed, expected_packed, "packed words case 79");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 64, 2);
        assert!(matches!(result, Ok(())), "extract case 79");
        assert_eq!(recovered, expected_recovered, "recovered words case 79");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 64, 4);
        assert!(matches!(result, Ok(())), "pack case 80");
        assert_eq!(packed, expected_packed, "packed words case 80");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 64, 4);
        assert!(matches!(result, Ok(())), "extract case 80");
        assert_eq!(recovered, expected_recovered, "recovered words case 80");
    }

    {
        let src: [u64; 1] = [16973735497189048958u64];
        let mut packed: [u64; 1] = [u64::MAX; 1];
        let expected_packed: [u64; 1] = [16973735497189048958u64];
        let result = pack_coefficients(&mut packed, &src, 1, 64, 1);
        assert!(matches!(result, Ok(())), "pack case 81");
        assert_eq!(packed, expected_packed, "packed words case 81");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [16973735497189048958u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 64, 1);
        assert!(matches!(result, Ok(())), "extract case 81");
        assert_eq!(recovered, expected_recovered, "recovered words case 81");
    }

    {
        let src: [u64; 1] = [16973735497189048958u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [16973735497189048958u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 64, 2);
        assert!(matches!(result, Ok(())), "pack case 82");
        assert_eq!(packed, expected_packed, "packed words case 82");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [16973735497189048958u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 64, 2);
        assert!(matches!(result, Ok(())), "extract case 82");
        assert_eq!(recovered, expected_recovered, "recovered words case 82");
    }

    {
        let src: [u64; 1] = [16973735497189048958u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [16973735497189048958u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 64, 4);
        assert!(matches!(result, Ok(())), "pack case 83");
        assert_eq!(packed, expected_packed, "packed words case 83");
        let mut recovered: [u64; 1] = [u64::MAX; 1];
        let expected_recovered: [u64; 1] = [16973735497189048958u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 64, 4);
        assert!(matches!(result, Ok(())), "extract case 83");
        assert_eq!(recovered, expected_recovered, "recovered words case 83");
    }

    {
        let src: [u64; 2] = [2032852354357496226u64, 15004381156240388124u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [2032852354357496226u64, 15004381156240388124u64];
        let result = pack_coefficients(&mut packed, &src, 2, 64, 1);
        assert!(matches!(result, Ok(())), "pack case 84");
        assert_eq!(packed, expected_packed, "packed words case 84");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [2032852354357496226u64, 15004381156240388124u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 64, 1);
        assert!(matches!(result, Ok(())), "extract case 84");
        assert_eq!(recovered, expected_recovered, "recovered words case 84");
    }

    {
        let src: [u64; 2] = [2032852354357496226u64, 15004381156240388124u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [2032852354357496226u64, 0u64, 15004381156240388124u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 64, 2);
        assert!(matches!(result, Ok(())), "pack case 85");
        assert_eq!(packed, expected_packed, "packed words case 85");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [2032852354357496226u64, 15004381156240388124u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 64, 2);
        assert!(matches!(result, Ok(())), "extract case 85");
        assert_eq!(recovered, expected_recovered, "recovered words case 85");
    }

    {
        let src: [u64; 2] = [2032852354357496226u64, 15004381156240388124u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [2032852354357496226u64, 0u64, 0u64, 0u64, 15004381156240388124u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 64, 4);
        assert!(matches!(result, Ok(())), "pack case 86");
        assert_eq!(packed, expected_packed, "packed words case 86");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [2032852354357496226u64, 15004381156240388124u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 64, 4);
        assert!(matches!(result, Ok(())), "extract case 86");
        assert_eq!(recovered, expected_recovered, "recovered words case 86");
    }

    {
        let src: [u64; 5] = [10736665898680588761u64, 13171660787586674380u64, 16873434430932153415u64, 8999390860046663916u64, 10090053836965767694u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [10736665898680588761u64, 13171660787586674380u64, 16873434430932153415u64, 8999390860046663916u64, 10090053836965767694u64];
        let result = pack_coefficients(&mut packed, &src, 5, 64, 1);
        assert!(matches!(result, Ok(())), "pack case 87");
        assert_eq!(packed, expected_packed, "packed words case 87");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [10736665898680588761u64, 13171660787586674380u64, 16873434430932153415u64, 8999390860046663916u64, 10090053836965767694u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 64, 1);
        assert!(matches!(result, Ok(())), "extract case 87");
        assert_eq!(recovered, expected_recovered, "recovered words case 87");
    }

    {
        let src: [u64; 5] = [10736665898680588761u64, 13171660787586674380u64, 16873434430932153415u64, 8999390860046663916u64, 10090053836965767694u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [10736665898680588761u64, 0u64, 13171660787586674380u64, 0u64, 16873434430932153415u64, 0u64, 8999390860046663916u64, 0u64, 10090053836965767694u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 64, 2);
        assert!(matches!(result, Ok(())), "pack case 88");
        assert_eq!(packed, expected_packed, "packed words case 88");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [10736665898680588761u64, 13171660787586674380u64, 16873434430932153415u64, 8999390860046663916u64, 10090053836965767694u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 64, 2);
        assert!(matches!(result, Ok(())), "extract case 88");
        assert_eq!(recovered, expected_recovered, "recovered words case 88");
    }

    {
        let src: [u64; 5] = [10736665898680588761u64, 13171660787586674380u64, 16873434430932153415u64, 8999390860046663916u64, 10090053836965767694u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [10736665898680588761u64, 0u64, 0u64, 0u64, 13171660787586674380u64, 0u64, 0u64, 0u64, 16873434430932153415u64, 0u64, 0u64, 0u64, 8999390860046663916u64, 0u64, 0u64, 0u64, 10090053836965767694u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 64, 4);
        assert!(matches!(result, Ok(())), "pack case 89");
        assert_eq!(packed, expected_packed, "packed words case 89");
        let mut recovered: [u64; 5] = [u64::MAX; 5];
        let expected_recovered: [u64; 5] = [10736665898680588761u64, 13171660787586674380u64, 16873434430932153415u64, 8999390860046663916u64, 10090053836965767694u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 64, 4);
        assert!(matches!(result, Ok(())), "extract case 89");
        assert_eq!(recovered, expected_recovered, "recovered words case 89");
    }

    {
        let src: [u64; 3] = [18446744073709551615u64, 0u64, 18446744073709551615u64];
        let mut packed: [u64; 9] = [u64::MAX; 9];
        let expected_packed: [u64; 9] = [18446744073709551615u64, 0u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 64, 3);
        assert!(matches!(result, Ok(())), "pack case 90");
        assert_eq!(packed, expected_packed, "packed words case 90");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [18446744073709551615u64, 0u64, 18446744073709551615u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 64, 3);
        assert!(matches!(result, Ok(())), "extract case 90");
        assert_eq!(recovered, expected_recovered, "recovered words case 90");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 65, 2);
        assert!(matches!(result, Ok(())), "pack case 91");
        assert_eq!(packed, expected_packed, "packed words case 91");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 65, 2);
        assert!(matches!(result, Ok(())), "extract case 91");
        assert_eq!(recovered, expected_recovered, "recovered words case 91");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 65, 3);
        assert!(matches!(result, Ok(())), "pack case 92");
        assert_eq!(packed, expected_packed, "packed words case 92");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 65, 3);
        assert!(matches!(result, Ok(())), "extract case 92");
        assert_eq!(recovered, expected_recovered, "recovered words case 92");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 65, 5);
        assert!(matches!(result, Ok(())), "pack case 93");
        assert_eq!(packed, expected_packed, "packed words case 93");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 65, 5);
        assert!(matches!(result, Ok(())), "extract case 93");
        assert_eq!(recovered, expected_recovered, "recovered words case 93");
    }

    {
        let src: [u64; 2] = [11959621192002983373u64, 1u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [11959621192002983373u64, 1u64];
        let result = pack_coefficients(&mut packed, &src, 1, 65, 2);
        assert!(matches!(result, Ok(())), "pack case 94");
        assert_eq!(packed, expected_packed, "packed words case 94");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [11959621192002983373u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 65, 2);
        assert!(matches!(result, Ok(())), "extract case 94");
        assert_eq!(recovered, expected_recovered, "recovered words case 94");
    }

    {
        let src: [u64; 2] = [11959621192002983373u64, 1u64];
        let mut packed: [u64; 3] = [u64::MAX; 3];
        let expected_packed: [u64; 3] = [11959621192002983373u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 65, 3);
        assert!(matches!(result, Ok(())), "pack case 95");
        assert_eq!(packed, expected_packed, "packed words case 95");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [11959621192002983373u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 65, 3);
        assert!(matches!(result, Ok(())), "extract case 95");
        assert_eq!(recovered, expected_recovered, "recovered words case 95");
    }

    {
        let src: [u64; 2] = [11959621192002983373u64, 1u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [11959621192002983373u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 65, 5);
        assert!(matches!(result, Ok(())), "pack case 96");
        assert_eq!(packed, expected_packed, "packed words case 96");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [11959621192002983373u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 65, 5);
        assert!(matches!(result, Ok(())), "extract case 96");
        assert_eq!(recovered, expected_recovered, "recovered words case 96");
    }

    {
        let src: [u64; 4] = [10918362538792567885u64, 0u64, 18202997064951067572u64, 1u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [10918362538792567885u64, 0u64, 18202997064951067572u64, 1u64];
        let result = pack_coefficients(&mut packed, &src, 2, 65, 2);
        assert!(matches!(result, Ok(())), "pack case 97");
        assert_eq!(packed, expected_packed, "packed words case 97");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [10918362538792567885u64, 0u64, 18202997064951067572u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 65, 2);
        assert!(matches!(result, Ok(())), "extract case 97");
        assert_eq!(recovered, expected_recovered, "recovered words case 97");
    }

    {
        let src: [u64; 4] = [10918362538792567885u64, 0u64, 18202997064951067572u64, 1u64];
        let mut packed: [u64; 6] = [u64::MAX; 6];
        let expected_packed: [u64; 6] = [10918362538792567885u64, 0u64, 0u64, 18202997064951067572u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 65, 3);
        assert!(matches!(result, Ok(())), "pack case 98");
        assert_eq!(packed, expected_packed, "packed words case 98");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [10918362538792567885u64, 0u64, 18202997064951067572u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 65, 3);
        assert!(matches!(result, Ok(())), "extract case 98");
        assert_eq!(recovered, expected_recovered, "recovered words case 98");
    }

    {
        let src: [u64; 4] = [10918362538792567885u64, 0u64, 18202997064951067572u64, 1u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [10918362538792567885u64, 0u64, 0u64, 0u64, 0u64, 18202997064951067572u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 65, 5);
        assert!(matches!(result, Ok(())), "pack case 99");
        assert_eq!(packed, expected_packed, "packed words case 99");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [10918362538792567885u64, 0u64, 18202997064951067572u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 65, 5);
        assert!(matches!(result, Ok(())), "extract case 99");
        assert_eq!(recovered, expected_recovered, "recovered words case 99");
    }

    {
        let src: [u64; 10] = [1800969835099141793u64, 0u64, 11995182937916331383u64, 1u64, 8278464841948762036u64, 0u64, 5886061693830610419u64, 1u64, 11604931063550416024u64, 1u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [1800969835099141793u64, 0u64, 11995182937916331383u64, 1u64, 8278464841948762036u64, 0u64, 5886061693830610419u64, 1u64, 11604931063550416024u64, 1u64];
        let result = pack_coefficients(&mut packed, &src, 5, 65, 2);
        assert!(matches!(result, Ok(())), "pack case 100");
        assert_eq!(packed, expected_packed, "packed words case 100");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [1800969835099141793u64, 0u64, 11995182937916331383u64, 1u64, 8278464841948762036u64, 0u64, 5886061693830610419u64, 1u64, 11604931063550416024u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 65, 2);
        assert!(matches!(result, Ok(())), "extract case 100");
        assert_eq!(recovered, expected_recovered, "recovered words case 100");
    }

    {
        let src: [u64; 10] = [1800969835099141793u64, 0u64, 11995182937916331383u64, 1u64, 8278464841948762036u64, 0u64, 5886061693830610419u64, 1u64, 11604931063550416024u64, 1u64];
        let mut packed: [u64; 15] = [u64::MAX; 15];
        let expected_packed: [u64; 15] = [1800969835099141793u64, 0u64, 0u64, 11995182937916331383u64, 1u64, 0u64, 8278464841948762036u64, 0u64, 0u64, 5886061693830610419u64, 1u64, 0u64, 11604931063550416024u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 65, 3);
        assert!(matches!(result, Ok(())), "pack case 101");
        assert_eq!(packed, expected_packed, "packed words case 101");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [1800969835099141793u64, 0u64, 11995182937916331383u64, 1u64, 8278464841948762036u64, 0u64, 5886061693830610419u64, 1u64, 11604931063550416024u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 65, 3);
        assert!(matches!(result, Ok(())), "extract case 101");
        assert_eq!(recovered, expected_recovered, "recovered words case 101");
    }

    {
        let src: [u64; 10] = [1800969835099141793u64, 0u64, 11995182937916331383u64, 1u64, 8278464841948762036u64, 0u64, 5886061693830610419u64, 1u64, 11604931063550416024u64, 1u64];
        let mut packed: [u64; 25] = [u64::MAX; 25];
        let expected_packed: [u64; 25] = [1800969835099141793u64, 0u64, 0u64, 0u64, 0u64, 11995182937916331383u64, 1u64, 0u64, 0u64, 0u64, 8278464841948762036u64, 0u64, 0u64, 0u64, 0u64, 5886061693830610419u64, 1u64, 0u64, 0u64, 0u64, 11604931063550416024u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 65, 5);
        assert!(matches!(result, Ok(())), "pack case 102");
        assert_eq!(packed, expected_packed, "packed words case 102");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [1800969835099141793u64, 0u64, 11995182937916331383u64, 1u64, 8278464841948762036u64, 0u64, 5886061693830610419u64, 1u64, 11604931063550416024u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 65, 5);
        assert!(matches!(result, Ok(())), "extract case 102");
        assert_eq!(recovered, expected_recovered, "recovered words case 102");
    }

    {
        let src: [u64; 6] = [18446744073709551615u64, 1u64, 0u64, 0u64, 18446744073709551615u64, 0u64];
        let mut packed: [u64; 12] = [u64::MAX; 12];
        let expected_packed: [u64; 12] = [18446744073709551615u64, 1u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 65, 4);
        assert!(matches!(result, Ok(())), "pack case 103");
        assert_eq!(packed, expected_packed, "packed words case 103");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [18446744073709551615u64, 1u64, 0u64, 0u64, 18446744073709551615u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 65, 4);
        assert!(matches!(result, Ok(())), "extract case 103");
        assert_eq!(recovered, expected_recovered, "recovered words case 103");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 66, 2);
        assert!(matches!(result, Ok(())), "pack case 104");
        assert_eq!(packed, expected_packed, "packed words case 104");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 66, 2);
        assert!(matches!(result, Ok(())), "extract case 104");
        assert_eq!(recovered, expected_recovered, "recovered words case 104");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 66, 3);
        assert!(matches!(result, Ok(())), "pack case 105");
        assert_eq!(packed, expected_packed, "packed words case 105");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 66, 3);
        assert!(matches!(result, Ok(())), "extract case 105");
        assert_eq!(recovered, expected_recovered, "recovered words case 105");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 66, 5);
        assert!(matches!(result, Ok(())), "pack case 106");
        assert_eq!(packed, expected_packed, "packed words case 106");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 66, 5);
        assert!(matches!(result, Ok(())), "extract case 106");
        assert_eq!(recovered, expected_recovered, "recovered words case 106");
    }

    {
        let src: [u64; 2] = [11374083385322803852u64, 3u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [11374083385322803852u64, 3u64];
        let result = pack_coefficients(&mut packed, &src, 1, 66, 2);
        assert!(matches!(result, Ok(())), "pack case 107");
        assert_eq!(packed, expected_packed, "packed words case 107");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [11374083385322803852u64, 3u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 66, 2);
        assert!(matches!(result, Ok(())), "extract case 107");
        assert_eq!(recovered, expected_recovered, "recovered words case 107");
    }

    {
        let src: [u64; 2] = [11374083385322803852u64, 3u64];
        let mut packed: [u64; 3] = [u64::MAX; 3];
        let expected_packed: [u64; 3] = [11374083385322803852u64, 3u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 66, 3);
        assert!(matches!(result, Ok(())), "pack case 108");
        assert_eq!(packed, expected_packed, "packed words case 108");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [11374083385322803852u64, 3u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 66, 3);
        assert!(matches!(result, Ok(())), "extract case 108");
        assert_eq!(recovered, expected_recovered, "recovered words case 108");
    }

    {
        let src: [u64; 2] = [11374083385322803852u64, 3u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [11374083385322803852u64, 3u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 66, 5);
        assert!(matches!(result, Ok(())), "pack case 109");
        assert_eq!(packed, expected_packed, "packed words case 109");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [11374083385322803852u64, 3u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 66, 5);
        assert!(matches!(result, Ok(())), "extract case 109");
        assert_eq!(recovered, expected_recovered, "recovered words case 109");
    }

    {
        let src: [u64; 4] = [6405145663166442517u64, 2u64, 16844029686601446877u64, 1u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [6405145663166442517u64, 2u64, 16844029686601446877u64, 1u64];
        let result = pack_coefficients(&mut packed, &src, 2, 66, 2);
        assert!(matches!(result, Ok(())), "pack case 110");
        assert_eq!(packed, expected_packed, "packed words case 110");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [6405145663166442517u64, 2u64, 16844029686601446877u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 66, 2);
        assert!(matches!(result, Ok(())), "extract case 110");
        assert_eq!(recovered, expected_recovered, "recovered words case 110");
    }

    {
        let src: [u64; 4] = [6405145663166442517u64, 2u64, 16844029686601446877u64, 1u64];
        let mut packed: [u64; 6] = [u64::MAX; 6];
        let expected_packed: [u64; 6] = [6405145663166442517u64, 2u64, 0u64, 16844029686601446877u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 66, 3);
        assert!(matches!(result, Ok(())), "pack case 111");
        assert_eq!(packed, expected_packed, "packed words case 111");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [6405145663166442517u64, 2u64, 16844029686601446877u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 66, 3);
        assert!(matches!(result, Ok(())), "extract case 111");
        assert_eq!(recovered, expected_recovered, "recovered words case 111");
    }

    {
        let src: [u64; 4] = [6405145663166442517u64, 2u64, 16844029686601446877u64, 1u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [6405145663166442517u64, 2u64, 0u64, 0u64, 0u64, 16844029686601446877u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 66, 5);
        assert!(matches!(result, Ok(())), "pack case 112");
        assert_eq!(packed, expected_packed, "packed words case 112");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [6405145663166442517u64, 2u64, 16844029686601446877u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 66, 5);
        assert!(matches!(result, Ok(())), "extract case 112");
        assert_eq!(recovered, expected_recovered, "recovered words case 112");
    }

    {
        let src: [u64; 10] = [5739499680523754001u64, 1u64, 8945190903593117679u64, 1u64, 9291021533241883904u64, 1u64, 13957563810732269288u64, 2u64, 3674135049195693810u64, 1u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [5739499680523754001u64, 1u64, 8945190903593117679u64, 1u64, 9291021533241883904u64, 1u64, 13957563810732269288u64, 2u64, 3674135049195693810u64, 1u64];
        let result = pack_coefficients(&mut packed, &src, 5, 66, 2);
        assert!(matches!(result, Ok(())), "pack case 113");
        assert_eq!(packed, expected_packed, "packed words case 113");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [5739499680523754001u64, 1u64, 8945190903593117679u64, 1u64, 9291021533241883904u64, 1u64, 13957563810732269288u64, 2u64, 3674135049195693810u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 66, 2);
        assert!(matches!(result, Ok(())), "extract case 113");
        assert_eq!(recovered, expected_recovered, "recovered words case 113");
    }

    {
        let src: [u64; 10] = [5739499680523754001u64, 1u64, 8945190903593117679u64, 1u64, 9291021533241883904u64, 1u64, 13957563810732269288u64, 2u64, 3674135049195693810u64, 1u64];
        let mut packed: [u64; 15] = [u64::MAX; 15];
        let expected_packed: [u64; 15] = [5739499680523754001u64, 1u64, 0u64, 8945190903593117679u64, 1u64, 0u64, 9291021533241883904u64, 1u64, 0u64, 13957563810732269288u64, 2u64, 0u64, 3674135049195693810u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 66, 3);
        assert!(matches!(result, Ok(())), "pack case 114");
        assert_eq!(packed, expected_packed, "packed words case 114");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [5739499680523754001u64, 1u64, 8945190903593117679u64, 1u64, 9291021533241883904u64, 1u64, 13957563810732269288u64, 2u64, 3674135049195693810u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 66, 3);
        assert!(matches!(result, Ok(())), "extract case 114");
        assert_eq!(recovered, expected_recovered, "recovered words case 114");
    }

    {
        let src: [u64; 10] = [5739499680523754001u64, 1u64, 8945190903593117679u64, 1u64, 9291021533241883904u64, 1u64, 13957563810732269288u64, 2u64, 3674135049195693810u64, 1u64];
        let mut packed: [u64; 25] = [u64::MAX; 25];
        let expected_packed: [u64; 25] = [5739499680523754001u64, 1u64, 0u64, 0u64, 0u64, 8945190903593117679u64, 1u64, 0u64, 0u64, 0u64, 9291021533241883904u64, 1u64, 0u64, 0u64, 0u64, 13957563810732269288u64, 2u64, 0u64, 0u64, 0u64, 3674135049195693810u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 66, 5);
        assert!(matches!(result, Ok(())), "pack case 115");
        assert_eq!(packed, expected_packed, "packed words case 115");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [5739499680523754001u64, 1u64, 8945190903593117679u64, 1u64, 9291021533241883904u64, 1u64, 13957563810732269288u64, 2u64, 3674135049195693810u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 66, 5);
        assert!(matches!(result, Ok(())), "extract case 115");
        assert_eq!(recovered, expected_recovered, "recovered words case 115");
    }

    {
        let src: [u64; 6] = [18446744073709551615u64, 3u64, 0u64, 0u64, 18446744073709551615u64, 0u64];
        let mut packed: [u64; 12] = [u64::MAX; 12];
        let expected_packed: [u64; 12] = [18446744073709551615u64, 3u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 66, 4);
        assert!(matches!(result, Ok(())), "pack case 116");
        assert_eq!(packed, expected_packed, "packed words case 116");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [18446744073709551615u64, 3u64, 0u64, 0u64, 18446744073709551615u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 66, 4);
        assert!(matches!(result, Ok(())), "extract case 116");
        assert_eq!(recovered, expected_recovered, "recovered words case 116");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 127, 2);
        assert!(matches!(result, Ok(())), "pack case 117");
        assert_eq!(packed, expected_packed, "packed words case 117");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 127, 2);
        assert!(matches!(result, Ok(())), "extract case 117");
        assert_eq!(recovered, expected_recovered, "recovered words case 117");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 127, 3);
        assert!(matches!(result, Ok(())), "pack case 118");
        assert_eq!(packed, expected_packed, "packed words case 118");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 127, 3);
        assert!(matches!(result, Ok(())), "extract case 118");
        assert_eq!(recovered, expected_recovered, "recovered words case 118");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 127, 5);
        assert!(matches!(result, Ok(())), "pack case 119");
        assert_eq!(packed, expected_packed, "packed words case 119");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 127, 5);
        assert!(matches!(result, Ok(())), "extract case 119");
        assert_eq!(recovered, expected_recovered, "recovered words case 119");
    }

    {
        let src: [u64; 2] = [3659217099208818713u64, 5347664239154630474u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [3659217099208818713u64, 5347664239154630474u64];
        let result = pack_coefficients(&mut packed, &src, 1, 127, 2);
        assert!(matches!(result, Ok(())), "pack case 120");
        assert_eq!(packed, expected_packed, "packed words case 120");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [3659217099208818713u64, 5347664239154630474u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 127, 2);
        assert!(matches!(result, Ok(())), "extract case 120");
        assert_eq!(recovered, expected_recovered, "recovered words case 120");
    }

    {
        let src: [u64; 2] = [3659217099208818713u64, 5347664239154630474u64];
        let mut packed: [u64; 3] = [u64::MAX; 3];
        let expected_packed: [u64; 3] = [3659217099208818713u64, 5347664239154630474u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 127, 3);
        assert!(matches!(result, Ok(())), "pack case 121");
        assert_eq!(packed, expected_packed, "packed words case 121");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [3659217099208818713u64, 5347664239154630474u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 127, 3);
        assert!(matches!(result, Ok(())), "extract case 121");
        assert_eq!(recovered, expected_recovered, "recovered words case 121");
    }

    {
        let src: [u64; 2] = [3659217099208818713u64, 5347664239154630474u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [3659217099208818713u64, 5347664239154630474u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 127, 5);
        assert!(matches!(result, Ok(())), "pack case 122");
        assert_eq!(packed, expected_packed, "packed words case 122");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [3659217099208818713u64, 5347664239154630474u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 127, 5);
        assert!(matches!(result, Ok(())), "extract case 122");
        assert_eq!(recovered, expected_recovered, "recovered words case 122");
    }

    {
        let src: [u64; 4] = [3025623187831287428u64, 7029850718435574634u64, 6343830320696037718u64, 4637050838664385606u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [3025623187831287428u64, 7029850718435574634u64, 6343830320696037718u64, 4637050838664385606u64];
        let result = pack_coefficients(&mut packed, &src, 2, 127, 2);
        assert!(matches!(result, Ok(())), "pack case 123");
        assert_eq!(packed, expected_packed, "packed words case 123");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [3025623187831287428u64, 7029850718435574634u64, 6343830320696037718u64, 4637050838664385606u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 127, 2);
        assert!(matches!(result, Ok(())), "extract case 123");
        assert_eq!(recovered, expected_recovered, "recovered words case 123");
    }

    {
        let src: [u64; 4] = [3025623187831287428u64, 7029850718435574634u64, 6343830320696037718u64, 4637050838664385606u64];
        let mut packed: [u64; 6] = [u64::MAX; 6];
        let expected_packed: [u64; 6] = [3025623187831287428u64, 7029850718435574634u64, 0u64, 6343830320696037718u64, 4637050838664385606u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 127, 3);
        assert!(matches!(result, Ok(())), "pack case 124");
        assert_eq!(packed, expected_packed, "packed words case 124");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [3025623187831287428u64, 7029850718435574634u64, 6343830320696037718u64, 4637050838664385606u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 127, 3);
        assert!(matches!(result, Ok(())), "extract case 124");
        assert_eq!(recovered, expected_recovered, "recovered words case 124");
    }

    {
        let src: [u64; 4] = [3025623187831287428u64, 7029850718435574634u64, 6343830320696037718u64, 4637050838664385606u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [3025623187831287428u64, 7029850718435574634u64, 0u64, 0u64, 0u64, 6343830320696037718u64, 4637050838664385606u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 127, 5);
        assert!(matches!(result, Ok(())), "pack case 125");
        assert_eq!(packed, expected_packed, "packed words case 125");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [3025623187831287428u64, 7029850718435574634u64, 6343830320696037718u64, 4637050838664385606u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 127, 5);
        assert!(matches!(result, Ok(())), "extract case 125");
        assert_eq!(recovered, expected_recovered, "recovered words case 125");
    }

    {
        let src: [u64; 10] = [6674033654684784919u64, 5380918671361496714u64, 8137390114030642051u64, 3225455303164068853u64, 11078081210615491870u64, 6259976158888337849u64, 2239716038336687165u64, 6901198107142069066u64, 7716900403433638986u64, 4529567622974044266u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [6674033654684784919u64, 5380918671361496714u64, 8137390114030642051u64, 3225455303164068853u64, 11078081210615491870u64, 6259976158888337849u64, 2239716038336687165u64, 6901198107142069066u64, 7716900403433638986u64, 4529567622974044266u64];
        let result = pack_coefficients(&mut packed, &src, 5, 127, 2);
        assert!(matches!(result, Ok(())), "pack case 126");
        assert_eq!(packed, expected_packed, "packed words case 126");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [6674033654684784919u64, 5380918671361496714u64, 8137390114030642051u64, 3225455303164068853u64, 11078081210615491870u64, 6259976158888337849u64, 2239716038336687165u64, 6901198107142069066u64, 7716900403433638986u64, 4529567622974044266u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 127, 2);
        assert!(matches!(result, Ok(())), "extract case 126");
        assert_eq!(recovered, expected_recovered, "recovered words case 126");
    }

    {
        let src: [u64; 10] = [6674033654684784919u64, 5380918671361496714u64, 8137390114030642051u64, 3225455303164068853u64, 11078081210615491870u64, 6259976158888337849u64, 2239716038336687165u64, 6901198107142069066u64, 7716900403433638986u64, 4529567622974044266u64];
        let mut packed: [u64; 15] = [u64::MAX; 15];
        let expected_packed: [u64; 15] = [6674033654684784919u64, 5380918671361496714u64, 0u64, 8137390114030642051u64, 3225455303164068853u64, 0u64, 11078081210615491870u64, 6259976158888337849u64, 0u64, 2239716038336687165u64, 6901198107142069066u64, 0u64, 7716900403433638986u64, 4529567622974044266u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 127, 3);
        assert!(matches!(result, Ok(())), "pack case 127");
        assert_eq!(packed, expected_packed, "packed words case 127");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [6674033654684784919u64, 5380918671361496714u64, 8137390114030642051u64, 3225455303164068853u64, 11078081210615491870u64, 6259976158888337849u64, 2239716038336687165u64, 6901198107142069066u64, 7716900403433638986u64, 4529567622974044266u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 127, 3);
        assert!(matches!(result, Ok(())), "extract case 127");
        assert_eq!(recovered, expected_recovered, "recovered words case 127");
    }

    {
        let src: [u64; 10] = [6674033654684784919u64, 5380918671361496714u64, 8137390114030642051u64, 3225455303164068853u64, 11078081210615491870u64, 6259976158888337849u64, 2239716038336687165u64, 6901198107142069066u64, 7716900403433638986u64, 4529567622974044266u64];
        let mut packed: [u64; 25] = [u64::MAX; 25];
        let expected_packed: [u64; 25] = [6674033654684784919u64, 5380918671361496714u64, 0u64, 0u64, 0u64, 8137390114030642051u64, 3225455303164068853u64, 0u64, 0u64, 0u64, 11078081210615491870u64, 6259976158888337849u64, 0u64, 0u64, 0u64, 2239716038336687165u64, 6901198107142069066u64, 0u64, 0u64, 0u64, 7716900403433638986u64, 4529567622974044266u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 127, 5);
        assert!(matches!(result, Ok(())), "pack case 128");
        assert_eq!(packed, expected_packed, "packed words case 128");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [6674033654684784919u64, 5380918671361496714u64, 8137390114030642051u64, 3225455303164068853u64, 11078081210615491870u64, 6259976158888337849u64, 2239716038336687165u64, 6901198107142069066u64, 7716900403433638986u64, 4529567622974044266u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 127, 5);
        assert!(matches!(result, Ok(())), "extract case 128");
        assert_eq!(recovered, expected_recovered, "recovered words case 128");
    }

    {
        let src: [u64; 6] = [18446744073709551615u64, 9223372036854775807u64, 0u64, 0u64, 18446744073709551615u64, 0u64];
        let mut packed: [u64; 12] = [u64::MAX; 12];
        let expected_packed: [u64; 12] = [18446744073709551615u64, 9223372036854775807u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 127, 4);
        assert!(matches!(result, Ok(())), "pack case 129");
        assert_eq!(packed, expected_packed, "packed words case 129");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [18446744073709551615u64, 9223372036854775807u64, 0u64, 0u64, 18446744073709551615u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 127, 4);
        assert!(matches!(result, Ok(())), "extract case 129");
        assert_eq!(recovered, expected_recovered, "recovered words case 129");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 128, 2);
        assert!(matches!(result, Ok(())), "pack case 130");
        assert_eq!(packed, expected_packed, "packed words case 130");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 128, 2);
        assert!(matches!(result, Ok(())), "extract case 130");
        assert_eq!(recovered, expected_recovered, "recovered words case 130");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 128, 3);
        assert!(matches!(result, Ok(())), "pack case 131");
        assert_eq!(packed, expected_packed, "packed words case 131");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 128, 3);
        assert!(matches!(result, Ok(())), "extract case 131");
        assert_eq!(recovered, expected_recovered, "recovered words case 131");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 128, 5);
        assert!(matches!(result, Ok(())), "pack case 132");
        assert_eq!(packed, expected_packed, "packed words case 132");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 128, 5);
        assert!(matches!(result, Ok(())), "extract case 132");
        assert_eq!(recovered, expected_recovered, "recovered words case 132");
    }

    {
        let src: [u64; 2] = [6004680905078282493u64, 12065132567861800899u64];
        let mut packed: [u64; 2] = [u64::MAX; 2];
        let expected_packed: [u64; 2] = [6004680905078282493u64, 12065132567861800899u64];
        let result = pack_coefficients(&mut packed, &src, 1, 128, 2);
        assert!(matches!(result, Ok(())), "pack case 133");
        assert_eq!(packed, expected_packed, "packed words case 133");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [6004680905078282493u64, 12065132567861800899u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 128, 2);
        assert!(matches!(result, Ok(())), "extract case 133");
        assert_eq!(recovered, expected_recovered, "recovered words case 133");
    }

    {
        let src: [u64; 2] = [6004680905078282493u64, 12065132567861800899u64];
        let mut packed: [u64; 3] = [u64::MAX; 3];
        let expected_packed: [u64; 3] = [6004680905078282493u64, 12065132567861800899u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 128, 3);
        assert!(matches!(result, Ok(())), "pack case 134");
        assert_eq!(packed, expected_packed, "packed words case 134");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [6004680905078282493u64, 12065132567861800899u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 128, 3);
        assert!(matches!(result, Ok(())), "extract case 134");
        assert_eq!(recovered, expected_recovered, "recovered words case 134");
    }

    {
        let src: [u64; 2] = [6004680905078282493u64, 12065132567861800899u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [6004680905078282493u64, 12065132567861800899u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 128, 5);
        assert!(matches!(result, Ok(())), "pack case 135");
        assert_eq!(packed, expected_packed, "packed words case 135");
        let mut recovered: [u64; 2] = [u64::MAX; 2];
        let expected_recovered: [u64; 2] = [6004680905078282493u64, 12065132567861800899u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 128, 5);
        assert!(matches!(result, Ok(())), "extract case 135");
        assert_eq!(recovered, expected_recovered, "recovered words case 135");
    }

    {
        let src: [u64; 4] = [16553670024452231138u64, 10669190236551133772u64, 904402068081584683u64, 15671179249953175015u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [16553670024452231138u64, 10669190236551133772u64, 904402068081584683u64, 15671179249953175015u64];
        let result = pack_coefficients(&mut packed, &src, 2, 128, 2);
        assert!(matches!(result, Ok(())), "pack case 136");
        assert_eq!(packed, expected_packed, "packed words case 136");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [16553670024452231138u64, 10669190236551133772u64, 904402068081584683u64, 15671179249953175015u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 128, 2);
        assert!(matches!(result, Ok(())), "extract case 136");
        assert_eq!(recovered, expected_recovered, "recovered words case 136");
    }

    {
        let src: [u64; 4] = [16553670024452231138u64, 10669190236551133772u64, 904402068081584683u64, 15671179249953175015u64];
        let mut packed: [u64; 6] = [u64::MAX; 6];
        let expected_packed: [u64; 6] = [16553670024452231138u64, 10669190236551133772u64, 0u64, 904402068081584683u64, 15671179249953175015u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 128, 3);
        assert!(matches!(result, Ok(())), "pack case 137");
        assert_eq!(packed, expected_packed, "packed words case 137");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [16553670024452231138u64, 10669190236551133772u64, 904402068081584683u64, 15671179249953175015u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 128, 3);
        assert!(matches!(result, Ok(())), "extract case 137");
        assert_eq!(recovered, expected_recovered, "recovered words case 137");
    }

    {
        let src: [u64; 4] = [16553670024452231138u64, 10669190236551133772u64, 904402068081584683u64, 15671179249953175015u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [16553670024452231138u64, 10669190236551133772u64, 0u64, 0u64, 0u64, 904402068081584683u64, 15671179249953175015u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 128, 5);
        assert!(matches!(result, Ok(())), "pack case 138");
        assert_eq!(packed, expected_packed, "packed words case 138");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [16553670024452231138u64, 10669190236551133772u64, 904402068081584683u64, 15671179249953175015u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 128, 5);
        assert!(matches!(result, Ok(())), "extract case 138");
        assert_eq!(recovered, expected_recovered, "recovered words case 138");
    }

    {
        let src: [u64; 10] = [13279301105305576078u64, 1178041497215362720u64, 10002249277286499485u64, 17170910453626314780u64, 13545800743868386827u64, 9174640912226802922u64, 3804836603927635424u64, 9040294204282747465u64, 7726177402517086708u64, 864023350334817859u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [13279301105305576078u64, 1178041497215362720u64, 10002249277286499485u64, 17170910453626314780u64, 13545800743868386827u64, 9174640912226802922u64, 3804836603927635424u64, 9040294204282747465u64, 7726177402517086708u64, 864023350334817859u64];
        let result = pack_coefficients(&mut packed, &src, 5, 128, 2);
        assert!(matches!(result, Ok(())), "pack case 139");
        assert_eq!(packed, expected_packed, "packed words case 139");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [13279301105305576078u64, 1178041497215362720u64, 10002249277286499485u64, 17170910453626314780u64, 13545800743868386827u64, 9174640912226802922u64, 3804836603927635424u64, 9040294204282747465u64, 7726177402517086708u64, 864023350334817859u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 128, 2);
        assert!(matches!(result, Ok(())), "extract case 139");
        assert_eq!(recovered, expected_recovered, "recovered words case 139");
    }

    {
        let src: [u64; 10] = [13279301105305576078u64, 1178041497215362720u64, 10002249277286499485u64, 17170910453626314780u64, 13545800743868386827u64, 9174640912226802922u64, 3804836603927635424u64, 9040294204282747465u64, 7726177402517086708u64, 864023350334817859u64];
        let mut packed: [u64; 15] = [u64::MAX; 15];
        let expected_packed: [u64; 15] = [13279301105305576078u64, 1178041497215362720u64, 0u64, 10002249277286499485u64, 17170910453626314780u64, 0u64, 13545800743868386827u64, 9174640912226802922u64, 0u64, 3804836603927635424u64, 9040294204282747465u64, 0u64, 7726177402517086708u64, 864023350334817859u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 128, 3);
        assert!(matches!(result, Ok(())), "pack case 140");
        assert_eq!(packed, expected_packed, "packed words case 140");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [13279301105305576078u64, 1178041497215362720u64, 10002249277286499485u64, 17170910453626314780u64, 13545800743868386827u64, 9174640912226802922u64, 3804836603927635424u64, 9040294204282747465u64, 7726177402517086708u64, 864023350334817859u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 128, 3);
        assert!(matches!(result, Ok(())), "extract case 140");
        assert_eq!(recovered, expected_recovered, "recovered words case 140");
    }

    {
        let src: [u64; 10] = [13279301105305576078u64, 1178041497215362720u64, 10002249277286499485u64, 17170910453626314780u64, 13545800743868386827u64, 9174640912226802922u64, 3804836603927635424u64, 9040294204282747465u64, 7726177402517086708u64, 864023350334817859u64];
        let mut packed: [u64; 25] = [u64::MAX; 25];
        let expected_packed: [u64; 25] = [13279301105305576078u64, 1178041497215362720u64, 0u64, 0u64, 0u64, 10002249277286499485u64, 17170910453626314780u64, 0u64, 0u64, 0u64, 13545800743868386827u64, 9174640912226802922u64, 0u64, 0u64, 0u64, 3804836603927635424u64, 9040294204282747465u64, 0u64, 0u64, 0u64, 7726177402517086708u64, 864023350334817859u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 128, 5);
        assert!(matches!(result, Ok(())), "pack case 141");
        assert_eq!(packed, expected_packed, "packed words case 141");
        let mut recovered: [u64; 10] = [u64::MAX; 10];
        let expected_recovered: [u64; 10] = [13279301105305576078u64, 1178041497215362720u64, 10002249277286499485u64, 17170910453626314780u64, 13545800743868386827u64, 9174640912226802922u64, 3804836603927635424u64, 9040294204282747465u64, 7726177402517086708u64, 864023350334817859u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 128, 5);
        assert!(matches!(result, Ok(())), "extract case 141");
        assert_eq!(recovered, expected_recovered, "recovered words case 141");
    }

    {
        let src: [u64; 6] = [18446744073709551615u64, 18446744073709551615u64, 0u64, 0u64, 18446744073709551615u64, 0u64];
        let mut packed: [u64; 12] = [u64::MAX; 12];
        let expected_packed: [u64; 12] = [18446744073709551615u64, 18446744073709551615u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 128, 4);
        assert!(matches!(result, Ok(())), "pack case 142");
        assert_eq!(packed, expected_packed, "packed words case 142");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [18446744073709551615u64, 18446744073709551615u64, 0u64, 0u64, 18446744073709551615u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 128, 4);
        assert!(matches!(result, Ok(())), "extract case 142");
        assert_eq!(recovered, expected_recovered, "recovered words case 142");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 129, 3);
        assert!(matches!(result, Ok(())), "pack case 143");
        assert_eq!(packed, expected_packed, "packed words case 143");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 129, 3);
        assert!(matches!(result, Ok(())), "extract case 143");
        assert_eq!(recovered, expected_recovered, "recovered words case 143");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 129, 4);
        assert!(matches!(result, Ok(())), "pack case 144");
        assert_eq!(packed, expected_packed, "packed words case 144");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 129, 4);
        assert!(matches!(result, Ok(())), "extract case 144");
        assert_eq!(recovered, expected_recovered, "recovered words case 144");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 129, 6);
        assert!(matches!(result, Ok(())), "pack case 145");
        assert_eq!(packed, expected_packed, "packed words case 145");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 129, 6);
        assert!(matches!(result, Ok(())), "extract case 145");
        assert_eq!(recovered, expected_recovered, "recovered words case 145");
    }

    {
        let src: [u64; 3] = [1616605818192558694u64, 7377108391050538667u64, 1u64];
        let mut packed: [u64; 3] = [u64::MAX; 3];
        let expected_packed: [u64; 3] = [1616605818192558694u64, 7377108391050538667u64, 1u64];
        let result = pack_coefficients(&mut packed, &src, 1, 129, 3);
        assert!(matches!(result, Ok(())), "pack case 146");
        assert_eq!(packed, expected_packed, "packed words case 146");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [1616605818192558694u64, 7377108391050538667u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 129, 3);
        assert!(matches!(result, Ok(())), "extract case 146");
        assert_eq!(recovered, expected_recovered, "recovered words case 146");
    }

    {
        let src: [u64; 3] = [1616605818192558694u64, 7377108391050538667u64, 1u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [1616605818192558694u64, 7377108391050538667u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 129, 4);
        assert!(matches!(result, Ok(())), "pack case 147");
        assert_eq!(packed, expected_packed, "packed words case 147");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [1616605818192558694u64, 7377108391050538667u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 129, 4);
        assert!(matches!(result, Ok(())), "extract case 147");
        assert_eq!(recovered, expected_recovered, "recovered words case 147");
    }

    {
        let src: [u64; 3] = [1616605818192558694u64, 7377108391050538667u64, 1u64];
        let mut packed: [u64; 6] = [u64::MAX; 6];
        let expected_packed: [u64; 6] = [1616605818192558694u64, 7377108391050538667u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 129, 6);
        assert!(matches!(result, Ok(())), "pack case 148");
        assert_eq!(packed, expected_packed, "packed words case 148");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [1616605818192558694u64, 7377108391050538667u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 129, 6);
        assert!(matches!(result, Ok(())), "extract case 148");
        assert_eq!(recovered, expected_recovered, "recovered words case 148");
    }

    {
        let src: [u64; 6] = [502644433627475331u64, 10761959553942034509u64, 1u64, 1305933907846941128u64, 1077648191295523074u64, 0u64];
        let mut packed: [u64; 6] = [u64::MAX; 6];
        let expected_packed: [u64; 6] = [502644433627475331u64, 10761959553942034509u64, 1u64, 1305933907846941128u64, 1077648191295523074u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 129, 3);
        assert!(matches!(result, Ok(())), "pack case 149");
        assert_eq!(packed, expected_packed, "packed words case 149");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [502644433627475331u64, 10761959553942034509u64, 1u64, 1305933907846941128u64, 1077648191295523074u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 129, 3);
        assert!(matches!(result, Ok(())), "extract case 149");
        assert_eq!(recovered, expected_recovered, "recovered words case 149");
    }

    {
        let src: [u64; 6] = [502644433627475331u64, 10761959553942034509u64, 1u64, 1305933907846941128u64, 1077648191295523074u64, 0u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [502644433627475331u64, 10761959553942034509u64, 1u64, 0u64, 1305933907846941128u64, 1077648191295523074u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 129, 4);
        assert!(matches!(result, Ok(())), "pack case 150");
        assert_eq!(packed, expected_packed, "packed words case 150");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [502644433627475331u64, 10761959553942034509u64, 1u64, 1305933907846941128u64, 1077648191295523074u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 129, 4);
        assert!(matches!(result, Ok(())), "extract case 150");
        assert_eq!(recovered, expected_recovered, "recovered words case 150");
    }

    {
        let src: [u64; 6] = [502644433627475331u64, 10761959553942034509u64, 1u64, 1305933907846941128u64, 1077648191295523074u64, 0u64];
        let mut packed: [u64; 12] = [u64::MAX; 12];
        let expected_packed: [u64; 12] = [502644433627475331u64, 10761959553942034509u64, 1u64, 0u64, 0u64, 0u64, 1305933907846941128u64, 1077648191295523074u64, 0u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 129, 6);
        assert!(matches!(result, Ok(())), "pack case 151");
        assert_eq!(packed, expected_packed, "packed words case 151");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [502644433627475331u64, 10761959553942034509u64, 1u64, 1305933907846941128u64, 1077648191295523074u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 129, 6);
        assert!(matches!(result, Ok(())), "extract case 151");
        assert_eq!(recovered, expected_recovered, "recovered words case 151");
    }

    {
        let src: [u64; 15] = [7839623558691153003u64, 18022911469140042305u64, 0u64, 4150123858630992370u64, 5450513959056885062u64, 0u64, 15101417097146365616u64, 7967561082083178923u64, 0u64, 17935852893444741658u64, 14063618980912473346u64, 1u64, 10004104417246295341u64, 17928534092831600502u64, 1u64];
        let mut packed: [u64; 15] = [u64::MAX; 15];
        let expected_packed: [u64; 15] = [7839623558691153003u64, 18022911469140042305u64, 0u64, 4150123858630992370u64, 5450513959056885062u64, 0u64, 15101417097146365616u64, 7967561082083178923u64, 0u64, 17935852893444741658u64, 14063618980912473346u64, 1u64, 10004104417246295341u64, 17928534092831600502u64, 1u64];
        let result = pack_coefficients(&mut packed, &src, 5, 129, 3);
        assert!(matches!(result, Ok(())), "pack case 152");
        assert_eq!(packed, expected_packed, "packed words case 152");
        let mut recovered: [u64; 15] = [u64::MAX; 15];
        let expected_recovered: [u64; 15] = [7839623558691153003u64, 18022911469140042305u64, 0u64, 4150123858630992370u64, 5450513959056885062u64, 0u64, 15101417097146365616u64, 7967561082083178923u64, 0u64, 17935852893444741658u64, 14063618980912473346u64, 1u64, 10004104417246295341u64, 17928534092831600502u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 129, 3);
        assert!(matches!(result, Ok(())), "extract case 152");
        assert_eq!(recovered, expected_recovered, "recovered words case 152");
    }

    {
        let src: [u64; 15] = [7839623558691153003u64, 18022911469140042305u64, 0u64, 4150123858630992370u64, 5450513959056885062u64, 0u64, 15101417097146365616u64, 7967561082083178923u64, 0u64, 17935852893444741658u64, 14063618980912473346u64, 1u64, 10004104417246295341u64, 17928534092831600502u64, 1u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [7839623558691153003u64, 18022911469140042305u64, 0u64, 0u64, 4150123858630992370u64, 5450513959056885062u64, 0u64, 0u64, 15101417097146365616u64, 7967561082083178923u64, 0u64, 0u64, 17935852893444741658u64, 14063618980912473346u64, 1u64, 0u64, 10004104417246295341u64, 17928534092831600502u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 129, 4);
        assert!(matches!(result, Ok(())), "pack case 153");
        assert_eq!(packed, expected_packed, "packed words case 153");
        let mut recovered: [u64; 15] = [u64::MAX; 15];
        let expected_recovered: [u64; 15] = [7839623558691153003u64, 18022911469140042305u64, 0u64, 4150123858630992370u64, 5450513959056885062u64, 0u64, 15101417097146365616u64, 7967561082083178923u64, 0u64, 17935852893444741658u64, 14063618980912473346u64, 1u64, 10004104417246295341u64, 17928534092831600502u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 129, 4);
        assert!(matches!(result, Ok(())), "extract case 153");
        assert_eq!(recovered, expected_recovered, "recovered words case 153");
    }

    {
        let src: [u64; 15] = [7839623558691153003u64, 18022911469140042305u64, 0u64, 4150123858630992370u64, 5450513959056885062u64, 0u64, 15101417097146365616u64, 7967561082083178923u64, 0u64, 17935852893444741658u64, 14063618980912473346u64, 1u64, 10004104417246295341u64, 17928534092831600502u64, 1u64];
        let mut packed: [u64; 30] = [u64::MAX; 30];
        let expected_packed: [u64; 30] = [7839623558691153003u64, 18022911469140042305u64, 0u64, 0u64, 0u64, 0u64, 4150123858630992370u64, 5450513959056885062u64, 0u64, 0u64, 0u64, 0u64, 15101417097146365616u64, 7967561082083178923u64, 0u64, 0u64, 0u64, 0u64, 17935852893444741658u64, 14063618980912473346u64, 1u64, 0u64, 0u64, 0u64, 10004104417246295341u64, 17928534092831600502u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 129, 6);
        assert!(matches!(result, Ok(())), "pack case 154");
        assert_eq!(packed, expected_packed, "packed words case 154");
        let mut recovered: [u64; 15] = [u64::MAX; 15];
        let expected_recovered: [u64; 15] = [7839623558691153003u64, 18022911469140042305u64, 0u64, 4150123858630992370u64, 5450513959056885062u64, 0u64, 15101417097146365616u64, 7967561082083178923u64, 0u64, 17935852893444741658u64, 14063618980912473346u64, 1u64, 10004104417246295341u64, 17928534092831600502u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 129, 6);
        assert!(matches!(result, Ok(())), "extract case 154");
        assert_eq!(recovered, expected_recovered, "recovered words case 154");
    }

    {
        let src: [u64; 9] = [18446744073709551615u64, 18446744073709551615u64, 1u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64];
        let mut packed: [u64; 15] = [u64::MAX; 15];
        let expected_packed: [u64; 15] = [18446744073709551615u64, 18446744073709551615u64, 1u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 129, 5);
        assert!(matches!(result, Ok(())), "pack case 155");
        assert_eq!(packed, expected_packed, "packed words case 155");
        let mut recovered: [u64; 9] = [u64::MAX; 9];
        let expected_recovered: [u64; 9] = [18446744073709551615u64, 18446744073709551615u64, 1u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 129, 5);
        assert!(matches!(result, Ok(())), "extract case 155");
        assert_eq!(recovered, expected_recovered, "recovered words case 155");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 191, 3);
        assert!(matches!(result, Ok(())), "pack case 156");
        assert_eq!(packed, expected_packed, "packed words case 156");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 191, 3);
        assert!(matches!(result, Ok(())), "extract case 156");
        assert_eq!(recovered, expected_recovered, "recovered words case 156");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 191, 4);
        assert!(matches!(result, Ok(())), "pack case 157");
        assert_eq!(packed, expected_packed, "packed words case 157");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 191, 4);
        assert!(matches!(result, Ok(())), "extract case 157");
        assert_eq!(recovered, expected_recovered, "recovered words case 157");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 191, 6);
        assert!(matches!(result, Ok(())), "pack case 158");
        assert_eq!(packed, expected_packed, "packed words case 158");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 191, 6);
        assert!(matches!(result, Ok(())), "extract case 158");
        assert_eq!(recovered, expected_recovered, "recovered words case 158");
    }

    {
        let src: [u64; 3] = [15873334500841930651u64, 10707546214059577996u64, 8886391428753403415u64];
        let mut packed: [u64; 3] = [u64::MAX; 3];
        let expected_packed: [u64; 3] = [15873334500841930651u64, 10707546214059577996u64, 8886391428753403415u64];
        let result = pack_coefficients(&mut packed, &src, 1, 191, 3);
        assert!(matches!(result, Ok(())), "pack case 159");
        assert_eq!(packed, expected_packed, "packed words case 159");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [15873334500841930651u64, 10707546214059577996u64, 8886391428753403415u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 191, 3);
        assert!(matches!(result, Ok(())), "extract case 159");
        assert_eq!(recovered, expected_recovered, "recovered words case 159");
    }

    {
        let src: [u64; 3] = [15873334500841930651u64, 10707546214059577996u64, 8886391428753403415u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [15873334500841930651u64, 10707546214059577996u64, 8886391428753403415u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 191, 4);
        assert!(matches!(result, Ok(())), "pack case 160");
        assert_eq!(packed, expected_packed, "packed words case 160");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [15873334500841930651u64, 10707546214059577996u64, 8886391428753403415u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 191, 4);
        assert!(matches!(result, Ok(())), "extract case 160");
        assert_eq!(recovered, expected_recovered, "recovered words case 160");
    }

    {
        let src: [u64; 3] = [15873334500841930651u64, 10707546214059577996u64, 8886391428753403415u64];
        let mut packed: [u64; 6] = [u64::MAX; 6];
        let expected_packed: [u64; 6] = [15873334500841930651u64, 10707546214059577996u64, 8886391428753403415u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 191, 6);
        assert!(matches!(result, Ok(())), "pack case 161");
        assert_eq!(packed, expected_packed, "packed words case 161");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [15873334500841930651u64, 10707546214059577996u64, 8886391428753403415u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 191, 6);
        assert!(matches!(result, Ok(())), "extract case 161");
        assert_eq!(recovered, expected_recovered, "recovered words case 161");
    }

    {
        let src: [u64; 6] = [8625759853631672155u64, 11402202365168887921u64, 4984899669091523533u64, 7896932514960013713u64, 4565638851027727216u64, 2740476663328847271u64];
        let mut packed: [u64; 6] = [u64::MAX; 6];
        let expected_packed: [u64; 6] = [8625759853631672155u64, 11402202365168887921u64, 4984899669091523533u64, 7896932514960013713u64, 4565638851027727216u64, 2740476663328847271u64];
        let result = pack_coefficients(&mut packed, &src, 2, 191, 3);
        assert!(matches!(result, Ok(())), "pack case 162");
        assert_eq!(packed, expected_packed, "packed words case 162");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [8625759853631672155u64, 11402202365168887921u64, 4984899669091523533u64, 7896932514960013713u64, 4565638851027727216u64, 2740476663328847271u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 191, 3);
        assert!(matches!(result, Ok(())), "extract case 162");
        assert_eq!(recovered, expected_recovered, "recovered words case 162");
    }

    {
        let src: [u64; 6] = [8625759853631672155u64, 11402202365168887921u64, 4984899669091523533u64, 7896932514960013713u64, 4565638851027727216u64, 2740476663328847271u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [8625759853631672155u64, 11402202365168887921u64, 4984899669091523533u64, 0u64, 7896932514960013713u64, 4565638851027727216u64, 2740476663328847271u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 191, 4);
        assert!(matches!(result, Ok(())), "pack case 163");
        assert_eq!(packed, expected_packed, "packed words case 163");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [8625759853631672155u64, 11402202365168887921u64, 4984899669091523533u64, 7896932514960013713u64, 4565638851027727216u64, 2740476663328847271u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 191, 4);
        assert!(matches!(result, Ok(())), "extract case 163");
        assert_eq!(recovered, expected_recovered, "recovered words case 163");
    }

    {
        let src: [u64; 6] = [8625759853631672155u64, 11402202365168887921u64, 4984899669091523533u64, 7896932514960013713u64, 4565638851027727216u64, 2740476663328847271u64];
        let mut packed: [u64; 12] = [u64::MAX; 12];
        let expected_packed: [u64; 12] = [8625759853631672155u64, 11402202365168887921u64, 4984899669091523533u64, 0u64, 0u64, 0u64, 7896932514960013713u64, 4565638851027727216u64, 2740476663328847271u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 191, 6);
        assert!(matches!(result, Ok(())), "pack case 164");
        assert_eq!(packed, expected_packed, "packed words case 164");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [8625759853631672155u64, 11402202365168887921u64, 4984899669091523533u64, 7896932514960013713u64, 4565638851027727216u64, 2740476663328847271u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 191, 6);
        assert!(matches!(result, Ok(())), "extract case 164");
        assert_eq!(recovered, expected_recovered, "recovered words case 164");
    }

    {
        let src: [u64; 15] = [15156533314333759555u64, 3366383500790898798u64, 84073699564623603u64, 5958327587536175619u64, 18348972217787652437u64, 4965084327248702548u64, 15411506145779618898u64, 13309543026176196160u64, 7532959988328641710u64, 15551577071405596131u64, 1351857550032661021u64, 4450980758809842259u64, 5017035366135180047u64, 9841550392045904913u64, 526558510108254720u64];
        let mut packed: [u64; 15] = [u64::MAX; 15];
        let expected_packed: [u64; 15] = [15156533314333759555u64, 3366383500790898798u64, 84073699564623603u64, 5958327587536175619u64, 18348972217787652437u64, 4965084327248702548u64, 15411506145779618898u64, 13309543026176196160u64, 7532959988328641710u64, 15551577071405596131u64, 1351857550032661021u64, 4450980758809842259u64, 5017035366135180047u64, 9841550392045904913u64, 526558510108254720u64];
        let result = pack_coefficients(&mut packed, &src, 5, 191, 3);
        assert!(matches!(result, Ok(())), "pack case 165");
        assert_eq!(packed, expected_packed, "packed words case 165");
        let mut recovered: [u64; 15] = [u64::MAX; 15];
        let expected_recovered: [u64; 15] = [15156533314333759555u64, 3366383500790898798u64, 84073699564623603u64, 5958327587536175619u64, 18348972217787652437u64, 4965084327248702548u64, 15411506145779618898u64, 13309543026176196160u64, 7532959988328641710u64, 15551577071405596131u64, 1351857550032661021u64, 4450980758809842259u64, 5017035366135180047u64, 9841550392045904913u64, 526558510108254720u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 191, 3);
        assert!(matches!(result, Ok(())), "extract case 165");
        assert_eq!(recovered, expected_recovered, "recovered words case 165");
    }

    {
        let src: [u64; 15] = [15156533314333759555u64, 3366383500790898798u64, 84073699564623603u64, 5958327587536175619u64, 18348972217787652437u64, 4965084327248702548u64, 15411506145779618898u64, 13309543026176196160u64, 7532959988328641710u64, 15551577071405596131u64, 1351857550032661021u64, 4450980758809842259u64, 5017035366135180047u64, 9841550392045904913u64, 526558510108254720u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [15156533314333759555u64, 3366383500790898798u64, 84073699564623603u64, 0u64, 5958327587536175619u64, 18348972217787652437u64, 4965084327248702548u64, 0u64, 15411506145779618898u64, 13309543026176196160u64, 7532959988328641710u64, 0u64, 15551577071405596131u64, 1351857550032661021u64, 4450980758809842259u64, 0u64, 5017035366135180047u64, 9841550392045904913u64, 526558510108254720u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 191, 4);
        assert!(matches!(result, Ok(())), "pack case 166");
        assert_eq!(packed, expected_packed, "packed words case 166");
        let mut recovered: [u64; 15] = [u64::MAX; 15];
        let expected_recovered: [u64; 15] = [15156533314333759555u64, 3366383500790898798u64, 84073699564623603u64, 5958327587536175619u64, 18348972217787652437u64, 4965084327248702548u64, 15411506145779618898u64, 13309543026176196160u64, 7532959988328641710u64, 15551577071405596131u64, 1351857550032661021u64, 4450980758809842259u64, 5017035366135180047u64, 9841550392045904913u64, 526558510108254720u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 191, 4);
        assert!(matches!(result, Ok(())), "extract case 166");
        assert_eq!(recovered, expected_recovered, "recovered words case 166");
    }

    {
        let src: [u64; 15] = [15156533314333759555u64, 3366383500790898798u64, 84073699564623603u64, 5958327587536175619u64, 18348972217787652437u64, 4965084327248702548u64, 15411506145779618898u64, 13309543026176196160u64, 7532959988328641710u64, 15551577071405596131u64, 1351857550032661021u64, 4450980758809842259u64, 5017035366135180047u64, 9841550392045904913u64, 526558510108254720u64];
        let mut packed: [u64; 30] = [u64::MAX; 30];
        let expected_packed: [u64; 30] = [15156533314333759555u64, 3366383500790898798u64, 84073699564623603u64, 0u64, 0u64, 0u64, 5958327587536175619u64, 18348972217787652437u64, 4965084327248702548u64, 0u64, 0u64, 0u64, 15411506145779618898u64, 13309543026176196160u64, 7532959988328641710u64, 0u64, 0u64, 0u64, 15551577071405596131u64, 1351857550032661021u64, 4450980758809842259u64, 0u64, 0u64, 0u64, 5017035366135180047u64, 9841550392045904913u64, 526558510108254720u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 191, 6);
        assert!(matches!(result, Ok(())), "pack case 167");
        assert_eq!(packed, expected_packed, "packed words case 167");
        let mut recovered: [u64; 15] = [u64::MAX; 15];
        let expected_recovered: [u64; 15] = [15156533314333759555u64, 3366383500790898798u64, 84073699564623603u64, 5958327587536175619u64, 18348972217787652437u64, 4965084327248702548u64, 15411506145779618898u64, 13309543026176196160u64, 7532959988328641710u64, 15551577071405596131u64, 1351857550032661021u64, 4450980758809842259u64, 5017035366135180047u64, 9841550392045904913u64, 526558510108254720u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 191, 6);
        assert!(matches!(result, Ok(())), "extract case 167");
        assert_eq!(recovered, expected_recovered, "recovered words case 167");
    }

    {
        let src: [u64; 9] = [18446744073709551615u64, 18446744073709551615u64, 9223372036854775807u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64];
        let mut packed: [u64; 15] = [u64::MAX; 15];
        let expected_packed: [u64; 15] = [18446744073709551615u64, 18446744073709551615u64, 9223372036854775807u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 191, 5);
        assert!(matches!(result, Ok(())), "pack case 168");
        assert_eq!(packed, expected_packed, "packed words case 168");
        let mut recovered: [u64; 9] = [u64::MAX; 9];
        let expected_recovered: [u64; 9] = [18446744073709551615u64, 18446744073709551615u64, 9223372036854775807u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 191, 5);
        assert!(matches!(result, Ok(())), "extract case 168");
        assert_eq!(recovered, expected_recovered, "recovered words case 168");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 192, 3);
        assert!(matches!(result, Ok(())), "pack case 169");
        assert_eq!(packed, expected_packed, "packed words case 169");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 192, 3);
        assert!(matches!(result, Ok(())), "extract case 169");
        assert_eq!(recovered, expected_recovered, "recovered words case 169");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 192, 4);
        assert!(matches!(result, Ok(())), "pack case 170");
        assert_eq!(packed, expected_packed, "packed words case 170");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 192, 4);
        assert!(matches!(result, Ok(())), "extract case 170");
        assert_eq!(recovered, expected_recovered, "recovered words case 170");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 192, 6);
        assert!(matches!(result, Ok(())), "pack case 171");
        assert_eq!(packed, expected_packed, "packed words case 171");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 192, 6);
        assert!(matches!(result, Ok(())), "extract case 171");
        assert_eq!(recovered, expected_recovered, "recovered words case 171");
    }

    {
        let src: [u64; 3] = [3371305549998265452u64, 11426975760872227560u64, 11804234533718871439u64];
        let mut packed: [u64; 3] = [u64::MAX; 3];
        let expected_packed: [u64; 3] = [3371305549998265452u64, 11426975760872227560u64, 11804234533718871439u64];
        let result = pack_coefficients(&mut packed, &src, 1, 192, 3);
        assert!(matches!(result, Ok(())), "pack case 172");
        assert_eq!(packed, expected_packed, "packed words case 172");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [3371305549998265452u64, 11426975760872227560u64, 11804234533718871439u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 192, 3);
        assert!(matches!(result, Ok(())), "extract case 172");
        assert_eq!(recovered, expected_recovered, "recovered words case 172");
    }

    {
        let src: [u64; 3] = [3371305549998265452u64, 11426975760872227560u64, 11804234533718871439u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [3371305549998265452u64, 11426975760872227560u64, 11804234533718871439u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 192, 4);
        assert!(matches!(result, Ok(())), "pack case 173");
        assert_eq!(packed, expected_packed, "packed words case 173");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [3371305549998265452u64, 11426975760872227560u64, 11804234533718871439u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 192, 4);
        assert!(matches!(result, Ok(())), "extract case 173");
        assert_eq!(recovered, expected_recovered, "recovered words case 173");
    }

    {
        let src: [u64; 3] = [3371305549998265452u64, 11426975760872227560u64, 11804234533718871439u64];
        let mut packed: [u64; 6] = [u64::MAX; 6];
        let expected_packed: [u64; 6] = [3371305549998265452u64, 11426975760872227560u64, 11804234533718871439u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 192, 6);
        assert!(matches!(result, Ok(())), "pack case 174");
        assert_eq!(packed, expected_packed, "packed words case 174");
        let mut recovered: [u64; 3] = [u64::MAX; 3];
        let expected_recovered: [u64; 3] = [3371305549998265452u64, 11426975760872227560u64, 11804234533718871439u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 192, 6);
        assert!(matches!(result, Ok(())), "extract case 174");
        assert_eq!(recovered, expected_recovered, "recovered words case 174");
    }

    {
        let src: [u64; 6] = [739303505153086467u64, 7876400575568417714u64, 16568735472140639662u64, 3698585413259401267u64, 14143194068643863121u64, 15254201964690597915u64];
        let mut packed: [u64; 6] = [u64::MAX; 6];
        let expected_packed: [u64; 6] = [739303505153086467u64, 7876400575568417714u64, 16568735472140639662u64, 3698585413259401267u64, 14143194068643863121u64, 15254201964690597915u64];
        let result = pack_coefficients(&mut packed, &src, 2, 192, 3);
        assert!(matches!(result, Ok(())), "pack case 175");
        assert_eq!(packed, expected_packed, "packed words case 175");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [739303505153086467u64, 7876400575568417714u64, 16568735472140639662u64, 3698585413259401267u64, 14143194068643863121u64, 15254201964690597915u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 192, 3);
        assert!(matches!(result, Ok(())), "extract case 175");
        assert_eq!(recovered, expected_recovered, "recovered words case 175");
    }

    {
        let src: [u64; 6] = [739303505153086467u64, 7876400575568417714u64, 16568735472140639662u64, 3698585413259401267u64, 14143194068643863121u64, 15254201964690597915u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [739303505153086467u64, 7876400575568417714u64, 16568735472140639662u64, 0u64, 3698585413259401267u64, 14143194068643863121u64, 15254201964690597915u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 192, 4);
        assert!(matches!(result, Ok(())), "pack case 176");
        assert_eq!(packed, expected_packed, "packed words case 176");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [739303505153086467u64, 7876400575568417714u64, 16568735472140639662u64, 3698585413259401267u64, 14143194068643863121u64, 15254201964690597915u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 192, 4);
        assert!(matches!(result, Ok(())), "extract case 176");
        assert_eq!(recovered, expected_recovered, "recovered words case 176");
    }

    {
        let src: [u64; 6] = [739303505153086467u64, 7876400575568417714u64, 16568735472140639662u64, 3698585413259401267u64, 14143194068643863121u64, 15254201964690597915u64];
        let mut packed: [u64; 12] = [u64::MAX; 12];
        let expected_packed: [u64; 12] = [739303505153086467u64, 7876400575568417714u64, 16568735472140639662u64, 0u64, 0u64, 0u64, 3698585413259401267u64, 14143194068643863121u64, 15254201964690597915u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 192, 6);
        assert!(matches!(result, Ok(())), "pack case 177");
        assert_eq!(packed, expected_packed, "packed words case 177");
        let mut recovered: [u64; 6] = [u64::MAX; 6];
        let expected_recovered: [u64; 6] = [739303505153086467u64, 7876400575568417714u64, 16568735472140639662u64, 3698585413259401267u64, 14143194068643863121u64, 15254201964690597915u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 192, 6);
        assert!(matches!(result, Ok(())), "extract case 177");
        assert_eq!(recovered, expected_recovered, "recovered words case 177");
    }

    {
        let src: [u64; 15] = [7386726363881063524u64, 875190069224217038u64, 18338189357317947260u64, 17770564908591552253u64, 2045128459888584445u64, 2606702637844478490u64, 11000284429185525548u64, 52051642805811470u64, 8665637323518413126u64, 5896852238293737798u64, 13174159071713716349u64, 5606704454446702161u64, 4764303036154217698u64, 11939216839318806787u64, 18291429743378987498u64];
        let mut packed: [u64; 15] = [u64::MAX; 15];
        let expected_packed: [u64; 15] = [7386726363881063524u64, 875190069224217038u64, 18338189357317947260u64, 17770564908591552253u64, 2045128459888584445u64, 2606702637844478490u64, 11000284429185525548u64, 52051642805811470u64, 8665637323518413126u64, 5896852238293737798u64, 13174159071713716349u64, 5606704454446702161u64, 4764303036154217698u64, 11939216839318806787u64, 18291429743378987498u64];
        let result = pack_coefficients(&mut packed, &src, 5, 192, 3);
        assert!(matches!(result, Ok(())), "pack case 178");
        assert_eq!(packed, expected_packed, "packed words case 178");
        let mut recovered: [u64; 15] = [u64::MAX; 15];
        let expected_recovered: [u64; 15] = [7386726363881063524u64, 875190069224217038u64, 18338189357317947260u64, 17770564908591552253u64, 2045128459888584445u64, 2606702637844478490u64, 11000284429185525548u64, 52051642805811470u64, 8665637323518413126u64, 5896852238293737798u64, 13174159071713716349u64, 5606704454446702161u64, 4764303036154217698u64, 11939216839318806787u64, 18291429743378987498u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 192, 3);
        assert!(matches!(result, Ok(())), "extract case 178");
        assert_eq!(recovered, expected_recovered, "recovered words case 178");
    }

    {
        let src: [u64; 15] = [7386726363881063524u64, 875190069224217038u64, 18338189357317947260u64, 17770564908591552253u64, 2045128459888584445u64, 2606702637844478490u64, 11000284429185525548u64, 52051642805811470u64, 8665637323518413126u64, 5896852238293737798u64, 13174159071713716349u64, 5606704454446702161u64, 4764303036154217698u64, 11939216839318806787u64, 18291429743378987498u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [7386726363881063524u64, 875190069224217038u64, 18338189357317947260u64, 0u64, 17770564908591552253u64, 2045128459888584445u64, 2606702637844478490u64, 0u64, 11000284429185525548u64, 52051642805811470u64, 8665637323518413126u64, 0u64, 5896852238293737798u64, 13174159071713716349u64, 5606704454446702161u64, 0u64, 4764303036154217698u64, 11939216839318806787u64, 18291429743378987498u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 192, 4);
        assert!(matches!(result, Ok(())), "pack case 179");
        assert_eq!(packed, expected_packed, "packed words case 179");
        let mut recovered: [u64; 15] = [u64::MAX; 15];
        let expected_recovered: [u64; 15] = [7386726363881063524u64, 875190069224217038u64, 18338189357317947260u64, 17770564908591552253u64, 2045128459888584445u64, 2606702637844478490u64, 11000284429185525548u64, 52051642805811470u64, 8665637323518413126u64, 5896852238293737798u64, 13174159071713716349u64, 5606704454446702161u64, 4764303036154217698u64, 11939216839318806787u64, 18291429743378987498u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 192, 4);
        assert!(matches!(result, Ok(())), "extract case 179");
        assert_eq!(recovered, expected_recovered, "recovered words case 179");
    }

    {
        let src: [u64; 15] = [7386726363881063524u64, 875190069224217038u64, 18338189357317947260u64, 17770564908591552253u64, 2045128459888584445u64, 2606702637844478490u64, 11000284429185525548u64, 52051642805811470u64, 8665637323518413126u64, 5896852238293737798u64, 13174159071713716349u64, 5606704454446702161u64, 4764303036154217698u64, 11939216839318806787u64, 18291429743378987498u64];
        let mut packed: [u64; 30] = [u64::MAX; 30];
        let expected_packed: [u64; 30] = [7386726363881063524u64, 875190069224217038u64, 18338189357317947260u64, 0u64, 0u64, 0u64, 17770564908591552253u64, 2045128459888584445u64, 2606702637844478490u64, 0u64, 0u64, 0u64, 11000284429185525548u64, 52051642805811470u64, 8665637323518413126u64, 0u64, 0u64, 0u64, 5896852238293737798u64, 13174159071713716349u64, 5606704454446702161u64, 0u64, 0u64, 0u64, 4764303036154217698u64, 11939216839318806787u64, 18291429743378987498u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 192, 6);
        assert!(matches!(result, Ok(())), "pack case 180");
        assert_eq!(packed, expected_packed, "packed words case 180");
        let mut recovered: [u64; 15] = [u64::MAX; 15];
        let expected_recovered: [u64; 15] = [7386726363881063524u64, 875190069224217038u64, 18338189357317947260u64, 17770564908591552253u64, 2045128459888584445u64, 2606702637844478490u64, 11000284429185525548u64, 52051642805811470u64, 8665637323518413126u64, 5896852238293737798u64, 13174159071713716349u64, 5606704454446702161u64, 4764303036154217698u64, 11939216839318806787u64, 18291429743378987498u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 192, 6);
        assert!(matches!(result, Ok(())), "extract case 180");
        assert_eq!(recovered, expected_recovered, "recovered words case 180");
    }

    {
        let src: [u64; 9] = [18446744073709551615u64, 18446744073709551615u64, 18446744073709551615u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64];
        let mut packed: [u64; 15] = [u64::MAX; 15];
        let expected_packed: [u64; 15] = [18446744073709551615u64, 18446744073709551615u64, 18446744073709551615u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 192, 5);
        assert!(matches!(result, Ok(())), "pack case 181");
        assert_eq!(packed, expected_packed, "packed words case 181");
        let mut recovered: [u64; 9] = [u64::MAX; 9];
        let expected_recovered: [u64; 9] = [18446744073709551615u64, 18446744073709551615u64, 18446744073709551615u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 192, 5);
        assert!(matches!(result, Ok(())), "extract case 181");
        assert_eq!(recovered, expected_recovered, "recovered words case 181");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 193, 4);
        assert!(matches!(result, Ok(())), "pack case 182");
        assert_eq!(packed, expected_packed, "packed words case 182");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 193, 4);
        assert!(matches!(result, Ok(())), "extract case 182");
        assert_eq!(recovered, expected_recovered, "recovered words case 182");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 193, 5);
        assert!(matches!(result, Ok(())), "pack case 183");
        assert_eq!(packed, expected_packed, "packed words case 183");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 193, 5);
        assert!(matches!(result, Ok(())), "extract case 183");
        assert_eq!(recovered, expected_recovered, "recovered words case 183");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 193, 7);
        assert!(matches!(result, Ok(())), "pack case 184");
        assert_eq!(packed, expected_packed, "packed words case 184");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 193, 7);
        assert!(matches!(result, Ok(())), "extract case 184");
        assert_eq!(recovered, expected_recovered, "recovered words case 184");
    }

    {
        let src: [u64; 4] = [9134304764990901986u64, 9212413688063096805u64, 3413674672484983556u64, 0u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [9134304764990901986u64, 9212413688063096805u64, 3413674672484983556u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 193, 4);
        assert!(matches!(result, Ok(())), "pack case 185");
        assert_eq!(packed, expected_packed, "packed words case 185");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [9134304764990901986u64, 9212413688063096805u64, 3413674672484983556u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 193, 4);
        assert!(matches!(result, Ok(())), "extract case 185");
        assert_eq!(recovered, expected_recovered, "recovered words case 185");
    }

    {
        let src: [u64; 4] = [9134304764990901986u64, 9212413688063096805u64, 3413674672484983556u64, 0u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [9134304764990901986u64, 9212413688063096805u64, 3413674672484983556u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 193, 5);
        assert!(matches!(result, Ok(())), "pack case 186");
        assert_eq!(packed, expected_packed, "packed words case 186");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [9134304764990901986u64, 9212413688063096805u64, 3413674672484983556u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 193, 5);
        assert!(matches!(result, Ok(())), "extract case 186");
        assert_eq!(recovered, expected_recovered, "recovered words case 186");
    }

    {
        let src: [u64; 4] = [9134304764990901986u64, 9212413688063096805u64, 3413674672484983556u64, 0u64];
        let mut packed: [u64; 7] = [u64::MAX; 7];
        let expected_packed: [u64; 7] = [9134304764990901986u64, 9212413688063096805u64, 3413674672484983556u64, 0u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 193, 7);
        assert!(matches!(result, Ok(())), "pack case 187");
        assert_eq!(packed, expected_packed, "packed words case 187");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [9134304764990901986u64, 9212413688063096805u64, 3413674672484983556u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 193, 7);
        assert!(matches!(result, Ok(())), "extract case 187");
        assert_eq!(recovered, expected_recovered, "recovered words case 187");
    }

    {
        let src: [u64; 8] = [16829442283501309693u64, 16855026296253714744u64, 15261829259765766957u64, 1u64, 3047930652341341299u64, 13932071381261787152u64, 6103539699837213442u64, 1u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [16829442283501309693u64, 16855026296253714744u64, 15261829259765766957u64, 1u64, 3047930652341341299u64, 13932071381261787152u64, 6103539699837213442u64, 1u64];
        let result = pack_coefficients(&mut packed, &src, 2, 193, 4);
        assert!(matches!(result, Ok(())), "pack case 188");
        assert_eq!(packed, expected_packed, "packed words case 188");
        let mut recovered: [u64; 8] = [u64::MAX; 8];
        let expected_recovered: [u64; 8] = [16829442283501309693u64, 16855026296253714744u64, 15261829259765766957u64, 1u64, 3047930652341341299u64, 13932071381261787152u64, 6103539699837213442u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 193, 4);
        assert!(matches!(result, Ok(())), "extract case 188");
        assert_eq!(recovered, expected_recovered, "recovered words case 188");
    }

    {
        let src: [u64; 8] = [16829442283501309693u64, 16855026296253714744u64, 15261829259765766957u64, 1u64, 3047930652341341299u64, 13932071381261787152u64, 6103539699837213442u64, 1u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [16829442283501309693u64, 16855026296253714744u64, 15261829259765766957u64, 1u64, 0u64, 3047930652341341299u64, 13932071381261787152u64, 6103539699837213442u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 193, 5);
        assert!(matches!(result, Ok(())), "pack case 189");
        assert_eq!(packed, expected_packed, "packed words case 189");
        let mut recovered: [u64; 8] = [u64::MAX; 8];
        let expected_recovered: [u64; 8] = [16829442283501309693u64, 16855026296253714744u64, 15261829259765766957u64, 1u64, 3047930652341341299u64, 13932071381261787152u64, 6103539699837213442u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 193, 5);
        assert!(matches!(result, Ok(())), "extract case 189");
        assert_eq!(recovered, expected_recovered, "recovered words case 189");
    }

    {
        let src: [u64; 8] = [16829442283501309693u64, 16855026296253714744u64, 15261829259765766957u64, 1u64, 3047930652341341299u64, 13932071381261787152u64, 6103539699837213442u64, 1u64];
        let mut packed: [u64; 14] = [u64::MAX; 14];
        let expected_packed: [u64; 14] = [16829442283501309693u64, 16855026296253714744u64, 15261829259765766957u64, 1u64, 0u64, 0u64, 0u64, 3047930652341341299u64, 13932071381261787152u64, 6103539699837213442u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 193, 7);
        assert!(matches!(result, Ok(())), "pack case 190");
        assert_eq!(packed, expected_packed, "packed words case 190");
        let mut recovered: [u64; 8] = [u64::MAX; 8];
        let expected_recovered: [u64; 8] = [16829442283501309693u64, 16855026296253714744u64, 15261829259765766957u64, 1u64, 3047930652341341299u64, 13932071381261787152u64, 6103539699837213442u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 193, 7);
        assert!(matches!(result, Ok(())), "extract case 190");
        assert_eq!(recovered, expected_recovered, "recovered words case 190");
    }

    {
        let src: [u64; 20] = [4227402156925429653u64, 14176091693472602516u64, 18260917031138589160u64, 0u64, 13938678184492958009u64, 4312514226372703227u64, 735126019421077871u64, 1u64, 3952330370591787393u64, 18245539437087917937u64, 13021917072322501288u64, 1u64, 11072435016164163983u64, 6958683311718530234u64, 6193266517816452703u64, 0u64, 13740862513420446709u64, 11439444766449801427u64, 7778941650853429486u64, 1u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [4227402156925429653u64, 14176091693472602516u64, 18260917031138589160u64, 0u64, 13938678184492958009u64, 4312514226372703227u64, 735126019421077871u64, 1u64, 3952330370591787393u64, 18245539437087917937u64, 13021917072322501288u64, 1u64, 11072435016164163983u64, 6958683311718530234u64, 6193266517816452703u64, 0u64, 13740862513420446709u64, 11439444766449801427u64, 7778941650853429486u64, 1u64];
        let result = pack_coefficients(&mut packed, &src, 5, 193, 4);
        assert!(matches!(result, Ok(())), "pack case 191");
        assert_eq!(packed, expected_packed, "packed words case 191");
        let mut recovered: [u64; 20] = [u64::MAX; 20];
        let expected_recovered: [u64; 20] = [4227402156925429653u64, 14176091693472602516u64, 18260917031138589160u64, 0u64, 13938678184492958009u64, 4312514226372703227u64, 735126019421077871u64, 1u64, 3952330370591787393u64, 18245539437087917937u64, 13021917072322501288u64, 1u64, 11072435016164163983u64, 6958683311718530234u64, 6193266517816452703u64, 0u64, 13740862513420446709u64, 11439444766449801427u64, 7778941650853429486u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 193, 4);
        assert!(matches!(result, Ok(())), "extract case 191");
        assert_eq!(recovered, expected_recovered, "recovered words case 191");
    }

    {
        let src: [u64; 20] = [4227402156925429653u64, 14176091693472602516u64, 18260917031138589160u64, 0u64, 13938678184492958009u64, 4312514226372703227u64, 735126019421077871u64, 1u64, 3952330370591787393u64, 18245539437087917937u64, 13021917072322501288u64, 1u64, 11072435016164163983u64, 6958683311718530234u64, 6193266517816452703u64, 0u64, 13740862513420446709u64, 11439444766449801427u64, 7778941650853429486u64, 1u64];
        let mut packed: [u64; 25] = [u64::MAX; 25];
        let expected_packed: [u64; 25] = [4227402156925429653u64, 14176091693472602516u64, 18260917031138589160u64, 0u64, 0u64, 13938678184492958009u64, 4312514226372703227u64, 735126019421077871u64, 1u64, 0u64, 3952330370591787393u64, 18245539437087917937u64, 13021917072322501288u64, 1u64, 0u64, 11072435016164163983u64, 6958683311718530234u64, 6193266517816452703u64, 0u64, 0u64, 13740862513420446709u64, 11439444766449801427u64, 7778941650853429486u64, 1u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 193, 5);
        assert!(matches!(result, Ok(())), "pack case 192");
        assert_eq!(packed, expected_packed, "packed words case 192");
        let mut recovered: [u64; 20] = [u64::MAX; 20];
        let expected_recovered: [u64; 20] = [4227402156925429653u64, 14176091693472602516u64, 18260917031138589160u64, 0u64, 13938678184492958009u64, 4312514226372703227u64, 735126019421077871u64, 1u64, 3952330370591787393u64, 18245539437087917937u64, 13021917072322501288u64, 1u64, 11072435016164163983u64, 6958683311718530234u64, 6193266517816452703u64, 0u64, 13740862513420446709u64, 11439444766449801427u64, 7778941650853429486u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 193, 5);
        assert!(matches!(result, Ok(())), "extract case 192");
        assert_eq!(recovered, expected_recovered, "recovered words case 192");
    }

    {
        let src: [u64; 20] = [4227402156925429653u64, 14176091693472602516u64, 18260917031138589160u64, 0u64, 13938678184492958009u64, 4312514226372703227u64, 735126019421077871u64, 1u64, 3952330370591787393u64, 18245539437087917937u64, 13021917072322501288u64, 1u64, 11072435016164163983u64, 6958683311718530234u64, 6193266517816452703u64, 0u64, 13740862513420446709u64, 11439444766449801427u64, 7778941650853429486u64, 1u64];
        let mut packed: [u64; 35] = [u64::MAX; 35];
        let expected_packed: [u64; 35] = [4227402156925429653u64, 14176091693472602516u64, 18260917031138589160u64, 0u64, 0u64, 0u64, 0u64, 13938678184492958009u64, 4312514226372703227u64, 735126019421077871u64, 1u64, 0u64, 0u64, 0u64, 3952330370591787393u64, 18245539437087917937u64, 13021917072322501288u64, 1u64, 0u64, 0u64, 0u64, 11072435016164163983u64, 6958683311718530234u64, 6193266517816452703u64, 0u64, 0u64, 0u64, 0u64, 13740862513420446709u64, 11439444766449801427u64, 7778941650853429486u64, 1u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 193, 7);
        assert!(matches!(result, Ok(())), "pack case 193");
        assert_eq!(packed, expected_packed, "packed words case 193");
        let mut recovered: [u64; 20] = [u64::MAX; 20];
        let expected_recovered: [u64; 20] = [4227402156925429653u64, 14176091693472602516u64, 18260917031138589160u64, 0u64, 13938678184492958009u64, 4312514226372703227u64, 735126019421077871u64, 1u64, 3952330370591787393u64, 18245539437087917937u64, 13021917072322501288u64, 1u64, 11072435016164163983u64, 6958683311718530234u64, 6193266517816452703u64, 0u64, 13740862513420446709u64, 11439444766449801427u64, 7778941650853429486u64, 1u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 193, 7);
        assert!(matches!(result, Ok(())), "extract case 193");
        assert_eq!(recovered, expected_recovered, "recovered words case 193");
    }

    {
        let src: [u64; 12] = [18446744073709551615u64, 18446744073709551615u64, 18446744073709551615u64, 1u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64];
        let mut packed: [u64; 18] = [u64::MAX; 18];
        let expected_packed: [u64; 18] = [18446744073709551615u64, 18446744073709551615u64, 18446744073709551615u64, 1u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 193, 6);
        assert!(matches!(result, Ok(())), "pack case 194");
        assert_eq!(packed, expected_packed, "packed words case 194");
        let mut recovered: [u64; 12] = [u64::MAX; 12];
        let expected_recovered: [u64; 12] = [18446744073709551615u64, 18446744073709551615u64, 18446744073709551615u64, 1u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 193, 6);
        assert!(matches!(result, Ok(())), "extract case 194");
        assert_eq!(recovered, expected_recovered, "recovered words case 194");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 255, 4);
        assert!(matches!(result, Ok(())), "pack case 195");
        assert_eq!(packed, expected_packed, "packed words case 195");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 255, 4);
        assert!(matches!(result, Ok(())), "extract case 195");
        assert_eq!(recovered, expected_recovered, "recovered words case 195");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 255, 5);
        assert!(matches!(result, Ok(())), "pack case 196");
        assert_eq!(packed, expected_packed, "packed words case 196");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 255, 5);
        assert!(matches!(result, Ok(())), "extract case 196");
        assert_eq!(recovered, expected_recovered, "recovered words case 196");
    }

    {
        let src: [u64; 0] = [];
        let mut packed: [u64; 0] = [u64::MAX; 0];
        let expected_packed: [u64; 0] = [];
        let result = pack_coefficients(&mut packed, &src, 0, 255, 7);
        assert!(matches!(result, Ok(())), "pack case 197");
        assert_eq!(packed, expected_packed, "packed words case 197");
        let mut recovered: [u64; 0] = [u64::MAX; 0];
        let expected_recovered: [u64; 0] = [];
        let result = extract_coefficients(&mut recovered, &packed, 0, 255, 7);
        assert!(matches!(result, Ok(())), "extract case 197");
        assert_eq!(recovered, expected_recovered, "recovered words case 197");
    }

    {
        let src: [u64; 4] = [3700497567337589470u64, 3989833677417957576u64, 14921658366608132760u64, 6983039180367634513u64];
        let mut packed: [u64; 4] = [u64::MAX; 4];
        let expected_packed: [u64; 4] = [3700497567337589470u64, 3989833677417957576u64, 14921658366608132760u64, 6983039180367634513u64];
        let result = pack_coefficients(&mut packed, &src, 1, 255, 4);
        assert!(matches!(result, Ok(())), "pack case 198");
        assert_eq!(packed, expected_packed, "packed words case 198");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [3700497567337589470u64, 3989833677417957576u64, 14921658366608132760u64, 6983039180367634513u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 255, 4);
        assert!(matches!(result, Ok(())), "extract case 198");
        assert_eq!(recovered, expected_recovered, "recovered words case 198");
    }

    {
        let src: [u64; 4] = [3700497567337589470u64, 3989833677417957576u64, 14921658366608132760u64, 6983039180367634513u64];
        let mut packed: [u64; 5] = [u64::MAX; 5];
        let expected_packed: [u64; 5] = [3700497567337589470u64, 3989833677417957576u64, 14921658366608132760u64, 6983039180367634513u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 255, 5);
        assert!(matches!(result, Ok(())), "pack case 199");
        assert_eq!(packed, expected_packed, "packed words case 199");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [3700497567337589470u64, 3989833677417957576u64, 14921658366608132760u64, 6983039180367634513u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 255, 5);
        assert!(matches!(result, Ok(())), "extract case 199");
        assert_eq!(recovered, expected_recovered, "recovered words case 199");
    }

    {
        let src: [u64; 4] = [3700497567337589470u64, 3989833677417957576u64, 14921658366608132760u64, 6983039180367634513u64];
        let mut packed: [u64; 7] = [u64::MAX; 7];
        let expected_packed: [u64; 7] = [3700497567337589470u64, 3989833677417957576u64, 14921658366608132760u64, 6983039180367634513u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 1, 255, 7);
        assert!(matches!(result, Ok(())), "pack case 200");
        assert_eq!(packed, expected_packed, "packed words case 200");
        let mut recovered: [u64; 4] = [u64::MAX; 4];
        let expected_recovered: [u64; 4] = [3700497567337589470u64, 3989833677417957576u64, 14921658366608132760u64, 6983039180367634513u64];
        let result = extract_coefficients(&mut recovered, &packed, 1, 255, 7);
        assert!(matches!(result, Ok(())), "extract case 200");
        assert_eq!(recovered, expected_recovered, "recovered words case 200");
    }

    {
        let src: [u64; 8] = [14426211588884150239u64, 5937402665196947763u64, 18176939668387347916u64, 3037601679009591965u64, 11442787440046684458u64, 20880070938480469u64, 12962172393585445338u64, 9108443077066674881u64];
        let mut packed: [u64; 8] = [u64::MAX; 8];
        let expected_packed: [u64; 8] = [14426211588884150239u64, 5937402665196947763u64, 18176939668387347916u64, 3037601679009591965u64, 11442787440046684458u64, 20880070938480469u64, 12962172393585445338u64, 9108443077066674881u64];
        let result = pack_coefficients(&mut packed, &src, 2, 255, 4);
        assert!(matches!(result, Ok(())), "pack case 201");
        assert_eq!(packed, expected_packed, "packed words case 201");
        let mut recovered: [u64; 8] = [u64::MAX; 8];
        let expected_recovered: [u64; 8] = [14426211588884150239u64, 5937402665196947763u64, 18176939668387347916u64, 3037601679009591965u64, 11442787440046684458u64, 20880070938480469u64, 12962172393585445338u64, 9108443077066674881u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 255, 4);
        assert!(matches!(result, Ok(())), "extract case 201");
        assert_eq!(recovered, expected_recovered, "recovered words case 201");
    }

    {
        let src: [u64; 8] = [14426211588884150239u64, 5937402665196947763u64, 18176939668387347916u64, 3037601679009591965u64, 11442787440046684458u64, 20880070938480469u64, 12962172393585445338u64, 9108443077066674881u64];
        let mut packed: [u64; 10] = [u64::MAX; 10];
        let expected_packed: [u64; 10] = [14426211588884150239u64, 5937402665196947763u64, 18176939668387347916u64, 3037601679009591965u64, 0u64, 11442787440046684458u64, 20880070938480469u64, 12962172393585445338u64, 9108443077066674881u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 255, 5);
        assert!(matches!(result, Ok(())), "pack case 202");
        assert_eq!(packed, expected_packed, "packed words case 202");
        let mut recovered: [u64; 8] = [u64::MAX; 8];
        let expected_recovered: [u64; 8] = [14426211588884150239u64, 5937402665196947763u64, 18176939668387347916u64, 3037601679009591965u64, 11442787440046684458u64, 20880070938480469u64, 12962172393585445338u64, 9108443077066674881u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 255, 5);
        assert!(matches!(result, Ok(())), "extract case 202");
        assert_eq!(recovered, expected_recovered, "recovered words case 202");
    }

    {
        let src: [u64; 8] = [14426211588884150239u64, 5937402665196947763u64, 18176939668387347916u64, 3037601679009591965u64, 11442787440046684458u64, 20880070938480469u64, 12962172393585445338u64, 9108443077066674881u64];
        let mut packed: [u64; 14] = [u64::MAX; 14];
        let expected_packed: [u64; 14] = [14426211588884150239u64, 5937402665196947763u64, 18176939668387347916u64, 3037601679009591965u64, 0u64, 0u64, 0u64, 11442787440046684458u64, 20880070938480469u64, 12962172393585445338u64, 9108443077066674881u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 2, 255, 7);
        assert!(matches!(result, Ok(())), "pack case 203");
        assert_eq!(packed, expected_packed, "packed words case 203");
        let mut recovered: [u64; 8] = [u64::MAX; 8];
        let expected_recovered: [u64; 8] = [14426211588884150239u64, 5937402665196947763u64, 18176939668387347916u64, 3037601679009591965u64, 11442787440046684458u64, 20880070938480469u64, 12962172393585445338u64, 9108443077066674881u64];
        let result = extract_coefficients(&mut recovered, &packed, 2, 255, 7);
        assert!(matches!(result, Ok(())), "extract case 203");
        assert_eq!(recovered, expected_recovered, "recovered words case 203");
    }

    {
        let src: [u64; 20] = [7884469422486616260u64, 17779843243987001509u64, 1702329080990447767u64, 8998304818106990573u64, 12796897535216210678u64, 12300089665653251277u64, 7936002228690590014u64, 6825717679939075116u64, 6933412866405623451u64, 4325149074908213545u64, 15953873216910735672u64, 1466891923848700744u64, 7357691274869972370u64, 12695587479715003107u64, 4021376927433194668u64, 2161757567185880083u64, 5430467894371975416u64, 3979845702216875199u64, 6563384897161854320u64, 5524603133306256910u64];
        let mut packed: [u64; 20] = [u64::MAX; 20];
        let expected_packed: [u64; 20] = [7884469422486616260u64, 17779843243987001509u64, 1702329080990447767u64, 8998304818106990573u64, 12796897535216210678u64, 12300089665653251277u64, 7936002228690590014u64, 6825717679939075116u64, 6933412866405623451u64, 4325149074908213545u64, 15953873216910735672u64, 1466891923848700744u64, 7357691274869972370u64, 12695587479715003107u64, 4021376927433194668u64, 2161757567185880083u64, 5430467894371975416u64, 3979845702216875199u64, 6563384897161854320u64, 5524603133306256910u64];
        let result = pack_coefficients(&mut packed, &src, 5, 255, 4);
        assert!(matches!(result, Ok(())), "pack case 204");
        assert_eq!(packed, expected_packed, "packed words case 204");
        let mut recovered: [u64; 20] = [u64::MAX; 20];
        let expected_recovered: [u64; 20] = [7884469422486616260u64, 17779843243987001509u64, 1702329080990447767u64, 8998304818106990573u64, 12796897535216210678u64, 12300089665653251277u64, 7936002228690590014u64, 6825717679939075116u64, 6933412866405623451u64, 4325149074908213545u64, 15953873216910735672u64, 1466891923848700744u64, 7357691274869972370u64, 12695587479715003107u64, 4021376927433194668u64, 2161757567185880083u64, 5430467894371975416u64, 3979845702216875199u64, 6563384897161854320u64, 5524603133306256910u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 255, 4);
        assert!(matches!(result, Ok(())), "extract case 204");
        assert_eq!(recovered, expected_recovered, "recovered words case 204");
    }

    {
        let src: [u64; 20] = [7884469422486616260u64, 17779843243987001509u64, 1702329080990447767u64, 8998304818106990573u64, 12796897535216210678u64, 12300089665653251277u64, 7936002228690590014u64, 6825717679939075116u64, 6933412866405623451u64, 4325149074908213545u64, 15953873216910735672u64, 1466891923848700744u64, 7357691274869972370u64, 12695587479715003107u64, 4021376927433194668u64, 2161757567185880083u64, 5430467894371975416u64, 3979845702216875199u64, 6563384897161854320u64, 5524603133306256910u64];
        let mut packed: [u64; 25] = [u64::MAX; 25];
        let expected_packed: [u64; 25] = [7884469422486616260u64, 17779843243987001509u64, 1702329080990447767u64, 8998304818106990573u64, 0u64, 12796897535216210678u64, 12300089665653251277u64, 7936002228690590014u64, 6825717679939075116u64, 0u64, 6933412866405623451u64, 4325149074908213545u64, 15953873216910735672u64, 1466891923848700744u64, 0u64, 7357691274869972370u64, 12695587479715003107u64, 4021376927433194668u64, 2161757567185880083u64, 0u64, 5430467894371975416u64, 3979845702216875199u64, 6563384897161854320u64, 5524603133306256910u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 255, 5);
        assert!(matches!(result, Ok(())), "pack case 205");
        assert_eq!(packed, expected_packed, "packed words case 205");
        let mut recovered: [u64; 20] = [u64::MAX; 20];
        let expected_recovered: [u64; 20] = [7884469422486616260u64, 17779843243987001509u64, 1702329080990447767u64, 8998304818106990573u64, 12796897535216210678u64, 12300089665653251277u64, 7936002228690590014u64, 6825717679939075116u64, 6933412866405623451u64, 4325149074908213545u64, 15953873216910735672u64, 1466891923848700744u64, 7357691274869972370u64, 12695587479715003107u64, 4021376927433194668u64, 2161757567185880083u64, 5430467894371975416u64, 3979845702216875199u64, 6563384897161854320u64, 5524603133306256910u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 255, 5);
        assert!(matches!(result, Ok(())), "extract case 205");
        assert_eq!(recovered, expected_recovered, "recovered words case 205");
    }

    {
        let src: [u64; 20] = [7884469422486616260u64, 17779843243987001509u64, 1702329080990447767u64, 8998304818106990573u64, 12796897535216210678u64, 12300089665653251277u64, 7936002228690590014u64, 6825717679939075116u64, 6933412866405623451u64, 4325149074908213545u64, 15953873216910735672u64, 1466891923848700744u64, 7357691274869972370u64, 12695587479715003107u64, 4021376927433194668u64, 2161757567185880083u64, 5430467894371975416u64, 3979845702216875199u64, 6563384897161854320u64, 5524603133306256910u64];
        let mut packed: [u64; 35] = [u64::MAX; 35];
        let expected_packed: [u64; 35] = [7884469422486616260u64, 17779843243987001509u64, 1702329080990447767u64, 8998304818106990573u64, 0u64, 0u64, 0u64, 12796897535216210678u64, 12300089665653251277u64, 7936002228690590014u64, 6825717679939075116u64, 0u64, 0u64, 0u64, 6933412866405623451u64, 4325149074908213545u64, 15953873216910735672u64, 1466891923848700744u64, 0u64, 0u64, 0u64, 7357691274869972370u64, 12695587479715003107u64, 4021376927433194668u64, 2161757567185880083u64, 0u64, 0u64, 0u64, 5430467894371975416u64, 3979845702216875199u64, 6563384897161854320u64, 5524603133306256910u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 5, 255, 7);
        assert!(matches!(result, Ok(())), "pack case 206");
        assert_eq!(packed, expected_packed, "packed words case 206");
        let mut recovered: [u64; 20] = [u64::MAX; 20];
        let expected_recovered: [u64; 20] = [7884469422486616260u64, 17779843243987001509u64, 1702329080990447767u64, 8998304818106990573u64, 12796897535216210678u64, 12300089665653251277u64, 7936002228690590014u64, 6825717679939075116u64, 6933412866405623451u64, 4325149074908213545u64, 15953873216910735672u64, 1466891923848700744u64, 7357691274869972370u64, 12695587479715003107u64, 4021376927433194668u64, 2161757567185880083u64, 5430467894371975416u64, 3979845702216875199u64, 6563384897161854320u64, 5524603133306256910u64];
        let result = extract_coefficients(&mut recovered, &packed, 5, 255, 7);
        assert!(matches!(result, Ok(())), "extract case 206");
        assert_eq!(recovered, expected_recovered, "recovered words case 206");
    }

    {
        let src: [u64; 12] = [18446744073709551615u64, 18446744073709551615u64, 18446744073709551615u64, 9223372036854775807u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64];
        let mut packed: [u64; 18] = [u64::MAX; 18];
        let expected_packed: [u64; 18] = [18446744073709551615u64, 18446744073709551615u64, 18446744073709551615u64, 9223372036854775807u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64, 0u64, 0u64];
        let result = pack_coefficients(&mut packed, &src, 3, 255, 6);
        assert!(matches!(result, Ok(())), "pack case 207");
        assert_eq!(packed, expected_packed, "packed words case 207");
        let mut recovered: [u64; 12] = [u64::MAX; 12];
        let expected_recovered: [u64; 12] = [18446744073709551615u64, 18446744073709551615u64, 18446744073709551615u64, 9223372036854775807u64, 0u64, 0u64, 0u64, 0u64, 18446744073709551615u64, 0u64, 0u64, 0u64];
        let result = extract_coefficients(&mut recovered, &packed, 3, 255, 6);
        assert!(matches!(result, Ok(())), "extract case 207");
        assert_eq!(recovered, expected_recovered, "recovered words case 207");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [91u64];
        let before = dst;
        let result = pack_coefficients(&mut dst, &src, 0, 0, 0);
        assert!(matches!(result, Err(PackedLayoutError::InvalidPrecision)), "pack error 0");
        assert_eq!(dst, before, "destination changed on error 0");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [92u64];
        let before = dst;
        let result = extract_coefficients(&mut dst, &src, 0, 0, 0);
        assert!(matches!(result, Err(PackedLayoutError::InvalidPrecision)), "extract error 1");
        assert_eq!(dst, before, "destination changed on error 1");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [921u64];
        let before = dst;
        let result = pack_coefficients(&mut dst, &src, 0, 1, 0);
        assert!(matches!(result, Err(PackedLayoutError::SlotTooNarrow)), "pack error 2");
        assert_eq!(dst, before, "destination changed on error 2");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [922u64];
        let before = dst;
        let result = extract_coefficients(&mut dst, &src, 0, 1, 0);
        assert!(matches!(result, Err(PackedLayoutError::SlotTooNarrow)), "extract error 3");
        assert_eq!(dst, before, "destination changed on error 3");
    }

    {
        let src: [u64; 2] = [7u64, 0u64];
        let mut dst: [u64; 1] = [93u64];
        let before = dst;
        let result = pack_coefficients(&mut dst, &src, 1, 65, 1);
        assert!(matches!(result, Err(PackedLayoutError::SlotTooNarrow)), "pack error 4");
        assert_eq!(dst, before, "destination changed on error 4");
    }

    {
        let src: [u64; 1] = [7u64];
        let mut dst: [u64; 1] = [94u64];
        let before = dst;
        let result = extract_coefficients(&mut dst, &src, 1, 65, 1);
        assert!(matches!(result, Err(PackedLayoutError::SlotTooNarrow)), "extract error 5");
        assert_eq!(dst, before, "destination changed on error 5");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [95u64];
        let before = dst;
        let result = pack_coefficients(&mut dst, &src, 18446744073709551615, 128, 2);
        assert!(matches!(result, Err(PackedLayoutError::LengthOverflow)), "pack error 6");
        assert_eq!(dst, before, "destination changed on error 6");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [96u64];
        let before = dst;
        let result = extract_coefficients(&mut dst, &src, 18446744073709551615, 128, 2);
        assert!(matches!(result, Err(PackedLayoutError::LengthOverflow)), "extract error 7");
        assert_eq!(dst, before, "destination changed on error 7");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [961u64];
        let before = dst;
        let result = pack_coefficients(&mut dst, &src, 18446744073709551615, 18446744073709551615, 288230376151711744);
        assert!(matches!(result, Err(PackedLayoutError::LengthOverflow)), "pack error 8");
        assert_eq!(dst, before, "destination changed on error 8");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [962u64];
        let before = dst;
        let result = extract_coefficients(&mut dst, &src, 18446744073709551615, 18446744073709551615, 288230376151711744);
        assert!(matches!(result, Err(PackedLayoutError::LengthOverflow)), "extract error 9");
        assert_eq!(dst, before, "destination changed on error 9");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [963u64];
        let before = dst;
        let result = pack_coefficients(&mut dst, &src, 1, 18446744073709551615, 288230376151711744);
        assert!(matches!(result, Err(PackedLayoutError::SourceLengthMismatch)), "pack error 10");
        assert_eq!(dst, before, "destination changed on error 10");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [964u64];
        let before = dst;
        let result = extract_coefficients(&mut dst, &src, 1, 18446744073709551615, 288230376151711744);
        assert!(matches!(result, Err(PackedLayoutError::SourceLengthMismatch)), "extract error 11");
        assert_eq!(dst, before, "destination changed on error 11");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [97u64];
        let before = dst;
        let result = pack_coefficients(&mut dst, &src, 9223372036854775808, 1, 2);
        assert!(matches!(result, Err(PackedLayoutError::LengthOverflow)), "pack error 12");
        assert_eq!(dst, before, "destination changed on error 12");
    }

    {
        let src: [u64; 0] = [];
        let mut dst: [u64; 1] = [98u64];
        let before = dst;
        let result = extract_coefficients(&mut dst, &src, 9223372036854775808, 1, 2);
        assert!(matches!(result, Err(PackedLayoutError::LengthOverflow)), "extract error 13");
        assert_eq!(dst, before, "destination changed on error 13");
    }

    {
        let src: [u64; 1] = [1u64];
        let mut dst: [u64; 3] = [99u64, 99u64, 99u64];
        let before = dst;
        let result = pack_coefficients(&mut dst, &src, 1, 65, 3);
        assert!(matches!(result, Err(PackedLayoutError::SourceLengthMismatch)), "pack error 14");
        assert_eq!(dst, before, "destination changed on error 14");
    }

    {
        let src: [u64; 2] = [1u64, 0u64];
        let mut dst: [u64; 2] = [99u64, 99u64];
        let before = dst;
        let result = pack_coefficients(&mut dst, &src, 1, 65, 3);
        assert!(matches!(result, Err(PackedLayoutError::DestinationLengthMismatch)), "pack error 15");
        assert_eq!(dst, before, "destination changed on error 15");
    }

    {
        let src: [u64; 2] = [1u64, 0u64];
        let mut dst: [u64; 2] = [99u64, 99u64];
        let before = dst;
        let result = extract_coefficients(&mut dst, &src, 1, 65, 3);
        assert!(matches!(result, Err(PackedLayoutError::SourceLengthMismatch)), "extract error 16");
        assert_eq!(dst, before, "destination changed on error 16");
    }

    {
        let src: [u64; 3] = [1u64, 0u64, 0u64];
        let mut dst: [u64; 1] = [99u64];
        let before = dst;
        let result = extract_coefficients(&mut dst, &src, 1, 65, 3);
        assert!(matches!(result, Err(PackedLayoutError::DestinationLengthMismatch)), "extract error 17");
        assert_eq!(dst, before, "destination changed on error 17");
    }

}

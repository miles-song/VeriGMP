extern crate verigmp;
use verigmp::packed_layout::pack_coefficients;
fn main() {
    let mut words = [1u64, 0u64];
    let _ = pack_coefficients(&mut words, &words, 1, 65, 2);
}

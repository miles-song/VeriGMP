//! Low square uses one cross product, contributing twice by symmetry.
use vstd::prelude::*;
use vstd::arithmetic::div_mod::*;
use crate::radix::*;
use crate::product::*;
use crate::fast_product::*;
use crate::{fast_multiply,toom_square,toom_low,fast_words,square_spec};
verus! {
#[inline]
fn doubled_limb(a:u64,b:u64,carry:u64)->(out:(u64,u64))
    requires carry<=2,
    ensures out.1<=2,
        (out.0 as int)+base()*(out.1 as int)
            ==square_spec::doubled_sum(a as int,b as int)+(carry as int),
{
    proof {square_spec::doubled_digit_bounds(a,b,carry);}
    let radix:u128=18446744073709551616;
    let total=(a as u128)+2*(b as u128)+(carry as u128);
    proof {lemma_fundamental_div_mod(total as int,base());}
    ((total%radix) as u64,(total/radix) as u64)
}

/// One pass over caller-owned equal-length slices, including empty slices.
#[inline]
fn add_double_assign(dst:&mut[u64],rhs:&[u64])->(carry:u64)
    requires old(dst)@.len()==rhs@.len(),
    ensures final(dst)@.len()==old(dst)@.len(),carry<=2,
        value(final(dst)@)+radix(rhs@.len())*(carry as int)
            ==square_spec::doubled_sum(value(old(dst)@),value(rhs@)),
        value(final(dst)@)==square_spec::doubled_sum(value(old(dst)@),value(rhs@))%radix(rhs@.len()),
{
    assert!(dst.len()==rhs.len());
    let ghost original=dst@;
    let mut i=0usize;let mut carry=0u64;
    let ghost mut visits:nat=0;
    while i<dst.len()
        invariant dst@.len()==original.len(),dst@.len()==rhs@.len(),i<=dst@.len(),carry<=2,
            visits==i,
            forall|j:int| i<=j<dst@.len() ==> #[trigger] dst@[j]==original[j],
            prefix(dst@,i as nat)+radix(i as nat)*(carry as int)
                ==square_spec::doubled_sum(prefix(original,i as nat),prefix(rhs@,i as nat)),
        decreases dst.len()-i,
    {
        let ghost before=dst@;let ghost incoming=carry;
        let (low,next)=doubled_limb(dst[i],rhs[i],carry);dst[i]=low;
        proof {
            equal_prefix(dst@,before,i as nat);
            assert(prefix(dst@,(i+1) as nat)+radix((i+1) as nat)*(next as int)
                ==square_spec::doubled_sum(prefix(original,(i+1) as nat),prefix(rhs@,(i+1) as nat)))
                by(nonlinear_arith)
                requires prefix(dst@,i as nat)==prefix(before,i as nat),
                    prefix(before,i as nat)+radix(i as nat)*(incoming as int)
                        ==prefix(original,i as nat)+2*prefix(rhs@,i as nat),
                    before[i as int]==original[i as int],
                    (low as int)+base()*(next as int)
                        ==(before[i as int] as int)+2*(rhs@[i as int] as int)+(incoming as int),
                    prefix(dst@,(i+1) as nat)==prefix(before,i as nat)+(low as int)*radix(i as nat),
                    prefix(original,(i+1) as nat)==prefix(original,i as nat)+(original[i as int] as int)*radix(i as nat),
                    prefix(rhs@,(i+1) as nat)==prefix(rhs@,i as nat)+(rhs@[i as int] as int)*radix(i as nat),
                    radix((i+1) as nat)==base()*radix(i as nat);
        }
        carry=next;i+=1;proof {visits=visits+1;}
    }
    proof {
        assert(visits==original.len());
        prefix_range(dst@,dst@.len());radix_positive(rhs@.len());
        assert(square_spec::doubled_sum(value(original),value(rhs@))
            ==(carry as int)*radix(rhs@.len())+value(dst@)) by(nonlinear_arith)
            requires value(dst@)+radix(rhs@.len())*(carry as int)
                ==square_spec::doubled_sum(value(original),value(rhs@));
        lemma_fundamental_div_mod_converse(square_spec::doubled_sum(value(original),value(rhs@)),
            radix(rhs@.len()),carry as int,value(dst@));
    }
    carry
}

#[verifier::spinoff_prover]
#[verifier::rlimit(20)]
pub fn low(dst:&mut[u64],a:&[u64],scratch:&mut[u64],threshold:usize,low_limit:usize,split_mode:u32)
    requires a@.len()>0,old(dst)@.len()==a@.len(),
        old(scratch)@.len()>=10*a@.len(),threshold>=24,low_limit>=24,split_mode<=2,
    ensures final(dst)@.len()==old(dst)@.len(),final(scratch)@.len()==old(scratch)@.len(),
        value(final(dst)@)==(value(a@)*value(a@))%radix(a@.len()),
    decreases a.len(),
{
    let b=a;
    let _capacity=scratch.len();
    proof {lemma_fundamental_div_mod(usize::MAX as int,10);}
    assert!(a.len()>0 && a.len()==b.len());assert!(a.len()<=usize::MAX/10);
    assert!(dst.len()==a.len() && scratch.len()>=10*a.len());assert!(threshold>=24 && low_limit>=24 && split_mode<=2);
    let n=a.len();
    if n<=low_limit {
        if n<9 {fast_multiply::base_low(dst,a,b);}
        else {crate::square_base::low(dst,a);}
        return;
    }
    // Quotient-first form avoids overflowing 11*n.
    let h=if split_mode==2 {(n/40)*9+((n%40)*9)/40}else if split_mode==1 {(n/36)*11+((n%36)*11)/36}else{n/2};
    proof {
        lemma_fundamental_div_mod(n as int,40);lemma_mod_division_less_than_divisor(n as int,40);
        lemma_fundamental_div_mod(((n%40)*9) as int,40);lemma_mod_division_less_than_divisor(((n%40)*9) as int,40);
        lemma_fundamental_div_mod(n as int,36);lemma_mod_division_less_than_divisor(n as int,36);
        lemma_fundamental_div_mod(((n%36)*11) as int,36);lemma_mod_division_less_than_divisor(((n%36)*11) as int,36);
        lemma_fundamental_div_mod(n as int,2);lemma_mod_division_less_than_divisor(n as int,2);
    }
    let k=n-h;
    {
        let (product,work)=scratch.split_at_mut(2*k);
        toom_square::full(product,&a[..k],work,threshold);
        proof {prefix_mod(product@,n as nat);}
        fast_words::copy_words(dst,&product[..n]);
    }
    let ghost initial=dst@;
    let ghost z0=part(a@,0,k as nat)*part(b@,0,k as nat);
    let (temp,work)=scratch.split_at_mut(h);
    toom_low::low(temp,&a[k..],&b[..h],work,threshold,low_limit,split_mode);
    let ghost c1=value(temp@);
    let ghost c2=value(temp@);
    let _carry=crate::limbs::add_assign(&mut dst[k..],temp);
    proof {
        congruent_suffix(initial,dst@,k as nat,2*c1);
        assert(part(a@,0,h as nat)*part(a@,k as nat,a@.len())
            ==part(a@,k as nat,a@.len())*part(a@,0,h as nat)) by(nonlinear_arith);
        low_identity(a@,b@,k as nat,h as nat,z0,c1,c2);
        radix_positive(k as nat);radix_positive(h as nat);radix_add(k as nat,h as nat);
        mod_add_scaled(z0,2*c1,radix(k as nat),radix(h as nat));
        assert(z0+radix(k as nat)*c1+radix(k as nat)*c2==z0+radix(k as nat)*(c1+c2)) by(nonlinear_arith);
    }
}

}

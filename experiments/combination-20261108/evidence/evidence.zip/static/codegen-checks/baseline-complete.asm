
/mnt/e/3sat/VeriGMP-combination-evidence-20261108/check-2/pair-checks/baseline.o:     file format elf64-x86-64


Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10arithmetic10square_mod:

0000000000000000 <verigmp::arithmetic::square_mod>:
   0:	41 57                	push   %r15
   2:	41 56                	push   %r14
   4:	53                   	push   %rbx
   5:	44 8b 7c 24 20       	mov    0x20(%rsp),%r15d
   a:	41 8d 47 ff          	lea    -0x1(%r15),%eax
   e:	83 f8 40             	cmp    $0x40,%eax
  11:	73 4c                	jae    5f <verigmp::arithmetic::square_mod+0x5f>
  13:	48 89 f3             	mov    %rsi,%rbx
  16:	49 89 fe             	mov    %rdi,%r14
  19:	48 83 ec 08          	sub    $0x8,%rsp
  1d:	6a 01                	push   $0x1
  1f:	6a 40                	push   $0x40
  21:	68 c0 00 00 00       	push   $0xc0
  26:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2c <verigmp::arithmetic::square_mod+0x2c>
			28: R_X86_64_GOTPCREL	verigmp::square_low::low-0x4
  2c:	48 83 c4 20          	add    $0x20,%rsp
  30:	48 85 db             	test   %rbx,%rbx
  33:	74 43                	je     78 <verigmp::arithmetic::square_mod+0x78>
  35:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  3c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  43:	44 89 f9             	mov    %r15d,%ecx
  46:	48 d3 e2             	shl    %cl,%rdx
  49:	41 83 ff 40          	cmp    $0x40,%r15d
  4d:	48 f7 d2             	not    %rdx
  50:	48 0f 44 d0          	cmove  %rax,%rdx
  54:	49 21 54 de f8       	and    %rdx,-0x8(%r14,%rbx,8)
  59:	5b                   	pop    %rbx
  5a:	41 5e                	pop    %r14
  5c:	41 5f                	pop    %r15
  5e:	c3                   	ret
  5f:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 66 <verigmp::arithmetic::square_mod+0x66>
			62: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.1-0x4
  66:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 6d <verigmp::arithmetic::square_mod+0x6d>
			69: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.3-0x4
  6d:	be 27 00 00 00       	mov    $0x27,%esi
  72:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 78 <verigmp::arithmetic::square_mod+0x78>
			74: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  78:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 7f <verigmp::arithmetic::square_mod+0x7f>
			7b: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.203-0x4
  7f:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 86 <verigmp::arithmetic::square_mod+0x86>
			82: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.205-0x4
  86:	be 1f 00 00 00       	mov    $0x1f,%esi
  8b:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 91 <verigmp::arithmetic::square_mod+0x91>
			8d: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10arithmetic7mul_mod:

0000000000000000 <verigmp::arithmetic::mul_mod>:
   0:	41 57                	push   %r15
   2:	41 56                	push   %r14
   4:	53                   	push   %rbx
   5:	48 89 f3             	mov    %rsi,%rbx
   8:	49 89 fe             	mov    %rdi,%r14
   b:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
  10:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
  15:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  1a:	41 8d 77 ff          	lea    -0x1(%r15),%esi
  1e:	48 81 f9 00 02 00 00 	cmp    $0x200,%rcx
  25:	73 20                	jae    47 <verigmp::arithmetic::mul_mod+0x47>
  27:	83 fe 40             	cmp    $0x40,%esi
  2a:	73 72                	jae    9e <verigmp::arithmetic::mul_mod+0x9e>
  2c:	48 83 ec 08          	sub    $0x8,%rsp
  30:	4c 89 f7             	mov    %r14,%rdi
  33:	48 89 de             	mov    %rbx,%rsi
  36:	6a 01                	push   $0x1
  38:	6a 40                	push   $0x40
  3a:	6a 18                	push   $0x18
  3c:	41 52                	push   %r10
  3e:	50                   	push   %rax
  3f:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 45 <verigmp::arithmetic::mul_mod+0x45>
			41: R_X86_64_GOTPCREL	verigmp::fast_multiply::low-0x4
  45:	eb 24                	jmp    6b <verigmp::arithmetic::mul_mod+0x6b>
  47:	83 fe 40             	cmp    $0x40,%esi
  4a:	73 6b                	jae    b7 <verigmp::arithmetic::mul_mod+0xb7>
  4c:	48 83 ec 08          	sub    $0x8,%rsp
  50:	4c 89 f7             	mov    %r14,%rdi
  53:	48 89 de             	mov    %rbx,%rsi
  56:	6a 02                	push   $0x2
  58:	68 80 00 00 00       	push   $0x80
  5d:	68 c0 00 00 00       	push   $0xc0
  62:	41 52                	push   %r10
  64:	50                   	push   %rax
  65:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 6b <verigmp::arithmetic::mul_mod+0x6b>
			67: R_X86_64_GOTPCREL	verigmp::toom_low::low-0x4
  6b:	48 83 c4 30          	add    $0x30,%rsp
  6f:	48 85 db             	test   %rbx,%rbx
  72:	74 5c                	je     d0 <verigmp::arithmetic::mul_mod+0xd0>
  74:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  7b:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  82:	44 89 f9             	mov    %r15d,%ecx
  85:	48 d3 e2             	shl    %cl,%rdx
  88:	41 83 ff 40          	cmp    $0x40,%r15d
  8c:	48 f7 d2             	not    %rdx
  8f:	48 0f 44 d0          	cmove  %rax,%rdx
  93:	49 21 54 de f8       	and    %rdx,-0x8(%r14,%rbx,8)
  98:	5b                   	pop    %rbx
  99:	41 5e                	pop    %r14
  9b:	41 5f                	pop    %r15
  9d:	c3                   	ret
  9e:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # a5 <verigmp::arithmetic::mul_mod+0xa5>
			a1: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.1-0x4
  a5:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # ac <verigmp::arithmetic::mul_mod+0xac>
			a8: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.91-0x4
  ac:	be 27 00 00 00       	mov    $0x27,%esi
  b1:	ff 15 00 00 00 00    	call   *0x0(%rip)        # b7 <verigmp::arithmetic::mul_mod+0xb7>
			b3: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  b7:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # be <verigmp::arithmetic::mul_mod+0xbe>
			ba: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.1-0x4
  be:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # c5 <verigmp::arithmetic::mul_mod+0xc5>
			c1: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.268-0x4
  c5:	be 27 00 00 00       	mov    $0x27,%esi
  ca:	ff 15 00 00 00 00    	call   *0x0(%rip)        # d0 <verigmp::arithmetic::mul_mod+0xd0>
			cc: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  d0:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # d7 <verigmp::arithmetic::mul_mod+0xd7>
			d3: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.203-0x4
  d7:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # de <verigmp::arithmetic::mul_mod+0xde>
			da: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.205-0x4
  de:	be 1f 00 00 00       	mov    $0x1f,%esi
  e3:	ff 15 00 00 00 00    	call   *0x0(%rip)        # e9 <verigmp::arithmetic::mul_mod+0xe9>
			e5: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10fast_words10copy_words:

0000000000000000 <verigmp::fast_words::copy_words>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	75 19                	jne    1e <verigmp::fast_words::copy_words+0x1e>
   5:	48 85 f6             	test   %rsi,%rsi
   8:	74 13                	je     1d <verigmp::fast_words::copy_words+0x1d>
   a:	48 c1 e6 03          	shl    $0x3,%rsi
   e:	48 89 f0             	mov    %rsi,%rax
  11:	48 89 d6             	mov    %rdx,%rsi
  14:	48 89 c2             	mov    %rax,%rdx
  17:	ff 25 00 00 00 00    	jmp    *0x0(%rip)        # 1d <verigmp::fast_words::copy_words+0x1d>
			19: R_X86_64_GOTPCREL	memcpy-0x4
  1d:	c3                   	ret
  1e:	50                   	push   %rax
  1f:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 26 <verigmp::fast_words::copy_words+0x26>
			22: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.4-0x4
  26:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 2d <verigmp::fast_words::copy_words+0x2d>
			29: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.6-0x4
  2d:	be 28 00 00 00       	mov    $0x28,%esi
  32:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 38 <verigmp::fast_words::copy_words+0x38>
			34: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10fast_words12add_extended:

0000000000000000 <verigmp::fast_words::add_extended>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	0f 82 b3 00 00 00    	jb     bc <verigmp::fast_words::add_extended+0xbc>
   9:	48 85 c9             	test   %rcx,%rcx
   c:	74 0d                	je     1b <verigmp::fast_words::add_extended+0x1b>
   e:	48 83 f9 01          	cmp    $0x1,%rcx
  12:	75 0a                	jne    1e <verigmp::fast_words::add_extended+0x1e>
  14:	31 c0                	xor    %eax,%eax
  16:	45 31 c0             	xor    %r8d,%r8d
  19:	eb 4f                	jmp    6a <verigmp::fast_words::add_extended+0x6a>
  1b:	31 c0                	xor    %eax,%eax
  1d:	c3                   	ret
  1e:	49 b9 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r9
  25:	ff ff 0f 
  28:	49 21 c9             	and    %rcx,%r9
  2b:	31 c0                	xor    %eax,%eax
  2d:	45 31 c0             	xor    %r8d,%r8d
  30:	45 31 d2             	xor    %r10d,%r10d
  33:	4a 03 04 c7          	add    (%rdi,%r8,8),%rax
  37:	41 0f 92 c2          	setb   %r10b
  3b:	4a 03 04 c2          	add    (%rdx,%r8,8),%rax
  3f:	4a 89 04 c7          	mov    %rax,(%rdi,%r8,8)
  43:	4e 13 54 c7 08       	adc    0x8(%rdi,%r8,8),%r10
  48:	0f 92 c0             	setb   %al
  4b:	0f b6 c0             	movzbl %al,%eax
  4e:	4e 03 54 c2 08       	add    0x8(%rdx,%r8,8),%r10
  53:	48 83 d0 00          	adc    $0x0,%rax
  57:	4e 89 54 c7 08       	mov    %r10,0x8(%rdi,%r8,8)
  5c:	49 83 c0 02          	add    $0x2,%r8
  60:	4d 39 c1             	cmp    %r8,%r9
  63:	75 cb                	jne    30 <verigmp::fast_words::add_extended+0x30>
  65:	f6 c1 01             	test   $0x1,%cl
  68:	74 1a                	je     84 <verigmp::fast_words::add_extended+0x84>
  6a:	45 31 c9             	xor    %r9d,%r9d
  6d:	4a 03 04 c7          	add    (%rdi,%r8,8),%rax
  71:	41 0f 92 c1          	setb   %r9b
  75:	4a 03 04 c2          	add    (%rdx,%r8,8),%rax
  79:	49 83 d1 00          	adc    $0x0,%r9
  7d:	4a 89 04 c7          	mov    %rax,(%rdi,%r8,8)
  81:	4c 89 c8             	mov    %r9,%rax
  84:	48 29 ce             	sub    %rcx,%rsi
  87:	74 32                	je     bb <verigmp::fast_words::add_extended+0xbb>
  89:	48 85 c0             	test   %rax,%rax
  8c:	74 2d                	je     bb <verigmp::fast_words::add_extended+0xbb>
  8e:	48 8d 0c cf          	lea    (%rdi,%rcx,8),%rcx
  92:	ba 01 00 00 00       	mov    $0x1,%edx
  97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  9e:	00 00 
  a0:	48 01 44 d1 f8       	add    %rax,-0x8(%rcx,%rdx,8)
  a5:	40 0f 92 c7          	setb   %dil
  a9:	31 c0                	xor    %eax,%eax
  ab:	40 88 f8             	mov    %dil,%al
  ae:	48 39 f2             	cmp    %rsi,%rdx
  b1:	73 08                	jae    bb <verigmp::fast_words::add_extended+0xbb>
  b3:	48 ff c2             	inc    %rdx
  b6:	40 84 ff             	test   %dil,%dil
  b9:	75 e5                	jne    a0 <verigmp::fast_words::add_extended+0xa0>
  bb:	c3                   	ret
  bc:	50                   	push   %rax
  bd:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # c4 <verigmp::fast_words::add_extended+0xc4>
			c0: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.7-0x4
  c4:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # cb <verigmp::fast_words::add_extended+0xcb>
			c7: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.8-0x4
  cb:	be 28 00 00 00       	mov    $0x28,%esi
  d0:	ff 15 00 00 00 00    	call   *0x0(%rip)        # d6 <verigmp::fast_words::add_extended+0xd6>
			d2: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10fast_words13combine_cross:

0000000000000000 <verigmp::fast_words::combine_cross>:
   0:	55                   	push   %rbp
   1:	53                   	push   %rbx
   2:	50                   	push   %rax
   3:	80 7c 24 20 00       	cmpb   $0x0,0x20(%rsp)
   8:	74 1a                	je     24 <verigmp::fast_words::combine_cross+0x24>
   a:	48 39 ce             	cmp    %rcx,%rsi
   d:	0f 85 0b 02 00 00    	jne    21e <verigmp::fast_words::combine_cross+0x21e>
  13:	48 85 f6             	test   %rsi,%rsi
  16:	74 2d                	je     45 <verigmp::fast_words::combine_cross+0x45>
  18:	48 83 fe 01          	cmp    $0x1,%rsi
  1c:	75 2e                	jne    4c <verigmp::fast_words::combine_cross+0x4c>
  1e:	31 c9                	xor    %ecx,%ecx
  20:	31 c0                	xor    %eax,%eax
  22:	eb 7b                	jmp    9f <verigmp::fast_words::combine_cross+0x9f>
  24:	48 39 ce             	cmp    %rcx,%rsi
  27:	0f 85 0a 02 00 00    	jne    237 <verigmp::fast_words::combine_cross+0x237>
  2d:	48 85 f6             	test   %rsi,%rsi
  30:	74 13                	je     45 <verigmp::fast_words::combine_cross+0x45>
  32:	48 83 fe 01          	cmp    $0x1,%rsi
  36:	0f 85 82 00 00 00    	jne    be <verigmp::fast_words::combine_cross+0xbe>
  3c:	31 c9                	xor    %ecx,%ecx
  3e:	31 c0                	xor    %eax,%eax
  40:	e9 d5 00 00 00       	jmp    11a <verigmp::fast_words::combine_cross+0x11a>
  45:	31 c9                	xor    %ecx,%ecx
  47:	e9 ef 00 00 00       	jmp    13b <verigmp::fast_words::combine_cross+0x13b>
  4c:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
  53:	ff ff 0f 
  56:	49 21 f2             	and    %rsi,%r10
  59:	31 c9                	xor    %ecx,%ecx
  5b:	31 c0                	xor    %eax,%eax
  5d:	0f 1f 00             	nopl   (%rax)
  60:	45 31 db             	xor    %r11d,%r11d
  63:	48 03 0c c7          	add    (%rdi,%rax,8),%rcx
  67:	41 0f 92 c3          	setb   %r11b
  6b:	48 03 0c c2          	add    (%rdx,%rax,8),%rcx
  6f:	48 89 0c c7          	mov    %rcx,(%rdi,%rax,8)
  73:	4c 13 5c c7 08       	adc    0x8(%rdi,%rax,8),%r11
  78:	0f 92 c1             	setb   %cl
  7b:	0f b6 c9             	movzbl %cl,%ecx
  7e:	4c 03 5c c2 08       	add    0x8(%rdx,%rax,8),%r11
  83:	48 83 d1 00          	adc    $0x0,%rcx
  87:	4c 89 5c c7 08       	mov    %r11,0x8(%rdi,%rax,8)
  8c:	48 83 c0 02          	add    $0x2,%rax
  90:	49 39 c2             	cmp    %rax,%r10
  93:	75 cb                	jne    60 <verigmp::fast_words::combine_cross+0x60>
  95:	40 f6 c6 01          	test   $0x1,%sil
  99:	0f 84 9c 00 00 00    	je     13b <verigmp::fast_words::combine_cross+0x13b>
  9f:	45 31 d2             	xor    %r10d,%r10d
  a2:	48 03 0c c7          	add    (%rdi,%rax,8),%rcx
  a6:	41 0f 92 c2          	setb   %r10b
  aa:	48 03 0c c2          	add    (%rdx,%rax,8),%rcx
  ae:	49 83 d2 00          	adc    $0x0,%r10
  b2:	48 89 0c c7          	mov    %rcx,(%rdi,%rax,8)
  b6:	4c 89 d1             	mov    %r10,%rcx
  b9:	e9 7d 00 00 00       	jmp    13b <verigmp::fast_words::combine_cross+0x13b>
  be:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
  c5:	ff ff 0f 
  c8:	49 21 f2             	and    %rsi,%r10
  cb:	31 c9                	xor    %ecx,%ecx
  cd:	31 c0                	xor    %eax,%eax
  cf:	90                   	nop
  d0:	4c 8b 1c c2          	mov    (%rdx,%rax,8),%r11
  d4:	4c 2b 1c c7          	sub    (%rdi,%rax,8),%r11
  d8:	0f 92 c3             	setb   %bl
  db:	49 29 cb             	sub    %rcx,%r11
  de:	0f 92 c1             	setb   %cl
  e1:	08 d9                	or     %bl,%cl
  e3:	0f b6 c9             	movzbl %cl,%ecx
  e6:	4c 89 1c c7          	mov    %r11,(%rdi,%rax,8)
  ea:	48 8b 5c c2 08       	mov    0x8(%rdx,%rax,8),%rbx
  ef:	48 2b 5c c7 08       	sub    0x8(%rdi,%rax,8),%rbx
  f4:	40 0f 92 c5          	setb   %bpl
  f8:	48 29 cb             	sub    %rcx,%rbx
  fb:	41 0f 92 c3          	setb   %r11b
  ff:	41 08 eb             	or     %bpl,%r11b
 102:	41 0f b6 cb          	movzbl %r11b,%ecx
 106:	48 89 5c c7 08       	mov    %rbx,0x8(%rdi,%rax,8)
 10b:	48 83 c0 02          	add    $0x2,%rax
 10f:	49 39 c2             	cmp    %rax,%r10
 112:	75 bc                	jne    d0 <verigmp::fast_words::combine_cross+0xd0>
 114:	40 f6 c6 01          	test   $0x1,%sil
 118:	74 1a                	je     134 <verigmp::fast_words::combine_cross+0x134>
 11a:	48 8b 14 c2          	mov    (%rdx,%rax,8),%rdx
 11e:	48 2b 14 c7          	sub    (%rdi,%rax,8),%rdx
 122:	41 0f 92 c2          	setb   %r10b
 126:	48 29 ca             	sub    %rcx,%rdx
 129:	41 0f 92 c3          	setb   %r11b
 12d:	45 08 d3             	or     %r10b,%r11b
 130:	48 89 14 c7          	mov    %rdx,(%rdi,%rax,8)
 134:	41 0f b6 cb          	movzbl %r11b,%ecx
 138:	48 f7 d9             	neg    %rcx
 13b:	4c 39 ce             	cmp    %r9,%rsi
 13e:	0f 82 c1 00 00 00    	jb     205 <verigmp::fast_words::combine_cross+0x205>
 144:	4d 85 c9             	test   %r9,%r9
 147:	74 0c                	je     155 <verigmp::fast_words::combine_cross+0x155>
 149:	49 83 f9 01          	cmp    $0x1,%r9
 14d:	75 0d                	jne    15c <verigmp::fast_words::combine_cross+0x15c>
 14f:	31 c0                	xor    %eax,%eax
 151:	31 d2                	xor    %edx,%edx
 153:	eb 56                	jmp    1ab <verigmp::fast_words::combine_cross+0x1ab>
 155:	31 c0                	xor    %eax,%eax
 157:	e9 9f 00 00 00       	jmp    1fb <verigmp::fast_words::combine_cross+0x1fb>
 15c:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
 163:	ff ff 0f 
 166:	4d 21 ca             	and    %r9,%r10
 169:	31 c0                	xor    %eax,%eax
 16b:	31 d2                	xor    %edx,%edx
 16d:	0f 1f 00             	nopl   (%rax)
 170:	45 31 db             	xor    %r11d,%r11d
 173:	48 03 04 d7          	add    (%rdi,%rdx,8),%rax
 177:	41 0f 92 c3          	setb   %r11b
 17b:	49 03 04 d0          	add    (%r8,%rdx,8),%rax
 17f:	48 89 04 d7          	mov    %rax,(%rdi,%rdx,8)
 183:	4c 13 5c d7 08       	adc    0x8(%rdi,%rdx,8),%r11
 188:	0f 92 c0             	setb   %al
 18b:	0f b6 c0             	movzbl %al,%eax
 18e:	4d 03 5c d0 08       	add    0x8(%r8,%rdx,8),%r11
 193:	48 83 d0 00          	adc    $0x0,%rax
 197:	4c 89 5c d7 08       	mov    %r11,0x8(%rdi,%rdx,8)
 19c:	48 83 c2 02          	add    $0x2,%rdx
 1a0:	49 39 d2             	cmp    %rdx,%r10
 1a3:	75 cb                	jne    170 <verigmp::fast_words::combine_cross+0x170>
 1a5:	41 f6 c1 01          	test   $0x1,%r9b
 1a9:	74 1a                	je     1c5 <verigmp::fast_words::combine_cross+0x1c5>
 1ab:	45 31 d2             	xor    %r10d,%r10d
 1ae:	48 03 04 d7          	add    (%rdi,%rdx,8),%rax
 1b2:	41 0f 92 c2          	setb   %r10b
 1b6:	49 03 04 d0          	add    (%r8,%rdx,8),%rax
 1ba:	49 83 d2 00          	adc    $0x0,%r10
 1be:	48 89 04 d7          	mov    %rax,(%rdi,%rdx,8)
 1c2:	4c 89 d0             	mov    %r10,%rax
 1c5:	4c 29 ce             	sub    %r9,%rsi
 1c8:	74 31                	je     1fb <verigmp::fast_words::combine_cross+0x1fb>
 1ca:	48 85 c0             	test   %rax,%rax
 1cd:	74 2c                	je     1fb <verigmp::fast_words::combine_cross+0x1fb>
 1cf:	4a 8d 14 cf          	lea    (%rdi,%r9,8),%rdx
 1d3:	bf 01 00 00 00       	mov    $0x1,%edi
 1d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 1df:	00 
 1e0:	48 01 44 fa f8       	add    %rax,-0x8(%rdx,%rdi,8)
 1e5:	41 0f 92 c0          	setb   %r8b
 1e9:	31 c0                	xor    %eax,%eax
 1eb:	44 88 c0             	mov    %r8b,%al
 1ee:	48 39 f7             	cmp    %rsi,%rdi
 1f1:	73 08                	jae    1fb <verigmp::fast_words::combine_cross+0x1fb>
 1f3:	48 ff c7             	inc    %rdi
 1f6:	45 84 c0             	test   %r8b,%r8b
 1f9:	75 e5                	jne    1e0 <verigmp::fast_words::combine_cross+0x1e0>
 1fb:	48 01 c8             	add    %rcx,%rax
 1fe:	48 83 c4 08          	add    $0x8,%rsp
 202:	5b                   	pop    %rbx
 203:	5d                   	pop    %rbp
 204:	c3                   	ret
 205:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 20c <verigmp::fast_words::combine_cross+0x20c>
			208: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.7-0x4
 20c:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 213 <verigmp::fast_words::combine_cross+0x213>
			20f: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.8-0x4
 213:	be 28 00 00 00       	mov    $0x28,%esi
 218:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 21e <verigmp::fast_words::combine_cross+0x21e>
			21a: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 21e:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 225 <verigmp::fast_words::combine_cross+0x225>
			221: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.13-0x4
 225:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 22c <verigmp::fast_words::combine_cross+0x22c>
			228: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.226-0x4
 22c:	be 28 00 00 00       	mov    $0x28,%esi
 231:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 237 <verigmp::fast_words::combine_cross+0x237>
			233: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 237:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 23e <verigmp::fast_words::combine_cross+0x23e>
			23a: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.13-0x4
 23e:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 245 <verigmp::fast_words::combine_cross+0x245>
			241: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.14-0x4
 245:	be 28 00 00 00       	mov    $0x28,%esi
 24a:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 250 <verigmp::fast_words::combine_cross+0x250>
			24c: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10fast_words14abs_difference:

0000000000000000 <verigmp::fast_words::abs_difference>:
   0:	53                   	push   %rbx
   1:	48 39 ce             	cmp    %rcx,%rsi
   4:	0f 85 06 02 00 00    	jne    210 <verigmp::fast_words::abs_difference+0x210>
   a:	4c 39 ce             	cmp    %r9,%rsi
   d:	0f 82 16 02 00 00    	jb     229 <verigmp::fast_words::abs_difference+0x229>
  13:	48 85 f6             	test   %rsi,%rsi
  16:	74 56                	je     6e <verigmp::fast_words::abs_difference+0x6e>
  18:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
  1c:	0f 1f 40 00          	nopl   0x0(%rax)
  20:	4c 39 c8             	cmp    %r9,%rax
  23:	73 1b                	jae    40 <verigmp::fast_words::abs_difference+0x40>
  25:	49 8b 0c c0          	mov    (%r8,%rax,8),%rcx
  29:	48 39 0c c2          	cmp    %rcx,(%rdx,%rax,8)
  2d:	74 19                	je     48 <verigmp::fast_words::abs_difference+0x48>
  2f:	eb 1f                	jmp    50 <verigmp::fast_words::abs_difference+0x50>
  31:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  38:	0f 1f 84 00 00 00 00 
  3f:	00 
  40:	31 c9                	xor    %ecx,%ecx
  42:	48 39 0c c2          	cmp    %rcx,(%rdx,%rax,8)
  46:	75 08                	jne    50 <verigmp::fast_words::abs_difference+0x50>
  48:	48 83 c0 ff          	add    $0xffffffffffffffff,%rax
  4c:	72 d2                	jb     20 <verigmp::fast_words::abs_difference+0x20>
  4e:	eb 1e                	jmp    6e <verigmp::fast_words::abs_difference+0x6e>
  50:	73 1c                	jae    6e <verigmp::fast_words::abs_difference+0x6e>
  52:	4d 85 c9             	test   %r9,%r9
  55:	0f 84 ea 00 00 00    	je     145 <verigmp::fast_words::abs_difference+0x145>
  5b:	49 83 f9 01          	cmp    $0x1,%r9
  5f:	0f 85 e4 00 00 00    	jne    149 <verigmp::fast_words::abs_difference+0x149>
  65:	31 c9                	xor    %ecx,%ecx
  67:	31 c0                	xor    %eax,%eax
  69:	e9 38 01 00 00       	jmp    1a6 <verigmp::fast_words::abs_difference+0x1a6>
  6e:	4d 85 c9             	test   %r9,%r9
  71:	74 0c                	je     7f <verigmp::fast_words::abs_difference+0x7f>
  73:	49 83 f9 01          	cmp    $0x1,%r9
  77:	75 0a                	jne    83 <verigmp::fast_words::abs_difference+0x83>
  79:	31 c0                	xor    %eax,%eax
  7b:	31 c9                	xor    %ecx,%ecx
  7d:	eb 67                	jmp    e6 <verigmp::fast_words::abs_difference+0xe6>
  7f:	31 c0                	xor    %eax,%eax
  81:	eb 7f                	jmp    102 <verigmp::fast_words::abs_difference+0x102>
  83:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
  8a:	ff ff 0f 
  8d:	4d 21 ca             	and    %r9,%r10
  90:	31 c0                	xor    %eax,%eax
  92:	31 c9                	xor    %ecx,%ecx
  94:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  9b:	00 00 00 00 00 
  a0:	4c 8b 1c ca          	mov    (%rdx,%rcx,8),%r11
  a4:	4d 2b 1c c8          	sub    (%r8,%rcx,8),%r11
  a8:	0f 92 c3             	setb   %bl
  ab:	49 29 c3             	sub    %rax,%r11
  ae:	0f 92 c0             	setb   %al
  b1:	08 d8                	or     %bl,%al
  b3:	0f b6 c0             	movzbl %al,%eax
  b6:	4c 89 1c cf          	mov    %r11,(%rdi,%rcx,8)
  ba:	4c 8b 5c ca 08       	mov    0x8(%rdx,%rcx,8),%r11
  bf:	4d 2b 5c c8 08       	sub    0x8(%r8,%rcx,8),%r11
  c4:	0f 92 c3             	setb   %bl
  c7:	49 29 c3             	sub    %rax,%r11
  ca:	0f 92 c0             	setb   %al
  cd:	08 d8                	or     %bl,%al
  cf:	0f b6 c0             	movzbl %al,%eax
  d2:	4c 89 5c cf 08       	mov    %r11,0x8(%rdi,%rcx,8)
  d7:	48 83 c1 02          	add    $0x2,%rcx
  db:	49 39 ca             	cmp    %rcx,%r10
  de:	75 c0                	jne    a0 <verigmp::fast_words::abs_difference+0xa0>
  e0:	41 f6 c1 01          	test   $0x1,%r9b
  e4:	74 1c                	je     102 <verigmp::fast_words::abs_difference+0x102>
  e6:	4c 8b 14 ca          	mov    (%rdx,%rcx,8),%r10
  ea:	4d 2b 14 c8          	sub    (%r8,%rcx,8),%r10
  ee:	41 0f 92 c3          	setb   %r11b
  f2:	49 29 c2             	sub    %rax,%r10
  f5:	0f 92 c0             	setb   %al
  f8:	44 08 d8             	or     %r11b,%al
  fb:	0f b6 c0             	movzbl %al,%eax
  fe:	4c 89 14 cf          	mov    %r10,(%rdi,%rcx,8)
 102:	49 39 f1             	cmp    %rsi,%r9
 105:	73 3a                	jae    141 <verigmp::fast_words::abs_difference+0x141>
 107:	4c 89 c9             	mov    %r9,%rcx
 10a:	eb 2b                	jmp    137 <verigmp::fast_words::abs_difference+0x137>
 10c:	0f 1f 40 00          	nopl   0x0(%rax)
 110:	4d 8b 14 c8          	mov    (%r8,%rcx,8),%r10
 114:	4c 8b 1c ca          	mov    (%rdx,%rcx,8),%r11
 118:	4d 29 d3             	sub    %r10,%r11
 11b:	41 0f 92 c2          	setb   %r10b
 11f:	49 29 c3             	sub    %rax,%r11
 122:	0f 92 c0             	setb   %al
 125:	44 08 d0             	or     %r10b,%al
 128:	0f b6 c0             	movzbl %al,%eax
 12b:	4c 89 1c cf          	mov    %r11,(%rdi,%rcx,8)
 12f:	48 ff c1             	inc    %rcx
 132:	48 39 ce             	cmp    %rcx,%rsi
 135:	74 0a                	je     141 <verigmp::fast_words::abs_difference+0x141>
 137:	4c 39 c9             	cmp    %r9,%rcx
 13a:	72 d4                	jb     110 <verigmp::fast_words::abs_difference+0x110>
 13c:	45 31 d2             	xor    %r10d,%r10d
 13f:	eb d3                	jmp    114 <verigmp::fast_words::abs_difference+0x114>
 141:	31 c0                	xor    %eax,%eax
 143:	5b                   	pop    %rbx
 144:	c3                   	ret
 145:	31 c9                	xor    %ecx,%ecx
 147:	eb 79                	jmp    1c2 <verigmp::fast_words::abs_difference+0x1c2>
 149:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
 150:	ff ff 0f 
 153:	4d 21 ca             	and    %r9,%r10
 156:	31 c9                	xor    %ecx,%ecx
 158:	31 c0                	xor    %eax,%eax
 15a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 160:	4d 8b 1c c0          	mov    (%r8,%rax,8),%r11
 164:	4c 2b 1c c2          	sub    (%rdx,%rax,8),%r11
 168:	0f 92 c3             	setb   %bl
 16b:	49 29 cb             	sub    %rcx,%r11
 16e:	0f 92 c1             	setb   %cl
 171:	08 d9                	or     %bl,%cl
 173:	0f b6 c9             	movzbl %cl,%ecx
 176:	4c 89 1c c7          	mov    %r11,(%rdi,%rax,8)
 17a:	4d 8b 5c c0 08       	mov    0x8(%r8,%rax,8),%r11
 17f:	4c 2b 5c c2 08       	sub    0x8(%rdx,%rax,8),%r11
 184:	0f 92 c3             	setb   %bl
 187:	49 29 cb             	sub    %rcx,%r11
 18a:	0f 92 c1             	setb   %cl
 18d:	08 d9                	or     %bl,%cl
 18f:	0f b6 c9             	movzbl %cl,%ecx
 192:	4c 89 5c c7 08       	mov    %r11,0x8(%rdi,%rax,8)
 197:	48 83 c0 02          	add    $0x2,%rax
 19b:	49 39 c2             	cmp    %rax,%r10
 19e:	75 c0                	jne    160 <verigmp::fast_words::abs_difference+0x160>
 1a0:	41 f6 c1 01          	test   $0x1,%r9b
 1a4:	74 1c                	je     1c2 <verigmp::fast_words::abs_difference+0x1c2>
 1a6:	4d 8b 14 c0          	mov    (%r8,%rax,8),%r10
 1aa:	4c 2b 14 c2          	sub    (%rdx,%rax,8),%r10
 1ae:	41 0f 92 c3          	setb   %r11b
 1b2:	49 29 ca             	sub    %rcx,%r10
 1b5:	0f 92 c1             	setb   %cl
 1b8:	44 08 d9             	or     %r11b,%cl
 1bb:	0f b6 c9             	movzbl %cl,%ecx
 1be:	4c 89 14 c7          	mov    %r10,(%rdi,%rax,8)
 1c2:	b0 01                	mov    $0x1,%al
 1c4:	49 39 f1             	cmp    %rsi,%r9
 1c7:	0f 83 76 ff ff ff    	jae    143 <verigmp::fast_words::abs_difference+0x143>
 1cd:	4d 89 ca             	mov    %r9,%r10
 1d0:	eb 33                	jmp    205 <verigmp::fast_words::abs_difference+0x205>
 1d2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1d9:	1f 84 00 00 00 00 00 
 1e0:	45 31 db             	xor    %r11d,%r11d
 1e3:	4e 2b 1c d2          	sub    (%rdx,%r10,8),%r11
 1e7:	0f 92 c3             	setb   %bl
 1ea:	49 29 cb             	sub    %rcx,%r11
 1ed:	0f 92 c1             	setb   %cl
 1f0:	08 d9                	or     %bl,%cl
 1f2:	0f b6 c9             	movzbl %cl,%ecx
 1f5:	4e 89 1c d7          	mov    %r11,(%rdi,%r10,8)
 1f9:	49 ff c2             	inc    %r10
 1fc:	4c 39 d6             	cmp    %r10,%rsi
 1ff:	0f 84 3e ff ff ff    	je     143 <verigmp::fast_words::abs_difference+0x143>
 205:	4d 39 ca             	cmp    %r9,%r10
 208:	73 d6                	jae    1e0 <verigmp::fast_words::abs_difference+0x1e0>
 20a:	4f 8b 1c d0          	mov    (%r8,%r10,8),%r11
 20e:	eb d3                	jmp    1e3 <verigmp::fast_words::abs_difference+0x1e3>
 210:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 217 <verigmp::fast_words::abs_difference+0x217>
			213: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.9-0x4
 217:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 21e <verigmp::fast_words::abs_difference+0x21e>
			21a: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.10-0x4
 21e:	be 26 00 00 00       	mov    $0x26,%esi
 223:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 229 <verigmp::fast_words::abs_difference+0x229>
			225: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 229:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 230 <verigmp::fast_words::abs_difference+0x230>
			22c: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.11-0x4
 230:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 237 <verigmp::fast_words::abs_difference+0x237>
			233: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.12-0x4
 237:	be 24 00 00 00       	mov    $0x24,%esi
 23c:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 242 <verigmp::fast_words::abs_difference+0x242>
			23e: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10fast_words16reverse_subtract:

0000000000000000 <verigmp::fast_words::reverse_subtract>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	0f 85 8e 00 00 00    	jne    97 <verigmp::fast_words::reverse_subtract+0x97>
   9:	48 85 f6             	test   %rsi,%rsi
   c:	74 0c                	je     1a <verigmp::fast_words::reverse_subtract+0x1a>
   e:	48 83 fe 01          	cmp    $0x1,%rsi
  12:	75 09                	jne    1d <verigmp::fast_words::reverse_subtract+0x1d>
  14:	31 c0                	xor    %eax,%eax
  16:	31 c9                	xor    %ecx,%ecx
  18:	eb 60                	jmp    7a <verigmp::fast_words::reverse_subtract+0x7a>
  1a:	31 c0                	xor    %eax,%eax
  1c:	c3                   	ret
  1d:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  24:	ff ff 0f 
  27:	49 21 f0             	and    %rsi,%r8
  2a:	31 c0                	xor    %eax,%eax
  2c:	31 c9                	xor    %ecx,%ecx
  2e:	66 90                	xchg   %ax,%ax
  30:	4c 8b 0c ca          	mov    (%rdx,%rcx,8),%r9
  34:	4c 2b 0c cf          	sub    (%rdi,%rcx,8),%r9
  38:	41 0f 92 c2          	setb   %r10b
  3c:	49 29 c1             	sub    %rax,%r9
  3f:	0f 92 c0             	setb   %al
  42:	44 08 d0             	or     %r10b,%al
  45:	0f b6 c0             	movzbl %al,%eax
  48:	4c 89 0c cf          	mov    %r9,(%rdi,%rcx,8)
  4c:	4c 8b 4c ca 08       	mov    0x8(%rdx,%rcx,8),%r9
  51:	4c 2b 4c cf 08       	sub    0x8(%rdi,%rcx,8),%r9
  56:	41 0f 92 c2          	setb   %r10b
  5a:	49 29 c1             	sub    %rax,%r9
  5d:	0f 92 c0             	setb   %al
  60:	44 08 d0             	or     %r10b,%al
  63:	0f b6 c0             	movzbl %al,%eax
  66:	4c 89 4c cf 08       	mov    %r9,0x8(%rdi,%rcx,8)
  6b:	48 83 c1 02          	add    $0x2,%rcx
  6f:	49 39 c8             	cmp    %rcx,%r8
  72:	75 bc                	jne    30 <verigmp::fast_words::reverse_subtract+0x30>
  74:	40 f6 c6 01          	test   $0x1,%sil
  78:	74 1c                	je     96 <verigmp::fast_words::reverse_subtract+0x96>
  7a:	48 8b 14 ca          	mov    (%rdx,%rcx,8),%rdx
  7e:	48 2b 14 cf          	sub    (%rdi,%rcx,8),%rdx
  82:	40 0f 92 c6          	setb   %sil
  86:	48 29 c2             	sub    %rax,%rdx
  89:	0f 92 c0             	setb   %al
  8c:	40 08 f0             	or     %sil,%al
  8f:	0f b6 c0             	movzbl %al,%eax
  92:	48 89 14 cf          	mov    %rdx,(%rdi,%rcx,8)
  96:	c3                   	ret
  97:	50                   	push   %rax
  98:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 9f <verigmp::fast_words::reverse_subtract+0x9f>
			9b: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.13-0x4
  9f:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # a6 <verigmp::fast_words::reverse_subtract+0xa6>
			a2: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.14-0x4
  a6:	be 28 00 00 00       	mov    $0x28,%esi
  ab:	ff 15 00 00 00 00    	call   *0x0(%rip)        # b1 <verigmp::fast_words::reverse_subtract+0xb1>
			ad: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10fast_words4less:

0000000000000000 <verigmp::fast_words::less>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	72 2f                	jb     34 <verigmp::fast_words::less+0x34>
   5:	48 85 f6             	test   %rsi,%rsi
   8:	74 27                	je     31 <verigmp::fast_words::less+0x31>
   a:	48 ff ce             	dec    %rsi
   d:	eb 0f                	jmp    1e <verigmp::fast_words::less+0x1e>
   f:	90                   	nop
  10:	31 c0                	xor    %eax,%eax
  12:	48 39 04 f7          	cmp    %rax,(%rdi,%rsi,8)
  16:	75 15                	jne    2d <verigmp::fast_words::less+0x2d>
  18:	48 83 c6 ff          	add    $0xffffffffffffffff,%rsi
  1c:	73 13                	jae    31 <verigmp::fast_words::less+0x31>
  1e:	48 39 ce             	cmp    %rcx,%rsi
  21:	73 ed                	jae    10 <verigmp::fast_words::less+0x10>
  23:	48 8b 04 f2          	mov    (%rdx,%rsi,8),%rax
  27:	48 39 04 f7          	cmp    %rax,(%rdi,%rsi,8)
  2b:	74 eb                	je     18 <verigmp::fast_words::less+0x18>
  2d:	0f 92 c0             	setb   %al
  30:	c3                   	ret
  31:	31 c0                	xor    %eax,%eax
  33:	c3                   	ret
  34:	50                   	push   %rax
  35:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 3c <verigmp::fast_words::less+0x3c>
			38: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.11-0x4
  3c:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 43 <verigmp::fast_words::less+0x43>
			3f: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.15-0x4
  43:	be 24 00 00 00       	mov    $0x24,%esi
  48:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4e <verigmp::fast_words::less+0x4e>
			4a: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10fast_words8mul_word:

0000000000000000 <verigmp::fast_words::mul_word>:
   0:	41 57                	push   %r15
   2:	41 56                	push   %r14
   4:	53                   	push   %rbx
   5:	48 39 ce             	cmp    %rcx,%rsi
   8:	0f 85 8e 00 00 00    	jne    9c <verigmp::fast_words::mul_word+0x9c>
   e:	48 85 f6             	test   %rsi,%rsi
  11:	74 10                	je     23 <verigmp::fast_words::mul_word+0x23>
  13:	49 89 d2             	mov    %rdx,%r10
  16:	48 83 fe 01          	cmp    $0x1,%rsi
  1a:	75 0c                	jne    28 <verigmp::fast_words::mul_word+0x28>
  1c:	45 31 c9             	xor    %r9d,%r9d
  1f:	31 db                	xor    %ebx,%ebx
  21:	eb 5b                	jmp    7e <verigmp::fast_words::mul_word+0x7e>
  23:	45 31 c9             	xor    %r9d,%r9d
  26:	eb 6b                	jmp    93 <verigmp::fast_words::mul_word+0x93>
  28:	49 be fe ff ff ff ff 	movabs $0xffffffffffffffe,%r14
  2f:	ff ff 0f 
  32:	49 21 f6             	and    %rsi,%r14
  35:	45 31 c9             	xor    %r9d,%r9d
  38:	31 db                	xor    %ebx,%ebx
  3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  40:	4c 89 c0             	mov    %r8,%rax
  43:	49 f7 24 da          	mulq   (%r10,%rbx,8)
  47:	48 89 d1             	mov    %rdx,%rcx
  4a:	49 89 c3             	mov    %rax,%r11
  4d:	4e 8d 3c 08          	lea    (%rax,%r9,1),%r15
  51:	4c 89 c0             	mov    %r8,%rax
  54:	49 f7 64 da 08       	mulq   0x8(%r10,%rbx,8)
  59:	4d 01 cb             	add    %r9,%r11
  5c:	48 11 c8             	adc    %rcx,%rax
  5f:	49 89 d1             	mov    %rdx,%r9
  62:	49 83 d1 00          	adc    $0x0,%r9
  66:	4c 89 3c df          	mov    %r15,(%rdi,%rbx,8)
  6a:	48 89 44 df 08       	mov    %rax,0x8(%rdi,%rbx,8)
  6f:	48 83 c3 02          	add    $0x2,%rbx
  73:	49 39 de             	cmp    %rbx,%r14
  76:	75 c8                	jne    40 <verigmp::fast_words::mul_word+0x40>
  78:	40 f6 c6 01          	test   $0x1,%sil
  7c:	74 15                	je     93 <verigmp::fast_words::mul_word+0x93>
  7e:	4c 89 c0             	mov    %r8,%rax
  81:	49 f7 24 da          	mulq   (%r10,%rbx,8)
  85:	4c 01 c8             	add    %r9,%rax
  88:	49 89 d1             	mov    %rdx,%r9
  8b:	49 83 d1 00          	adc    $0x0,%r9
  8f:	48 89 04 df          	mov    %rax,(%rdi,%rbx,8)
  93:	4c 89 c8             	mov    %r9,%rax
  96:	5b                   	pop    %rbx
  97:	41 5e                	pop    %r14
  99:	41 5f                	pop    %r15
  9b:	c3                   	ret
  9c:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # a3 <verigmp::fast_words::mul_word+0xa3>
			9f: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.13-0x4
  a3:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # aa <verigmp::fast_words::mul_word+0xaa>
			a6: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.16-0x4
  aa:	be 28 00 00 00       	mov    $0x28,%esi
  af:	ff 15 00 00 00 00    	call   *0x0(%rip)        # b5 <verigmp::fast_words::mul_word+0xb5>
			b1: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10fast_words9add_cross:

0000000000000000 <verigmp::fast_words::add_cross>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	0f 82 05 01 00 00    	jb     10e <verigmp::fast_words::add_cross+0x10e>
   9:	49 89 f1             	mov    %rsi,%r9
   c:	48 85 c9             	test   %rcx,%rcx
   f:	0f 84 b9 00 00 00    	je     ce <verigmp::fast_words::add_cross+0xce>
  15:	48 83 f9 01          	cmp    $0x1,%rcx
  19:	75 07                	jne    22 <verigmp::fast_words::add_cross+0x22>
  1b:	31 c0                	xor    %eax,%eax
  1d:	45 31 c9             	xor    %r9d,%r9d
  20:	eb 58                	jmp    7a <verigmp::fast_words::add_cross+0x7a>
  22:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
  29:	ff ff 0f 
  2c:	49 21 ca             	and    %rcx,%r10
  2f:	31 c0                	xor    %eax,%eax
  31:	45 31 c9             	xor    %r9d,%r9d
  34:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  3b:	00 00 00 00 00 
  40:	45 31 db             	xor    %r11d,%r11d
  43:	4a 03 04 cf          	add    (%rdi,%r9,8),%rax
  47:	41 0f 92 c3          	setb   %r11b
  4b:	4a 03 04 ca          	add    (%rdx,%r9,8),%rax
  4f:	4a 89 04 cf          	mov    %rax,(%rdi,%r9,8)
  53:	4e 13 5c cf 08       	adc    0x8(%rdi,%r9,8),%r11
  58:	0f 92 c0             	setb   %al
  5b:	0f b6 c0             	movzbl %al,%eax
  5e:	4e 03 5c ca 08       	add    0x8(%rdx,%r9,8),%r11
  63:	48 83 d0 00          	adc    $0x0,%rax
  67:	4e 89 5c cf 08       	mov    %r11,0x8(%rdi,%r9,8)
  6c:	49 83 c1 02          	add    $0x2,%r9
  70:	4d 39 ca             	cmp    %r9,%r10
  73:	75 cb                	jne    40 <verigmp::fast_words::add_cross+0x40>
  75:	f6 c1 01             	test   $0x1,%cl
  78:	74 1a                	je     94 <verigmp::fast_words::add_cross+0x94>
  7a:	45 31 d2             	xor    %r10d,%r10d
  7d:	4a 03 04 cf          	add    (%rdi,%r9,8),%rax
  81:	41 0f 92 c2          	setb   %r10b
  85:	4a 03 04 ca          	add    (%rdx,%r9,8),%rax
  89:	49 83 d2 00          	adc    $0x0,%r10
  8d:	4a 89 04 cf          	mov    %rax,(%rdi,%r9,8)
  91:	4c 89 d0             	mov    %r10,%rax
  94:	49 89 f1             	mov    %rsi,%r9
  97:	49 29 c9             	sub    %rcx,%r9
  9a:	74 32                	je     ce <verigmp::fast_words::add_cross+0xce>
  9c:	48 85 c0             	test   %rax,%rax
  9f:	74 2d                	je     ce <verigmp::fast_words::add_cross+0xce>
  a1:	48 8d 14 cf          	lea    (%rdi,%rcx,8),%rdx
  a5:	41 ba 01 00 00 00    	mov    $0x1,%r10d
  ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  b0:	45 31 db             	xor    %r11d,%r11d
  b3:	4a 01 44 d2 f8       	add    %rax,-0x8(%rdx,%r10,8)
  b8:	0f 92 c0             	setb   %al
  bb:	4d 39 ca             	cmp    %r9,%r10
  be:	73 0e                	jae    ce <verigmp::fast_words::add_cross+0xce>
  c0:	41 88 c3             	mov    %al,%r11b
  c3:	49 ff c2             	inc    %r10
  c6:	4c 89 d8             	mov    %r11,%rax
  c9:	45 84 db             	test   %r11b,%r11b
  cc:	75 e2                	jne    b0 <verigmp::fast_words::add_cross+0xb0>
  ce:	48 39 ce             	cmp    %rcx,%rsi
  d1:	74 3a                	je     10d <verigmp::fast_words::add_cross+0x10d>
  d3:	4d 85 c0             	test   %r8,%r8
  d6:	74 35                	je     10d <verigmp::fast_words::add_cross+0x10d>
  d8:	48 8d 04 cf          	lea    (%rdi,%rcx,8),%rax
  dc:	b9 01 00 00 00       	mov    $0x1,%ecx
  e1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  e8:	0f 1f 84 00 00 00 00 
  ef:	00 
  f0:	31 d2                	xor    %edx,%edx
  f2:	4c 01 44 c8 f8       	add    %r8,-0x8(%rax,%rcx,8)
  f7:	40 0f 92 c6          	setb   %sil
  fb:	4c 39 c9             	cmp    %r9,%rcx
  fe:	73 0d                	jae    10d <verigmp::fast_words::add_cross+0x10d>
 100:	40 88 f2             	mov    %sil,%dl
 103:	48 ff c1             	inc    %rcx
 106:	49 89 d0             	mov    %rdx,%r8
 109:	84 d2                	test   %dl,%dl
 10b:	75 e3                	jne    f0 <verigmp::fast_words::add_cross+0xf0>
 10d:	c3                   	ret
 10e:	50                   	push   %rax
 10f:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 116 <verigmp::fast_words::add_cross+0x116>
			112: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.7-0x4
 116:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 11d <verigmp::fast_words::add_cross+0x11d>
			119: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.17-0x4
 11d:	be 28 00 00 00       	mov    $0x28,%esi
 122:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 128 <verigmp::fast_words::add_cross+0x128>
			124: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10square_low3low:

0000000000000000 <verigmp::square_low::low>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	48 83 ec 38          	sub    $0x38,%rsp
   e:	48 85 c9             	test   %rcx,%rcx
  11:	0f 84 e5 04 00 00    	je     4fc <verigmp::square_low::low+0x4fc>
  17:	49 89 ce             	mov    %rcx,%r14
  1a:	48 39 ce             	cmp    %rcx,%rsi
  1d:	0f 85 c0 04 00 00    	jne    4e3 <verigmp::square_low::low+0x4e3>
  23:	4d 89 ca             	mov    %r9,%r10
  26:	4b 8d 04 36          	lea    (%r14,%r14,1),%rax
  2a:	48 8d 04 80          	lea    (%rax,%rax,4),%rax
  2e:	49 39 c1             	cmp    %rax,%r9
  31:	0f 82 ac 04 00 00    	jb     4e3 <verigmp::square_low::low+0x4e3>
  37:	4c 8b 5c 24 70       	mov    0x70(%rsp),%r11
  3c:	49 83 fb 18          	cmp    $0x18,%r11
  40:	0f 82 84 04 00 00    	jb     4ca <verigmp::square_low::low+0x4ca>
  46:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
  4b:	48 83 fe 18          	cmp    $0x18,%rsi
  4f:	0f 82 75 04 00 00    	jb     4ca <verigmp::square_low::low+0x4ca>
  55:	4d 89 c4             	mov    %r8,%r12
  58:	44 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8d
  5f:	00 
  60:	41 83 f8 03          	cmp    $0x3,%r8d
  64:	0f 83 60 04 00 00    	jae    4ca <verigmp::square_low::low+0x4ca>
  6a:	49 89 d7             	mov    %rdx,%r15
  6d:	49 39 f6             	cmp    %rsi,%r14
  70:	76 4e                	jbe    c0 <verigmp::square_low::low+0xc0>
  72:	41 83 f8 01          	cmp    $0x1,%r8d
  76:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  7b:	0f 84 1c 02 00 00    	je     29d <verigmp::square_low::low+0x29d>
  81:	41 83 f8 02          	cmp    $0x2,%r8d
  85:	0f 85 52 02 00 00    	jne    2dd <verigmp::square_low::low+0x2dd>
  8b:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
  92:	cc cc cc 
  95:	4c 89 f0             	mov    %r14,%rax
  98:	48 f7 e1             	mul    %rcx
  9b:	48 c1 ea 05          	shr    $0x5,%rdx
  9f:	48 8d 04 d2          	lea    (%rdx,%rdx,8),%rax
  a3:	c1 e2 03             	shl    $0x3,%edx
  a6:	8d 0c 92             	lea    (%rdx,%rdx,4),%ecx
  a9:	44 89 f2             	mov    %r14d,%edx
  ac:	29 ca                	sub    %ecx,%edx
  ae:	8d 0c d2             	lea    (%rdx,%rdx,8),%ecx
  b1:	0f b7 c9             	movzwl %cx,%ecx
  b4:	44 69 e9 67 06 00 00 	imul   $0x667,%ecx,%r13d
  bb:	e9 14 02 00 00       	jmp    2d4 <verigmp::square_low::low+0x2d4>
  c0:	49 83 fe 09          	cmp    $0x9,%r14
  c4:	0f 83 b6 01 00 00    	jae    280 <verigmp::square_low::low+0x280>
  ca:	49 8b 0f             	mov    (%r15),%rcx
  cd:	48 89 c8             	mov    %rcx,%rax
  d0:	48 f7 e1             	mul    %rcx
  d3:	48 89 07             	mov    %rax,(%rdi)
  d6:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
  db:	49 83 fe 01          	cmp    $0x1,%r14
  df:	0f 84 d6 03 00 00    	je     4bb <verigmp::square_low::low+0x4bb>
  e5:	49 89 d0             	mov    %rdx,%r8
  e8:	48 89 c8             	mov    %rcx,%rax
  eb:	49 f7 67 08          	mulq   0x8(%r15)
  ef:	48 89 d6             	mov    %rdx,%rsi
  f2:	4c 01 c0             	add    %r8,%rax
  f5:	48 83 d6 00          	adc    $0x0,%rsi
  f9:	48 89 47 08          	mov    %rax,0x8(%rdi)
  fd:	48 83 7c 24 08 02    	cmpq   $0x2,0x8(%rsp)
 103:	0f 84 aa 00 00 00    	je     1b3 <verigmp::square_low::low+0x1b3>
 109:	48 89 c8             	mov    %rcx,%rax
 10c:	49 f7 67 10          	mulq   0x10(%r15)
 110:	49 89 d0             	mov    %rdx,%r8
 113:	48 01 f0             	add    %rsi,%rax
 116:	49 83 d0 00          	adc    $0x0,%r8
 11a:	48 89 47 10          	mov    %rax,0x10(%rdi)
 11e:	48 83 7c 24 08 03    	cmpq   $0x3,0x8(%rsp)
 124:	0f 84 89 00 00 00    	je     1b3 <verigmp::square_low::low+0x1b3>
 12a:	48 89 c8             	mov    %rcx,%rax
 12d:	49 f7 67 18          	mulq   0x18(%r15)
 131:	48 89 d6             	mov    %rdx,%rsi
 134:	4c 01 c0             	add    %r8,%rax
 137:	48 83 d6 00          	adc    $0x0,%rsi
 13b:	48 89 47 18          	mov    %rax,0x18(%rdi)
 13f:	48 83 7c 24 08 04    	cmpq   $0x4,0x8(%rsp)
 145:	74 6c                	je     1b3 <verigmp::square_low::low+0x1b3>
 147:	48 89 c8             	mov    %rcx,%rax
 14a:	49 f7 67 20          	mulq   0x20(%r15)
 14e:	49 89 d0             	mov    %rdx,%r8
 151:	48 01 f0             	add    %rsi,%rax
 154:	49 83 d0 00          	adc    $0x0,%r8
 158:	48 89 47 20          	mov    %rax,0x20(%rdi)
 15c:	48 83 7c 24 08 05    	cmpq   $0x5,0x8(%rsp)
 162:	74 4f                	je     1b3 <verigmp::square_low::low+0x1b3>
 164:	48 89 c8             	mov    %rcx,%rax
 167:	49 f7 67 28          	mulq   0x28(%r15)
 16b:	48 89 d6             	mov    %rdx,%rsi
 16e:	4c 01 c0             	add    %r8,%rax
 171:	48 83 d6 00          	adc    $0x0,%rsi
 175:	48 89 47 28          	mov    %rax,0x28(%rdi)
 179:	48 83 7c 24 08 06    	cmpq   $0x6,0x8(%rsp)
 17f:	74 32                	je     1b3 <verigmp::square_low::low+0x1b3>
 181:	48 89 c8             	mov    %rcx,%rax
 184:	49 f7 67 30          	mulq   0x30(%r15)
 188:	48 01 f0             	add    %rsi,%rax
 18b:	48 83 d2 00          	adc    $0x0,%rdx
 18f:	48 89 47 30          	mov    %rax,0x30(%rdi)
 193:	48 83 7c 24 08 07    	cmpq   $0x7,0x8(%rsp)
 199:	74 18                	je     1b3 <verigmp::square_low::low+0x1b3>
 19b:	49 0f af 4f 38       	imul   0x38(%r15),%rcx
 1a0:	48 01 d1             	add    %rdx,%rcx
 1a3:	48 89 4f 38          	mov    %rcx,0x38(%rdi)
 1a7:	48 83 7c 24 08 01    	cmpq   $0x1,0x8(%rsp)
 1ad:	0f 84 08 03 00 00    	je     4bb <verigmp::square_low::low+0x4bb>
 1b3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 1b8:	4c 8d 70 fe          	lea    -0x2(%rax),%r14
 1bc:	48 8d 77 10          	lea    0x10(%rdi),%rsi
 1c0:	4c 8d 40 ff          	lea    -0x1(%rax),%r8
 1c4:	41 b9 01 00 00 00    	mov    $0x1,%r9d
 1ca:	45 31 d2             	xor    %r10d,%r10d
 1cd:	eb 32                	jmp    201 <verigmp::square_low::low+0x201>
 1cf:	90                   	nop
 1d0:	31 db                	xor    %ebx,%ebx
 1d2:	45 31 db             	xor    %r11d,%r11d
 1d5:	4a 8d 04 cf          	lea    (%rdi,%r9,8),%rax
 1d9:	4b 0f af 0c df       	imul   (%r15,%r11,8),%rcx
 1de:	4a 03 1c d8          	add    (%rax,%r11,8),%rbx
 1e2:	48 01 cb             	add    %rcx,%rbx
 1e5:	4a 89 1c d8          	mov    %rbx,(%rax,%r11,8)
 1e9:	49 ff c1             	inc    %r9
 1ec:	49 ff c2             	inc    %r10
 1ef:	48 83 c6 08          	add    $0x8,%rsi
 1f3:	49 ff c8             	dec    %r8
 1f6:	4c 3b 4c 24 08       	cmp    0x8(%rsp),%r9
 1fb:	0f 84 ba 02 00 00    	je     4bb <verigmp::square_low::low+0x4bb>
 201:	4b 8b 0c cf          	mov    (%r15,%r9,8),%rcx
 205:	4d 39 d6             	cmp    %r10,%r14
 208:	74 c6                	je     1d0 <verigmp::square_low::low+0x1d0>
 20a:	4d 89 c5             	mov    %r8,%r13
 20d:	49 83 e5 fe          	and    $0xfffffffffffffffe,%r13
 211:	4d 89 d4             	mov    %r10,%r12
 214:	49 f7 d4             	not    %r12
 217:	4c 03 64 24 08       	add    0x8(%rsp),%r12
 21c:	31 db                	xor    %ebx,%ebx
 21e:	45 31 db             	xor    %r11d,%r11d
 221:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 228:	0f 1f 84 00 00 00 00 
 22f:	00 
 230:	48 89 c8             	mov    %rcx,%rax
 233:	4b f7 24 df          	mulq   (%r15,%r11,8)
 237:	31 ed                	xor    %ebp,%ebp
 239:	4a 03 5c de f8       	add    -0x8(%rsi,%r11,8),%rbx
 23e:	40 0f 92 c5          	setb   %bpl
 242:	48 01 c3             	add    %rax,%rbx
 245:	48 11 d5             	adc    %rdx,%rbp
 248:	4a 89 5c de f8       	mov    %rbx,-0x8(%rsi,%r11,8)
 24d:	48 89 c8             	mov    %rcx,%rax
 250:	4b f7 64 df 08       	mulq   0x8(%r15,%r11,8)
 255:	31 db                	xor    %ebx,%ebx
 257:	4a 03 2c de          	add    (%rsi,%r11,8),%rbp
 25b:	0f 92 c3             	setb   %bl
 25e:	48 01 c5             	add    %rax,%rbp
 261:	48 11 d3             	adc    %rdx,%rbx
 264:	4a 89 2c de          	mov    %rbp,(%rsi,%r11,8)
 268:	49 83 c3 02          	add    $0x2,%r11
 26c:	4d 39 dd             	cmp    %r11,%r13
 26f:	75 bf                	jne    230 <verigmp::square_low::low+0x230>
 271:	41 f6 c4 01          	test   $0x1,%r12b
 275:	0f 85 5a ff ff ff    	jne    1d5 <verigmp::square_low::low+0x1d5>
 27b:	e9 69 ff ff ff       	jmp    1e9 <verigmp::square_low::low+0x1e9>
 280:	4c 89 f6             	mov    %r14,%rsi
 283:	4c 89 fa             	mov    %r15,%rdx
 286:	4c 89 f1             	mov    %r14,%rcx
 289:	48 83 c4 38          	add    $0x38,%rsp
 28d:	5b                   	pop    %rbx
 28e:	41 5c                	pop    %r12
 290:	41 5d                	pop    %r13
 292:	41 5e                	pop    %r14
 294:	41 5f                	pop    %r15
 296:	5d                   	pop    %rbp
 297:	ff 25 00 00 00 00    	jmp    *0x0(%rip)        # 29d <verigmp::square_low::low+0x29d>
			299: R_X86_64_GOTPCREL	verigmp::square_base::low-0x4
 29d:	48 b9 8f e3 38 8e e3 	movabs $0xe38e38e38e38e38f,%rcx
 2a4:	38 8e e3 
 2a7:	4c 89 f0             	mov    %r14,%rax
 2aa:	48 f7 e1             	mul    %rcx
 2ad:	48 c1 ea 05          	shr    $0x5,%rdx
 2b1:	48 8d 04 92          	lea    (%rdx,%rdx,4),%rax
 2b5:	48 8d 04 42          	lea    (%rdx,%rax,2),%rax
 2b9:	c1 e2 02             	shl    $0x2,%edx
 2bc:	8d 0c d2             	lea    (%rdx,%rdx,8),%ecx
 2bf:	44 89 f2             	mov    %r14d,%edx
 2c2:	29 ca                	sub    %ecx,%edx
 2c4:	8d 0c 92             	lea    (%rdx,%rdx,4),%ecx
 2c7:	8d 0c 4a             	lea    (%rdx,%rcx,2),%ecx
 2ca:	0f b7 c9             	movzwl %cx,%ecx
 2cd:	44 69 e9 1d 07 00 00 	imul   $0x71d,%ecx,%r13d
 2d4:	41 c1 ed 10          	shr    $0x10,%r13d
 2d8:	49 01 c5             	add    %rax,%r13
 2db:	eb 06                	jmp    2e3 <verigmp::square_low::low+0x2e3>
 2dd:	4d 89 f5             	mov    %r14,%r13
 2e0:	49 d1 ed             	shr    $1,%r13
 2e3:	4c 89 f3             	mov    %r14,%rbx
 2e6:	4c 29 eb             	sub    %r13,%rbx
 2e9:	48 8d 2c 1b          	lea    (%rbx,%rbx,1),%rbp
 2ed:	4d 89 d1             	mov    %r10,%r9
 2f0:	49 29 e9             	sub    %rbp,%r9
 2f3:	0f 82 1c 02 00 00    	jb     515 <verigmp::square_low::low+0x515>
 2f9:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
 2fe:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
 303:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
 308:	4d 8d 04 ec          	lea    (%r12,%rbp,8),%r8
 30c:	48 83 ec 08          	sub    $0x8,%rsp
 310:	4c 89 e7             	mov    %r12,%rdi
 313:	48 89 ee             	mov    %rbp,%rsi
 316:	4c 89 fa             	mov    %r15,%rdx
 319:	48 89 d9             	mov    %rbx,%rcx
 31c:	41 53                	push   %r11
 31e:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
 323:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 329 <verigmp::square_low::low+0x329>
			325: R_X86_64_GOTPCREL	verigmp::toom_square::full-0x4
 329:	48 83 c4 10          	add    $0x10,%rsp
 32d:	49 39 ee             	cmp    %rbp,%r14
 330:	0f 87 f8 01 00 00    	ja     52e <verigmp::square_low::low+0x52e>
 336:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
 33b:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
 342:	00 
 343:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
 348:	48 89 ef             	mov    %rbp,%rdi
 34b:	4c 89 e6             	mov    %r12,%rsi
 34e:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 354 <verigmp::square_low::low+0x354>
			350: R_X86_64_GOTPCREL	memcpy-0x4
 354:	4b 8d 04 ec          	lea    (%r12,%r13,8),%rax
 358:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
 35d:	4d 29 ea             	sub    %r13,%r10
 360:	49 8d 14 df          	lea    (%r15,%rbx,8),%rdx
 364:	48 83 ec 08          	sub    $0x8,%rsp
 368:	4c 89 e7             	mov    %r12,%rdi
 36b:	4c 89 ee             	mov    %r13,%rsi
 36e:	4c 89 e9             	mov    %r13,%rcx
 371:	4d 89 f8             	mov    %r15,%r8
 374:	4d 89 e9             	mov    %r13,%r9
 377:	ff 74 24 20          	push   0x20(%rsp)
 37b:	ff 74 24 30          	push   0x30(%rsp)
 37f:	ff 74 24 28          	push   0x28(%rsp)
 383:	41 52                	push   %r10
 385:	50                   	push   %rax
 386:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 38c <verigmp::square_low::low+0x38c>
			388: R_X86_64_GOTPCREL	verigmp::toom_low::low-0x4
 38c:	48 83 c4 30          	add    $0x30,%rsp
 390:	4d 85 ed             	test   %r13,%r13
 393:	0f 84 22 01 00 00    	je     4bb <verigmp::square_low::low+0x4bb>
 399:	48 8d 04 dd 00 00 00 	lea    0x0(,%rbx,8),%rax
 3a0:	00 
 3a1:	48 01 e8             	add    %rbp,%rax
 3a4:	4c 89 e9             	mov    %r13,%rcx
 3a7:	48 ff c9             	dec    %rcx
 3aa:	0f 84 dd 00 00 00    	je     48d <verigmp::square_low::low+0x48d>
 3b0:	4c 89 ef             	mov    %r13,%rdi
 3b3:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
 3b7:	4a 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%rdx
 3be:	00 
 3bf:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
 3c4:	4e 8d 04 d5 00 00 00 	lea    0x0(,%r10,8),%r8
 3cb:	00 
 3cc:	49 01 e8             	add    %rbp,%r8
 3cf:	49 29 d0             	sub    %rdx,%r8
 3d2:	49 83 c0 08          	add    $0x8,%r8
 3d6:	31 d2                	xor    %edx,%edx
 3d8:	31 f6                	xor    %esi,%esi
 3da:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 3e0:	45 31 c9             	xor    %r9d,%r9d
 3e3:	49 03 54 f0 f8       	add    -0x8(%r8,%rsi,8),%rdx
 3e8:	41 0f 92 c1          	setb   %r9b
 3ec:	49 03 14 f4          	add    (%r12,%rsi,8),%rdx
 3f0:	49 89 54 f0 f8       	mov    %rdx,-0x8(%r8,%rsi,8)
 3f5:	4d 13 0c f0          	adc    (%r8,%rsi,8),%r9
 3f9:	0f 92 c2             	setb   %dl
 3fc:	0f b6 d2             	movzbl %dl,%edx
 3ff:	4d 03 4c f4 08       	add    0x8(%r12,%rsi,8),%r9
 404:	48 83 d2 00          	adc    $0x0,%rdx
 408:	4d 89 0c f0          	mov    %r9,(%r8,%rsi,8)
 40c:	48 83 c6 02          	add    $0x2,%rsi
 410:	48 39 f7             	cmp    %rsi,%rdi
 413:	75 cb                	jne    3e0 <verigmp::square_low::low+0x3e0>
 415:	41 f6 c5 01          	test   $0x1,%r13b
 419:	75 7b                	jne    496 <verigmp::square_low::low+0x496>
 41b:	48 85 c9             	test   %rcx,%rcx
 41e:	0f 84 87 00 00 00    	je     4ab <verigmp::square_low::low+0x4ab>
 424:	4c 89 ee             	mov    %r13,%rsi
 427:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
 42b:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
 432:	00 
 433:	4a 8d 3c d5 00 00 00 	lea    0x0(,%r10,8),%rdi
 43a:	00 
 43b:	48 01 ef             	add    %rbp,%rdi
 43e:	48 29 cf             	sub    %rcx,%rdi
 441:	48 83 c7 08          	add    $0x8,%rdi
 445:	31 c9                	xor    %ecx,%ecx
 447:	31 d2                	xor    %edx,%edx
 449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 450:	45 31 c0             	xor    %r8d,%r8d
 453:	48 03 4c d7 f8       	add    -0x8(%rdi,%rdx,8),%rcx
 458:	41 0f 92 c0          	setb   %r8b
 45c:	49 03 0c d4          	add    (%r12,%rdx,8),%rcx
 460:	48 89 4c d7 f8       	mov    %rcx,-0x8(%rdi,%rdx,8)
 465:	4c 13 04 d7          	adc    (%rdi,%rdx,8),%r8
 469:	0f 92 c1             	setb   %cl
 46c:	0f b6 c9             	movzbl %cl,%ecx
 46f:	4d 03 44 d4 08       	add    0x8(%r12,%rdx,8),%r8
 474:	48 83 d1 00          	adc    $0x0,%rcx
 478:	4c 89 04 d7          	mov    %r8,(%rdi,%rdx,8)
 47c:	48 83 c2 02          	add    $0x2,%rdx
 480:	48 39 d6             	cmp    %rdx,%rsi
 483:	75 cb                	jne    450 <verigmp::square_low::low+0x450>
 485:	41 f6 c5 01          	test   $0x1,%r13b
 489:	75 24                	jne    4af <verigmp::square_low::low+0x4af>
 48b:	eb 2e                	jmp    4bb <verigmp::square_low::low+0x4bb>
 48d:	31 d2                	xor    %edx,%edx
 48f:	31 f6                	xor    %esi,%esi
 491:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
 496:	48 03 14 f0          	add    (%rax,%rsi,8),%rdx
 49a:	49 03 14 f4          	add    (%r12,%rsi,8),%rdx
 49e:	48 89 14 f0          	mov    %rdx,(%rax,%rsi,8)
 4a2:	48 85 c9             	test   %rcx,%rcx
 4a5:	0f 85 79 ff ff ff    	jne    424 <verigmp::square_low::low+0x424>
 4ab:	31 c9                	xor    %ecx,%ecx
 4ad:	31 d2                	xor    %edx,%edx
 4af:	48 03 0c d0          	add    (%rax,%rdx,8),%rcx
 4b3:	49 03 0c d4          	add    (%r12,%rdx,8),%rcx
 4b7:	48 89 0c d0          	mov    %rcx,(%rax,%rdx,8)
 4bb:	48 83 c4 38          	add    $0x38,%rsp
 4bf:	5b                   	pop    %rbx
 4c0:	41 5c                	pop    %r12
 4c2:	41 5d                	pop    %r13
 4c4:	41 5e                	pop    %r14
 4c6:	41 5f                	pop    %r15
 4c8:	5d                   	pop    %rbp
 4c9:	c3                   	ret
 4ca:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 4d1 <verigmp::square_low::low+0x4d1>
			4cd: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.23-0x4
 4d1:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 4d8 <verigmp::square_low::low+0x4d8>
			4d4: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.24-0x4
 4d8:	be 47 00 00 00       	mov    $0x47,%esi
 4dd:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4e3 <verigmp::square_low::low+0x4e3>
			4df: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 4e3:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 4ea <verigmp::square_low::low+0x4ea>
			4e6: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.21-0x4
 4ea:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 4f1 <verigmp::square_low::low+0x4f1>
			4ed: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.22-0x4
 4f1:	be 47 00 00 00       	mov    $0x47,%esi
 4f6:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4fc <verigmp::square_low::low+0x4fc>
			4f8: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 4fc:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 503 <verigmp::square_low::low+0x503>
			4ff: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.18-0x4
 503:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 50a <verigmp::square_low::low+0x50a>
			506: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.20-0x4
 50a:	be 33 00 00 00       	mov    $0x33,%esi
 50f:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 515 <verigmp::square_low::low+0x515>
			511: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 515:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 51c <verigmp::square_low::low+0x51c>
			518: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.0-0x4
 51c:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 523 <verigmp::square_low::low+0x523>
			51f: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.25-0x4
 523:	be 13 00 00 00       	mov    $0x13,%esi
 528:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 52e <verigmp::square_low::low+0x52e>
			52a: R_X86_64_GOTPCREL	core::panicking::panic_fmt-0x4
 52e:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 535 <verigmp::square_low::low+0x535>
			531: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.27-0x4
 535:	31 ff                	xor    %edi,%edi
 537:	4c 89 f6             	mov    %r14,%rsi
 53a:	48 89 ea             	mov    %rbp,%rdx
 53d:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 543 <verigmp::square_low::low+0x543>
			53f: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10toom_words11add_shifted:

0000000000000000 <verigmp::toom_words::add_shifted>:
   0:	48 89 f0             	mov    %rsi,%rax
   3:	4c 29 c0             	sub    %r8,%rax
   6:	0f 82 5a 01 00 00    	jb     166 <verigmp::toom_words::add_shifted+0x166>
   c:	4e 8d 0c c7          	lea    (%rdi,%r8,8),%r9
  10:	48 39 c8             	cmp    %rcx,%rax
  13:	73 27                	jae    3c <verigmp::toom_words::add_shifted+0x3c>
  15:	4c 39 c6             	cmp    %r8,%rsi
  18:	0f 84 e0 00 00 00    	je     fe <verigmp::toom_words::add_shifted+0xfe>
  1e:	49 8d 48 01          	lea    0x1(%r8),%rcx
  22:	48 39 ce             	cmp    %rcx,%rsi
  25:	0f 85 d4 00 00 00    	jne    ff <verigmp::toom_words::add_shifted+0xff>
  2b:	31 c9                	xor    %ecx,%ecx
  2d:	31 f6                	xor    %esi,%esi
  2f:	49 03 0c f1          	add    (%r9,%rsi,8),%rcx
  33:	48 03 0c f2          	add    (%rdx,%rsi,8),%rcx
  37:	49 89 0c f1          	mov    %rcx,(%r9,%rsi,8)
  3b:	c3                   	ret
  3c:	48 85 c9             	test   %rcx,%rcx
  3f:	0f 84 b9 00 00 00    	je     fe <verigmp::toom_words::add_shifted+0xfe>
  45:	48 83 f9 01          	cmp    $0x1,%rcx
  49:	75 06                	jne    51 <verigmp::toom_words::add_shifted+0x51>
  4b:	31 f6                	xor    %esi,%esi
  4d:	31 ff                	xor    %edi,%edi
  4f:	eb 5b                	jmp    ac <verigmp::toom_words::add_shifted+0xac>
  51:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
  58:	ff ff 0f 
  5b:	49 21 ca             	and    %rcx,%r10
  5e:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
  62:	49 83 c0 08          	add    $0x8,%r8
  66:	31 f6                	xor    %esi,%esi
  68:	31 ff                	xor    %edi,%edi
  6a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  70:	45 31 db             	xor    %r11d,%r11d
  73:	49 03 74 f8 f8       	add    -0x8(%r8,%rdi,8),%rsi
  78:	41 0f 92 c3          	setb   %r11b
  7c:	48 03 34 fa          	add    (%rdx,%rdi,8),%rsi
  80:	49 89 74 f8 f8       	mov    %rsi,-0x8(%r8,%rdi,8)
  85:	4d 13 1c f8          	adc    (%r8,%rdi,8),%r11
  89:	40 0f 92 c6          	setb   %sil
  8d:	40 0f b6 f6          	movzbl %sil,%esi
  91:	4c 03 5c fa 08       	add    0x8(%rdx,%rdi,8),%r11
  96:	48 83 d6 00          	adc    $0x0,%rsi
  9a:	4d 89 1c f8          	mov    %r11,(%r8,%rdi,8)
  9e:	48 83 c7 02          	add    $0x2,%rdi
  a2:	49 39 fa             	cmp    %rdi,%r10
  a5:	75 c9                	jne    70 <verigmp::toom_words::add_shifted+0x70>
  a7:	f6 c1 01             	test   $0x1,%cl
  aa:	74 1a                	je     c6 <verigmp::toom_words::add_shifted+0xc6>
  ac:	45 31 c0             	xor    %r8d,%r8d
  af:	49 03 34 f9          	add    (%r9,%rdi,8),%rsi
  b3:	41 0f 92 c0          	setb   %r8b
  b7:	48 03 34 fa          	add    (%rdx,%rdi,8),%rsi
  bb:	49 83 d0 00          	adc    $0x0,%r8
  bf:	49 89 34 f9          	mov    %rsi,(%r9,%rdi,8)
  c3:	4c 89 c6             	mov    %r8,%rsi
  c6:	48 29 c8             	sub    %rcx,%rax
  c9:	74 33                	je     fe <verigmp::toom_words::add_shifted+0xfe>
  cb:	48 85 f6             	test   %rsi,%rsi
  ce:	74 2e                	je     fe <verigmp::toom_words::add_shifted+0xfe>
  d0:	49 8d 0c c9          	lea    (%r9,%rcx,8),%rcx
  d4:	ba 01 00 00 00       	mov    $0x1,%edx
  d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  e0:	31 ff                	xor    %edi,%edi
  e2:	48 01 74 d1 f8       	add    %rsi,-0x8(%rcx,%rdx,8)
  e7:	40 0f 92 c6          	setb   %sil
  eb:	48 39 c2             	cmp    %rax,%rdx
  ee:	73 0e                	jae    fe <verigmp::toom_words::add_shifted+0xfe>
  f0:	40 88 f7             	mov    %sil,%dil
  f3:	48 ff c2             	inc    %rdx
  f6:	48 89 fe             	mov    %rdi,%rsi
  f9:	40 84 ff             	test   %dil,%dil
  fc:	75 e2                	jne    e0 <verigmp::toom_words::add_shifted+0xe0>
  fe:	c3                   	ret
  ff:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
 106:	ff ff 0f 
 109:	49 21 c2             	and    %rax,%r10
 10c:	4a 8d 3c c7          	lea    (%rdi,%r8,8),%rdi
 110:	48 83 c7 08          	add    $0x8,%rdi
 114:	31 c9                	xor    %ecx,%ecx
 116:	31 f6                	xor    %esi,%esi
 118:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 11f:	00 
 120:	45 31 c0             	xor    %r8d,%r8d
 123:	48 03 4c f7 f8       	add    -0x8(%rdi,%rsi,8),%rcx
 128:	41 0f 92 c0          	setb   %r8b
 12c:	48 03 0c f2          	add    (%rdx,%rsi,8),%rcx
 130:	48 89 4c f7 f8       	mov    %rcx,-0x8(%rdi,%rsi,8)
 135:	4c 13 04 f7          	adc    (%rdi,%rsi,8),%r8
 139:	0f 92 c1             	setb   %cl
 13c:	0f b6 c9             	movzbl %cl,%ecx
 13f:	4c 03 44 f2 08       	add    0x8(%rdx,%rsi,8),%r8
 144:	48 83 d1 00          	adc    $0x0,%rcx
 148:	4c 89 04 f7          	mov    %r8,(%rdi,%rsi,8)
 14c:	48 83 c6 02          	add    $0x2,%rsi
 150:	49 39 f2             	cmp    %rsi,%r10
 153:	75 cb                	jne    120 <verigmp::toom_words::add_shifted+0x120>
 155:	a8 01                	test   $0x1,%al
 157:	74 a5                	je     fe <verigmp::toom_words::add_shifted+0xfe>
 159:	49 03 0c f1          	add    (%r9,%rsi,8),%rcx
 15d:	48 03 0c f2          	add    (%rdx,%rsi,8),%rcx
 161:	49 89 0c f1          	mov    %rcx,(%r9,%rsi,8)
 165:	c3                   	ret
 166:	50                   	push   %rax
 167:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 16e <verigmp::toom_words::add_shifted+0x16e>
			16a: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.28-0x4
 16e:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 175 <verigmp::toom_words::add_shifted+0x175>
			171: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.30-0x4
 175:	be 25 00 00 00       	mov    $0x25,%esi
 17a:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 180 <verigmp::toom_words::add_shifted+0x180>
			17c: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10toom_words11scale_exact:

0000000000000000 <verigmp::toom_words::scale_exact>:
   0:	48 85 f6             	test   %rsi,%rsi
   3:	74 72                	je     77 <verigmp::toom_words::scale_exact+0x77>
   5:	48 89 d1             	mov    %rdx,%rcx
   8:	48 83 fe 01          	cmp    $0x1,%rsi
   c:	75 08                	jne    16 <verigmp::toom_words::scale_exact+0x16>
   e:	45 31 db             	xor    %r11d,%r11d
  11:	45 31 d2             	xor    %r10d,%r10d
  14:	eb 55                	jmp    6b <verigmp::toom_words::scale_exact+0x6b>
  16:	53                   	push   %rbx
  17:	48 bb fe ff ff ff ff 	movabs $0xffffffffffffffe,%rbx
  1e:	ff ff 0f 
  21:	48 21 f3             	and    %rsi,%rbx
  24:	45 31 db             	xor    %r11d,%r11d
  27:	45 31 d2             	xor    %r10d,%r10d
  2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  30:	48 89 c8             	mov    %rcx,%rax
  33:	4a f7 24 d7          	mulq   (%rdi,%r10,8)
  37:	49 89 d0             	mov    %rdx,%r8
  3a:	49 89 c1             	mov    %rax,%r9
  3d:	48 89 c8             	mov    %rcx,%rax
  40:	4a f7 64 d7 08       	mulq   0x8(%rdi,%r10,8)
  45:	4d 01 d9             	add    %r11,%r9
  48:	4c 11 c0             	adc    %r8,%rax
  4b:	49 89 d3             	mov    %rdx,%r11
  4e:	49 83 d3 00          	adc    $0x0,%r11
  52:	4e 89 0c d7          	mov    %r9,(%rdi,%r10,8)
  56:	4a 89 44 d7 08       	mov    %rax,0x8(%rdi,%r10,8)
  5b:	49 83 c2 02          	add    $0x2,%r10
  5f:	4c 39 d3             	cmp    %r10,%rbx
  62:	75 cc                	jne    30 <verigmp::toom_words::scale_exact+0x30>
  64:	40 f6 c6 01          	test   $0x1,%sil
  68:	5b                   	pop    %rbx
  69:	74 0c                	je     77 <verigmp::toom_words::scale_exact+0x77>
  6b:	4a 0f af 0c d7       	imul   (%rdi,%r10,8),%rcx
  70:	4c 01 d9             	add    %r11,%rcx
  73:	4a 89 0c d7          	mov    %rcx,(%rdi,%r10,8)
  77:	c3                   	ret

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10toom_words15subtract_assign:

0000000000000000 <verigmp::toom_words::subtract_assign>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	72 4d                	jb     52 <verigmp::toom_words::subtract_assign+0x52>
   5:	31 c0                	xor    %eax,%eax
   7:	48 85 f6             	test   %rsi,%rsi
   a:	74 45                	je     51 <verigmp::toom_words::subtract_assign+0x51>
   c:	45 31 c0             	xor    %r8d,%r8d
   f:	eb 36                	jmp    47 <verigmp::toom_words::subtract_assign+0x47>
  11:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  18:	0f 1f 84 00 00 00 00 
  1f:	00 
  20:	4e 8b 0c c2          	mov    (%rdx,%r8,8),%r9
  24:	4e 8b 14 c7          	mov    (%rdi,%r8,8),%r10
  28:	4d 29 ca             	sub    %r9,%r10
  2b:	41 0f 92 c1          	setb   %r9b
  2f:	49 29 c2             	sub    %rax,%r10
  32:	0f 92 c0             	setb   %al
  35:	44 08 c8             	or     %r9b,%al
  38:	0f b6 c0             	movzbl %al,%eax
  3b:	4e 89 14 c7          	mov    %r10,(%rdi,%r8,8)
  3f:	49 ff c0             	inc    %r8
  42:	4c 39 c6             	cmp    %r8,%rsi
  45:	74 0a                	je     51 <verigmp::toom_words::subtract_assign+0x51>
  47:	49 39 c8             	cmp    %rcx,%r8
  4a:	72 d4                	jb     20 <verigmp::toom_words::subtract_assign+0x20>
  4c:	45 31 c9             	xor    %r9d,%r9d
  4f:	eb d3                	jmp    24 <verigmp::toom_words::subtract_assign+0x24>
  51:	c3                   	ret
  52:	50                   	push   %rax
  53:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 5a <verigmp::toom_words::subtract_assign+0x5a>
			56: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.7-0x4
  5a:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 61 <verigmp::toom_words::subtract_assign+0x61>
			5d: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.31-0x4
  61:	be 28 00 00 00       	mov    $0x28,%esi
  66:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 6c <verigmp::toom_words::subtract_assign+0x6c>
			68: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10toom_words25reverse_subtract_extended:

0000000000000000 <verigmp::toom_words::reverse_subtract_extended>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	72 4a                	jb     4f <verigmp::toom_words::reverse_subtract_extended+0x4f>
   5:	31 c0                	xor    %eax,%eax
   7:	48 85 f6             	test   %rsi,%rsi
   a:	74 42                	je     4e <verigmp::toom_words::reverse_subtract_extended+0x4e>
   c:	45 31 c0             	xor    %r8d,%r8d
   f:	eb 33                	jmp    44 <verigmp::toom_words::reverse_subtract_extended+0x44>
  11:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  18:	0f 1f 84 00 00 00 00 
  1f:	00 
  20:	4e 8b 0c c2          	mov    (%rdx,%r8,8),%r9
  24:	4e 2b 0c c7          	sub    (%rdi,%r8,8),%r9
  28:	41 0f 92 c2          	setb   %r10b
  2c:	49 29 c1             	sub    %rax,%r9
  2f:	0f 92 c0             	setb   %al
  32:	44 08 d0             	or     %r10b,%al
  35:	0f b6 c0             	movzbl %al,%eax
  38:	4e 89 0c c7          	mov    %r9,(%rdi,%r8,8)
  3c:	49 ff c0             	inc    %r8
  3f:	4c 39 c6             	cmp    %r8,%rsi
  42:	74 0a                	je     4e <verigmp::toom_words::reverse_subtract_extended+0x4e>
  44:	49 39 c8             	cmp    %rcx,%r8
  47:	72 d7                	jb     20 <verigmp::toom_words::reverse_subtract_extended+0x20>
  49:	45 31 c9             	xor    %r9d,%r9d
  4c:	eb d6                	jmp    24 <verigmp::toom_words::reverse_subtract_extended+0x24>
  4e:	c3                   	ret
  4f:	50                   	push   %rax
  50:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 57 <verigmp::toom_words::reverse_subtract_extended+0x57>
			53: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.7-0x4
  57:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 5e <verigmp::toom_words::reverse_subtract_extended+0x5e>
			5a: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.32-0x4
  5e:	be 28 00 00 00       	mov    $0x28,%esi
  63:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 69 <verigmp::toom_words::reverse_subtract_extended+0x69>
			65: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10toom_words8copy_pad:

0000000000000000 <verigmp::toom_words::copy_pad>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	0f 82 92 00 00 00    	jb     9b <verigmp::toom_words::copy_pad+0x9b>
   9:	48 85 f6             	test   %rsi,%rsi
   c:	0f 84 88 00 00 00    	je     9a <verigmp::toom_words::copy_pad+0x9a>
  12:	48 83 fe 01          	cmp    $0x1,%rsi
  16:	75 0d                	jne    25 <verigmp::toom_words::copy_pad+0x25>
  18:	31 c0                	xor    %eax,%eax
  1a:	48 39 c8             	cmp    %rcx,%rax
  1d:	73 75                	jae    94 <verigmp::toom_words::copy_pad+0x94>
  1f:	48 8b 0c c2          	mov    (%rdx,%rax,8),%rcx
  23:	eb 71                	jmp    96 <verigmp::toom_words::copy_pad+0x96>
  25:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  2c:	ff ff 0f 
  2f:	49 21 f0             	and    %rsi,%r8
  32:	45 31 c9             	xor    %r9d,%r9d
  35:	eb 1b                	jmp    52 <verigmp::toom_words::copy_pad+0x52>
  37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  3e:	00 00 
  40:	4c 8b 54 c2 08       	mov    0x8(%rdx,%rax,8),%r10
  45:	4c 89 54 c7 08       	mov    %r10,0x8(%rdi,%rax,8)
  4a:	49 ff c1             	inc    %r9
  4d:	4d 39 c1             	cmp    %r8,%r9
  50:	74 33                	je     85 <verigmp::toom_words::copy_pad+0x85>
  52:	4c 89 c8             	mov    %r9,%rax
  55:	49 39 c9             	cmp    %rcx,%r9
  58:	73 16                	jae    70 <verigmp::toom_words::copy_pad+0x70>
  5a:	4c 8b 0c c2          	mov    (%rdx,%rax,8),%r9
  5e:	4c 89 0c c7          	mov    %r9,(%rdi,%rax,8)
  62:	4c 8d 48 01          	lea    0x1(%rax),%r9
  66:	49 39 c9             	cmp    %rcx,%r9
  69:	72 d5                	jb     40 <verigmp::toom_words::copy_pad+0x40>
  6b:	eb 13                	jmp    80 <verigmp::toom_words::copy_pad+0x80>
  6d:	0f 1f 00             	nopl   (%rax)
  70:	45 31 c9             	xor    %r9d,%r9d
  73:	4c 89 0c c7          	mov    %r9,(%rdi,%rax,8)
  77:	4c 8d 48 01          	lea    0x1(%rax),%r9
  7b:	49 39 c9             	cmp    %rcx,%r9
  7e:	72 c0                	jb     40 <verigmp::toom_words::copy_pad+0x40>
  80:	45 31 d2             	xor    %r10d,%r10d
  83:	eb c0                	jmp    45 <verigmp::toom_words::copy_pad+0x45>
  85:	40 f6 c6 01          	test   $0x1,%sil
  89:	74 0f                	je     9a <verigmp::toom_words::copy_pad+0x9a>
  8b:	48 83 c0 02          	add    $0x2,%rax
  8f:	48 39 c8             	cmp    %rcx,%rax
  92:	72 8b                	jb     1f <verigmp::toom_words::copy_pad+0x1f>
  94:	31 c9                	xor    %ecx,%ecx
  96:	48 89 0c c7          	mov    %rcx,(%rdi,%rax,8)
  9a:	c3                   	ret
  9b:	50                   	push   %rax
  9c:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # a3 <verigmp::toom_words::copy_pad+0xa3>
			9f: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.33-0x4
  a3:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # aa <verigmp::toom_words::copy_pad+0xaa>
			a6: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.34-0x4
  aa:	be 28 00 00 00       	mov    $0x28,%esi
  af:	ff 15 00 00 00 00    	call   *0x0(%rip)        # b5 <verigmp::toom_words::copy_pad+0xb5>
			b1: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10toom_words9add_exact:

0000000000000000 <verigmp::toom_words::add_exact>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	0f 82 c5 00 00 00    	jb     ce <verigmp::toom_words::add_exact+0xce>
   9:	48 85 c9             	test   %rcx,%rcx
   c:	0f 84 bb 00 00 00    	je     cd <verigmp::toom_words::add_exact+0xcd>
  12:	48 83 f9 01          	cmp    $0x1,%rcx
  16:	75 07                	jne    1f <verigmp::toom_words::add_exact+0x1f>
  18:	31 c0                	xor    %eax,%eax
  1a:	45 31 c0             	xor    %r8d,%r8d
  1d:	eb 5b                	jmp    7a <verigmp::toom_words::add_exact+0x7a>
  1f:	49 b9 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r9
  26:	ff ff 0f 
  29:	49 21 c9             	and    %rcx,%r9
  2c:	31 c0                	xor    %eax,%eax
  2e:	45 31 c0             	xor    %r8d,%r8d
  31:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  38:	0f 1f 84 00 00 00 00 
  3f:	00 
  40:	45 31 d2             	xor    %r10d,%r10d
  43:	4a 03 04 c7          	add    (%rdi,%r8,8),%rax
  47:	41 0f 92 c2          	setb   %r10b
  4b:	4a 03 04 c2          	add    (%rdx,%r8,8),%rax
  4f:	4a 89 04 c7          	mov    %rax,(%rdi,%r8,8)
  53:	4e 13 54 c7 08       	adc    0x8(%rdi,%r8,8),%r10
  58:	0f 92 c0             	setb   %al
  5b:	0f b6 c0             	movzbl %al,%eax
  5e:	4e 03 54 c2 08       	add    0x8(%rdx,%r8,8),%r10
  63:	48 83 d0 00          	adc    $0x0,%rax
  67:	4e 89 54 c7 08       	mov    %r10,0x8(%rdi,%r8,8)
  6c:	49 83 c0 02          	add    $0x2,%r8
  70:	4d 39 c1             	cmp    %r8,%r9
  73:	75 cb                	jne    40 <verigmp::toom_words::add_exact+0x40>
  75:	f6 c1 01             	test   $0x1,%cl
  78:	74 1a                	je     94 <verigmp::toom_words::add_exact+0x94>
  7a:	45 31 c9             	xor    %r9d,%r9d
  7d:	4a 03 04 c7          	add    (%rdi,%r8,8),%rax
  81:	41 0f 92 c1          	setb   %r9b
  85:	4a 03 04 c2          	add    (%rdx,%r8,8),%rax
  89:	49 83 d1 00          	adc    $0x0,%r9
  8d:	4a 89 04 c7          	mov    %rax,(%rdi,%r8,8)
  91:	4c 89 c8             	mov    %r9,%rax
  94:	48 29 ce             	sub    %rcx,%rsi
  97:	74 34                	je     cd <verigmp::toom_words::add_exact+0xcd>
  99:	48 85 c0             	test   %rax,%rax
  9c:	74 2f                	je     cd <verigmp::toom_words::add_exact+0xcd>
  9e:	48 8d 0c cf          	lea    (%rdi,%rcx,8),%rcx
  a2:	ba 01 00 00 00       	mov    $0x1,%edx
  a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  ae:	00 00 
  b0:	31 ff                	xor    %edi,%edi
  b2:	48 01 44 d1 f8       	add    %rax,-0x8(%rcx,%rdx,8)
  b7:	0f 92 c0             	setb   %al
  ba:	48 39 f2             	cmp    %rsi,%rdx
  bd:	73 0e                	jae    cd <verigmp::toom_words::add_exact+0xcd>
  bf:	40 88 c7             	mov    %al,%dil
  c2:	48 ff c2             	inc    %rdx
  c5:	48 89 f8             	mov    %rdi,%rax
  c8:	40 84 ff             	test   %dil,%dil
  cb:	75 e3                	jne    b0 <verigmp::toom_words::add_exact+0xb0>
  cd:	c3                   	ret
  ce:	50                   	push   %rax
  cf:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # d6 <verigmp::toom_words::add_exact+0xd6>
			d2: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.7-0x4
  d6:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # dd <verigmp::toom_words::add_exact+0xdd>
			d9: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.8-0x4
  dd:	be 28 00 00 00       	mov    $0x28,%esi
  e2:	ff 15 00 00 00 00    	call   *0x0(%rip)        # e8 <verigmp::toom_words::add_exact+0xe8>
			e4: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp10toom_words9sub_exact:

0000000000000000 <verigmp::toom_words::sub_exact>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	72 4f                	jb     54 <verigmp::toom_words::sub_exact+0x54>
   5:	48 85 f6             	test   %rsi,%rsi
   8:	74 49                	je     53 <verigmp::toom_words::sub_exact+0x53>
   a:	45 31 c0             	xor    %r8d,%r8d
   d:	31 c0                	xor    %eax,%eax
   f:	eb 38                	jmp    49 <verigmp::toom_words::sub_exact+0x49>
  11:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  18:	0f 1f 84 00 00 00 00 
  1f:	00 
  20:	4c 8b 0c c2          	mov    (%rdx,%rax,8),%r9
  24:	4c 8b 14 c7          	mov    (%rdi,%rax,8),%r10
  28:	4d 29 ca             	sub    %r9,%r10
  2b:	41 0f 92 c1          	setb   %r9b
  2f:	4d 29 c2             	sub    %r8,%r10
  32:	41 0f 92 c0          	setb   %r8b
  36:	45 08 c8             	or     %r9b,%r8b
  39:	45 0f b6 c0          	movzbl %r8b,%r8d
  3d:	4c 89 14 c7          	mov    %r10,(%rdi,%rax,8)
  41:	48 ff c0             	inc    %rax
  44:	48 39 c6             	cmp    %rax,%rsi
  47:	74 0a                	je     53 <verigmp::toom_words::sub_exact+0x53>
  49:	48 39 c8             	cmp    %rcx,%rax
  4c:	72 d2                	jb     20 <verigmp::toom_words::sub_exact+0x20>
  4e:	45 31 c9             	xor    %r9d,%r9d
  51:	eb d1                	jmp    24 <verigmp::toom_words::sub_exact+0x24>
  53:	c3                   	ret
  54:	50                   	push   %rax
  55:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 5c <verigmp::toom_words::sub_exact+0x5c>
			58: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.7-0x4
  5c:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 63 <verigmp::toom_words::sub_exact+0x63>
			5f: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.31-0x4
  63:	be 28 00 00 00       	mov    $0x28,%esi
  68:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 6e <verigmp::toom_words::sub_exact+0x6e>
			6a: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp11square_base3low:

0000000000000000 <verigmp::square_base::low>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	50                   	push   %rax
   b:	48 85 c9             	test   %rcx,%rcx
   e:	0f 84 e6 01 00 00    	je     1fa <verigmp::square_base::low+0x1fa>
  14:	48 89 cb             	mov    %rcx,%rbx
  17:	48 39 ce             	cmp    %rcx,%rsi
  1a:	0f 85 da 01 00 00    	jne    1fa <verigmp::square_base::low+0x1fa>
  20:	49 89 d7             	mov    %rdx,%r15
  23:	49 89 fe             	mov    %rdi,%r14
  26:	48 8d 14 dd 00 00 00 	lea    0x0(,%rbx,8),%rdx
  2d:	00 
  2e:	45 31 e4             	xor    %r12d,%r12d
  31:	31 f6                	xor    %esi,%esi
  33:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 39 <verigmp::square_base::low+0x39>
			35: R_X86_64_GOTPCREL	memset-0x4
  39:	48 83 fb 02          	cmp    $0x2,%rbx
  3d:	0f 82 ff 00 00 00    	jb     142 <verigmp::square_base::low+0x142>
  43:	49 8d 76 10          	lea    0x10(%r14),%rsi
  47:	48 8d 7b ff          	lea    -0x1(%rbx),%rdi
  4b:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  51:	45 31 c9             	xor    %r9d,%r9d
  54:	48 89 1c 24          	mov    %rbx,(%rsp)
  58:	eb 1c                	jmp    76 <verigmp::square_base::low+0x76>
  5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  60:	49 ff c0             	inc    %r8
  63:	49 ff c1             	inc    %r9
  66:	48 83 c6 08          	add    $0x8,%rsi
  6a:	48 ff cf             	dec    %rdi
  6d:	49 39 d8             	cmp    %rbx,%r8
  70:	0f 84 d3 00 00 00    	je     149 <verigmp::square_base::low+0x149>
  76:	4c 39 c7             	cmp    %r8,%rdi
  79:	4c 89 c5             	mov    %r8,%rbp
  7c:	48 0f 42 ef          	cmovb  %rdi,%rbp
  80:	4d 89 cd             	mov    %r9,%r13
  83:	49 f7 d5             	not    %r13
  86:	49 01 dd             	add    %rbx,%r13
  89:	4d 39 c5             	cmp    %r8,%r13
  8c:	4d 0f 43 e8          	cmovae %r8,%r13
  90:	49 89 da             	mov    %rbx,%r10
  93:	4d 29 c2             	sub    %r8,%r10
  96:	4d 39 d0             	cmp    %r10,%r8
  99:	4d 0f 42 d0          	cmovb  %r8,%r10
  9d:	4b 8b 0c c7          	mov    (%r15,%r8,8),%rcx
  a1:	49 83 fd 01          	cmp    $0x1,%r13
  a5:	75 09                	jne    b0 <verigmp::square_base::low+0xb0>
  a7:	45 31 db             	xor    %r11d,%r11d
  aa:	45 31 e4             	xor    %r12d,%r12d
  ad:	eb 59                	jmp    108 <verigmp::square_base::low+0x108>
  af:	90                   	nop
  b0:	48 83 e5 fe          	and    $0xfffffffffffffffe,%rbp
  b4:	45 31 db             	xor    %r11d,%r11d
  b7:	45 31 e4             	xor    %r12d,%r12d
  ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  c0:	48 89 c8             	mov    %rcx,%rax
  c3:	4b f7 24 e7          	mulq   (%r15,%r12,8)
  c7:	31 db                	xor    %ebx,%ebx
  c9:	4e 03 5c e6 f8       	add    -0x8(%rsi,%r12,8),%r11
  ce:	0f 92 c3             	setb   %bl
  d1:	49 01 c3             	add    %rax,%r11
  d4:	48 11 d3             	adc    %rdx,%rbx
  d7:	4e 89 5c e6 f8       	mov    %r11,-0x8(%rsi,%r12,8)
  dc:	48 89 c8             	mov    %rcx,%rax
  df:	4b f7 64 e7 08       	mulq   0x8(%r15,%r12,8)
  e4:	45 31 db             	xor    %r11d,%r11d
  e7:	4a 03 1c e6          	add    (%rsi,%r12,8),%rbx
  eb:	41 0f 92 c3          	setb   %r11b
  ef:	48 01 c3             	add    %rax,%rbx
  f2:	49 11 d3             	adc    %rdx,%r11
  f5:	4a 89 1c e6          	mov    %rbx,(%rsi,%r12,8)
  f9:	49 83 c4 02          	add    $0x2,%r12
  fd:	4c 39 e5             	cmp    %r12,%rbp
 100:	75 be                	jne    c0 <verigmp::square_base::low+0xc0>
 102:	41 f6 c5 01          	test   $0x1,%r13b
 106:	74 21                	je     129 <verigmp::square_base::low+0x129>
 108:	48 89 c8             	mov    %rcx,%rax
 10b:	4b f7 24 e7          	mulq   (%r15,%r12,8)
 10f:	4b 8d 0c c6          	lea    (%r14,%r8,8),%rcx
 113:	31 db                	xor    %ebx,%ebx
 115:	4e 03 1c e1          	add    (%rcx,%r12,8),%r11
 119:	0f 92 c3             	setb   %bl
 11c:	49 01 c3             	add    %rax,%r11
 11f:	48 11 d3             	adc    %rdx,%rbx
 122:	4e 89 1c e1          	mov    %r11,(%rcx,%r12,8)
 126:	49 89 db             	mov    %rbx,%r11
 129:	4d 01 c2             	add    %r8,%r10
 12c:	48 8b 1c 24          	mov    (%rsp),%rbx
 130:	49 39 da             	cmp    %rbx,%r10
 133:	0f 83 27 ff ff ff    	jae    60 <verigmp::square_base::low+0x60>
 139:	4f 89 1c d6          	mov    %r11,(%r14,%r10,8)
 13d:	e9 1e ff ff ff       	jmp    60 <verigmp::square_base::low+0x60>
 142:	31 c9                	xor    %ecx,%ecx
 144:	e9 87 00 00 00       	jmp    1d0 <verigmp::square_base::low+0x1d0>
 149:	48 8d 4b ff          	lea    -0x1(%rbx),%rcx
 14d:	be 02 00 00 00       	mov    $0x2,%esi
 152:	45 31 e4             	xor    %r12d,%r12d
 155:	31 ff                	xor    %edi,%edi
 157:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 15e:	00 00 
 160:	4d 8b 44 f6 f0       	mov    -0x10(%r14,%rsi,8),%r8
 165:	49 8b 04 ff          	mov    (%r15,%rdi,8),%rax
 169:	48 f7 e0             	mul    %rax
 16c:	4d 8b 4c f6 f8       	mov    -0x8(%r14,%rsi,8),%r9
 171:	4d 89 c2             	mov    %r8,%r10
 174:	49 c1 ea 3f          	shr    $0x3f,%r10
 178:	4d 01 c0             	add    %r8,%r8
 17b:	4d 01 e0             	add    %r12,%r8
 17e:	49 83 d2 00          	adc    $0x0,%r10
 182:	4d 89 cc             	mov    %r9,%r12
 185:	49 c1 ec 3f          	shr    $0x3f,%r12
 189:	4d 01 c9             	add    %r9,%r9
 18c:	49 01 d1             	add    %rdx,%r9
 18f:	49 83 d4 00          	adc    $0x0,%r12
 193:	49 01 c0             	add    %rax,%r8
 196:	4d 11 d1             	adc    %r10,%r9
 199:	49 83 d4 00          	adc    $0x0,%r12
 19d:	4d 89 44 f6 f0       	mov    %r8,-0x10(%r14,%rsi,8)
 1a2:	4d 89 4c f6 f8       	mov    %r9,-0x8(%r14,%rsi,8)
 1a7:	48 39 ce             	cmp    %rcx,%rsi
 1aa:	73 1f                	jae    1cb <verigmp::square_base::low+0x1cb>
 1ac:	48 ff c7             	inc    %rdi
 1af:	48 83 c6 02          	add    $0x2,%rsi
 1b3:	48 39 df             	cmp    %rbx,%rdi
 1b6:	72 a8                	jb     160 <verigmp::square_base::low+0x160>
 1b8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 1bf <verigmp::square_base::low+0x1bf>
			1bb: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.38-0x4
 1bf:	48 89 df             	mov    %rbx,%rdi
 1c2:	48 89 de             	mov    %rbx,%rsi
 1c5:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1cb <verigmp::square_base::low+0x1cb>
			1c7: R_X86_64_GOTPCREL	core::panicking::panic_bounds_check-0x4
 1cb:	f6 c3 01             	test   $0x1,%bl
 1ce:	74 1b                	je     1eb <verigmp::square_base::low+0x1eb>
 1d0:	49 8b 04 ce          	mov    (%r14,%rcx,8),%rax
 1d4:	48 83 e3 fe          	and    $0xfffffffffffffffe,%rbx
 1d8:	49 8b 14 9f          	mov    (%r15,%rbx,4),%rdx
 1dc:	48 0f af d2          	imul   %rdx,%rdx
 1e0:	49 8d 04 44          	lea    (%r12,%rax,2),%rax
 1e4:	48 01 d0             	add    %rdx,%rax
 1e7:	49 89 04 ce          	mov    %rax,(%r14,%rcx,8)
 1eb:	48 83 c4 08          	add    $0x8,%rsp
 1ef:	5b                   	pop    %rbx
 1f0:	41 5c                	pop    %r12
 1f2:	41 5d                	pop    %r13
 1f4:	41 5e                	pop    %r14
 1f6:	41 5f                	pop    %r15
 1f8:	5d                   	pop    %rbp
 1f9:	c3                   	ret
 1fa:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 201 <verigmp::square_base::low+0x201>
			1fd: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.35-0x4
 201:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 208 <verigmp::square_base::low+0x208>
			204: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.37-0x4
 208:	be 35 00 00 00       	mov    $0x35,%esi
 20d:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 213 <verigmp::square_base::low+0x213>
			20f: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp11square_base4full:

0000000000000000 <verigmp::square_base::full>:
   0:	41 57                	push   %r15
   2:	41 56                	push   %r14
   4:	41 54                	push   %r12
   6:	53                   	push   %rbx
   7:	50                   	push   %rax
   8:	48 85 c9             	test   %rcx,%rcx
   b:	0f 84 62 01 00 00    	je     173 <verigmp::square_base::full+0x173>
  11:	48 89 cb             	mov    %rcx,%rbx
  14:	49 89 d6             	mov    %rdx,%r14
  17:	48 89 f2             	mov    %rsi,%rdx
  1a:	48 8d 04 09          	lea    (%rcx,%rcx,1),%rax
  1e:	48 39 c6             	cmp    %rax,%rsi
  21:	0f 85 65 01 00 00    	jne    18c <verigmp::square_base::full+0x18c>
  27:	49 89 ff             	mov    %rdi,%r15
  2a:	48 c1 e2 03          	shl    $0x3,%rdx
  2e:	31 f6                	xor    %esi,%esi
  30:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 36 <verigmp::square_base::full+0x36>
			32: R_X86_64_GOTPCREL	memset-0x4
  36:	48 83 fb 01          	cmp    $0x1,%rbx
  3a:	75 6d                	jne    a9 <verigmp::square_base::full+0xa9>
  3c:	49 83 c7 08          	add    $0x8,%r15
  40:	31 f6                	xor    %esi,%esi
  42:	31 c9                	xor    %ecx,%ecx
  44:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  4b:	00 00 00 00 00 
  50:	49 8b 7f f8          	mov    -0x8(%r15),%rdi
  54:	49 8b 04 ce          	mov    (%r14,%rcx,8),%rax
  58:	48 f7 e0             	mul    %rax
  5b:	49 89 f8             	mov    %rdi,%r8
  5e:	49 c1 e8 3f          	shr    $0x3f,%r8
  62:	48 01 ff             	add    %rdi,%rdi
  65:	48 01 f7             	add    %rsi,%rdi
  68:	49 83 d0 00          	adc    $0x0,%r8
  6c:	4d 8b 0f             	mov    (%r15),%r9
  6f:	4c 89 ce             	mov    %r9,%rsi
  72:	48 c1 ee 3f          	shr    $0x3f,%rsi
  76:	4d 01 c9             	add    %r9,%r9
  79:	49 01 d1             	add    %rdx,%r9
  7c:	48 83 d6 00          	adc    $0x0,%rsi
  80:	48 01 c7             	add    %rax,%rdi
  83:	4d 11 c1             	adc    %r8,%r9
  86:	48 83 d6 00          	adc    $0x0,%rsi
  8a:	49 89 7f f8          	mov    %rdi,-0x8(%r15)
  8e:	4d 89 0f             	mov    %r9,(%r15)
  91:	48 ff c1             	inc    %rcx
  94:	49 83 c7 10          	add    $0x10,%r15
  98:	48 39 cb             	cmp    %rcx,%rbx
  9b:	75 b3                	jne    50 <verigmp::square_base::full+0x50>
  9d:	48 83 c4 08          	add    $0x8,%rsp
  a1:	5b                   	pop    %rbx
  a2:	41 5c                	pop    %r12
  a4:	41 5e                	pop    %r14
  a6:	41 5f                	pop    %r15
  a8:	c3                   	ret
  a9:	49 8d 77 10          	lea    0x10(%r15),%rsi
  ad:	bf 01 00 00 00       	mov    $0x1,%edi
  b2:	45 31 c0             	xor    %r8d,%r8d
  b5:	eb 50                	jmp    107 <verigmp::square_base::full+0x107>
  b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  be:	00 00 
  c0:	45 31 c9             	xor    %r9d,%r9d
  c3:	45 31 d2             	xor    %r10d,%r10d
  c6:	48 89 c8             	mov    %rcx,%rax
  c9:	4b f7 24 d6          	mulq   (%r14,%r10,8)
  cd:	49 8d 0c ff          	lea    (%r15,%rdi,8),%rcx
  d1:	45 31 db             	xor    %r11d,%r11d
  d4:	4e 03 0c d1          	add    (%rcx,%r10,8),%r9
  d8:	41 0f 92 c3          	setb   %r11b
  dc:	49 01 c1             	add    %rax,%r9
  df:	49 11 d3             	adc    %rdx,%r11
  e2:	4e 89 0c d1          	mov    %r9,(%rcx,%r10,8)
  e6:	4d 89 d9             	mov    %r11,%r9
  e9:	48 89 f8             	mov    %rdi,%rax
  ec:	48 c1 e0 04          	shl    $0x4,%rax
  f0:	4d 89 0c 07          	mov    %r9,(%r15,%rax,1)
  f4:	48 ff c7             	inc    %rdi
  f7:	49 ff c0             	inc    %r8
  fa:	48 83 c6 08          	add    $0x8,%rsi
  fe:	48 39 df             	cmp    %rbx,%rdi
 101:	0f 84 35 ff ff ff    	je     3c <verigmp::square_base::full+0x3c>
 107:	49 8b 0c fe          	mov    (%r14,%rdi,8),%rcx
 10b:	4d 85 c0             	test   %r8,%r8
 10e:	74 b0                	je     c0 <verigmp::square_base::full+0xc0>
 110:	49 89 fb             	mov    %rdi,%r11
 113:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
 117:	45 31 c9             	xor    %r9d,%r9d
 11a:	45 31 d2             	xor    %r10d,%r10d
 11d:	0f 1f 00             	nopl   (%rax)
 120:	48 89 c8             	mov    %rcx,%rax
 123:	4b f7 24 d6          	mulq   (%r14,%r10,8)
 127:	45 31 e4             	xor    %r12d,%r12d
 12a:	4e 03 4c d6 f8       	add    -0x8(%rsi,%r10,8),%r9
 12f:	41 0f 92 c4          	setb   %r12b
 133:	49 01 c1             	add    %rax,%r9
 136:	49 11 d4             	adc    %rdx,%r12
 139:	4e 89 4c d6 f8       	mov    %r9,-0x8(%rsi,%r10,8)
 13e:	48 89 c8             	mov    %rcx,%rax
 141:	4b f7 64 d6 08       	mulq   0x8(%r14,%r10,8)
 146:	45 31 c9             	xor    %r9d,%r9d
 149:	4e 03 24 d6          	add    (%rsi,%r10,8),%r12
 14d:	41 0f 92 c1          	setb   %r9b
 151:	49 01 c4             	add    %rax,%r12
 154:	49 11 d1             	adc    %rdx,%r9
 157:	4e 89 24 d6          	mov    %r12,(%rsi,%r10,8)
 15b:	49 83 c2 02          	add    $0x2,%r10
 15f:	4d 39 d3             	cmp    %r10,%r11
 162:	75 bc                	jne    120 <verigmp::square_base::full+0x120>
 164:	40 f6 c7 01          	test   $0x1,%dil
 168:	0f 85 58 ff ff ff    	jne    c6 <verigmp::square_base::full+0xc6>
 16e:	e9 76 ff ff ff       	jmp    e9 <verigmp::square_base::full+0xe9>
 173:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 17a <verigmp::square_base::full+0x17a>
			176: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.39-0x4
 17a:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 181 <verigmp::square_base::full+0x181>
			17d: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.40-0x4
 181:	be 3a 00 00 00       	mov    $0x3a,%esi
 186:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 18c <verigmp::square_base::full+0x18c>
			188: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 18c:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 193 <verigmp::square_base::full+0x193>
			18f: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.41-0x4
 193:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 19a <verigmp::square_base::full+0x19a>
			196: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.42-0x4
 19a:	be 24 00 00 00       	mov    $0x24,%esi
 19f:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a5 <verigmp::square_base::full+0x1a5>
			1a1: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp11square_spec12square_range:

0000000000000000 <verigmp::square_spec::square_range>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::square_spec::square_range+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::square_spec::square_range+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.45-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::square_spec::square_range+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp11square_spec13signed_square:

0000000000000000 <verigmp::square_spec::signed_square>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::square_spec::signed_square+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::square_spec::signed_square+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.46-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::square_spec::signed_square+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp11square_spec5cross:

0000000000000000 <verigmp::square_spec::cross>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::square_spec::cross+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::square_spec::cross+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.47-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::square_spec::cross+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp11square_spec9recompose:

0000000000000000 <verigmp::square_spec::recompose>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::square_spec::recompose+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::square_spec::recompose+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.48-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::square_spec::recompose+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp11toom_blocks12three_blocks:

0000000000000000 <verigmp::toom_blocks::three_blocks>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom_blocks::three_blocks+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom_blocks::three_blocks+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.50-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom_blocks::three_blocks+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp11toom_blocks16product_capacity:

0000000000000000 <verigmp::toom_blocks::product_capacity>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom_blocks::product_capacity+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom_blocks::product_capacity+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.51-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom_blocks::product_capacity+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp11toom_square4full:

0000000000000000 <verigmp::toom_square::full>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	48 83 ec 58          	sub    $0x58,%rsp
   e:	48 85 c9             	test   %rcx,%rcx
  11:	0f 84 3b 08 00 00    	je     852 <verigmp::toom_square::full+0x852>
  17:	48 8d 04 09          	lea    (%rcx,%rcx,1),%rax
  1b:	48 39 c6             	cmp    %rax,%rsi
  1e:	0f 85 15 08 00 00    	jne    839 <verigmp::toom_square::full+0x839>
  24:	48 8d 04 80          	lea    (%rax,%rax,4),%rax
  28:	49 39 c1             	cmp    %rax,%r9
  2b:	0f 82 08 08 00 00    	jb     839 <verigmp::toom_square::full+0x839>
  31:	4c 8b 94 24 90 00 00 	mov    0x90(%rsp),%r10
  38:	00 
  39:	49 83 fa 17          	cmp    $0x17,%r10
  3d:	0f 86 f6 07 00 00    	jbe    839 <verigmp::toom_square::full+0x839>
  43:	49 89 d4             	mov    %rdx,%r12
  46:	48 89 fb             	mov    %rdi,%rbx
  49:	4c 39 d1             	cmp    %r10,%rcx
  4c:	0f 86 cb 01 00 00    	jbe    21d <verigmp::toom_square::full+0x21d>
  52:	48 8d 41 02          	lea    0x2(%rcx),%rax
  56:	48 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdx
  5d:	aa aa aa 
  60:	48 f7 e2             	mul    %rdx
  63:	49 89 d5             	mov    %rdx,%r13
  66:	49 d1 ed             	shr    $1,%r13
  69:	4a 8d 14 6d 02 00 00 	lea    0x2(,%r13,2),%rdx
  70:	00 
  71:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
  75:	49 29 c1             	sub    %rax,%r9
  78:	49 29 d1             	sub    %rdx,%r9
  7b:	49 29 d1             	sub    %rdx,%r9
  7e:	0f 82 2f 08 00 00    	jb     8b3 <verigmp::toom_square::full+0x8b3>
  84:	4d 39 cd             	cmp    %r9,%r13
  87:	0f 83 3f 08 00 00    	jae    8cc <verigmp::toom_square::full+0x8cc>
  8d:	49 39 cd             	cmp    %rcx,%r13
  90:	0f 87 d5 07 00 00    	ja     86b <verigmp::toom_square::full+0x86b>
  96:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
  9b:	4a 8d 34 6d 00 00 00 	lea    0x0(,%r13,2),%rsi
  a2:	00 
  a3:	48 89 cd             	mov    %rcx,%rbp
  a6:	48 29 f5             	sub    %rsi,%rbp
  a9:	0f 82 36 08 00 00    	jb     8e5 <verigmp::toom_square::full+0x8e5>
  af:	49 8d 55 01          	lea    0x1(%r13),%rdx
  b3:	48 89 d1             	mov    %rdx,%rcx
  b6:	48 c1 e1 04          	shl    $0x4,%rcx
  ba:	49 8d 04 08          	lea    (%r8,%rcx,1),%rax
  be:	48 89 04 24          	mov    %rax,(%rsp)
  c2:	48 01 c8             	add    %rcx,%rax
  c5:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  ca:	48 01 c8             	add    %rcx,%rax
  cd:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  d2:	48 01 c1             	add    %rax,%rcx
  d5:	4a 8d 04 6d 02 00 00 	lea    0x2(,%r13,2),%rax
  dc:	00 
  dd:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  e2:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  e6:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  eb:	4c 8d 1c d0          	lea    (%rax,%rdx,8),%r11
  ef:	49 29 d1             	sub    %rdx,%r9
  f2:	48 83 ec 08          	sub    $0x8,%rsp
  f6:	4c 89 c7             	mov    %r8,%rdi
  f9:	4c 89 e2             	mov    %r12,%rdx
  fc:	4c 89 e9             	mov    %r13,%rcx
  ff:	4d 89 c7             	mov    %r8,%r15
 102:	4c 89 5c 24 28       	mov    %r11,0x28(%rsp)
 107:	4d 89 d8             	mov    %r11,%r8
 10a:	4d 89 ce             	mov    %r9,%r14
 10d:	41 52                	push   %r10
 10f:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 115 <verigmp::toom_square::full+0x115>
			111: R_X86_64_GOTPCREL	verigmp::toom_square::full-0x4
 115:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
 11c:	00 
 11d:	48 83 c4 10          	add    $0x10,%rsp
 121:	0f 57 c0             	xorps  %xmm0,%xmm0
 124:	4c 89 7c 24 48       	mov    %r15,0x48(%rsp)
 129:	41 0f 11 04 c7       	movups %xmm0,(%r15,%rax,8)
 12e:	4d 89 f1             	mov    %r14,%r9
 131:	4c 8d 74 2d 00       	lea    0x0(%rbp,%rbp,1),%r14
 136:	4a 8d 0c 6d 02 00 00 	lea    0x2(,%r13,2),%rcx
 13d:	00 
 13e:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
 143:	4a 8d 0c 6d 02 00 00 	lea    0x2(,%r13,2),%rcx
 14a:	00 
 14b:	4c 39 f1             	cmp    %r14,%rcx
 14e:	0f 82 2f 07 00 00    	jb     883 <verigmp::toom_square::full+0x883>
 154:	49 8d 14 c4          	lea    (%r12,%rax,8),%rdx
 158:	48 83 ec 08          	sub    $0x8,%rsp
 15c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
 161:	4c 89 f6             	mov    %r14,%rsi
 164:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
 169:	48 89 e9             	mov    %rbp,%rcx
 16c:	4c 8b 44 24 28       	mov    0x28(%rsp),%r8
 171:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
 176:	ff b4 24 98 00 00 00 	push   0x98(%rsp)
 17d:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 183 <verigmp::toom_square::full+0x183>
			17f: R_X86_64_GOTPCREL	verigmp::toom_square::full-0x4
 183:	48 83 c4 10          	add    $0x10,%rsp
 187:	4a 8d 14 6d 02 00 00 	lea    0x2(,%r13,2),%rdx
 18e:	00 
 18f:	4c 29 f2             	sub    %r14,%rdx
 192:	74 1c                	je     1b0 <verigmp::toom_square::full+0x1b0>
 194:	48 8b 04 24          	mov    (%rsp),%rax
 198:	4a 8d 3c f0          	lea    (%rax,%r14,8),%rdi
 19c:	48 83 fa 01          	cmp    $0x1,%rdx
 1a0:	48 83 d2 00          	adc    $0x0,%rdx
 1a4:	48 c1 e2 03          	shl    $0x3,%rdx
 1a8:	31 f6                	xor    %esi,%esi
 1aa:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1b0 <verigmp::toom_square::full+0x1b0>
			1ac: R_X86_64_GOTPCREL	memset-0x4
 1b0:	4c 39 ed             	cmp    %r13,%rbp
 1b3:	0f 87 e1 06 00 00    	ja     89a <verigmp::toom_square::full+0x89a>
 1b9:	4d 89 ea             	mov    %r13,%r10
 1bc:	49 c1 e2 04          	shl    $0x4,%r10
 1c0:	31 ff                	xor    %edi,%edi
 1c2:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
 1c7:	4c 89 c8             	mov    %r9,%rax
 1ca:	4c 89 e9             	mov    %r13,%rcx
 1cd:	4c 89 e2             	mov    %r12,%rdx
 1d0:	31 f6                	xor    %esi,%esi
 1d2:	4d 8d 45 01          	lea    0x1(%r13),%r8
 1d6:	4f 8d 04 c1          	lea    (%r9,%r8,8),%r8
 1da:	eb 37                	jmp    213 <verigmp::toom_square::full+0x213>
 1dc:	0f 1f 40 00          	nopl   0x0(%rax)
 1e0:	4e 8b 1c 12          	mov    (%rdx,%r10,1),%r11
 1e4:	45 31 c9             	xor    %r9d,%r9d
 1e7:	49 01 fb             	add    %rdi,%r11
 1ea:	41 0f 92 c1          	setb   %r9b
 1ee:	4e 03 1c ea          	add    (%rdx,%r13,8),%r11
 1f2:	49 83 d1 00          	adc    $0x0,%r9
 1f6:	4c 03 1a             	add    (%rdx),%r11
 1f9:	4c 89 cf             	mov    %r9,%rdi
 1fc:	48 83 d7 00          	adc    $0x0,%rdi
 200:	4c 89 18             	mov    %r11,(%rax)
 203:	48 ff c6             	inc    %rsi
 206:	48 83 c2 08          	add    $0x8,%rdx
 20a:	48 83 c0 08          	add    $0x8,%rax
 20e:	48 ff c9             	dec    %rcx
 211:	74 25                	je     238 <verigmp::toom_square::full+0x238>
 213:	48 39 ee             	cmp    %rbp,%rsi
 216:	72 c8                	jb     1e0 <verigmp::toom_square::full+0x1e0>
 218:	45 31 db             	xor    %r11d,%r11d
 21b:	eb c7                	jmp    1e4 <verigmp::toom_square::full+0x1e4>
 21d:	48 83 ec 08          	sub    $0x8,%rsp
 221:	48 89 df             	mov    %rbx,%rdi
 224:	4c 89 e2             	mov    %r12,%rdx
 227:	6a 18                	push   $0x18
 229:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 22f <verigmp::toom_square::full+0x22f>
			22b: R_X86_64_GOTPCREL	verigmp::square::full-0x4
 22f:	48 83 c4 68          	add    $0x68,%rsp
 233:	e9 f6 05 00 00       	jmp    82e <verigmp::toom_square::full+0x82e>
 238:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
 23d:	4b 89 3c ef          	mov    %rdi,(%r15,%r13,8)
 241:	48 83 ec 08          	sub    $0x8,%rsp
 245:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 24a:	4a 8d 34 6d 02 00 00 	lea    0x2(,%r13,2),%rsi
 251:	00 
 252:	4c 89 fa             	mov    %r15,%rdx
 255:	49 8d 4d 01          	lea    0x1(%r13),%rcx
 259:	4c 89 54 24 10       	mov    %r10,0x10(%rsp)
 25e:	4c 8b 74 24 38       	mov    0x38(%rsp),%r14
 263:	4d 89 f1             	mov    %r14,%r9
 266:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
 26d:	00 
 26e:	50                   	push   %rax
 26f:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 275 <verigmp::toom_square::full+0x275>
			271: R_X86_64_GOTPCREL	verigmp::toom_square::full-0x4
 275:	48 83 c4 10          	add    $0x10,%rsp
 279:	4c 89 ff             	mov    %r15,%rdi
 27c:	49 8d 75 01          	lea    0x1(%r13),%rsi
 280:	4c 89 e2             	mov    %r12,%rdx
 283:	4c 89 e9             	mov    %r13,%rcx
 286:	4f 8d 04 ec          	lea    (%r12,%r13,8),%r8
 28a:	4d 89 e9             	mov    %r13,%r9
 28d:	55                   	push   %rbp
 28e:	ff 74 24 48          	push   0x48(%rsp)
 292:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 298 <verigmp::toom_square::full+0x298>
			294: R_X86_64_GOTPCREL	verigmp::toom_evaluate::negative-0x4
 298:	48 83 c4 08          	add    $0x8,%rsp
 29c:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
 2a1:	4a 8d 34 6d 02 00 00 	lea    0x2(,%r13,2),%rsi
 2a8:	00 
 2a9:	4c 89 fa             	mov    %r15,%rdx
 2ac:	49 8d 4d 01          	lea    0x1(%r13),%rcx
 2b0:	4c 8b 44 24 28       	mov    0x28(%rsp),%r8
 2b5:	4d 89 f1             	mov    %r14,%r9
 2b8:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
 2bd:	ff b4 24 98 00 00 00 	push   0x98(%rsp)
 2c4:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2ca <verigmp::toom_square::full+0x2ca>
			2c6: R_X86_64_GOTPCREL	verigmp::toom_square::full-0x4
 2ca:	48 83 c4 10          	add    $0x10,%rsp
 2ce:	31 f6                	xor    %esi,%esi
 2d0:	4c 89 f8             	mov    %r15,%rax
 2d3:	4c 89 e9             	mov    %r13,%rcx
 2d6:	31 d2                	xor    %edx,%edx
 2d8:	4c 8b 7c 24 48       	mov    0x48(%rsp),%r15
 2dd:	eb 49                	jmp    328 <verigmp::toom_square::full+0x328>
 2df:	90                   	nop
 2e0:	4b 8b 3c 34          	mov    (%r12,%r14,1),%rdi
 2e4:	4f 8b 04 ec          	mov    (%r12,%r13,8),%r8
 2e8:	4d 89 c1             	mov    %r8,%r9
 2eb:	49 c1 e9 3f          	shr    $0x3f,%r9
 2ef:	4d 01 c0             	add    %r8,%r8
 2f2:	49 89 fa             	mov    %rdi,%r10
 2f5:	49 c1 ea 3e          	shr    $0x3e,%r10
 2f9:	48 c1 e7 02          	shl    $0x2,%rdi
 2fd:	48 01 f7             	add    %rsi,%rdi
 300:	49 83 d2 00          	adc    $0x0,%r10
 304:	49 03 3c 24          	add    (%r12),%rdi
 308:	49 83 d2 00          	adc    $0x0,%r10
 30c:	4c 01 c7             	add    %r8,%rdi
 30f:	4c 89 d6             	mov    %r10,%rsi
 312:	4c 11 ce             	adc    %r9,%rsi
 315:	48 89 38             	mov    %rdi,(%rax)
 318:	48 ff c2             	inc    %rdx
 31b:	49 83 c4 08          	add    $0x8,%r12
 31f:	48 83 c0 08          	add    $0x8,%rax
 323:	48 ff c9             	dec    %rcx
 326:	74 09                	je     331 <verigmp::toom_square::full+0x331>
 328:	48 39 ea             	cmp    %rbp,%rdx
 32b:	72 b3                	jb     2e0 <verigmp::toom_square::full+0x2e0>
 32d:	31 ff                	xor    %edi,%edi
 32f:	eb b3                	jmp    2e4 <verigmp::toom_square::full+0x2e4>
 331:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 336:	4a 89 34 ea          	mov    %rsi,(%rdx,%r13,8)
 33a:	48 83 ec 08          	sub    $0x8,%rsp
 33e:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
 343:	48 89 ef             	mov    %rbp,%rdi
 346:	4e 8d 24 6d 02 00 00 	lea    0x2(,%r13,2),%r12
 34d:	00 
 34e:	4c 89 e6             	mov    %r12,%rsi
 351:	49 8d 4d 01          	lea    0x1(%r13),%rcx
 355:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
 35a:	4d 89 f0             	mov    %r14,%r8
 35d:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
 362:	ff b4 24 98 00 00 00 	push   0x98(%rsp)
 369:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 36f <verigmp::toom_square::full+0x36f>
			36b: R_X86_64_GOTPCREL	verigmp::toom_square::full-0x4
 36f:	48 83 c4 08          	add    $0x8,%rsp
 373:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 378:	4c 89 e6             	mov    %r12,%rsi
 37b:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 380:	4c 89 e1             	mov    %r12,%rcx
 383:	49 89 e8             	mov    %rbp,%r8
 386:	4d 89 e1             	mov    %r12,%r9
 389:	41 54                	push   %r12
 38b:	41 56                	push   %r14
 38d:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
 392:	6a 00                	push   $0x0
 394:	41 54                	push   %r12
 396:	ff 74 24 28          	push   0x28(%rsp)
 39a:	41 54                	push   %r12
 39c:	41 57                	push   %r15
 39e:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 3a4 <verigmp::toom_square::full+0x3a4>
			3a0: R_X86_64_GOTPCREL	verigmp::toom_interpolate::interpolate-0x4
 3a4:	48 83 c4 40          	add    $0x40,%rsp
 3a8:	48 8b 6c 24 50       	mov    0x50(%rsp),%rbp
 3ad:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
 3b4:	00 
 3b5:	45 31 e4             	xor    %r12d,%r12d
 3b8:	48 89 df             	mov    %rbx,%rdi
 3bb:	31 f6                	xor    %esi,%esi
 3bd:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 3c3 <verigmp::toom_square::full+0x3c3>
			3bf: R_X86_64_GOTPCREL	memset-0x4
 3c3:	49 8d 4e 10          	lea    0x10(%r14),%rcx
 3c7:	31 c0                	xor    %eax,%eax
 3c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 3d0:	31 d2                	xor    %edx,%edx
 3d2:	4c 03 24 03          	add    (%rbx,%rax,1),%r12
 3d6:	0f 92 c2             	setb   %dl
 3d9:	4d 03 24 07          	add    (%r15,%rax,1),%r12
 3dd:	4c 89 24 03          	mov    %r12,(%rbx,%rax,1)
 3e1:	48 13 54 03 08       	adc    0x8(%rbx,%rax,1),%rdx
 3e6:	40 0f 92 c6          	setb   %sil
 3ea:	44 0f b6 e6          	movzbl %sil,%r12d
 3ee:	49 03 54 07 08       	add    0x8(%r15,%rax,1),%rdx
 3f3:	49 83 d4 00          	adc    $0x0,%r12
 3f7:	48 89 54 03 08       	mov    %rdx,0x8(%rbx,%rax,1)
 3fc:	48 83 c0 10          	add    $0x10,%rax
 400:	48 39 c1             	cmp    %rax,%rcx
 403:	75 cb                	jne    3d0 <verigmp::toom_square::full+0x3d0>
 405:	4d 85 e4             	test   %r12,%r12
 408:	4f 8d 5c 2d 00       	lea    0x0(%r13,%r13,1),%r11
 40d:	74 3f                	je     44e <verigmp::toom_square::full+0x44e>
 40f:	48 89 e8             	mov    %rbp,%rax
 412:	4a 8d 14 6d 02 00 00 	lea    0x2(,%r13,2),%rdx
 419:	00 
 41a:	48 29 d0             	sub    %rdx,%rax
 41d:	48 8d 14 d3          	lea    (%rbx,%rdx,8),%rdx
 421:	be 01 00 00 00       	mov    $0x1,%esi
 426:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 42d:	00 00 00 
 430:	31 ff                	xor    %edi,%edi
 432:	4c 01 64 f2 f8       	add    %r12,-0x8(%rdx,%rsi,8)
 437:	41 0f 92 c0          	setb   %r8b
 43b:	48 39 c6             	cmp    %rax,%rsi
 43e:	73 0e                	jae    44e <verigmp::toom_square::full+0x44e>
 440:	44 88 c7             	mov    %r8b,%dil
 443:	48 ff c6             	inc    %rsi
 446:	49 89 fc             	mov    %rdi,%r12
 449:	40 84 ff             	test   %dil,%dil
 44c:	75 e2                	jne    430 <verigmp::toom_square::full+0x430>
 44e:	4a 8d 34 eb          	lea    (%rbx,%r13,8),%rsi
 452:	4c 89 e8             	mov    %r13,%rax
 455:	48 c1 e0 05          	shl    $0x5,%rax
 459:	4a 8d 3c 38          	lea    (%rax,%r15,1),%rdi
 45d:	48 83 c7 28          	add    $0x28,%rdi
 461:	31 d2                	xor    %edx,%edx
 463:	45 31 c0             	xor    %r8d,%r8d
 466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 46d:	00 00 00 
 470:	45 31 c9             	xor    %r9d,%r9d
 473:	4a 03 14 06          	add    (%rsi,%r8,1),%rdx
 477:	41 0f 92 c1          	setb   %r9b
 47b:	4a 03 54 07 f8       	add    -0x8(%rdi,%r8,1),%rdx
 480:	4a 89 14 06          	mov    %rdx,(%rsi,%r8,1)
 484:	4e 13 4c 06 08       	adc    0x8(%rsi,%r8,1),%r9
 489:	0f 92 c2             	setb   %dl
 48c:	0f b6 d2             	movzbl %dl,%edx
 48f:	4e 03 0c 07          	add    (%rdi,%r8,1),%r9
 493:	48 83 d2 00          	adc    $0x0,%rdx
 497:	4e 89 4c 06 08       	mov    %r9,0x8(%rsi,%r8,1)
 49c:	49 83 c0 10          	add    $0x10,%r8
 4a0:	4c 39 c1             	cmp    %r8,%rcx
 4a3:	75 cb                	jne    470 <verigmp::toom_square::full+0x470>
 4a5:	48 85 d2             	test   %rdx,%rdx
 4a8:	4f 8d 64 2d 02       	lea    0x2(%r13,%r13,1),%r12
 4ad:	74 3f                	je     4ee <verigmp::toom_square::full+0x4ee>
 4af:	48 89 ef             	mov    %rbp,%rdi
 4b2:	4c 29 ef             	sub    %r13,%rdi
 4b5:	4c 29 e7             	sub    %r12,%rdi
 4b8:	4a 8d 34 e6          	lea    (%rsi,%r12,8),%rsi
 4bc:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 4c2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 4c9:	1f 84 00 00 00 00 00 
 4d0:	45 31 c9             	xor    %r9d,%r9d
 4d3:	4a 01 54 c6 f8       	add    %rdx,-0x8(%rsi,%r8,8)
 4d8:	0f 92 c2             	setb   %dl
 4db:	49 39 f8             	cmp    %rdi,%r8
 4de:	73 0e                	jae    4ee <verigmp::toom_square::full+0x4ee>
 4e0:	41 88 d1             	mov    %dl,%r9b
 4e3:	49 ff c0             	inc    %r8
 4e6:	4c 89 ca             	mov    %r9,%rdx
 4e9:	45 84 c9             	test   %r9b,%r9b
 4ec:	75 e2                	jne    4d0 <verigmp::toom_square::full+0x4d0>
 4ee:	48 89 ee             	mov    %rbp,%rsi
 4f1:	4c 29 de             	sub    %r11,%rsi
 4f4:	4a 8d 14 db          	lea    (%rbx,%r11,8),%rdx
 4f8:	4c 39 e6             	cmp    %r12,%rsi
 4fb:	73 16                	jae    513 <verigmp::toom_square::full+0x513>
 4fd:	49 8d 73 01          	lea    0x1(%r11),%rsi
 501:	48 39 f5             	cmp    %rsi,%rbp
 504:	0f 85 be 00 00 00    	jne    5c8 <verigmp::toom_square::full+0x5c8>
 50a:	31 f6                	xor    %esi,%esi
 50c:	31 ff                	xor    %edi,%edi
 50e:	e9 2a 01 00 00       	jmp    63d <verigmp::toom_square::full+0x63d>
 513:	4d 8d 04 1e          	lea    (%r14,%rbx,1),%r8
 517:	49 83 c0 08          	add    $0x8,%r8
 51b:	4a 8d 3c 6d 00 00 00 	lea    0x0(,%r13,2),%rdi
 522:	00 
 523:	4c 01 ef             	add    %r13,%rdi
 526:	48 c1 e7 04          	shl    $0x4,%rdi
 52a:	4e 8d 0c 3f          	lea    (%rdi,%r15,1),%r9
 52e:	49 83 c1 38          	add    $0x38,%r9
 532:	31 ff                	xor    %edi,%edi
 534:	45 31 d2             	xor    %r10d,%r10d
 537:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 53e:	00 00 
 540:	45 31 db             	xor    %r11d,%r11d
 543:	4b 03 7c 10 f8       	add    -0x8(%r8,%r10,1),%rdi
 548:	41 0f 92 c3          	setb   %r11b
 54c:	4b 03 7c 11 f8       	add    -0x8(%r9,%r10,1),%rdi
 551:	4b 89 7c 10 f8       	mov    %rdi,-0x8(%r8,%r10,1)
 556:	4f 13 1c 10          	adc    (%r8,%r10,1),%r11
 55a:	40 0f 92 c7          	setb   %dil
 55e:	40 0f b6 ff          	movzbl %dil,%edi
 562:	4f 03 1c 11          	add    (%r9,%r10,1),%r11
 566:	48 83 d7 00          	adc    $0x0,%rdi
 56a:	4f 89 1c 10          	mov    %r11,(%r8,%r10,1)
 56e:	49 83 c2 10          	add    $0x10,%r10
 572:	4c 39 d1             	cmp    %r10,%rcx
 575:	75 c9                	jne    540 <verigmp::toom_square::full+0x540>
 577:	4c 29 e6             	sub    %r12,%rsi
 57a:	0f 84 ce 00 00 00    	je     64e <verigmp::toom_square::full+0x64e>
 580:	48 85 ff             	test   %rdi,%rdi
 583:	0f 84 c5 00 00 00    	je     64e <verigmp::toom_square::full+0x64e>
 589:	4a 8d 14 e2          	lea    (%rdx,%r12,8),%rdx
 58d:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 593:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 59a:	84 00 00 00 00 00 
 5a0:	45 31 c9             	xor    %r9d,%r9d
 5a3:	4a 01 7c c2 f8       	add    %rdi,-0x8(%rdx,%r8,8)
 5a8:	40 0f 92 c7          	setb   %dil
 5ac:	49 39 f0             	cmp    %rsi,%r8
 5af:	0f 83 99 00 00 00    	jae    64e <verigmp::toom_square::full+0x64e>
 5b5:	41 88 f9             	mov    %dil,%r9b
 5b8:	49 ff c0             	inc    %r8
 5bb:	4c 89 cf             	mov    %r9,%rdi
 5be:	45 84 c9             	test   %r9b,%r9b
 5c1:	75 dd                	jne    5a0 <verigmp::toom_square::full+0x5a0>
 5c3:	e9 86 00 00 00       	jmp    64e <verigmp::toom_square::full+0x64e>
 5c8:	4d 8d 04 1e          	lea    (%r14,%rbx,1),%r8
 5cc:	49 83 c0 08          	add    $0x8,%r8
 5d0:	4a 8d 34 6d 00 00 00 	lea    0x0(,%r13,2),%rsi
 5d7:	00 
 5d8:	4c 01 ee             	add    %r13,%rsi
 5db:	48 c1 e6 04          	shl    $0x4,%rsi
 5df:	4e 8d 0c 3e          	lea    (%rsi,%r15,1),%r9
 5e3:	49 83 c1 38          	add    $0x38,%r9
 5e7:	49 89 ea             	mov    %rbp,%r10
 5ea:	49 83 e2 fe          	and    $0xfffffffffffffffe,%r10
 5ee:	4d 29 da             	sub    %r11,%r10
 5f1:	31 f6                	xor    %esi,%esi
 5f3:	31 ff                	xor    %edi,%edi
 5f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 5fc:	00 00 00 00 
 600:	45 31 db             	xor    %r11d,%r11d
 603:	49 03 74 f8 f8       	add    -0x8(%r8,%rdi,8),%rsi
 608:	41 0f 92 c3          	setb   %r11b
 60c:	49 03 74 f9 f8       	add    -0x8(%r9,%rdi,8),%rsi
 611:	49 89 74 f8 f8       	mov    %rsi,-0x8(%r8,%rdi,8)
 616:	4d 13 1c f8          	adc    (%r8,%rdi,8),%r11
 61a:	40 0f 92 c6          	setb   %sil
 61e:	40 0f b6 f6          	movzbl %sil,%esi
 622:	4d 03 1c f9          	add    (%r9,%rdi,8),%r11
 626:	48 83 d6 00          	adc    $0x0,%rsi
 62a:	4d 89 1c f8          	mov    %r11,(%r8,%rdi,8)
 62e:	48 83 c7 02          	add    $0x2,%rdi
 632:	49 39 fa             	cmp    %rdi,%r10
 635:	75 c9                	jne    600 <verigmp::toom_square::full+0x600>
 637:	40 f6 c5 01          	test   $0x1,%bpl
 63b:	74 11                	je     64e <verigmp::toom_square::full+0x64e>
 63d:	48 03 34 fa          	add    (%rdx,%rdi,8),%rsi
 641:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
 646:	49 03 34 f8          	add    (%r8,%rdi,8),%rsi
 64a:	48 89 34 fa          	mov    %rsi,(%rdx,%rdi,8)
 64e:	4a 8d 3c 6d 00 00 00 	lea    0x0(,%r13,2),%rdi
 655:	00 
 656:	4c 01 ef             	add    %r13,%rdi
 659:	48 89 ea             	mov    %rbp,%rdx
 65c:	48 29 fa             	sub    %rdi,%rdx
 65f:	48 8d 34 fb          	lea    (%rbx,%rdi,8),%rsi
 663:	4c 39 e2             	cmp    %r12,%rdx
 666:	73 1a                	jae    682 <verigmp::toom_square::full+0x682>
 668:	48 8d 4f 01          	lea    0x1(%rdi),%rcx
 66c:	48 39 cd             	cmp    %rcx,%rbp
 66f:	0f 85 b0 00 00 00    	jne    725 <verigmp::toom_square::full+0x725>
 675:	31 c9                	xor    %ecx,%ecx
 677:	31 ff                	xor    %edi,%edi
 679:	4c 8b 14 24          	mov    (%rsp),%r10
 67d:	e9 0c 01 00 00       	jmp    78e <verigmp::toom_square::full+0x78e>
 682:	4c 8d 04 fb          	lea    (%rbx,%rdi,8),%r8
 686:	49 83 c0 08          	add    $0x8,%r8
 68a:	4c 89 ef             	mov    %r13,%rdi
 68d:	48 c1 e7 06          	shl    $0x6,%rdi
 691:	4e 8d 0c 3f          	lea    (%rdi,%r15,1),%r9
 695:	49 83 c1 48          	add    $0x48,%r9
 699:	31 ff                	xor    %edi,%edi
 69b:	45 31 d2             	xor    %r10d,%r10d
 69e:	66 90                	xchg   %ax,%ax
 6a0:	45 31 db             	xor    %r11d,%r11d
 6a3:	4b 03 7c 10 f8       	add    -0x8(%r8,%r10,1),%rdi
 6a8:	41 0f 92 c3          	setb   %r11b
 6ac:	4b 03 7c 11 f8       	add    -0x8(%r9,%r10,1),%rdi
 6b1:	4b 89 7c 10 f8       	mov    %rdi,-0x8(%r8,%r10,1)
 6b6:	4f 13 1c 10          	adc    (%r8,%r10,1),%r11
 6ba:	40 0f 92 c7          	setb   %dil
 6be:	40 0f b6 ff          	movzbl %dil,%edi
 6c2:	4f 03 1c 11          	add    (%r9,%r10,1),%r11
 6c6:	48 83 d7 00          	adc    $0x0,%rdi
 6ca:	4f 89 1c 10          	mov    %r11,(%r8,%r10,1)
 6ce:	49 83 c2 10          	add    $0x10,%r10
 6d2:	4c 39 d1             	cmp    %r10,%rcx
 6d5:	75 c9                	jne    6a0 <verigmp::toom_square::full+0x6a0>
 6d7:	4c 29 e2             	sub    %r12,%rdx
 6da:	4c 8b 14 24          	mov    (%rsp),%r10
 6de:	0f 84 bb 00 00 00    	je     79f <verigmp::toom_square::full+0x79f>
 6e4:	48 85 ff             	test   %rdi,%rdi
 6e7:	0f 84 b2 00 00 00    	je     79f <verigmp::toom_square::full+0x79f>
 6ed:	4a 8d 0c e6          	lea    (%rsi,%r12,8),%rcx
 6f1:	be 01 00 00 00       	mov    $0x1,%esi
 6f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 6fd:	00 00 00 
 700:	45 31 c0             	xor    %r8d,%r8d
 703:	48 01 7c f1 f8       	add    %rdi,-0x8(%rcx,%rsi,8)
 708:	40 0f 92 c7          	setb   %dil
 70c:	48 39 d6             	cmp    %rdx,%rsi
 70f:	0f 83 8a 00 00 00    	jae    79f <verigmp::toom_square::full+0x79f>
 715:	41 88 f8             	mov    %dil,%r8b
 718:	48 ff c6             	inc    %rsi
 71b:	4c 89 c7             	mov    %r8,%rdi
 71e:	45 84 c0             	test   %r8b,%r8b
 721:	75 dd                	jne    700 <verigmp::toom_square::full+0x700>
 723:	eb 7a                	jmp    79f <verigmp::toom_square::full+0x79f>
 725:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
 72c:	ff ff 0f 
 72f:	49 21 d0             	and    %rdx,%r8
 732:	4c 8d 0c fb          	lea    (%rbx,%rdi,8),%r9
 736:	49 83 c1 08          	add    $0x8,%r9
 73a:	4c 89 e9             	mov    %r13,%rcx
 73d:	48 c1 e1 06          	shl    $0x6,%rcx
 741:	4e 8d 14 39          	lea    (%rcx,%r15,1),%r10
 745:	49 83 c2 48          	add    $0x48,%r10
 749:	31 c9                	xor    %ecx,%ecx
 74b:	31 ff                	xor    %edi,%edi
 74d:	0f 1f 00             	nopl   (%rax)
 750:	45 31 db             	xor    %r11d,%r11d
 753:	49 03 4c f9 f8       	add    -0x8(%r9,%rdi,8),%rcx
 758:	41 0f 92 c3          	setb   %r11b
 75c:	49 03 4c fa f8       	add    -0x8(%r10,%rdi,8),%rcx
 761:	49 89 4c f9 f8       	mov    %rcx,-0x8(%r9,%rdi,8)
 766:	4d 13 1c f9          	adc    (%r9,%rdi,8),%r11
 76a:	0f 92 c1             	setb   %cl
 76d:	0f b6 c9             	movzbl %cl,%ecx
 770:	4d 03 1c fa          	add    (%r10,%rdi,8),%r11
 774:	48 83 d1 00          	adc    $0x0,%rcx
 778:	4d 89 1c f9          	mov    %r11,(%r9,%rdi,8)
 77c:	48 83 c7 02          	add    $0x2,%rdi
 780:	49 39 f8             	cmp    %rdi,%r8
 783:	75 cb                	jne    750 <verigmp::toom_square::full+0x750>
 785:	f6 c2 01             	test   $0x1,%dl
 788:	4c 8b 14 24          	mov    (%rsp),%r10
 78c:	74 11                	je     79f <verigmp::toom_square::full+0x79f>
 78e:	48 03 0c fe          	add    (%rsi,%rdi,8),%rcx
 792:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 797:	48 03 0c fa          	add    (%rdx,%rdi,8),%rcx
 79b:	48 89 0c fe          	mov    %rcx,(%rsi,%rdi,8)
 79f:	49 c1 e5 02          	shl    $0x2,%r13
 7a3:	4c 39 ed             	cmp    %r13,%rbp
 7a6:	0f 84 7e 00 00 00    	je     82a <verigmp::toom_square::full+0x82a>
 7ac:	49 8d 4d 01          	lea    0x1(%r13),%rcx
 7b0:	48 39 cd             	cmp    %rcx,%rbp
 7b3:	75 06                	jne    7bb <verigmp::toom_square::full+0x7bb>
 7b5:	31 c9                	xor    %ecx,%ecx
 7b7:	31 d2                	xor    %edx,%edx
 7b9:	eb 60                	jmp    81b <verigmp::toom_square::full+0x81b>
 7bb:	48 8d 34 18          	lea    (%rax,%rbx,1),%rsi
 7bf:	48 83 c6 08          	add    $0x8,%rsi
 7c3:	4b 8d 3c 3e          	lea    (%r14,%r15,1),%rdi
 7c7:	48 83 c7 18          	add    $0x18,%rdi
 7cb:	49 89 e8             	mov    %rbp,%r8
 7ce:	49 83 e0 fe          	and    $0xfffffffffffffffe,%r8
 7d2:	4d 29 e8             	sub    %r13,%r8
 7d5:	31 c9                	xor    %ecx,%ecx
 7d7:	31 d2                	xor    %edx,%edx
 7d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 7e0:	45 31 c9             	xor    %r9d,%r9d
 7e3:	48 03 4c d6 f8       	add    -0x8(%rsi,%rdx,8),%rcx
 7e8:	41 0f 92 c1          	setb   %r9b
 7ec:	48 03 4c d7 f8       	add    -0x8(%rdi,%rdx,8),%rcx
 7f1:	48 89 4c d6 f8       	mov    %rcx,-0x8(%rsi,%rdx,8)
 7f6:	4c 13 0c d6          	adc    (%rsi,%rdx,8),%r9
 7fa:	0f 92 c1             	setb   %cl
 7fd:	0f b6 c9             	movzbl %cl,%ecx
 800:	4c 03 0c d7          	add    (%rdi,%rdx,8),%r9
 804:	48 83 d1 00          	adc    $0x0,%rcx
 808:	4c 89 0c d6          	mov    %r9,(%rsi,%rdx,8)
 80c:	48 83 c2 02          	add    $0x2,%rdx
 810:	49 39 d0             	cmp    %rdx,%r8
 813:	75 cb                	jne    7e0 <verigmp::toom_square::full+0x7e0>
 815:	40 f6 c5 01          	test   $0x1,%bpl
 819:	74 0f                	je     82a <verigmp::toom_square::full+0x82a>
 81b:	48 01 c3             	add    %rax,%rbx
 81e:	48 03 0c d3          	add    (%rbx,%rdx,8),%rcx
 822:	49 03 0c d2          	add    (%r10,%rdx,8),%rcx
 826:	48 89 0c d3          	mov    %rcx,(%rbx,%rdx,8)
 82a:	48 83 c4 58          	add    $0x58,%rsp
 82e:	5b                   	pop    %rbx
 82f:	41 5c                	pop    %r12
 831:	41 5d                	pop    %r13
 833:	41 5e                	pop    %r14
 835:	41 5f                	pop    %r15
 837:	5d                   	pop    %rbp
 838:	c3                   	ret
 839:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 840 <verigmp::toom_square::full+0x840>
			83c: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.55-0x4
 840:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 847 <verigmp::toom_square::full+0x847>
			843: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.56-0x4
 847:	be 5e 00 00 00       	mov    $0x5e,%esi
 84c:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 852 <verigmp::toom_square::full+0x852>
			84e: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 852:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 859 <verigmp::toom_square::full+0x859>
			855: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.52-0x4
 859:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 860 <verigmp::toom_square::full+0x860>
			85c: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.54-0x4
 860:	be 51 00 00 00       	mov    $0x51,%esi
 865:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 86b <verigmp::toom_square::full+0x86b>
			867: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 86b:	48 8d 05 00 00 00 00 	lea    0x0(%rip),%rax        # 872 <verigmp::toom_square::full+0x872>
			86e: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.61-0x4
 872:	31 ff                	xor    %edi,%edi
 874:	4c 89 ee             	mov    %r13,%rsi
 877:	48 89 ca             	mov    %rcx,%rdx
 87a:	48 89 c1             	mov    %rax,%rcx
 87d:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 883 <verigmp::toom_square::full+0x883>
			87f: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 883:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 88a <verigmp::toom_square::full+0x88a>
			886: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.59-0x4
 88a:	31 ff                	xor    %edi,%edi
 88c:	4c 89 f6             	mov    %r14,%rsi
 88f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 894:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 89a <verigmp::toom_square::full+0x89a>
			896: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 89a:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8a1 <verigmp::toom_square::full+0x8a1>
			89d: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.117-0x4
 8a1:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 8a8 <verigmp::toom_square::full+0x8a8>
			8a4: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.122-0x4
 8a8:	be 3e 00 00 00       	mov    $0x3e,%esi
 8ad:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 8b3 <verigmp::toom_square::full+0x8b3>
			8af: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 8b3:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8ba <verigmp::toom_square::full+0x8ba>
			8b6: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.0-0x4
 8ba:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 8c1 <verigmp::toom_square::full+0x8c1>
			8bd: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.57-0x4
 8c1:	be 13 00 00 00       	mov    $0x13,%esi
 8c6:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 8cc <verigmp::toom_square::full+0x8cc>
			8c8: R_X86_64_GOTPCREL	core::panicking::panic_fmt-0x4
 8cc:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8d3 <verigmp::toom_square::full+0x8d3>
			8cf: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.0-0x4
 8d3:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 8da <verigmp::toom_square::full+0x8da>
			8d6: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.58-0x4
 8da:	be 13 00 00 00       	mov    $0x13,%esi
 8df:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 8e5 <verigmp::toom_square::full+0x8e5>
			8e1: R_X86_64_GOTPCREL	core::panicking::panic_fmt-0x4
 8e5:	48 8d 05 00 00 00 00 	lea    0x0(%rip),%rax        # 8ec <verigmp::toom_square::full+0x8ec>
			8e8: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.60-0x4
 8ec:	4c 89 ef             	mov    %r13,%rdi
 8ef:	48 89 ca             	mov    %rcx,%rdx
 8f2:	48 89 c1             	mov    %rax,%rcx
 8f5:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 8fb <verigmp::toom_square::full+0x8fb>
			8f7: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product10prefix_mod:

0000000000000000 <verigmp::fast_product::prefix_mod>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::prefix_mod+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::prefix_mod+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.63-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::prefix_mod+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product12low_identity:

0000000000000000 <verigmp::fast_product::low_identity>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::low_identity+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::low_identity+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.64-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::low_identity+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product12prefix_frame:

0000000000000000 <verigmp::fast_product::prefix_frame>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::prefix_frame+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::prefix_frame+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.65-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::prefix_frame+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product13extended_step:

0000000000000000 <verigmp::fast_product::extended_step>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::extended_step+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::extended_step+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.66-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::extended_step+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product13segment_split:

0000000000000000 <verigmp::fast_product::segment_split>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::segment_split+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::segment_split+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.67-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::segment_split+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product14mod_add_scaled:

0000000000000000 <verigmp::fast_product::mod_add_scaled>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::mod_add_scaled+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::mod_add_scaled+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.68-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::mod_add_scaled+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product16congruent_suffix:

0000000000000000 <verigmp::fast_product::congruent_suffix>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::congruent_suffix+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::congruent_suffix+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.69-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::congruent_suffix+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product18karatsuba_identity:

0000000000000000 <verigmp::fast_product::karatsuba_identity>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::karatsuba_identity+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::karatsuba_identity+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.70-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::karatsuba_identity+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product4part:

0000000000000000 <verigmp::fast_product::part>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::part+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::part+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.71-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::part+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product5digit:

0000000000000000 <verigmp::fast_product::digit>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::digit+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::digit+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.72-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::digit+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product5split:

0000000000000000 <verigmp::fast_product::split>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::split+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::split+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.73-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::split+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp12fast_product8extended:

0000000000000000 <verigmp::fast_product::extended>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::fast_product::extended+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::fast_product::extended+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.74-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::fast_product::extended+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp13fast_multiply3low:

0000000000000000 <verigmp::fast_multiply::low>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	48 83 ec 28          	sub    $0x28,%rsp
   e:	48 85 c9             	test   %rcx,%rcx
  11:	0f 84 c8 04 00 00    	je     4df <verigmp::fast_multiply::low+0x4df>
  17:	4c 39 c9             	cmp    %r9,%rcx
  1a:	0f 85 bf 04 00 00    	jne    4df <verigmp::fast_multiply::low+0x4df>
  20:	4d 89 c4             	mov    %r8,%r12
  23:	49 89 d3             	mov    %rdx,%r11
  26:	49 89 fe             	mov    %rdi,%r14
  29:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
  2e:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
  33:	48 39 ce             	cmp    %rcx,%rsi
  36:	0f 94 c2             	sete   %dl
  39:	48 8d 04 8d 00 00 00 	lea    0x0(,%rcx,4),%rax
  40:	00 
  41:	48 39 c7             	cmp    %rax,%rdi
  44:	0f 93 c0             	setae  %al
  47:	20 d0                	and    %dl,%al
  49:	49 83 f8 08          	cmp    $0x8,%r8
  4d:	0f 82 44 04 00 00    	jb     497 <verigmp::fast_multiply::low+0x497>
  53:	48 89 ce             	mov    %rcx,%rsi
  56:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  5b:	48 83 f9 08          	cmp    $0x8,%rcx
  5f:	0f 82 32 04 00 00    	jb     497 <verigmp::fast_multiply::low+0x497>
  65:	84 c0                	test   %al,%al
  67:	0f 84 47 04 00 00    	je     4b4 <verigmp::fast_multiply::low+0x4b4>
  6d:	48 39 ce             	cmp    %rcx,%rsi
  70:	48 89 34 24          	mov    %rsi,(%rsp)
  74:	76 50                	jbe    c6 <verigmp::fast_multiply::low+0xc6>
  76:	80 bc 24 80 00 00 00 	cmpb   $0x0,0x80(%rsp)
  7d:	00 
  7e:	0f 84 d6 00 00 00    	je     15a <verigmp::fast_multiply::low+0x15a>
  84:	48 b9 8f e3 38 8e e3 	movabs $0xe38e38e38e38e38f,%rcx
  8b:	38 8e e3 
  8e:	48 89 f0             	mov    %rsi,%rax
  91:	48 f7 e1             	mul    %rcx
  94:	48 c1 ea 05          	shr    $0x5,%rdx
  98:	48 8d 04 92          	lea    (%rdx,%rdx,4),%rax
  9c:	48 8d 04 42          	lea    (%rdx,%rax,2),%rax
  a0:	c1 e2 02             	shl    $0x2,%edx
  a3:	8d 0c d2             	lea    (%rdx,%rdx,8),%ecx
  a6:	89 f2                	mov    %esi,%edx
  a8:	29 ca                	sub    %ecx,%edx
  aa:	8d 0c 92             	lea    (%rdx,%rdx,4),%ecx
  ad:	8d 0c 4a             	lea    (%rdx,%rcx,2),%ecx
  b0:	0f b7 c9             	movzwl %cx,%ecx
  b3:	44 69 e9 1d 07 00 00 	imul   $0x71d,%ecx,%r13d
  ba:	41 c1 ed 10          	shr    $0x10,%r13d
  be:	49 01 c5             	add    %rax,%r13
  c1:	e9 9a 00 00 00       	jmp    160 <verigmp::fast_multiply::low+0x160>
  c6:	49 8b 0b             	mov    (%r11),%rcx
  c9:	48 89 f0             	mov    %rsi,%rax
  cc:	48 ff c8             	dec    %rax
  cf:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  d4:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
  d9:	0f 84 e5 01 00 00    	je     2c4 <verigmp::fast_multiply::low+0x2c4>
  df:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
  e6:	ff ff 0f 
  e9:	49 21 f2             	and    %rsi,%r10
  ec:	45 31 c0             	xor    %r8d,%r8d
  ef:	45 31 c9             	xor    %r9d,%r9d
  f2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  f9:	1f 84 00 00 00 00 00 
 100:	48 89 c8             	mov    %rcx,%rax
 103:	4b f7 24 cc          	mulq   (%r12,%r9,8)
 107:	48 89 d6             	mov    %rdx,%rsi
 10a:	48 89 c7             	mov    %rax,%rdi
 10d:	4e 8d 1c 00          	lea    (%rax,%r8,1),%r11
 111:	48 89 c8             	mov    %rcx,%rax
 114:	4b f7 64 cc 08       	mulq   0x8(%r12,%r9,8)
 119:	4c 01 c7             	add    %r8,%rdi
 11c:	48 11 f0             	adc    %rsi,%rax
 11f:	49 89 d0             	mov    %rdx,%r8
 122:	49 83 d0 00          	adc    $0x0,%r8
 126:	4f 89 1c ce          	mov    %r11,(%r14,%r9,8)
 12a:	4b 89 44 ce 08       	mov    %rax,0x8(%r14,%r9,8)
 12f:	49 83 c1 02          	add    $0x2,%r9
 133:	4d 39 ca             	cmp    %r9,%r10
 136:	75 c8                	jne    100 <verigmp::fast_multiply::low+0x100>
 138:	48 8b 34 24          	mov    (%rsp),%rsi
 13c:	40 f6 c6 01          	test   $0x1,%sil
 140:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
 145:	0f 85 7f 01 00 00    	jne    2ca <verigmp::fast_multiply::low+0x2ca>
 14b:	48 83 fe 02          	cmp    $0x2,%rsi
 14f:	0f 83 8b 01 00 00    	jae    2e0 <verigmp::fast_multiply::low+0x2e0>
 155:	e9 2e 03 00 00       	jmp    488 <verigmp::fast_multiply::low+0x488>
 15a:	49 89 f5             	mov    %rsi,%r13
 15d:	49 d1 ed             	shr    $1,%r13
 160:	48 89 f1             	mov    %rsi,%rcx
 163:	4c 29 e9             	sub    %r13,%rcx
 166:	4c 8d 3c 09          	lea    (%rcx,%rcx,1),%r15
 16a:	48 89 f8             	mov    %rdi,%rax
 16d:	4c 29 f8             	sub    %r15,%rax
 170:	0f 82 82 03 00 00    	jb     4f8 <verigmp::fast_multiply::low+0x4f8>
 176:	48 8b 6c 24 60       	mov    0x60(%rsp),%rbp
 17b:	4e 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%r10
 182:	00 
 183:	49 01 ea             	add    %rbp,%r10
 186:	48 83 ec 08          	sub    $0x8,%rsp
 18a:	48 89 ef             	mov    %rbp,%rdi
 18d:	4c 89 fe             	mov    %r15,%rsi
 190:	4c 89 da             	mov    %r11,%rdx
 193:	4c 89 c3             	mov    %r8,%rbx
 196:	4d 89 e0             	mov    %r12,%r8
 199:	49 89 c9             	mov    %rcx,%r9
 19c:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
 1a1:	53                   	push   %rbx
 1a2:	50                   	push   %rax
 1a3:	41 52                	push   %r10
 1a5:	4c 89 db             	mov    %r11,%rbx
 1a8:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1ae <verigmp::fast_multiply::low+0x1ae>
			1aa: R_X86_64_GOTPCREL	verigmp::fast_multiply::full-0x4
 1ae:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
 1b3:	48 83 c4 20          	add    $0x20,%rsp
 1b7:	4c 39 fe             	cmp    %r15,%rsi
 1ba:	0f 87 0d 03 00 00    	ja     4cd <verigmp::fast_multiply::low+0x4cd>
 1c0:	48 8d 14 f5 00 00 00 	lea    0x0(,%rsi,8),%rdx
 1c7:	00 
 1c8:	4c 89 f7             	mov    %r14,%rdi
 1cb:	48 89 ee             	mov    %rbp,%rsi
 1ce:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1d4 <verigmp::fast_multiply::low+0x1d4>
			1d0: R_X86_64_GOTPCREL	memcpy-0x4
 1d4:	4e 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%r10
 1db:	00 
 1dc:	49 01 ea             	add    %rbp,%r10
 1df:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
 1e4:	4c 29 e8             	sub    %r13,%rax
 1e7:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
 1ec:	4a 8d 14 fb          	lea    (%rbx,%r15,8),%rdx
 1f0:	48 83 ec 08          	sub    $0x8,%rsp
 1f4:	44 0f b6 9c 24 88 00 	movzbl 0x88(%rsp),%r11d
 1fb:	00 00 
 1fd:	48 89 ef             	mov    %rbp,%rdi
 200:	4c 89 ee             	mov    %r13,%rsi
 203:	4c 89 e9             	mov    %r13,%rcx
 206:	4d 89 e0             	mov    %r12,%r8
 209:	4d 89 e9             	mov    %r13,%r9
 20c:	4c 89 5c 24 28       	mov    %r11,0x28(%rsp)
 211:	41 53                	push   %r11
 213:	ff b4 24 88 00 00 00 	push   0x88(%rsp)
 21a:	ff b4 24 88 00 00 00 	push   0x88(%rsp)
 221:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
 226:	50                   	push   %rax
 227:	41 52                	push   %r10
 229:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 22f <verigmp::fast_multiply::low+0x22f>
			22b: R_X86_64_GOTPCREL	verigmp::fast_multiply::low-0x4
 22f:	48 83 c4 30          	add    $0x30,%rsp
 233:	4d 85 ed             	test   %r13,%r13
 236:	0f 84 a3 02 00 00    	je     4df <verigmp::fast_multiply::low+0x4df>
 23c:	4d 89 fa             	mov    %r15,%r10
 23f:	4f 8d 0c fe          	lea    (%r14,%r15,8),%r9
 243:	4d 89 ef             	mov    %r13,%r15
 246:	49 ff cf             	dec    %r15
 249:	0f 84 5c 01 00 00    	je     3ab <verigmp::fast_multiply::low+0x3ab>
 24f:	4d 89 e8             	mov    %r13,%r8
 252:	49 83 e0 fe          	and    $0xfffffffffffffffe,%r8
 256:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
 25d:	00 
 25e:	48 8b 0c 24          	mov    (%rsp),%rcx
 262:	49 8d 34 ce          	lea    (%r14,%rcx,8),%rsi
 266:	48 29 c6             	sub    %rax,%rsi
 269:	48 83 c6 08          	add    $0x8,%rsi
 26d:	31 c0                	xor    %eax,%eax
 26f:	31 c9                	xor    %ecx,%ecx
 271:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 278:	0f 1f 84 00 00 00 00 
 27f:	00 
 280:	31 ff                	xor    %edi,%edi
 282:	48 03 44 ce f8       	add    -0x8(%rsi,%rcx,8),%rax
 287:	40 0f 92 c7          	setb   %dil
 28b:	48 03 44 cd 00       	add    0x0(%rbp,%rcx,8),%rax
 290:	48 89 44 ce f8       	mov    %rax,-0x8(%rsi,%rcx,8)
 295:	48 13 3c ce          	adc    (%rsi,%rcx,8),%rdi
 299:	0f 92 c0             	setb   %al
 29c:	0f b6 c0             	movzbl %al,%eax
 29f:	48 03 7c cd 08       	add    0x8(%rbp,%rcx,8),%rdi
 2a4:	48 83 d0 00          	adc    $0x0,%rax
 2a8:	48 89 3c ce          	mov    %rdi,(%rsi,%rcx,8)
 2ac:	48 83 c1 02          	add    $0x2,%rcx
 2b0:	49 39 c8             	cmp    %rcx,%r8
 2b3:	75 cb                	jne    280 <verigmp::fast_multiply::low+0x280>
 2b5:	41 f6 c5 01          	test   $0x1,%r13b
 2b9:	0f 85 f0 00 00 00    	jne    3af <verigmp::fast_multiply::low+0x3af>
 2bf:	e9 f8 00 00 00       	jmp    3bc <verigmp::fast_multiply::low+0x3bc>
 2c4:	45 31 c0             	xor    %r8d,%r8d
 2c7:	45 31 c9             	xor    %r9d,%r9d
 2ca:	4b 0f af 0c cc       	imul   (%r12,%r9,8),%rcx
 2cf:	4c 01 c1             	add    %r8,%rcx
 2d2:	4b 89 0c ce          	mov    %rcx,(%r14,%r9,8)
 2d6:	48 83 fe 02          	cmp    $0x2,%rsi
 2da:	0f 82 a8 01 00 00    	jb     488 <verigmp::fast_multiply::low+0x488>
 2e0:	48 8d 5e fe          	lea    -0x2(%rsi),%rbx
 2e4:	49 8d 7e 10          	lea    0x10(%r14),%rdi
 2e8:	41 b9 01 00 00 00    	mov    $0x1,%r9d
 2ee:	45 31 d2             	xor    %r10d,%r10d
 2f1:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
 2f6:	eb 38                	jmp    330 <verigmp::fast_multiply::low+0x330>
 2f8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 2ff:	00 
 300:	45 31 ed             	xor    %r13d,%r13d
 303:	45 31 ff             	xor    %r15d,%r15d
 306:	4b 8d 04 ce          	lea    (%r14,%r9,8),%rax
 30a:	4b 0f af 0c fc       	imul   (%r12,%r15,8),%rcx
 30f:	4e 03 2c f8          	add    (%rax,%r15,8),%r13
 313:	49 01 cd             	add    %rcx,%r13
 316:	4e 89 2c f8          	mov    %r13,(%rax,%r15,8)
 31a:	49 ff c1             	inc    %r9
 31d:	49 ff c2             	inc    %r10
 320:	48 83 c7 08          	add    $0x8,%rdi
 324:	49 ff c8             	dec    %r8
 327:	49 39 f1             	cmp    %rsi,%r9
 32a:	0f 84 58 01 00 00    	je     488 <verigmp::fast_multiply::low+0x488>
 330:	4b 8b 0c cb          	mov    (%r11,%r9,8),%rcx
 334:	4c 39 d3             	cmp    %r10,%rbx
 337:	74 c7                	je     300 <verigmp::fast_multiply::low+0x300>
 339:	4d 89 c3             	mov    %r8,%r11
 33c:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
 340:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
 345:	4c 29 d5             	sub    %r10,%rbp
 348:	45 31 ed             	xor    %r13d,%r13d
 34b:	45 31 ff             	xor    %r15d,%r15d
 34e:	66 90                	xchg   %ax,%ax
 350:	48 89 c8             	mov    %rcx,%rax
 353:	4b f7 24 fc          	mulq   (%r12,%r15,8)
 357:	31 f6                	xor    %esi,%esi
 359:	4e 03 6c ff f8       	add    -0x8(%rdi,%r15,8),%r13
 35e:	40 0f 92 c6          	setb   %sil
 362:	49 01 c5             	add    %rax,%r13
 365:	48 11 d6             	adc    %rdx,%rsi
 368:	4e 89 6c ff f8       	mov    %r13,-0x8(%rdi,%r15,8)
 36d:	48 89 c8             	mov    %rcx,%rax
 370:	4b f7 64 fc 08       	mulq   0x8(%r12,%r15,8)
 375:	45 31 ed             	xor    %r13d,%r13d
 378:	4a 03 34 ff          	add    (%rdi,%r15,8),%rsi
 37c:	41 0f 92 c5          	setb   %r13b
 380:	48 01 c6             	add    %rax,%rsi
 383:	49 11 d5             	adc    %rdx,%r13
 386:	4a 89 34 ff          	mov    %rsi,(%rdi,%r15,8)
 38a:	49 83 c7 02          	add    $0x2,%r15
 38e:	4d 39 fb             	cmp    %r15,%r11
 391:	75 bd                	jne    350 <verigmp::fast_multiply::low+0x350>
 393:	40 f6 c5 01          	test   $0x1,%bpl
 397:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
 39c:	48 8b 34 24          	mov    (%rsp),%rsi
 3a0:	0f 85 60 ff ff ff    	jne    306 <verigmp::fast_multiply::low+0x306>
 3a6:	e9 6f ff ff ff       	jmp    31a <verigmp::fast_multiply::low+0x31a>
 3ab:	31 c0                	xor    %eax,%eax
 3ad:	31 c9                	xor    %ecx,%ecx
 3af:	49 03 04 c9          	add    (%r9,%rcx,8),%rax
 3b3:	48 03 44 cd 00       	add    0x0(%rbp,%rcx,8),%rax
 3b8:	49 89 04 c9          	mov    %rax,(%r9,%rcx,8)
 3bc:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
 3c1:	4f 8d 04 d4          	lea    (%r12,%r10,8),%r8
 3c5:	48 83 ec 08          	sub    $0x8,%rsp
 3c9:	48 89 ef             	mov    %rbp,%rdi
 3cc:	4c 89 ee             	mov    %r13,%rsi
 3cf:	48 89 da             	mov    %rbx,%rdx
 3d2:	4c 89 e9             	mov    %r13,%rcx
 3d5:	4d 89 e9             	mov    %r13,%r9
 3d8:	ff 74 24 28          	push   0x28(%rsp)
 3dc:	ff b4 24 88 00 00 00 	push   0x88(%rsp)
 3e3:	ff b4 24 88 00 00 00 	push   0x88(%rsp)
 3ea:	ff 74 24 28          	push   0x28(%rsp)
 3ee:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
 3f5:	00 
 3f6:	48 01 e8             	add    %rbp,%rax
 3f9:	50                   	push   %rax
 3fa:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 400 <verigmp::fast_multiply::low+0x400>
			3fc: R_X86_64_GOTPCREL	verigmp::fast_multiply::low-0x4
 400:	48 83 c4 30          	add    $0x30,%rsp
 404:	4d 85 ff             	test   %r15,%r15
 407:	74 69                	je     472 <verigmp::fast_multiply::low+0x472>
 409:	4c 89 ea             	mov    %r13,%rdx
 40c:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
 410:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
 417:	00 
 418:	48 8b 0c 24          	mov    (%rsp),%rcx
 41c:	49 8d 34 ce          	lea    (%r14,%rcx,8),%rsi
 420:	48 29 c6             	sub    %rax,%rsi
 423:	48 83 c6 08          	add    $0x8,%rsi
 427:	31 c0                	xor    %eax,%eax
 429:	31 c9                	xor    %ecx,%ecx
 42b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 430:	31 ff                	xor    %edi,%edi
 432:	48 03 44 ce f8       	add    -0x8(%rsi,%rcx,8),%rax
 437:	40 0f 92 c7          	setb   %dil
 43b:	48 03 44 cd 00       	add    0x0(%rbp,%rcx,8),%rax
 440:	48 89 44 ce f8       	mov    %rax,-0x8(%rsi,%rcx,8)
 445:	48 13 3c ce          	adc    (%rsi,%rcx,8),%rdi
 449:	0f 92 c0             	setb   %al
 44c:	0f b6 c0             	movzbl %al,%eax
 44f:	48 03 7c cd 08       	add    0x8(%rbp,%rcx,8),%rdi
 454:	48 83 d0 00          	adc    $0x0,%rax
 458:	48 89 3c ce          	mov    %rdi,(%rsi,%rcx,8)
 45c:	48 83 c1 02          	add    $0x2,%rcx
 460:	48 39 ca             	cmp    %rcx,%rdx
 463:	75 cb                	jne    430 <verigmp::fast_multiply::low+0x430>
 465:	41 f6 c5 01          	test   $0x1,%r13b
 469:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 46e:	75 0b                	jne    47b <verigmp::fast_multiply::low+0x47b>
 470:	eb 16                	jmp    488 <verigmp::fast_multiply::low+0x488>
 472:	31 c0                	xor    %eax,%eax
 474:	31 c9                	xor    %ecx,%ecx
 476:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 47b:	48 03 04 ca          	add    (%rdx,%rcx,8),%rax
 47f:	48 03 44 cd 00       	add    0x0(%rbp,%rcx,8),%rax
 484:	48 89 04 ca          	mov    %rax,(%rdx,%rcx,8)
 488:	48 83 c4 28          	add    $0x28,%rsp
 48c:	5b                   	pop    %rbx
 48d:	41 5c                	pop    %r12
 48f:	41 5d                	pop    %r13
 491:	41 5e                	pop    %r14
 493:	41 5f                	pop    %r15
 495:	5d                   	pop    %rbp
 496:	c3                   	ret
 497:	84 c0                	test   %al,%al
 499:	74 19                	je     4b4 <verigmp::fast_multiply::low+0x4b4>
 49b:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 4a2 <verigmp::fast_multiply::low+0x4a2>
			49e: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.79-0x4
 4a2:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 4a9 <verigmp::fast_multiply::low+0x4a9>
			4a5: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.80-0x4
 4a9:	be 32 00 00 00       	mov    $0x32,%esi
 4ae:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4b4 <verigmp::fast_multiply::low+0x4b4>
			4b0: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 4b4:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 4bb <verigmp::fast_multiply::low+0x4bb>
			4b7: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.77-0x4
 4bb:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 4c2 <verigmp::fast_multiply::low+0x4c2>
			4be: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.78-0x4
 4c2:	be 46 00 00 00       	mov    $0x46,%esi
 4c7:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4cd <verigmp::fast_multiply::low+0x4cd>
			4c9: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 4cd:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 4d4 <verigmp::fast_multiply::low+0x4d4>
			4d0: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.82-0x4
 4d4:	31 ff                	xor    %edi,%edi
 4d6:	4c 89 fa             	mov    %r15,%rdx
 4d9:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4df <verigmp::fast_multiply::low+0x4df>
			4db: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 4df:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 4e6 <verigmp::fast_multiply::low+0x4e6>
			4e2: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.18-0x4
 4e6:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 4ed <verigmp::fast_multiply::low+0x4ed>
			4e9: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.76-0x4
 4ed:	be 33 00 00 00       	mov    $0x33,%esi
 4f2:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4f8 <verigmp::fast_multiply::low+0x4f8>
			4f4: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 4f8:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 4ff <verigmp::fast_multiply::low+0x4ff>
			4fb: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.0-0x4
 4ff:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 506 <verigmp::fast_multiply::low+0x506>
			502: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.81-0x4
 506:	be 13 00 00 00       	mov    $0x13,%esi
 50b:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 511 <verigmp::fast_multiply::low+0x511>
			50d: R_X86_64_GOTPCREL	core::panicking::panic_fmt-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp13fast_multiply4full:

0000000000000000 <verigmp::fast_multiply::full>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	48 83 ec 68          	sub    $0x68,%rsp
   e:	48 85 c9             	test   %rcx,%rcx
  11:	0f 84 df 02 00 00    	je     2f6 <verigmp::fast_multiply::full+0x2f6>
  17:	48 89 cd             	mov    %rcx,%rbp
  1a:	4c 39 c9             	cmp    %r9,%rcx
  1d:	0f 85 d3 02 00 00    	jne    2f6 <verigmp::fast_multiply::full+0x2f6>
  23:	48 8d 04 6d 00 00 00 	lea    0x0(,%rbp,2),%rax
  2a:	00 
  2b:	48 39 c6             	cmp    %rax,%rsi
  2e:	0f 85 db 02 00 00    	jne    30f <verigmp::fast_multiply::full+0x30f>
  34:	4c 8b a4 24 a8 00 00 	mov    0xa8(%rsp),%r12
  3b:	00 
  3c:	48 8d 04 6d 00 00 00 	lea    0x0(,%rbp,2),%rax
  43:	00 
  44:	48 01 e8             	add    %rbp,%rax
  47:	49 39 c4             	cmp    %rax,%r12
  4a:	0f 82 bf 02 00 00    	jb     30f <verigmp::fast_multiply::full+0x30f>
  50:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
  57:	00 
  58:	48 83 f9 07          	cmp    $0x7,%rcx
  5c:	0f 86 c6 02 00 00    	jbe    328 <verigmp::fast_multiply::full+0x328>
  62:	48 39 cd             	cmp    %rcx,%rbp
  65:	0f 86 71 02 00 00    	jbe    2dc <verigmp::fast_multiply::full+0x2dc>
  6b:	49 89 ed             	mov    %rbp,%r13
  6e:	49 d1 ed             	shr    $1,%r13
  71:	49 89 ee             	mov    %rbp,%r14
  74:	4d 29 ee             	sub    %r13,%r14
  77:	49 89 f2             	mov    %rsi,%r10
  7a:	48 89 f0             	mov    %rsi,%rax
  7d:	4c 29 f0             	sub    %r14,%rax
  80:	0f 82 bb 02 00 00    	jb     341 <verigmp::fast_multiply::full+0x341>
  86:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  8b:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
  90:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  95:	4c 89 44 24 40       	mov    %r8,0x40(%rsp)
  9a:	4c 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%r15
  a1:	00 
  a2:	4e 8d 04 f2          	lea    (%rdx,%r14,8),%r8
  a6:	48 89 fb             	mov    %rdi,%rbx
  a9:	4c 89 f6             	mov    %r14,%rsi
  ac:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
  b1:	4c 89 f1             	mov    %r14,%rcx
  b4:	4c 89 44 24 50       	mov    %r8,0x50(%rsp)
  b9:	4d 89 e9             	mov    %r13,%r9
  bc:	4d 89 d4             	mov    %r10,%r12
  bf:	ff 15 00 00 00 00    	call   *0x0(%rip)        # c5 <verigmp::fast_multiply::full+0xc5>
			c1: R_X86_64_GOTPCREL	verigmp::fast_words::abs_difference-0x4
  c5:	49 89 d9             	mov    %rbx,%r9
  c8:	4b 8d 1c 36          	lea    (%r14,%r14,1),%rbx
  cc:	4c 89 e1             	mov    %r12,%rcx
  cf:	48 29 d9             	sub    %rbx,%rcx
  d2:	0f 82 7e 02 00 00    	jb     356 <verigmp::fast_multiply::full+0x356>
  d8:	4b 8d 3c f1          	lea    (%r9,%r14,8),%rdi
  dc:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  e1:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  e6:	4e 8d 04 f2          	lea    (%rdx,%r14,8),%r8
  ea:	4c 89 44 24 48       	mov    %r8,0x48(%rsp)
  ef:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  f4:	4c 89 f6             	mov    %r14,%rsi
  f7:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  fc:	88 44 24 0f          	mov    %al,0xf(%rsp)
 100:	4c 89 f1             	mov    %r14,%rcx
 103:	4d 89 e9             	mov    %r13,%r9
 106:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 10c <verigmp::fast_multiply::full+0x10c>
			108: R_X86_64_GOTPCREL	verigmp::fast_words::abs_difference-0x4
 10c:	88 44 24 10          	mov    %al,0x10(%rsp)
 110:	49 8d 04 df          	lea    (%r15,%rbx,8),%rax
 114:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
 119:	49 29 dc             	sub    %rbx,%r12
 11c:	48 83 ec 08          	sub    $0x8,%rsp
 120:	4c 89 ff             	mov    %r15,%rdi
 123:	48 89 de             	mov    %rbx,%rsi
 126:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
 12b:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
 130:	4c 89 ea             	mov    %r13,%rdx
 133:	4c 89 f1             	mov    %r14,%rcx
 136:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
 13b:	4d 89 f1             	mov    %r14,%r9
 13e:	ff 74 24 30          	push   0x30(%rsp)
 142:	41 54                	push   %r12
 144:	50                   	push   %rax
 145:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 14b <verigmp::fast_multiply::full+0x14b>
			147: R_X86_64_GOTPCREL	verigmp::fast_multiply::full-0x4
 14b:	48 83 c4 20          	add    $0x20,%rsp
 14f:	0f b6 44 24 10       	movzbl 0x10(%rsp),%eax
 154:	30 44 24 0f          	xor    %al,0xf(%rsp)
 158:	48 8d 3c dd 00 00 00 	lea    0x0(,%rbx,8),%rdi
 15f:	00 
 160:	4c 01 ef             	add    %r13,%rdi
 163:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
 168:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
 16d:	48 83 ec 08          	sub    $0x8,%rsp
 171:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
 176:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
 17b:	4c 89 e9             	mov    %r13,%rcx
 17e:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
 183:	4d 89 e9             	mov    %r13,%r9
 186:	ff 74 24 30          	push   0x30(%rsp)
 18a:	41 54                	push   %r12
 18c:	49 8d 04 df          	lea    (%r15,%rbx,8),%rax
 190:	50                   	push   %rax
 191:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 197 <verigmp::fast_multiply::full+0x197>
			193: R_X86_64_GOTPCREL	verigmp::fast_multiply::full-0x4
 197:	48 83 c4 18          	add    $0x18,%rsp
 19b:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
 1a0:	48 89 de             	mov    %rbx,%rsi
 1a3:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
 1a8:	4c 89 f1             	mov    %r14,%rcx
 1ab:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
 1b0:	4d 89 f1             	mov    %r14,%r9
 1b3:	ff 74 24 30          	push   0x30(%rsp)
 1b7:	41 54                	push   %r12
 1b9:	49 8d 04 df          	lea    (%r15,%rbx,8),%rax
 1bd:	50                   	push   %rax
 1be:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1c4 <verigmp::fast_multiply::full+0x1c4>
			1c0: R_X86_64_GOTPCREL	verigmp::fast_multiply::full-0x4
 1c4:	48 83 c4 20          	add    $0x20,%rsp
 1c8:	0f b6 44 24 0f       	movzbl 0xf(%rsp),%eax
 1cd:	48 83 ec 08          	sub    $0x8,%rsp
 1d1:	4c 89 ff             	mov    %r15,%rdi
 1d4:	48 89 de             	mov    %rbx,%rsi
 1d7:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
 1dc:	49 89 d6             	mov    %rdx,%r14
 1df:	48 89 d9             	mov    %rbx,%rcx
 1e2:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
 1e7:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
 1ec:	50                   	push   %rax
 1ed:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1f3 <verigmp::fast_multiply::full+0x1f3>
			1ef: R_X86_64_GOTPCREL	verigmp::fast_words::combine_cross-0x4
 1f3:	48 83 c4 10          	add    $0x10,%rsp
 1f7:	4c 8b 4c 24 60       	mov    0x60(%rsp),%r9
 1fc:	49 39 d9             	cmp    %rbx,%r9
 1ff:	0f 82 67 01 00 00    	jb     36c <verigmp::fast_multiply::full+0x36c>
 205:	49 c1 e5 03          	shl    $0x3,%r13
 209:	49 8d 0c ee          	lea    (%r14,%rbp,8),%rcx
 20d:	4c 29 e9             	sub    %r13,%rcx
 210:	48 83 c1 08          	add    $0x8,%rcx
 214:	31 f6                	xor    %esi,%esi
 216:	31 d2                	xor    %edx,%edx
 218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 21f:	00 
 220:	31 ff                	xor    %edi,%edi
 222:	48 03 74 d1 f8       	add    -0x8(%rcx,%rdx,8),%rsi
 227:	40 0f 92 c7          	setb   %dil
 22b:	49 03 34 d7          	add    (%r15,%rdx,8),%rsi
 22f:	48 89 74 d1 f8       	mov    %rsi,-0x8(%rcx,%rdx,8)
 234:	48 13 3c d1          	adc    (%rcx,%rdx,8),%rdi
 238:	40 0f 92 c6          	setb   %sil
 23c:	40 0f b6 f6          	movzbl %sil,%esi
 240:	49 03 7c d7 08       	add    0x8(%r15,%rdx,8),%rdi
 245:	48 83 d6 00          	adc    $0x0,%rsi
 249:	48 89 3c d1          	mov    %rdi,(%rcx,%rdx,8)
 24d:	48 83 c2 02          	add    $0x2,%rdx
 251:	48 39 d3             	cmp    %rdx,%rbx
 254:	75 ca                	jne    220 <verigmp::fast_multiply::full+0x220>
 256:	4c 89 c9             	mov    %r9,%rcx
 259:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
 25e:	48 8d 14 da          	lea    (%rdx,%rbx,8),%rdx
 262:	48 29 d9             	sub    %rbx,%rcx
 265:	74 38                	je     29f <verigmp::fast_multiply::full+0x29f>
 267:	48 85 f6             	test   %rsi,%rsi
 26a:	74 33                	je     29f <verigmp::fast_multiply::full+0x29f>
 26c:	bf 01 00 00 00       	mov    $0x1,%edi
 271:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 278:	0f 1f 84 00 00 00 00 
 27f:	00 
 280:	45 31 c0             	xor    %r8d,%r8d
 283:	48 01 74 fa f8       	add    %rsi,-0x8(%rdx,%rdi,8)
 288:	40 0f 92 c6          	setb   %sil
 28c:	48 39 cf             	cmp    %rcx,%rdi
 28f:	73 0e                	jae    29f <verigmp::fast_multiply::full+0x29f>
 291:	41 88 f0             	mov    %sil,%r8b
 294:	48 ff c7             	inc    %rdi
 297:	4c 89 c6             	mov    %r8,%rsi
 29a:	45 84 c0             	test   %r8b,%r8b
 29d:	75 e1                	jne    280 <verigmp::fast_multiply::full+0x280>
 29f:	49 39 d9             	cmp    %rbx,%r9
 2a2:	74 29                	je     2cd <verigmp::fast_multiply::full+0x2cd>
 2a4:	48 85 c0             	test   %rax,%rax
 2a7:	74 24                	je     2cd <verigmp::fast_multiply::full+0x2cd>
 2a9:	be 01 00 00 00       	mov    $0x1,%esi
 2ae:	66 90                	xchg   %ax,%ax
 2b0:	31 ff                	xor    %edi,%edi
 2b2:	48 01 44 f2 f8       	add    %rax,-0x8(%rdx,%rsi,8)
 2b7:	0f 92 c0             	setb   %al
 2ba:	48 39 ce             	cmp    %rcx,%rsi
 2bd:	73 0e                	jae    2cd <verigmp::fast_multiply::full+0x2cd>
 2bf:	40 88 c7             	mov    %al,%dil
 2c2:	48 ff c6             	inc    %rsi
 2c5:	48 89 f8             	mov    %rdi,%rax
 2c8:	40 84 ff             	test   %dil,%dil
 2cb:	75 e3                	jne    2b0 <verigmp::fast_multiply::full+0x2b0>
 2cd:	48 83 c4 68          	add    $0x68,%rsp
 2d1:	5b                   	pop    %rbx
 2d2:	41 5c                	pop    %r12
 2d4:	41 5d                	pop    %r13
 2d6:	41 5e                	pop    %r14
 2d8:	41 5f                	pop    %r15
 2da:	5d                   	pop    %rbp
 2db:	c3                   	ret
 2dc:	48 89 e9             	mov    %rbp,%rcx
 2df:	49 89 e9             	mov    %rbp,%r9
 2e2:	48 83 c4 68          	add    $0x68,%rsp
 2e6:	5b                   	pop    %rbx
 2e7:	41 5c                	pop    %r12
 2e9:	41 5d                	pop    %r13
 2eb:	41 5e                	pop    %r14
 2ed:	41 5f                	pop    %r15
 2ef:	5d                   	pop    %rbp
 2f0:	ff 25 00 00 00 00    	jmp    *0x0(%rip)        # 2f6 <verigmp::fast_multiply::full+0x2f6>
			2f2: R_X86_64_GOTPCREL	verigmp::fast_multiply::base_full-0x4
 2f6:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 2fd <verigmp::fast_multiply::full+0x2fd>
			2f9: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.18-0x4
 2fd:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 304 <verigmp::fast_multiply::full+0x304>
			300: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.84-0x4
 304:	be 33 00 00 00       	mov    $0x33,%esi
 309:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 30f <verigmp::fast_multiply::full+0x30f>
			30b: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 30f:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 316 <verigmp::fast_multiply::full+0x316>
			312: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.85-0x4
 316:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 31d <verigmp::fast_multiply::full+0x31d>
			319: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.86-0x4
 31d:	be 4a 00 00 00       	mov    $0x4a,%esi
 322:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 328 <verigmp::fast_multiply::full+0x328>
			324: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 328:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 32f <verigmp::fast_multiply::full+0x32f>
			32b: R_X86_64_PC32	.Lanon.d1b2563b732ee79941e9b189853f7bd7.87-0x4
 32f:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 336 <verigmp::fast_multiply::full+0x336>
			332: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.88-0x4
 336:	be 20 00 00 00       	mov    $0x20,%esi
 33b:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 341 <verigmp::fast_multiply::full+0x341>
			33d: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 341:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 348 <verigmp::fast_multiply::full+0x348>
			344: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.90-0x4
 348:	31 ff                	xor    %edi,%edi
 34a:	4c 89 f6             	mov    %r14,%rsi
 34d:	4c 89 d2             	mov    %r10,%rdx
 350:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 356 <verigmp::fast_multiply::full+0x356>
			352: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 356:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 35d <verigmp::fast_multiply::full+0x35d>
			359: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.89-0x4
 35d:	4c 89 f7             	mov    %r14,%rdi
 360:	48 89 de             	mov    %rbx,%rsi
 363:	4c 89 e2             	mov    %r12,%rdx
 366:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 36c <verigmp::fast_multiply::full+0x36c>
			368: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 36c:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 373 <verigmp::fast_multiply::full+0x373>
			36f: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.7-0x4
 373:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 37a <verigmp::fast_multiply::full+0x37a>
			376: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.17-0x4
 37a:	be 28 00 00 00       	mov    $0x28,%esi
 37f:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 385 <verigmp::fast_multiply::full+0x385>
			381: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp13fast_multiply7modular:

0000000000000000 <verigmp::fast_multiply::modular>:
   0:	41 57                	push   %r15
   2:	41 56                	push   %r14
   4:	53                   	push   %rbx
   5:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
   a:	41 8d 47 ff          	lea    -0x1(%r15),%eax
   e:	83 f8 40             	cmp    $0x40,%eax
  11:	73 59                	jae    6c <verigmp::fast_multiply::modular+0x6c>
  13:	48 89 f3             	mov    %rsi,%rbx
  16:	49 89 fe             	mov    %rdi,%r14
  19:	48 83 ec 08          	sub    $0x8,%rsp
  1d:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
  22:	50                   	push   %rax
  23:	ff 74 24 50          	push   0x50(%rsp)
  27:	ff 74 24 50          	push   0x50(%rsp)
  2b:	ff 74 24 48          	push   0x48(%rsp)
  2f:	ff 74 24 48          	push   0x48(%rsp)
  33:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 39 <verigmp::fast_multiply::modular+0x39>
			35: R_X86_64_GOTPCREL	verigmp::fast_multiply::low-0x4
  39:	48 83 c4 30          	add    $0x30,%rsp
  3d:	48 85 db             	test   %rbx,%rbx
  40:	74 43                	je     85 <verigmp::fast_multiply::modular+0x85>
  42:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  49:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  50:	44 89 f9             	mov    %r15d,%ecx
  53:	48 d3 e2             	shl    %cl,%rdx
  56:	41 83 ff 40          	cmp    $0x40,%r15d
  5a:	48 f7 d2             	not    %rdx
  5d:	48 0f 44 d0          	cmove  %rax,%rdx
  61:	49 21 54 de f8       	and    %rdx,-0x8(%r14,%rbx,8)
  66:	5b                   	pop    %rbx
  67:	41 5e                	pop    %r14
  69:	41 5f                	pop    %r15
  6b:	c3                   	ret
  6c:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 73 <verigmp::fast_multiply::modular+0x73>
			6f: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.1-0x4
  73:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 7a <verigmp::fast_multiply::modular+0x7a>
			76: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.91-0x4
  7a:	be 27 00 00 00       	mov    $0x27,%esi
  7f:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 85 <verigmp::fast_multiply::modular+0x85>
			81: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  85:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8c <verigmp::fast_multiply::modular+0x8c>
			88: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.203-0x4
  8c:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 93 <verigmp::fast_multiply::modular+0x93>
			8f: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.205-0x4
  93:	be 1f 00 00 00       	mov    $0x1f,%esi
  98:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 9e <verigmp::fast_multiply::modular+0x9e>
			9a: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp13fast_multiply7mul_mod:

0000000000000000 <verigmp::fast_multiply::mul_mod>:
   0:	41 57                	push   %r15
   2:	41 56                	push   %r14
   4:	53                   	push   %rbx
   5:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
   a:	41 8d 47 ff          	lea    -0x1(%r15),%eax
   e:	83 f8 40             	cmp    $0x40,%eax
  11:	73 51                	jae    64 <verigmp::fast_multiply::mul_mod+0x64>
  13:	48 89 f3             	mov    %rsi,%rbx
  16:	49 89 fe             	mov    %rdi,%r14
  19:	48 83 ec 08          	sub    $0x8,%rsp
  1d:	6a 01                	push   $0x1
  1f:	6a 40                	push   $0x40
  21:	6a 18                	push   $0x18
  23:	ff 74 24 48          	push   0x48(%rsp)
  27:	ff 74 24 48          	push   0x48(%rsp)
  2b:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 31 <verigmp::fast_multiply::mul_mod+0x31>
			2d: R_X86_64_GOTPCREL	verigmp::fast_multiply::low-0x4
  31:	48 83 c4 30          	add    $0x30,%rsp
  35:	48 85 db             	test   %rbx,%rbx
  38:	74 43                	je     7d <verigmp::fast_multiply::mul_mod+0x7d>
  3a:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  41:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  48:	44 89 f9             	mov    %r15d,%ecx
  4b:	48 d3 e2             	shl    %cl,%rdx
  4e:	41 83 ff 40          	cmp    $0x40,%r15d
  52:	48 f7 d2             	not    %rdx
  55:	48 0f 44 d0          	cmove  %rax,%rdx
  59:	49 21 54 de f8       	and    %rdx,-0x8(%r14,%rbx,8)
  5e:	5b                   	pop    %rbx
  5f:	41 5e                	pop    %r14
  61:	41 5f                	pop    %r15
  63:	c3                   	ret
  64:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 6b <verigmp::fast_multiply::mul_mod+0x6b>
			67: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.1-0x4
  6b:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 72 <verigmp::fast_multiply::mul_mod+0x72>
			6e: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.91-0x4
  72:	be 27 00 00 00       	mov    $0x27,%esi
  77:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 7d <verigmp::fast_multiply::mul_mod+0x7d>
			79: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  7d:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 84 <verigmp::fast_multiply::mul_mod+0x84>
			80: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.203-0x4
  84:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 8b <verigmp::fast_multiply::mul_mod+0x8b>
			87: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.205-0x4
  8b:	be 1f 00 00 00       	mov    $0x1f,%esi
  90:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 96 <verigmp::fast_multiply::mul_mod+0x96>
			92: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp13fast_multiply8base_low:

0000000000000000 <verigmp::fast_multiply::base_low>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	48 83 ec 18          	sub    $0x18,%rsp
   e:	48 39 ce             	cmp    %rcx,%rsi
  11:	0f 85 86 01 00 00    	jne    19d <verigmp::fast_multiply::base_low+0x19d>
  17:	48 85 c9             	test   %rcx,%rcx
  1a:	0f 84 7d 01 00 00    	je     19d <verigmp::fast_multiply::base_low+0x19d>
  20:	4c 39 c9             	cmp    %r9,%rcx
  23:	0f 85 74 01 00 00    	jne    19d <verigmp::fast_multiply::base_low+0x19d>
  29:	49 89 d4             	mov    %rdx,%r12
  2c:	48 8b 32             	mov    (%rdx),%rsi
  2f:	48 89 c8             	mov    %rcx,%rax
  32:	48 ff c8             	dec    %rax
  35:	48 89 04 24          	mov    %rax,(%rsp)
  39:	74 5d                	je     98 <verigmp::fast_multiply::base_low+0x98>
  3b:	49 bf fe ff ff ff ff 	movabs $0xffffffffffffffe,%r15
  42:	ff ff 0f 
  45:	49 21 cf             	and    %rcx,%r15
  48:	31 db                	xor    %ebx,%ebx
  4a:	45 31 f6             	xor    %r14d,%r14d
  4d:	0f 1f 00             	nopl   (%rax)
  50:	48 89 f0             	mov    %rsi,%rax
  53:	4b f7 24 f0          	mulq   (%r8,%r14,8)
  57:	49 89 d1             	mov    %rdx,%r9
  5a:	49 89 c3             	mov    %rax,%r11
  5d:	4c 8d 14 18          	lea    (%rax,%rbx,1),%r10
  61:	48 89 f0             	mov    %rsi,%rax
  64:	4b f7 64 f0 08       	mulq   0x8(%r8,%r14,8)
  69:	49 01 db             	add    %rbx,%r11
  6c:	4c 11 c8             	adc    %r9,%rax
  6f:	48 89 d3             	mov    %rdx,%rbx
  72:	48 83 d3 00          	adc    $0x0,%rbx
  76:	4e 89 14 f7          	mov    %r10,(%rdi,%r14,8)
  7a:	4a 89 44 f7 08       	mov    %rax,0x8(%rdi,%r14,8)
  7f:	49 83 c6 02          	add    $0x2,%r14
  83:	4d 39 f7             	cmp    %r14,%r15
  86:	75 c8                	jne    50 <verigmp::fast_multiply::base_low+0x50>
  88:	f6 c1 01             	test   $0x1,%cl
  8b:	75 10                	jne    9d <verigmp::fast_multiply::base_low+0x9d>
  8d:	48 83 f9 02          	cmp    $0x2,%rcx
  91:	73 20                	jae    b3 <verigmp::fast_multiply::base_low+0xb3>
  93:	e9 f6 00 00 00       	jmp    18e <verigmp::fast_multiply::base_low+0x18e>
  98:	31 db                	xor    %ebx,%ebx
  9a:	45 31 f6             	xor    %r14d,%r14d
  9d:	4b 0f af 34 f0       	imul   (%r8,%r14,8),%rsi
  a2:	48 01 de             	add    %rbx,%rsi
  a5:	4a 89 34 f7          	mov    %rsi,(%rdi,%r14,8)
  a9:	48 83 f9 02          	cmp    $0x2,%rcx
  ad:	0f 82 db 00 00 00    	jb     18e <verigmp::fast_multiply::base_low+0x18e>
  b3:	48 8d 51 fe          	lea    -0x2(%rcx),%rdx
  b7:	4c 8d 5f 10          	lea    0x10(%rdi),%r11
  bb:	41 be 01 00 00 00    	mov    $0x1,%r14d
  c1:	45 31 ff             	xor    %r15d,%r15d
  c4:	4c 8b 0c 24          	mov    (%rsp),%r9
  c8:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  cd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  d2:	eb 3b                	jmp    10f <verigmp::fast_multiply::base_low+0x10f>
  d4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  db:	00 00 00 00 00 
  e0:	31 ed                	xor    %ebp,%ebp
  e2:	45 31 ed             	xor    %r13d,%r13d
  e5:	4a 8d 04 f7          	lea    (%rdi,%r14,8),%rax
  e9:	4b 0f af 34 e8       	imul   (%r8,%r13,8),%rsi
  ee:	4a 03 2c e8          	add    (%rax,%r13,8),%rbp
  f2:	48 01 f5             	add    %rsi,%rbp
  f5:	4a 89 2c e8          	mov    %rbp,(%rax,%r13,8)
  f9:	49 ff c6             	inc    %r14
  fc:	49 ff c7             	inc    %r15
  ff:	49 83 c3 08          	add    $0x8,%r11
 103:	49 ff c9             	dec    %r9
 106:	49 39 ce             	cmp    %rcx,%r14
 109:	0f 84 7f 00 00 00    	je     18e <verigmp::fast_multiply::base_low+0x18e>
 10f:	4b 8b 34 f4          	mov    (%r12,%r14,8),%rsi
 113:	4c 39 fa             	cmp    %r15,%rdx
 116:	74 c8                	je     e0 <verigmp::fast_multiply::base_low+0xe0>
 118:	4c 89 e1             	mov    %r12,%rcx
 11b:	4d 89 cc             	mov    %r9,%r12
 11e:	49 83 e4 fe          	and    $0xfffffffffffffffe,%r12
 122:	48 8b 1c 24          	mov    (%rsp),%rbx
 126:	4c 29 fb             	sub    %r15,%rbx
 129:	31 ed                	xor    %ebp,%ebp
 12b:	45 31 ed             	xor    %r13d,%r13d
 12e:	66 90                	xchg   %ax,%ax
 130:	48 89 f0             	mov    %rsi,%rax
 133:	4b f7 24 e8          	mulq   (%r8,%r13,8)
 137:	45 31 d2             	xor    %r10d,%r10d
 13a:	4b 03 6c eb f8       	add    -0x8(%r11,%r13,8),%rbp
 13f:	41 0f 92 c2          	setb   %r10b
 143:	48 01 c5             	add    %rax,%rbp
 146:	49 11 d2             	adc    %rdx,%r10
 149:	4b 89 6c eb f8       	mov    %rbp,-0x8(%r11,%r13,8)
 14e:	48 89 f0             	mov    %rsi,%rax
 151:	4b f7 64 e8 08       	mulq   0x8(%r8,%r13,8)
 156:	31 ed                	xor    %ebp,%ebp
 158:	4f 03 14 eb          	add    (%r11,%r13,8),%r10
 15c:	40 0f 92 c5          	setb   %bpl
 160:	49 01 c2             	add    %rax,%r10
 163:	48 11 d5             	adc    %rdx,%rbp
 166:	4f 89 14 eb          	mov    %r10,(%r11,%r13,8)
 16a:	49 83 c5 02          	add    $0x2,%r13
 16e:	4d 39 ec             	cmp    %r13,%r12
 171:	75 bd                	jne    130 <verigmp::fast_multiply::base_low+0x130>
 173:	f6 c3 01             	test   $0x1,%bl
 176:	49 89 cc             	mov    %rcx,%r12
 179:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
 17e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 183:	0f 85 5c ff ff ff    	jne    e5 <verigmp::fast_multiply::base_low+0xe5>
 189:	e9 6b ff ff ff       	jmp    f9 <verigmp::fast_multiply::base_low+0xf9>
 18e:	48 83 c4 18          	add    $0x18,%rsp
 192:	5b                   	pop    %rbx
 193:	41 5c                	pop    %r12
 195:	41 5d                	pop    %r13
 197:	41 5e                	pop    %r14
 199:	41 5f                	pop    %r15
 19b:	5d                   	pop    %rbp
 19c:	c3                   	ret
 19d:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 1a4 <verigmp::fast_multiply::base_low+0x1a4>
			1a0: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.92-0x4
 1a4:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 1ab <verigmp::fast_multiply::base_low+0x1ab>
			1a7: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.93-0x4
 1ab:	be 4b 00 00 00       	mov    $0x4b,%esi
 1b0:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1b6 <verigmp::fast_multiply::base_low+0x1b6>
			1b2: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp13fast_multiply9base_full:

0000000000000000 <verigmp::fast_multiply::base_full>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	50                   	push   %rax
   b:	48 85 c9             	test   %rcx,%rcx
   e:	0f 84 6a 01 00 00    	je     17e <verigmp::fast_multiply::base_full+0x17e>
  14:	4c 39 c9             	cmp    %r9,%rcx
  17:	0f 85 7a 01 00 00    	jne    197 <verigmp::fast_multiply::base_full+0x197>
  1d:	48 8d 04 09          	lea    (%rcx,%rcx,1),%rax
  21:	48 39 c6             	cmp    %rax,%rsi
  24:	0f 85 86 01 00 00    	jne    1b0 <verigmp::fast_multiply::base_full+0x1b0>
  2a:	49 89 d2             	mov    %rdx,%r10
  2d:	48 bb fe ff ff ff ff 	movabs $0xffffffffffffffe,%rbx
  34:	ff ff 0f 
  37:	48 8b 32             	mov    (%rdx),%rsi
  3a:	49 89 ce             	mov    %rcx,%r14
  3d:	49 ff ce             	dec    %r14
  40:	74 57                	je     99 <verigmp::fast_multiply::base_full+0x99>
  42:	49 89 cd             	mov    %rcx,%r13
  45:	49 21 dd             	and    %rbx,%r13
  48:	45 31 ff             	xor    %r15d,%r15d
  4b:	45 31 e4             	xor    %r12d,%r12d
  4e:	66 90                	xchg   %ax,%ax
  50:	48 89 f0             	mov    %rsi,%rax
  53:	4b f7 24 e0          	mulq   (%r8,%r12,8)
  57:	49 89 d1             	mov    %rdx,%r9
  5a:	49 89 c3             	mov    %rax,%r11
  5d:	4a 8d 2c 38          	lea    (%rax,%r15,1),%rbp
  61:	48 89 f0             	mov    %rsi,%rax
  64:	4b f7 64 e0 08       	mulq   0x8(%r8,%r12,8)
  69:	4d 01 fb             	add    %r15,%r11
  6c:	4c 11 c8             	adc    %r9,%rax
  6f:	49 89 d7             	mov    %rdx,%r15
  72:	49 83 d7 00          	adc    $0x0,%r15
  76:	4a 89 2c e7          	mov    %rbp,(%rdi,%r12,8)
  7a:	4a 89 44 e7 08       	mov    %rax,0x8(%rdi,%r12,8)
  7f:	49 83 c4 02          	add    $0x2,%r12
  83:	4d 39 e5             	cmp    %r12,%r13
  86:	75 c8                	jne    50 <verigmp::fast_multiply::base_full+0x50>
  88:	f6 c1 01             	test   $0x1,%cl
  8b:	75 12                	jne    9f <verigmp::fast_multiply::base_full+0x9f>
  8d:	4c 89 3c cf          	mov    %r15,(%rdi,%rcx,8)
  91:	48 83 f9 01          	cmp    $0x1,%rcx
  95:	74 27                	je     be <verigmp::fast_multiply::base_full+0xbe>
  97:	eb 34                	jmp    cd <verigmp::fast_multiply::base_full+0xcd>
  99:	45 31 ff             	xor    %r15d,%r15d
  9c:	45 31 e4             	xor    %r12d,%r12d
  9f:	48 89 f0             	mov    %rsi,%rax
  a2:	4b f7 24 e0          	mulq   (%r8,%r12,8)
  a6:	4c 01 f8             	add    %r15,%rax
  a9:	48 83 d2 00          	adc    $0x0,%rdx
  ad:	4a 89 04 e7          	mov    %rax,(%rdi,%r12,8)
  b1:	49 89 d7             	mov    %rdx,%r15
  b4:	4c 89 3c cf          	mov    %r15,(%rdi,%rcx,8)
  b8:	48 83 f9 01          	cmp    $0x1,%rcx
  bc:	75 0f                	jne    cd <verigmp::fast_multiply::base_full+0xcd>
  be:	48 83 c4 08          	add    $0x8,%rsp
  c2:	5b                   	pop    %rbx
  c3:	41 5c                	pop    %r12
  c5:	41 5d                	pop    %r13
  c7:	41 5e                	pop    %r14
  c9:	41 5f                	pop    %r15
  cb:	5d                   	pop    %rbp
  cc:	c3                   	ret
  cd:	48 21 cb             	and    %rcx,%rbx
  d0:	4c 8d 4f 10          	lea    0x10(%rdi),%r9
  d4:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  da:	eb 32                	jmp    10e <verigmp::fast_multiply::base_full+0x10e>
  dc:	0f 1f 40 00          	nopl   0x0(%rax)
  e0:	48 89 f0             	mov    %rsi,%rax
  e3:	4b f7 24 e0          	mulq   (%r8,%r12,8)
  e7:	31 f6                	xor    %esi,%esi
  e9:	4f 03 2c e7          	add    (%r15,%r12,8),%r13
  ed:	40 0f 92 c6          	setb   %sil
  f1:	49 01 c5             	add    %rax,%r13
  f4:	48 11 d6             	adc    %rdx,%rsi
  f7:	4f 89 2c e7          	mov    %r13,(%r15,%r12,8)
  fb:	49 89 f5             	mov    %rsi,%r13
  fe:	4d 89 2c cf          	mov    %r13,(%r15,%rcx,8)
 102:	49 ff c3             	inc    %r11
 105:	49 83 c1 08          	add    $0x8,%r9
 109:	49 39 cb             	cmp    %rcx,%r11
 10c:	74 b0                	je     be <verigmp::fast_multiply::base_full+0xbe>
 10e:	4e 8d 3c df          	lea    (%rdi,%r11,8),%r15
 112:	4b 8b 34 da          	mov    (%r10,%r11,8),%rsi
 116:	45 31 ed             	xor    %r13d,%r13d
 119:	45 31 e4             	xor    %r12d,%r12d
 11c:	4d 85 f6             	test   %r14,%r14
 11f:	74 bf                	je     e0 <verigmp::fast_multiply::base_full+0xe0>
 121:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 128:	0f 1f 84 00 00 00 00 
 12f:	00 
 130:	48 89 f0             	mov    %rsi,%rax
 133:	4b f7 24 e0          	mulq   (%r8,%r12,8)
 137:	31 ed                	xor    %ebp,%ebp
 139:	4f 03 6c e1 f8       	add    -0x8(%r9,%r12,8),%r13
 13e:	40 0f 92 c5          	setb   %bpl
 142:	49 01 c5             	add    %rax,%r13
 145:	48 11 d5             	adc    %rdx,%rbp
 148:	4f 89 6c e1 f8       	mov    %r13,-0x8(%r9,%r12,8)
 14d:	48 89 f0             	mov    %rsi,%rax
 150:	4b f7 64 e0 08       	mulq   0x8(%r8,%r12,8)
 155:	45 31 ed             	xor    %r13d,%r13d
 158:	4b 03 2c e1          	add    (%r9,%r12,8),%rbp
 15c:	41 0f 92 c5          	setb   %r13b
 160:	48 01 c5             	add    %rax,%rbp
 163:	49 11 d5             	adc    %rdx,%r13
 166:	4b 89 2c e1          	mov    %rbp,(%r9,%r12,8)
 16a:	49 83 c4 02          	add    $0x2,%r12
 16e:	4c 39 e3             	cmp    %r12,%rbx
 171:	75 bd                	jne    130 <verigmp::fast_multiply::base_full+0x130>
 173:	f6 c1 01             	test   $0x1,%cl
 176:	0f 85 64 ff ff ff    	jne    e0 <verigmp::fast_multiply::base_full+0xe0>
 17c:	eb 80                	jmp    fe <verigmp::fast_multiply::base_full+0xfe>
 17e:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 185 <verigmp::fast_multiply::base_full+0x185>
			181: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.94-0x4
 185:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 18c <verigmp::fast_multiply::base_full+0x18c>
			188: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.95-0x4
 18c:	be 1d 00 00 00       	mov    $0x1d,%esi
 191:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 197 <verigmp::fast_multiply::base_full+0x197>
			193: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 197:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 19e <verigmp::fast_multiply::base_full+0x19e>
			19a: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.96-0x4
 19e:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 1a5 <verigmp::fast_multiply::base_full+0x1a5>
			1a1: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.97-0x4
 1a5:	be 24 00 00 00       	mov    $0x24,%esi
 1aa:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1b0 <verigmp::fast_multiply::base_full+0x1b0>
			1ac: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 1b0:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 1b7 <verigmp::fast_multiply::base_full+0x1b7>
			1b3: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.98-0x4
 1b7:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 1be <verigmp::fast_multiply::base_full+0x1be>
			1ba: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.99-0x4
 1be:	be 2a 00 00 00       	mov    $0x2a,%esi
 1c3:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1c9 <verigmp::fast_multiply::base_full+0x1c9>
			1c5: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout10slot_entry:

0000000000000000 <verigmp::packed_layout::slot_entry>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_layout::slot_entry+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_layout::slot_entry+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.101-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_layout::slot_entry+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout11slots_equal:

0000000000000000 <verigmp::packed_layout::slots_equal>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_layout::slots_equal+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_layout::slots_equal+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.102-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_layout::slots_equal+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout14checked_layout:

0000000000000000 <verigmp::packed_layout::checked_layout>:
   0:	48 85 d2             	test   %rdx,%rdx
   3:	74 39                	je     3e <verigmp::packed_layout::checked_layout+0x3e>
   5:	48 ff ca             	dec    %rdx
   8:	48 c1 ea 06          	shr    $0x6,%rdx
   c:	48 39 d1             	cmp    %rdx,%rcx
   f:	76 39                	jbe    4a <verigmp::packed_layout::checked_layout+0x4a>
  11:	48 ff c2             	inc    %rdx
  14:	48 89 f0             	mov    %rsi,%rax
  17:	49 89 d1             	mov    %rdx,%r9
  1a:	48 f7 e2             	mul    %rdx
  1d:	70 37                	jo     56 <verigmp::packed_layout::checked_layout+0x56>
  1f:	49 89 c0             	mov    %rax,%r8
  22:	48 89 f0             	mov    %rsi,%rax
  25:	48 f7 e1             	mul    %rcx
  28:	70 2c                	jo     56 <verigmp::packed_layout::checked_layout+0x56>
  2a:	4c 89 4f 08          	mov    %r9,0x8(%rdi)
  2e:	4c 89 47 10          	mov    %r8,0x10(%rdi)
  32:	48 89 47 18          	mov    %rax,0x18(%rdi)
  36:	31 c0                	xor    %eax,%eax
  38:	88 07                	mov    %al,(%rdi)
  3a:	48 89 f8             	mov    %rdi,%rax
  3d:	c3                   	ret
  3e:	c6 47 01 00          	movb   $0x0,0x1(%rdi)
  42:	b0 01                	mov    $0x1,%al
  44:	88 07                	mov    %al,(%rdi)
  46:	48 89 f8             	mov    %rdi,%rax
  49:	c3                   	ret
  4a:	c6 47 01 01          	movb   $0x1,0x1(%rdi)
  4e:	b0 01                	mov    $0x1,%al
  50:	88 07                	mov    %al,(%rdi)
  52:	48 89 f8             	mov    %rdi,%rax
  55:	c3                   	ret
  56:	c6 47 01 02          	movb   $0x2,0x1(%rdi)
  5a:	b0 01                	mov    $0x1,%al
  5c:	88 07                	mov    %al,(%rdi)
  5e:	48 89 f8             	mov    %rdi,%rax
  61:	c3                   	ret

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout17coefficient_limbs:

0000000000000000 <verigmp::packed_layout::coefficient_limbs>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_layout::coefficient_limbs+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_layout::coefficient_limbs+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.103-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_layout::coefficient_limbs+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout17pack_coefficients:

0000000000000000 <verigmp::packed_layout::pack_coefficients>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	48 83 ec 28          	sub    $0x28,%rsp
   e:	48 89 34 24          	mov    %rsi,(%rsp)
  12:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  17:	4d 85 c9             	test   %r9,%r9
  1a:	74 65                	je     81 <verigmp::packed_layout::pack_coefficients+0x81>
  1c:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  21:	49 ff c9             	dec    %r9
  24:	49 c1 e9 06          	shr    $0x6,%r9
  28:	b0 01                	mov    $0x1,%al
  2a:	4c 39 ce             	cmp    %r9,%rsi
  2d:	76 54                	jbe    83 <verigmp::packed_layout::pack_coefficients+0x83>
  2f:	49 89 d3             	mov    %rdx,%r11
  32:	49 8d 79 01          	lea    0x1(%r9),%rdi
  36:	4c 89 c0             	mov    %r8,%rax
  39:	48 f7 e7             	mul    %rdi
  3c:	49 89 c2             	mov    %rax,%r10
  3f:	b0 02                	mov    $0x2,%al
  41:	70 40                	jo     83 <verigmp::packed_layout::pack_coefficients+0x83>
  43:	4c 89 c0             	mov    %r8,%rax
  46:	48 f7 e6             	mul    %rsi
  49:	48 89 c2             	mov    %rax,%rdx
  4c:	b0 02                	mov    $0x2,%al
  4e:	70 33                	jo     83 <verigmp::packed_layout::pack_coefficients+0x83>
  50:	b0 03                	mov    $0x3,%al
  52:	4c 39 d1             	cmp    %r10,%rcx
  55:	75 2c                	jne    83 <verigmp::packed_layout::pack_coefficients+0x83>
  57:	b0 04                	mov    $0x4,%al
  59:	48 39 14 24          	cmp    %rdx,(%rsp)
  5d:	75 24                	jne    83 <verigmp::packed_layout::pack_coefficients+0x83>
  5f:	b0 ff                	mov    $0xff,%al
  61:	4d 85 c0             	test   %r8,%r8
  64:	74 1d                	je     83 <verigmp::packed_layout::pack_coefficients+0x83>
  66:	48 89 c8             	mov    %rcx,%rax
  69:	48 09 f8             	or     %rdi,%rax
  6c:	48 c1 e8 20          	shr    $0x20,%rax
  70:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  75:	74 1b                	je     92 <verigmp::packed_layout::pack_coefficients+0x92>
  77:	48 89 c8             	mov    %rcx,%rax
  7a:	31 d2                	xor    %edx,%edx
  7c:	48 f7 f7             	div    %rdi
  7f:	eb 17                	jmp    98 <verigmp::packed_layout::pack_coefficients+0x98>
  81:	31 c0                	xor    %eax,%eax
  83:	48 83 c4 28          	add    $0x28,%rsp
  87:	5b                   	pop    %rbx
  88:	41 5c                	pop    %r12
  8a:	41 5d                	pop    %r13
  8c:	41 5e                	pop    %r14
  8e:	41 5f                	pop    %r15
  90:	5d                   	pop    %rbp
  91:	c3                   	ret
  92:	89 c8                	mov    %ecx,%eax
  94:	31 d2                	xor    %edx,%edx
  96:	f7 f7                	div    %edi
  98:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  9d:	49 89 f5             	mov    %rsi,%r13
  a0:	49 83 e5 fe          	and    $0xfffffffffffffffe,%r13
  a4:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
  a9:	49 8d 6b 08          	lea    0x8(%r11),%rbp
  ad:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  b2:	4c 8d 60 08          	lea    0x8(%rax),%r12
  b6:	31 db                	xor    %ebx,%ebx
  b8:	45 31 db             	xor    %r11d,%r11d
  bb:	31 d2                	xor    %edx,%edx
  bd:	45 31 d2             	xor    %r10d,%r10d
  c0:	b0 ff                	mov    $0xff,%al
  c2:	eb 51                	jmp    115 <verigmp::packed_layout::pack_coefficients+0x115>
  c4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  cb:	00 00 00 00 00 
  d0:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  d5:	48 8d 3c df          	lea    (%rdi,%rbx,8),%rdi
  d9:	48 8b 1c cf          	mov    (%rdi,%rcx,8),%rbx
  dd:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  e2:	4a 8d 3c df          	lea    (%rdi,%r11,8),%rdi
  e6:	48 89 1c cf          	mov    %rbx,(%rdi,%rcx,8)
  ea:	48 ff c2             	inc    %rdx
  ed:	4a 8d 0c cd 08 00 00 	lea    0x8(,%r9,8),%rcx
  f4:	00 
  f5:	48 01 cd             	add    %rcx,%rbp
  f8:	48 8d 0c f5 00 00 00 	lea    0x0(,%rsi,8),%rcx
  ff:	00 
 100:	49 01 cc             	add    %rcx,%r12
 103:	4c 89 f3             	mov    %r14,%rbx
 106:	4d 89 d3             	mov    %r10,%r11
 109:	4c 39 c2             	cmp    %r8,%rdx
 10c:	4c 89 ff             	mov    %r15,%rdi
 10f:	0f 84 6e ff ff ff    	je     83 <verigmp::packed_layout::pack_coefficients+0x83>
 115:	49 01 f2             	add    %rsi,%r10
 118:	0f 82 9a 00 00 00    	jb     1b8 <verigmp::packed_layout::pack_coefficients+0x1b8>
 11e:	4c 3b 14 24          	cmp    (%rsp),%r10
 122:	0f 87 90 00 00 00    	ja     1b8 <verigmp::packed_layout::pack_coefficients+0x1b8>
 128:	4c 8d 34 3b          	lea    (%rbx,%rdi,1),%r14
 12c:	48 3b 54 24 08       	cmp    0x8(%rsp),%rdx
 131:	0f 84 98 00 00 00    	je     1cf <verigmp::packed_layout::pack_coefficients+0x1cf>
 137:	49 89 ff             	mov    %rdi,%r15
 13a:	31 c9                	xor    %ecx,%ecx
 13c:	48 83 fe 01          	cmp    $0x1,%rsi
 140:	75 20                	jne    162 <verigmp::packed_layout::pack_coefficients+0x162>
 142:	eb 64                	jmp    1a8 <verigmp::packed_layout::pack_coefficients+0x1a8>
 144:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 14b:	00 00 00 00 00 
 150:	48 8b 7c cd 00       	mov    0x0(%rbp,%rcx,8),%rdi
 155:	49 89 3c cc          	mov    %rdi,(%r12,%rcx,8)
 159:	48 83 c1 02          	add    $0x2,%rcx
 15d:	49 39 cd             	cmp    %rcx,%r13
 160:	74 3c                	je     19e <verigmp::packed_layout::pack_coefficients+0x19e>
 162:	4c 39 c9             	cmp    %r9,%rcx
 165:	76 19                	jbe    180 <verigmp::packed_layout::pack_coefficients+0x180>
 167:	31 ff                	xor    %edi,%edi
 169:	49 89 7c cc f8       	mov    %rdi,-0x8(%r12,%rcx,8)
 16e:	4c 39 c9             	cmp    %r9,%rcx
 171:	72 dd                	jb     150 <verigmp::packed_layout::pack_coefficients+0x150>
 173:	eb 1a                	jmp    18f <verigmp::packed_layout::pack_coefficients+0x18f>
 175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 17c:	00 00 00 00 
 180:	48 8b 7c cd f8       	mov    -0x8(%rbp,%rcx,8),%rdi
 185:	49 89 7c cc f8       	mov    %rdi,-0x8(%r12,%rcx,8)
 18a:	4c 39 c9             	cmp    %r9,%rcx
 18d:	72 c1                	jb     150 <verigmp::packed_layout::pack_coefficients+0x150>
 18f:	31 ff                	xor    %edi,%edi
 191:	49 89 3c cc          	mov    %rdi,(%r12,%rcx,8)
 195:	48 83 c1 02          	add    $0x2,%rcx
 199:	49 39 cd             	cmp    %rcx,%r13
 19c:	75 c4                	jne    162 <verigmp::packed_layout::pack_coefficients+0x162>
 19e:	40 f6 c6 01          	test   $0x1,%sil
 1a2:	0f 84 42 ff ff ff    	je     ea <verigmp::packed_layout::pack_coefficients+0xea>
 1a8:	4c 39 c9             	cmp    %r9,%rcx
 1ab:	0f 86 1f ff ff ff    	jbe    d0 <verigmp::packed_layout::pack_coefficients+0xd0>
 1b1:	31 db                	xor    %ebx,%ebx
 1b3:	e9 25 ff ff ff       	jmp    dd <verigmp::packed_layout::pack_coefficients+0xdd>
 1b8:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 1bf <verigmp::packed_layout::pack_coefficients+0x1bf>
			1bb: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.105-0x4
 1bf:	4c 89 df             	mov    %r11,%rdi
 1c2:	4c 89 d6             	mov    %r10,%rsi
 1c5:	48 8b 14 24          	mov    (%rsp),%rdx
 1c9:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1cf <verigmp::packed_layout::pack_coefficients+0x1cf>
			1cb: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 1cf:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 1d6 <verigmp::packed_layout::pack_coefficients+0x1d6>
			1d2: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.104-0x4
 1d6:	48 89 df             	mov    %rbx,%rdi
 1d9:	4c 89 f6             	mov    %r14,%rsi
 1dc:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 1e1:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1e7 <verigmp::packed_layout::pack_coefficients+0x1e7>
			1e3: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout18layout_lengths_fit:

0000000000000000 <verigmp::packed_layout::layout_lengths_fit>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_layout::layout_lengths_fit+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_layout::layout_lengths_fit+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.106-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_layout::layout_lengths_fit+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout18pack_error_matches:

0000000000000000 <verigmp::packed_layout::pack_error_matches>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_layout::pack_error_matches+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_layout::pack_error_matches+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.107-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_layout::pack_error_matches+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout20compact_coefficients:

0000000000000000 <verigmp::packed_layout::compact_coefficients>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_layout::compact_coefficients+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_layout::compact_coefficients+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.108-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_layout::compact_coefficients+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout20extract_coefficients:

0000000000000000 <verigmp::packed_layout::extract_coefficients>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	48 83 ec 28          	sub    $0x28,%rsp
   e:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  13:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  18:	4d 85 c9             	test   %r9,%r9
  1b:	74 68                	je     85 <verigmp::packed_layout::extract_coefficients+0x85>
  1d:	4d 89 ce             	mov    %r9,%r14
  20:	49 ff ce             	dec    %r14
  23:	49 c1 ee 06          	shr    $0x6,%r14
  27:	40 b7 01             	mov    $0x1,%dil
  2a:	4c 39 74 24 60       	cmp    %r14,0x60(%rsp)
  2f:	76 56                	jbe    87 <verigmp::packed_layout::extract_coefficients+0x87>
  31:	4d 89 c4             	mov    %r8,%r12
  34:	49 ff c6             	inc    %r14
  37:	4c 89 c0             	mov    %r8,%rax
  3a:	49 f7 e6             	mul    %r14
  3d:	40 b7 02             	mov    $0x2,%dil
  40:	70 45                	jo     87 <verigmp::packed_layout::extract_coefficients+0x87>
  42:	48 89 cb             	mov    %rcx,%rbx
  45:	48 89 c1             	mov    %rax,%rcx
  48:	4c 89 e0             	mov    %r12,%rax
  4b:	48 f7 64 24 60       	mulq   0x60(%rsp)
  50:	70 35                	jo     87 <verigmp::packed_layout::extract_coefficients+0x87>
  52:	40 b7 03             	mov    $0x3,%dil
  55:	48 39 c3             	cmp    %rax,%rbx
  58:	75 2d                	jne    87 <verigmp::packed_layout::extract_coefficients+0x87>
  5a:	40 b7 04             	mov    $0x4,%dil
  5d:	48 39 ce             	cmp    %rcx,%rsi
  60:	75 25                	jne    87 <verigmp::packed_layout::extract_coefficients+0x87>
  62:	40 b7 ff             	mov    $0xff,%dil
  65:	4d 85 e4             	test   %r12,%r12
  68:	74 1d                	je     87 <verigmp::packed_layout::extract_coefficients+0x87>
  6a:	48 89 f0             	mov    %rsi,%rax
  6d:	4c 09 f0             	or     %r14,%rax
  70:	48 c1 e8 20          	shr    $0x20,%rax
  74:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  79:	74 1d                	je     98 <verigmp::packed_layout::extract_coefficients+0x98>
  7b:	48 89 f0             	mov    %rsi,%rax
  7e:	31 d2                	xor    %edx,%edx
  80:	49 f7 f6             	div    %r14
  83:	eb 1a                	jmp    9f <verigmp::packed_layout::extract_coefficients+0x9f>
  85:	31 ff                	xor    %edi,%edi
  87:	89 f8                	mov    %edi,%eax
  89:	48 83 c4 28          	add    $0x28,%rsp
  8d:	5b                   	pop    %rbx
  8e:	41 5c                	pop    %r12
  90:	41 5d                	pop    %r13
  92:	41 5e                	pop    %r14
  94:	41 5f                	pop    %r15
  96:	5d                   	pop    %rbp
  97:	c3                   	ret
  98:	89 f0                	mov    %esi,%eax
  9a:	31 d2                	xor    %edx,%edx
  9c:	41 f7 f6             	div    %r14d
  9f:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  a4:	31 ff                	xor    %edi,%edi
  a6:	31 ed                	xor    %ebp,%ebp
  a8:	45 31 ff             	xor    %r15d,%r15d
  ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  b0:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  b5:	4c 8d 2c 07          	lea    (%rdi,%rax,1),%r13
  b9:	49 39 fd             	cmp    %rdi,%r13
  bc:	72 48                	jb     106 <verigmp::packed_layout::extract_coefficients+0x106>
  be:	49 39 dd             	cmp    %rbx,%r13
  c1:	77 43                	ja     106 <verigmp::packed_layout::extract_coefficients+0x106>
  c3:	49 8d 34 3e          	lea    (%r14,%rdi,1),%rsi
  c7:	48 39 de             	cmp    %rbx,%rsi
  ca:	77 4d                	ja     119 <verigmp::packed_layout::extract_coefficients+0x119>
  cc:	4c 39 7c 24 08       	cmp    %r15,0x8(%rsp)
  d1:	74 56                	je     129 <verigmp::packed_layout::extract_coefficients+0x129>
  d3:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  d8:	48 8d 34 f8          	lea    (%rax,%rdi,8),%rsi
  dc:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  e1:	48 8d 3c e8          	lea    (%rax,%rbp,8),%rdi
  e5:	4c 01 f5             	add    %r14,%rbp
  e8:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
  ef:	00 
  f0:	ff 15 00 00 00 00    	call   *0x0(%rip)        # f6 <verigmp::packed_layout::extract_coefficients+0xf6>
			f2: R_X86_64_GOTPCREL	memcpy-0x4
  f6:	49 ff c7             	inc    %r15
  f9:	4c 89 ef             	mov    %r13,%rdi
  fc:	4d 39 fc             	cmp    %r15,%r12
  ff:	75 af                	jne    b0 <verigmp::packed_layout::extract_coefficients+0xb0>
 101:	40 b7 ff             	mov    $0xff,%dil
 104:	eb 81                	jmp    87 <verigmp::packed_layout::extract_coefficients+0x87>
 106:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 10d <verigmp::packed_layout::extract_coefficients+0x10d>
			109: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.111-0x4
 10d:	4c 89 ee             	mov    %r13,%rsi
 110:	48 89 da             	mov    %rbx,%rdx
 113:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 119 <verigmp::packed_layout::extract_coefficients+0x119>
			115: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 119:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 120 <verigmp::packed_layout::extract_coefficients+0x120>
			11c: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.110-0x4
 120:	48 89 da             	mov    %rbx,%rdx
 123:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 129 <verigmp::packed_layout::extract_coefficients+0x129>
			125: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 129:	49 01 ee             	add    %rbp,%r14
 12c:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 133 <verigmp::packed_layout::extract_coefficients+0x133>
			12f: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.109-0x4
 133:	48 89 ef             	mov    %rbp,%rdi
 136:	4c 89 f6             	mov    %r14,%rsi
 139:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 13e:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 144 <verigmp::packed_layout::extract_coefficients+0x144>
			140: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout21extract_error_matches:

0000000000000000 <verigmp::packed_layout::extract_error_matches>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_layout::extract_error_matches+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_layout::extract_error_matches+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.112-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_layout::extract_error_matches+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout22canonical_packed_slots:

0000000000000000 <verigmp::packed_layout::canonical_packed_slots>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_layout::canonical_packed_slots+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_layout::canonical_packed_slots+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.113-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_layout::canonical_packed_slots+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout24canonical_slot_low_value:

0000000000000000 <verigmp::packed_layout::canonical_slot_low_value>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_layout::canonical_slot_low_value+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_layout::canonical_slot_low_value+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.114-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_layout::canonical_slot_low_value+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout31precision_layout_interpretation:

0000000000000000 <verigmp::packed_layout::precision_layout_interpretation>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_layout::precision_layout_interpretation+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_layout::precision_layout_interpretation+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.115-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_layout::precision_layout_interpretation+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp13packed_layout34coefficient_width_covers_precision:

0000000000000000 <verigmp::packed_layout::coefficient_width_covers_precision>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_layout::coefficient_width_covers_precision+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_layout::coefficient_width_covers_precision+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.116-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_layout::coefficient_width_covers_precision+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp13toom_evaluate8negative:

0000000000000000 <verigmp::toom_evaluate::negative>:
   0:	53                   	push   %rbx
   1:	4c 39 c9             	cmp    %r9,%rcx
   4:	0f 85 3f 02 00 00    	jne    249 <verigmp::toom_evaluate::negative+0x249>
   a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   f:	48 39 c8             	cmp    %rcx,%rax
  12:	0f 87 31 02 00 00    	ja     249 <verigmp::toom_evaluate::negative+0x249>
  18:	4c 8d 49 01          	lea    0x1(%rcx),%r9
  1c:	4c 39 ce             	cmp    %r9,%rsi
  1f:	0f 85 3d 02 00 00    	jne    262 <verigmp::toom_evaluate::negative+0x262>
  25:	48 83 fe 01          	cmp    $0x1,%rsi
  29:	75 0e                	jne    39 <verigmp::toom_evaluate::negative+0x39>
  2b:	45 31 c9             	xor    %r9d,%r9d
  2e:	49 39 c9             	cmp    %rcx,%r9
  31:	73 7b                	jae    ae <verigmp::toom_evaluate::negative+0xae>
  33:	4a 8b 14 ca          	mov    (%rdx,%r9,8),%rdx
  37:	eb 77                	jmp    b0 <verigmp::toom_evaluate::negative+0xb0>
  39:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
  40:	ff ff 0f 
  43:	49 21 f2             	and    %rsi,%r10
  46:	45 31 db             	xor    %r11d,%r11d
  49:	eb 17                	jmp    62 <verigmp::toom_evaluate::negative+0x62>
  4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  50:	4a 8b 5c ca 08       	mov    0x8(%rdx,%r9,8),%rbx
  55:	4a 89 5c cf 08       	mov    %rbx,0x8(%rdi,%r9,8)
  5a:	49 ff c3             	inc    %r11
  5d:	4d 39 d3             	cmp    %r10,%r11
  60:	74 3d                	je     9f <verigmp::toom_evaluate::negative+0x9f>
  62:	4d 89 d9             	mov    %r11,%r9
  65:	49 39 cb             	cmp    %rcx,%r11
  68:	73 16                	jae    80 <verigmp::toom_evaluate::negative+0x80>
  6a:	4e 8b 1c ca          	mov    (%rdx,%r9,8),%r11
  6e:	4e 89 1c cf          	mov    %r11,(%rdi,%r9,8)
  72:	4d 8d 59 01          	lea    0x1(%r9),%r11
  76:	49 39 cb             	cmp    %rcx,%r11
  79:	72 d5                	jb     50 <verigmp::toom_evaluate::negative+0x50>
  7b:	eb 13                	jmp    90 <verigmp::toom_evaluate::negative+0x90>
  7d:	0f 1f 00             	nopl   (%rax)
  80:	45 31 db             	xor    %r11d,%r11d
  83:	4e 89 1c cf          	mov    %r11,(%rdi,%r9,8)
  87:	4d 8d 59 01          	lea    0x1(%r9),%r11
  8b:	49 39 cb             	cmp    %rcx,%r11
  8e:	72 c0                	jb     50 <verigmp::toom_evaluate::negative+0x50>
  90:	31 db                	xor    %ebx,%ebx
  92:	4a 89 5c cf 08       	mov    %rbx,0x8(%rdi,%r9,8)
  97:	49 ff c3             	inc    %r11
  9a:	4d 39 d3             	cmp    %r10,%r11
  9d:	75 c3                	jne    62 <verigmp::toom_evaluate::negative+0x62>
  9f:	40 f6 c6 01          	test   $0x1,%sil
  a3:	74 0f                	je     b4 <verigmp::toom_evaluate::negative+0xb4>
  a5:	49 83 c1 02          	add    $0x2,%r9
  a9:	49 39 c9             	cmp    %rcx,%r9
  ac:	72 85                	jb     33 <verigmp::toom_evaluate::negative+0x33>
  ae:	31 d2                	xor    %edx,%edx
  b0:	4a 89 14 cf          	mov    %rdx,(%rdi,%r9,8)
  b4:	48 85 c0             	test   %rax,%rax
  b7:	0f 84 c1 00 00 00    	je     17e <verigmp::toom_evaluate::negative+0x17e>
  bd:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  c2:	48 83 f8 01          	cmp    $0x1,%rax
  c6:	75 07                	jne    cf <verigmp::toom_evaluate::negative+0xcf>
  c8:	31 d2                	xor    %edx,%edx
  ca:	45 31 d2             	xor    %r10d,%r10d
  cd:	eb 58                	jmp    127 <verigmp::toom_evaluate::negative+0x127>
  cf:	49 bb fe ff ff ff ff 	movabs $0xffffffffffffffe,%r11
  d6:	ff ff 0f 
  d9:	49 21 c3             	and    %rax,%r11
  dc:	31 d2                	xor    %edx,%edx
  de:	45 31 d2             	xor    %r10d,%r10d
  e1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  e8:	0f 1f 84 00 00 00 00 
  ef:	00 
  f0:	31 db                	xor    %ebx,%ebx
  f2:	4a 03 14 d7          	add    (%rdi,%r10,8),%rdx
  f6:	0f 92 c3             	setb   %bl
  f9:	4b 03 14 d1          	add    (%r9,%r10,8),%rdx
  fd:	4a 89 14 d7          	mov    %rdx,(%rdi,%r10,8)
 101:	4a 13 5c d7 08       	adc    0x8(%rdi,%r10,8),%rbx
 106:	0f 92 c2             	setb   %dl
 109:	0f b6 d2             	movzbl %dl,%edx
 10c:	4b 03 5c d1 08       	add    0x8(%r9,%r10,8),%rbx
 111:	48 83 d2 00          	adc    $0x0,%rdx
 115:	4a 89 5c d7 08       	mov    %rbx,0x8(%rdi,%r10,8)
 11a:	49 83 c2 02          	add    $0x2,%r10
 11e:	4d 39 d3             	cmp    %r10,%r11
 121:	75 cd                	jne    f0 <verigmp::toom_evaluate::negative+0xf0>
 123:	a8 01                	test   $0x1,%al
 125:	74 1a                	je     141 <verigmp::toom_evaluate::negative+0x141>
 127:	45 31 db             	xor    %r11d,%r11d
 12a:	4a 03 14 d7          	add    (%rdi,%r10,8),%rdx
 12e:	41 0f 92 c3          	setb   %r11b
 132:	4b 03 14 d1          	add    (%r9,%r10,8),%rdx
 136:	49 83 d3 00          	adc    $0x0,%r11
 13a:	4a 89 14 d7          	mov    %rdx,(%rdi,%r10,8)
 13e:	4c 89 da             	mov    %r11,%rdx
 141:	48 85 d2             	test   %rdx,%rdx
 144:	74 38                	je     17e <verigmp::toom_evaluate::negative+0x17e>
 146:	49 89 f1             	mov    %rsi,%r9
 149:	49 29 c1             	sub    %rax,%r9
 14c:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
 150:	41 ba 01 00 00 00    	mov    $0x1,%r10d
 156:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 15d:	00 00 00 
 160:	45 31 db             	xor    %r11d,%r11d
 163:	4a 01 54 d0 f8       	add    %rdx,-0x8(%rax,%r10,8)
 168:	0f 92 c2             	setb   %dl
 16b:	4d 39 ca             	cmp    %r9,%r10
 16e:	73 0e                	jae    17e <verigmp::toom_evaluate::negative+0x17e>
 170:	41 88 d3             	mov    %dl,%r11b
 173:	49 ff c2             	inc    %r10
 176:	4c 89 da             	mov    %r11,%rdx
 179:	45 84 db             	test   %r11b,%r11b
 17c:	75 e2                	jne    160 <verigmp::toom_evaluate::negative+0x160>
 17e:	48 85 f6             	test   %rsi,%rsi
 181:	74 7b                	je     1fe <verigmp::toom_evaluate::negative+0x1fe>
 183:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
 187:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 18e:	00 00 
 190:	48 39 c8             	cmp    %rcx,%rax
 193:	73 1b                	jae    1b0 <verigmp::toom_evaluate::negative+0x1b0>
 195:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
 199:	48 39 14 c7          	cmp    %rdx,(%rdi,%rax,8)
 19d:	74 19                	je     1b8 <verigmp::toom_evaluate::negative+0x1b8>
 19f:	eb 1f                	jmp    1c0 <verigmp::toom_evaluate::negative+0x1c0>
 1a1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1a8:	0f 1f 84 00 00 00 00 
 1af:	00 
 1b0:	31 d2                	xor    %edx,%edx
 1b2:	48 39 14 c7          	cmp    %rdx,(%rdi,%rax,8)
 1b6:	75 08                	jne    1c0 <verigmp::toom_evaluate::negative+0x1c0>
 1b8:	48 83 c0 ff          	add    $0xffffffffffffffff,%rax
 1bc:	72 d2                	jb     190 <verigmp::toom_evaluate::negative+0x190>
 1be:	eb 3e                	jmp    1fe <verigmp::toom_evaluate::negative+0x1fe>
 1c0:	73 3c                	jae    1fe <verigmp::toom_evaluate::negative+0x1fe>
 1c2:	31 d2                	xor    %edx,%edx
 1c4:	31 c0                	xor    %eax,%eax
 1c6:	eb 2c                	jmp    1f4 <verigmp::toom_evaluate::negative+0x1f4>
 1c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 1cf:	00 
 1d0:	4d 8b 0c c0          	mov    (%r8,%rax,8),%r9
 1d4:	4c 2b 0c c7          	sub    (%rdi,%rax,8),%r9
 1d8:	41 0f 92 c2          	setb   %r10b
 1dc:	49 29 d1             	sub    %rdx,%r9
 1df:	0f 92 c2             	setb   %dl
 1e2:	44 08 d2             	or     %r10b,%dl
 1e5:	0f b6 d2             	movzbl %dl,%edx
 1e8:	4c 89 0c c7          	mov    %r9,(%rdi,%rax,8)
 1ec:	48 ff c0             	inc    %rax
 1ef:	48 39 c6             	cmp    %rax,%rsi
 1f2:	74 51                	je     245 <verigmp::toom_evaluate::negative+0x245>
 1f4:	48 39 c8             	cmp    %rcx,%rax
 1f7:	72 d7                	jb     1d0 <verigmp::toom_evaluate::negative+0x1d0>
 1f9:	45 31 c9             	xor    %r9d,%r9d
 1fc:	eb d6                	jmp    1d4 <verigmp::toom_evaluate::negative+0x1d4>
 1fe:	31 d2                	xor    %edx,%edx
 200:	31 c0                	xor    %eax,%eax
 202:	eb 33                	jmp    237 <verigmp::toom_evaluate::negative+0x237>
 204:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 20b:	00 00 00 00 00 
 210:	4d 8b 0c c0          	mov    (%r8,%rax,8),%r9
 214:	4c 8b 14 c7          	mov    (%rdi,%rax,8),%r10
 218:	4d 29 ca             	sub    %r9,%r10
 21b:	41 0f 92 c1          	setb   %r9b
 21f:	49 29 d2             	sub    %rdx,%r10
 222:	0f 92 c2             	setb   %dl
 225:	44 08 ca             	or     %r9b,%dl
 228:	0f b6 d2             	movzbl %dl,%edx
 22b:	4c 89 14 c7          	mov    %r10,(%rdi,%rax,8)
 22f:	48 ff c0             	inc    %rax
 232:	48 39 c6             	cmp    %rax,%rsi
 235:	74 0a                	je     241 <verigmp::toom_evaluate::negative+0x241>
 237:	48 39 c8             	cmp    %rcx,%rax
 23a:	72 d4                	jb     210 <verigmp::toom_evaluate::negative+0x210>
 23c:	45 31 c9             	xor    %r9d,%r9d
 23f:	eb d3                	jmp    214 <verigmp::toom_evaluate::negative+0x214>
 241:	31 c0                	xor    %eax,%eax
 243:	5b                   	pop    %rbx
 244:	c3                   	ret
 245:	b0 01                	mov    $0x1,%al
 247:	5b                   	pop    %rbx
 248:	c3                   	ret
 249:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 250 <verigmp::toom_evaluate::negative+0x250>
			24c: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.117-0x4
 250:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 257 <verigmp::toom_evaluate::negative+0x257>
			253: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.119-0x4
 257:	be 3e 00 00 00       	mov    $0x3e,%esi
 25c:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 262 <verigmp::toom_evaluate::negative+0x262>
			25e: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 262:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 269 <verigmp::toom_evaluate::negative+0x269>
			265: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.120-0x4
 269:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 270 <verigmp::toom_evaluate::negative+0x270>
			26c: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.121-0x4
 270:	be 44 00 00 00       	mov    $0x44,%esi
 275:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 27b <verigmp::toom_evaluate::negative+0x27b>
			277: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp13toom_multiply4full:

0000000000000000 <verigmp::toom_multiply::full>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	48 83 ec 58          	sub    $0x58,%rsp
   e:	48 85 c9             	test   %rcx,%rcx
  11:	0f 84 80 09 00 00    	je     997 <verigmp::toom_multiply::full+0x997>
  17:	4c 39 c9             	cmp    %r9,%rcx
  1a:	0f 85 77 09 00 00    	jne    997 <verigmp::toom_multiply::full+0x997>
  20:	48 8d 04 09          	lea    (%rcx,%rcx,1),%rax
  24:	48 39 c6             	cmp    %rax,%rsi
  27:	0f 85 51 09 00 00    	jne    97e <verigmp::toom_multiply::full+0x97e>
  2d:	4c 8b 94 24 98 00 00 	mov    0x98(%rsp),%r10
  34:	00 
  35:	48 8d 04 8d 00 00 00 	lea    0x0(,%rcx,4),%rax
  3c:	00 
  3d:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  41:	49 39 c2             	cmp    %rax,%r10
  44:	0f 82 34 09 00 00    	jb     97e <verigmp::toom_multiply::full+0x97e>
  4a:	4c 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%r15
  51:	00 
  52:	49 83 ff 17          	cmp    $0x17,%r15
  56:	0f 86 22 09 00 00    	jbe    97e <verigmp::toom_multiply::full+0x97e>
  5c:	4d 89 c6             	mov    %r8,%r14
  5f:	48 89 d5             	mov    %rdx,%rbp
  62:	48 89 fb             	mov    %rdi,%rbx
  65:	4c 8b 9c 24 90 00 00 	mov    0x90(%rsp),%r11
  6c:	00 
  6d:	4c 39 f9             	cmp    %r15,%rcx
  70:	0f 86 d7 01 00 00    	jbe    24d <verigmp::toom_multiply::full+0x24d>
  76:	48 8d 41 02          	lea    0x2(%rcx),%rax
  7a:	48 ba ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdx
  81:	aa aa aa 
  84:	48 f7 e2             	mul    %rdx
  87:	49 89 d5             	mov    %rdx,%r13
  8a:	49 d1 ed             	shr    $1,%r13
  8d:	4c 89 e8             	mov    %r13,%rax
  90:	48 f7 d0             	not    %rax
  93:	4a 8d 14 6d 02 00 00 	lea    0x2(,%r13,2),%rdx
  9a:	00 
  9b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  9f:	49 29 d2             	sub    %rdx,%r10
  a2:	49 8d 14 82          	lea    (%r10,%rax,4),%rdx
  a6:	49 39 d5             	cmp    %rdx,%r13
  a9:	0f 83 59 09 00 00    	jae    a08 <verigmp::toom_multiply::full+0xa08>
  af:	49 8d 7d 01          	lea    0x1(%r13),%rdi
  b3:	48 29 fa             	sub    %rdi,%rdx
  b6:	49 39 d5             	cmp    %rdx,%r13
  b9:	0f 83 62 09 00 00    	jae    a21 <verigmp::toom_multiply::full+0xa21>
  bf:	49 39 cd             	cmp    %rcx,%r13
  c2:	0f 87 e8 08 00 00    	ja     9b0 <verigmp::toom_multiply::full+0x9b0>
  c8:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
  cd:	4a 8d 34 6d 00 00 00 	lea    0x0(,%r13,2),%rsi
  d4:	00 
  d5:	49 89 cc             	mov    %rcx,%r12
  d8:	49 29 f4             	sub    %rsi,%r12
  db:	0f 82 59 09 00 00    	jb     a3a <verigmp::toom_multiply::full+0xa3a>
  e1:	48 89 f9             	mov    %rdi,%rcx
  e4:	48 c1 e1 04          	shl    $0x4,%rcx
  e8:	49 8d 04 0b          	lea    (%r11,%rcx,1),%rax
  ec:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  f1:	48 01 c8             	add    %rcx,%rax
  f4:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  f9:	48 01 c8             	add    %rcx,%rax
  fc:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
 101:	48 01 c8             	add    %rcx,%rax
 104:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 109:	48 01 c1             	add    %rax,%rcx
 10c:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
 111:	48 8d 04 f9          	lea    (%rcx,%rdi,8),%rax
 115:	48 89 04 24          	mov    %rax,(%rsp)
 119:	48 8d 04 f8          	lea    (%rax,%rdi,8),%rax
 11d:	48 29 fa             	sub    %rdi,%rdx
 120:	48 83 ec 08          	sub    $0x8,%rsp
 124:	4c 89 df             	mov    %r11,%rdi
 127:	49 89 d2             	mov    %rdx,%r10
 12a:	48 89 ea             	mov    %rbp,%rdx
 12d:	4c 89 e9             	mov    %r13,%rcx
 130:	4d 89 f0             	mov    %r14,%r8
 133:	4d 89 e9             	mov    %r13,%r9
 136:	41 57                	push   %r15
 138:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
 13d:	41 52                	push   %r10
 13f:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 144:	50                   	push   %rax
 145:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 14b <verigmp::toom_multiply::full+0x14b>
			147: R_X86_64_GOTPCREL	verigmp::toom_multiply::full-0x4
 14b:	4a 8d 0c 6d 00 00 00 	lea    0x0(,%r13,2),%rcx
 152:	00 
 153:	48 83 c4 20          	add    $0x20,%rsp
 157:	0f 57 c0             	xorps  %xmm0,%xmm0
 15a:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
 161:	00 
 162:	0f 11 04 c8          	movups %xmm0,(%rax,%rcx,8)
 166:	4d 89 fa             	mov    %r15,%r10
 169:	4f 8d 3c 24          	lea    (%r12,%r12,1),%r15
 16d:	4a 8d 14 6d 02 00 00 	lea    0x2(,%r13,2),%rdx
 174:	00 
 175:	4c 39 fa             	cmp    %r15,%rdx
 178:	0f 82 4a 08 00 00    	jb     9c8 <verigmp::toom_multiply::full+0x9c8>
 17e:	48 8d 14 cd 00 00 00 	lea    0x0(,%rcx,8),%rdx
 185:	00 
 186:	48 01 ea             	add    %rbp,%rdx
 189:	4d 8d 04 ce          	lea    (%r14,%rcx,8),%r8
 18d:	48 83 ec 08          	sub    $0x8,%rsp
 191:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
 196:	4c 89 fe             	mov    %r15,%rsi
 199:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
 19e:	4c 89 e1             	mov    %r12,%rcx
 1a1:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
 1a6:	4d 89 e1             	mov    %r12,%r9
 1a9:	41 52                	push   %r10
 1ab:	ff 74 24 30          	push   0x30(%rsp)
 1af:	ff 74 24 30          	push   0x30(%rsp)
 1b3:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1b9 <verigmp::toom_multiply::full+0x1b9>
			1b5: R_X86_64_GOTPCREL	verigmp::toom_multiply::full-0x4
 1b9:	48 83 c4 20          	add    $0x20,%rsp
 1bd:	4a 8d 14 6d 02 00 00 	lea    0x2(,%r13,2),%rdx
 1c4:	00 
 1c5:	4c 29 fa             	sub    %r15,%rdx
 1c8:	74 1d                	je     1e7 <verigmp::toom_multiply::full+0x1e7>
 1ca:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 1cf:	4a 8d 3c f8          	lea    (%rax,%r15,8),%rdi
 1d3:	48 83 fa 01          	cmp    $0x1,%rdx
 1d7:	48 83 d2 00          	adc    $0x0,%rdx
 1db:	48 c1 e2 03          	shl    $0x3,%rdx
 1df:	31 f6                	xor    %esi,%esi
 1e1:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1e7 <verigmp::toom_multiply::full+0x1e7>
			1e3: R_X86_64_GOTPCREL	memset-0x4
 1e7:	4d 39 ec             	cmp    %r13,%r12
 1ea:	0f 87 ea 07 00 00    	ja     9da <verigmp::toom_multiply::full+0x9da>
 1f0:	4d 89 ef             	mov    %r13,%r15
 1f3:	49 c1 e7 04          	shl    $0x4,%r15
 1f7:	31 ff                	xor    %edi,%edi
 1f9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
 1fe:	48 89 d0             	mov    %rdx,%rax
 201:	4c 89 e9             	mov    %r13,%rcx
 204:	49 89 eb             	mov    %rbp,%r11
 207:	31 f6                	xor    %esi,%esi
 209:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
 20e:	eb 33                	jmp    243 <verigmp::toom_multiply::full+0x243>
 210:	4f 8b 04 3b          	mov    (%r11,%r15,1),%r8
 214:	45 31 c9             	xor    %r9d,%r9d
 217:	49 01 f8             	add    %rdi,%r8
 21a:	41 0f 92 c1          	setb   %r9b
 21e:	4f 03 04 eb          	add    (%r11,%r13,8),%r8
 222:	49 83 d1 00          	adc    $0x0,%r9
 226:	4d 03 03             	add    (%r11),%r8
 229:	4c 89 cf             	mov    %r9,%rdi
 22c:	48 83 d7 00          	adc    $0x0,%rdi
 230:	4c 89 00             	mov    %r8,(%rax)
 233:	48 ff c6             	inc    %rsi
 236:	49 83 c3 08          	add    $0x8,%r11
 23a:	48 83 c0 08          	add    $0x8,%rax
 23e:	48 ff c9             	dec    %rcx
 241:	74 2f                	je     272 <verigmp::toom_multiply::full+0x272>
 243:	4c 39 e6             	cmp    %r12,%rsi
 246:	72 c8                	jb     210 <verigmp::toom_multiply::full+0x210>
 248:	45 31 c0             	xor    %r8d,%r8d
 24b:	eb c7                	jmp    214 <verigmp::toom_multiply::full+0x214>
 24d:	48 83 ec 08          	sub    $0x8,%rsp
 251:	48 89 df             	mov    %rbx,%rdi
 254:	48 89 ea             	mov    %rbp,%rdx
 257:	4d 89 f0             	mov    %r14,%r8
 25a:	49 89 c9             	mov    %rcx,%r9
 25d:	6a 18                	push   $0x18
 25f:	41 52                	push   %r10
 261:	41 53                	push   %r11
 263:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 269 <verigmp::toom_multiply::full+0x269>
			265: R_X86_64_GOTPCREL	verigmp::fast_multiply::full-0x4
 269:	48 83 c4 78          	add    $0x78,%rsp
 26d:	e9 01 07 00 00       	jmp    973 <verigmp::toom_multiply::full+0x973>
 272:	4a 89 3c ea          	mov    %rdi,(%rdx,%r13,8)
 276:	31 ff                	xor    %edi,%edi
 278:	48 8b 04 24          	mov    (%rsp),%rax
 27c:	4c 89 e9             	mov    %r13,%rcx
 27f:	4d 89 f3             	mov    %r14,%r11
 282:	31 f6                	xor    %esi,%esi
 284:	eb 3d                	jmp    2c3 <verigmp::toom_multiply::full+0x2c3>
 286:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 28d:	00 00 00 
 290:	4f 8b 04 3b          	mov    (%r11,%r15,1),%r8
 294:	45 31 c9             	xor    %r9d,%r9d
 297:	49 01 f8             	add    %rdi,%r8
 29a:	41 0f 92 c1          	setb   %r9b
 29e:	4f 03 04 eb          	add    (%r11,%r13,8),%r8
 2a2:	49 83 d1 00          	adc    $0x0,%r9
 2a6:	4d 03 03             	add    (%r11),%r8
 2a9:	4c 89 cf             	mov    %r9,%rdi
 2ac:	48 83 d7 00          	adc    $0x0,%rdi
 2b0:	4c 89 00             	mov    %r8,(%rax)
 2b3:	48 ff c6             	inc    %rsi
 2b6:	49 83 c3 08          	add    $0x8,%r11
 2ba:	48 83 c0 08          	add    $0x8,%rax
 2be:	48 ff c9             	dec    %rcx
 2c1:	74 0a                	je     2cd <verigmp::toom_multiply::full+0x2cd>
 2c3:	4c 39 e6             	cmp    %r12,%rsi
 2c6:	72 c8                	jb     290 <verigmp::toom_multiply::full+0x290>
 2c8:	45 31 c0             	xor    %r8d,%r8d
 2cb:	eb c7                	jmp    294 <verigmp::toom_multiply::full+0x294>
 2cd:	4c 8b 04 24          	mov    (%rsp),%r8
 2d1:	4b 89 3c e8          	mov    %rdi,(%r8,%r13,8)
 2d5:	48 83 ec 08          	sub    $0x8,%rsp
 2d9:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
 2de:	4a 8d 34 6d 02 00 00 	lea    0x2(,%r13,2),%rsi
 2e5:	00 
 2e6:	49 8d 4d 01          	lea    0x1(%r13),%rcx
 2ea:	49 89 c9             	mov    %rcx,%r9
 2ed:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
 2f4:	00 
 2f5:	50                   	push   %rax
 2f6:	ff 74 24 30          	push   0x30(%rsp)
 2fa:	41 52                	push   %r10
 2fc:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 302 <verigmp::toom_multiply::full+0x302>
			2fe: R_X86_64_GOTPCREL	verigmp::toom_multiply::full-0x4
 302:	48 83 c4 20          	add    $0x20,%rsp
 306:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
 30b:	49 8d 75 01          	lea    0x1(%r13),%rsi
 30f:	48 89 ea             	mov    %rbp,%rdx
 312:	4c 89 e9             	mov    %r13,%rcx
 315:	4e 8d 44 ed 00       	lea    0x0(%rbp,%r13,8),%r8
 31a:	4d 89 e9             	mov    %r13,%r9
 31d:	41 54                	push   %r12
 31f:	ff 74 24 30          	push   0x30(%rsp)
 323:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 329 <verigmp::toom_multiply::full+0x329>
			325: R_X86_64_GOTPCREL	verigmp::toom_evaluate::negative-0x4
 329:	48 83 c4 10          	add    $0x10,%rsp
 32d:	88 44 24 28          	mov    %al,0x28(%rsp)
 331:	48 8b 3c 24          	mov    (%rsp),%rdi
 335:	49 8d 75 01          	lea    0x1(%r13),%rsi
 339:	4c 89 f2             	mov    %r14,%rdx
 33c:	4c 89 e9             	mov    %r13,%rcx
 33f:	4f 8d 04 ee          	lea    (%r14,%r13,8),%r8
 343:	4d 89 e9             	mov    %r13,%r9
 346:	41 54                	push   %r12
 348:	ff 74 24 38          	push   0x38(%rsp)
 34c:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 352 <verigmp::toom_multiply::full+0x352>
			34e: R_X86_64_GOTPCREL	verigmp::toom_evaluate::negative-0x4
 352:	48 83 c4 10          	add    $0x10,%rsp
 356:	88 44 24 30          	mov    %al,0x30(%rsp)
 35a:	48 83 ec 08          	sub    $0x8,%rsp
 35e:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
 363:	4a 8d 34 6d 02 00 00 	lea    0x2(,%r13,2),%rsi
 36a:	00 
 36b:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
 370:	49 8d 4d 01          	lea    0x1(%r13),%rcx
 374:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
 379:	49 89 c9             	mov    %rcx,%r9
 37c:	ff b4 24 a8 00 00 00 	push   0xa8(%rsp)
 383:	ff 74 24 30          	push   0x30(%rsp)
 387:	ff 74 24 30          	push   0x30(%rsp)
 38b:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 391 <verigmp::toom_multiply::full+0x391>
			38d: R_X86_64_GOTPCREL	verigmp::toom_multiply::full-0x4
 391:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
 396:	48 83 c4 20          	add    $0x20,%rsp
 39a:	31 f6                	xor    %esi,%esi
 39c:	48 89 d0             	mov    %rdx,%rax
 39f:	4c 89 e9             	mov    %r13,%rcx
 3a2:	45 31 db             	xor    %r11d,%r11d
 3a5:	eb 53                	jmp    3fa <verigmp::toom_multiply::full+0x3fa>
 3a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 3ae:	00 00 
 3b0:	4a 8b 7c 3d 00       	mov    0x0(%rbp,%r15,1),%rdi
 3b5:	4e 8b 44 ed 00       	mov    0x0(%rbp,%r13,8),%r8
 3ba:	4d 89 c1             	mov    %r8,%r9
 3bd:	49 c1 e9 3f          	shr    $0x3f,%r9
 3c1:	4d 01 c0             	add    %r8,%r8
 3c4:	49 89 fa             	mov    %rdi,%r10
 3c7:	49 c1 ea 3e          	shr    $0x3e,%r10
 3cb:	48 c1 e7 02          	shl    $0x2,%rdi
 3cf:	48 01 f7             	add    %rsi,%rdi
 3d2:	49 83 d2 00          	adc    $0x0,%r10
 3d6:	48 03 7d 00          	add    0x0(%rbp),%rdi
 3da:	49 83 d2 00          	adc    $0x0,%r10
 3de:	4c 01 c7             	add    %r8,%rdi
 3e1:	4c 89 d6             	mov    %r10,%rsi
 3e4:	4c 11 ce             	adc    %r9,%rsi
 3e7:	48 89 38             	mov    %rdi,(%rax)
 3ea:	49 ff c3             	inc    %r11
 3ed:	48 83 c5 08          	add    $0x8,%rbp
 3f1:	48 83 c0 08          	add    $0x8,%rax
 3f5:	48 ff c9             	dec    %rcx
 3f8:	74 09                	je     403 <verigmp::toom_multiply::full+0x403>
 3fa:	4d 39 e3             	cmp    %r12,%r11
 3fd:	72 b1                	jb     3b0 <verigmp::toom_multiply::full+0x3b0>
 3ff:	31 ff                	xor    %edi,%edi
 401:	eb b2                	jmp    3b5 <verigmp::toom_multiply::full+0x3b5>
 403:	4a 89 34 ea          	mov    %rsi,(%rdx,%r13,8)
 407:	31 f6                	xor    %esi,%esi
 409:	48 8b 04 24          	mov    (%rsp),%rax
 40d:	4c 89 e9             	mov    %r13,%rcx
 410:	45 31 db             	xor    %r11d,%r11d
 413:	4a 8d 2c 6d 02 00 00 	lea    0x2(,%r13,2),%rbp
 41a:	00 
 41b:	eb 4a                	jmp    467 <verigmp::toom_multiply::full+0x467>
 41d:	0f 1f 00             	nopl   (%rax)
 420:	4b 8b 3c 3e          	mov    (%r14,%r15,1),%rdi
 424:	4f 8b 04 ee          	mov    (%r14,%r13,8),%r8
 428:	4d 89 c1             	mov    %r8,%r9
 42b:	49 c1 e9 3f          	shr    $0x3f,%r9
 42f:	4d 01 c0             	add    %r8,%r8
 432:	49 89 fa             	mov    %rdi,%r10
 435:	49 c1 ea 3e          	shr    $0x3e,%r10
 439:	48 c1 e7 02          	shl    $0x2,%rdi
 43d:	48 01 f7             	add    %rsi,%rdi
 440:	49 83 d2 00          	adc    $0x0,%r10
 444:	49 03 3e             	add    (%r14),%rdi
 447:	49 83 d2 00          	adc    $0x0,%r10
 44b:	4c 01 c7             	add    %r8,%rdi
 44e:	4c 89 d6             	mov    %r10,%rsi
 451:	4c 11 ce             	adc    %r9,%rsi
 454:	48 89 38             	mov    %rdi,(%rax)
 457:	49 ff c3             	inc    %r11
 45a:	49 83 c6 08          	add    $0x8,%r14
 45e:	48 83 c0 08          	add    $0x8,%rax
 462:	48 ff c9             	dec    %rcx
 465:	74 09                	je     470 <verigmp::toom_multiply::full+0x470>
 467:	4d 39 e3             	cmp    %r12,%r11
 46a:	72 b4                	jb     420 <verigmp::toom_multiply::full+0x420>
 46c:	31 ff                	xor    %edi,%edi
 46e:	eb b4                	jmp    424 <verigmp::toom_multiply::full+0x424>
 470:	4c 8b 04 24          	mov    (%rsp),%r8
 474:	4b 89 34 e8          	mov    %rsi,(%r8,%r13,8)
 478:	48 83 ec 08          	sub    $0x8,%rsp
 47c:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
 481:	48 89 ee             	mov    %rbp,%rsi
 484:	49 8d 4d 01          	lea    0x1(%r13),%rcx
 488:	49 89 c9             	mov    %rcx,%r9
 48b:	ff b4 24 a8 00 00 00 	push   0xa8(%rsp)
 492:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
 497:	41 54                	push   %r12
 499:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
 49e:	41 56                	push   %r14
 4a0:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4a6 <verigmp::toom_multiply::full+0x4a6>
			4a2: R_X86_64_GOTPCREL	verigmp::toom_multiply::full-0x4
 4a6:	48 83 c4 20          	add    $0x20,%rsp
 4aa:	4c 39 e5             	cmp    %r12,%rbp
 4ad:	0f 87 40 05 00 00    	ja     9f3 <verigmp::toom_multiply::full+0x9f3>
 4b3:	0f b6 44 24 28       	movzbl 0x28(%rsp),%eax
 4b8:	32 44 24 30          	xor    0x30(%rsp),%al
 4bc:	48 83 ec 08          	sub    $0x8,%rsp
 4c0:	0f b6 c0             	movzbl %al,%eax
 4c3:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
 4c8:	48 89 ee             	mov    %rbp,%rsi
 4cb:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
 4d0:	48 89 e9             	mov    %rbp,%rcx
 4d3:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
 4d8:	49 89 e9             	mov    %rbp,%r9
 4db:	55                   	push   %rbp
 4dc:	41 56                	push   %r14
 4de:	50                   	push   %rax
 4df:	55                   	push   %rbp
 4e0:	ff 74 24 30          	push   0x30(%rsp)
 4e4:	55                   	push   %rbp
 4e5:	48 8b ac 24 c8 00 00 	mov    0xc8(%rsp),%rbp
 4ec:	00 
 4ed:	55                   	push   %rbp
 4ee:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4f4 <verigmp::toom_multiply::full+0x4f4>
			4f0: R_X86_64_GOTPCREL	verigmp::toom_interpolate::interpolate-0x4
 4f4:	48 83 c4 40          	add    $0x40,%rsp
 4f8:	4c 8b 64 24 50       	mov    0x50(%rsp),%r12
 4fd:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
 504:	00 
 505:	45 31 f6             	xor    %r14d,%r14d
 508:	48 89 df             	mov    %rbx,%rdi
 50b:	31 f6                	xor    %esi,%esi
 50d:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 513 <verigmp::toom_multiply::full+0x513>
			50f: R_X86_64_GOTPCREL	memset-0x4
 513:	49 89 ea             	mov    %rbp,%r10
 516:	49 8d 4f 10          	lea    0x10(%r15),%rcx
 51a:	31 c0                	xor    %eax,%eax
 51c:	0f 1f 40 00          	nopl   0x0(%rax)
 520:	31 d2                	xor    %edx,%edx
 522:	4c 03 34 03          	add    (%rbx,%rax,1),%r14
 526:	0f 92 c2             	setb   %dl
 529:	4d 03 34 02          	add    (%r10,%rax,1),%r14
 52d:	4c 89 34 03          	mov    %r14,(%rbx,%rax,1)
 531:	48 13 54 03 08       	adc    0x8(%rbx,%rax,1),%rdx
 536:	40 0f 92 c6          	setb   %sil
 53a:	44 0f b6 f6          	movzbl %sil,%r14d
 53e:	49 03 54 02 08       	add    0x8(%r10,%rax,1),%rdx
 543:	49 83 d6 00          	adc    $0x0,%r14
 547:	48 89 54 03 08       	mov    %rdx,0x8(%rbx,%rax,1)
 54c:	48 83 c0 10          	add    $0x10,%rax
 550:	48 39 c1             	cmp    %rax,%rcx
 553:	75 cb                	jne    520 <verigmp::toom_multiply::full+0x520>
 555:	4d 85 f6             	test   %r14,%r14
 558:	4b 8d 6c 2d 02       	lea    0x2(%r13,%r13,1),%rbp
 55d:	74 2f                	je     58e <verigmp::toom_multiply::full+0x58e>
 55f:	4c 89 e0             	mov    %r12,%rax
 562:	48 29 e8             	sub    %rbp,%rax
 565:	48 8d 14 eb          	lea    (%rbx,%rbp,8),%rdx
 569:	be 01 00 00 00       	mov    $0x1,%esi
 56e:	66 90                	xchg   %ax,%ax
 570:	31 ff                	xor    %edi,%edi
 572:	4c 01 74 f2 f8       	add    %r14,-0x8(%rdx,%rsi,8)
 577:	41 0f 92 c0          	setb   %r8b
 57b:	48 39 c6             	cmp    %rax,%rsi
 57e:	73 0e                	jae    58e <verigmp::toom_multiply::full+0x58e>
 580:	44 88 c7             	mov    %r8b,%dil
 583:	48 ff c6             	inc    %rsi
 586:	49 89 fe             	mov    %rdi,%r14
 589:	40 84 ff             	test   %dil,%dil
 58c:	75 e2                	jne    570 <verigmp::toom_multiply::full+0x570>
 58e:	4a 8d 34 eb          	lea    (%rbx,%r13,8),%rsi
 592:	4c 89 e8             	mov    %r13,%rax
 595:	48 c1 e0 05          	shl    $0x5,%rax
 599:	4a 8d 3c 10          	lea    (%rax,%r10,1),%rdi
 59d:	48 83 c7 28          	add    $0x28,%rdi
 5a1:	31 d2                	xor    %edx,%edx
 5a3:	45 31 c0             	xor    %r8d,%r8d
 5a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 5ad:	00 00 00 
 5b0:	45 31 c9             	xor    %r9d,%r9d
 5b3:	4a 03 14 06          	add    (%rsi,%r8,1),%rdx
 5b7:	41 0f 92 c1          	setb   %r9b
 5bb:	4a 03 54 07 f8       	add    -0x8(%rdi,%r8,1),%rdx
 5c0:	4a 89 14 06          	mov    %rdx,(%rsi,%r8,1)
 5c4:	4e 13 4c 06 08       	adc    0x8(%rsi,%r8,1),%r9
 5c9:	0f 92 c2             	setb   %dl
 5cc:	0f b6 d2             	movzbl %dl,%edx
 5cf:	4e 03 0c 07          	add    (%rdi,%r8,1),%r9
 5d3:	48 83 d2 00          	adc    $0x0,%rdx
 5d7:	4e 89 4c 06 08       	mov    %r9,0x8(%rsi,%r8,1)
 5dc:	49 83 c0 10          	add    $0x10,%r8
 5e0:	4c 39 c1             	cmp    %r8,%rcx
 5e3:	75 cb                	jne    5b0 <verigmp::toom_multiply::full+0x5b0>
 5e5:	48 85 d2             	test   %rdx,%rdx
 5e8:	74 34                	je     61e <verigmp::toom_multiply::full+0x61e>
 5ea:	4c 89 e7             	mov    %r12,%rdi
 5ed:	4c 29 ef             	sub    %r13,%rdi
 5f0:	48 29 ef             	sub    %rbp,%rdi
 5f3:	48 8d 34 ee          	lea    (%rsi,%rbp,8),%rsi
 5f7:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 5fd:	0f 1f 00             	nopl   (%rax)
 600:	45 31 c9             	xor    %r9d,%r9d
 603:	4a 01 54 c6 f8       	add    %rdx,-0x8(%rsi,%r8,8)
 608:	0f 92 c2             	setb   %dl
 60b:	49 39 f8             	cmp    %rdi,%r8
 60e:	73 0e                	jae    61e <verigmp::toom_multiply::full+0x61e>
 610:	41 88 d1             	mov    %dl,%r9b
 613:	49 ff c0             	inc    %r8
 616:	4c 89 ca             	mov    %r9,%rdx
 619:	45 84 c9             	test   %r9b,%r9b
 61c:	75 e2                	jne    600 <verigmp::toom_multiply::full+0x600>
 61e:	4c 89 e6             	mov    %r12,%rsi
 621:	4a 8d 3c 6d 00 00 00 	lea    0x0(,%r13,2),%rdi
 628:	00 
 629:	48 29 fe             	sub    %rdi,%rsi
 62c:	48 8d 14 fb          	lea    (%rbx,%rdi,8),%rdx
 630:	48 39 ee             	cmp    %rbp,%rsi
 633:	73 16                	jae    64b <verigmp::toom_multiply::full+0x64b>
 635:	48 8d 77 01          	lea    0x1(%rdi),%rsi
 639:	49 39 f4             	cmp    %rsi,%r12
 63c:	0f 85 b6 00 00 00    	jne    6f8 <verigmp::toom_multiply::full+0x6f8>
 642:	31 f6                	xor    %esi,%esi
 644:	31 ff                	xor    %edi,%edi
 646:	e9 2a 01 00 00       	jmp    775 <verigmp::toom_multiply::full+0x775>
 64b:	4d 8d 04 1f          	lea    (%r15,%rbx,1),%r8
 64f:	49 83 c0 08          	add    $0x8,%r8
 653:	4a 8d 3c 6d 00 00 00 	lea    0x0(,%r13,2),%rdi
 65a:	00 
 65b:	4c 01 ef             	add    %r13,%rdi
 65e:	48 c1 e7 04          	shl    $0x4,%rdi
 662:	4e 8d 0c 17          	lea    (%rdi,%r10,1),%r9
 666:	49 83 c1 38          	add    $0x38,%r9
 66a:	31 ff                	xor    %edi,%edi
 66c:	45 31 d2             	xor    %r10d,%r10d
 66f:	90                   	nop
 670:	45 31 db             	xor    %r11d,%r11d
 673:	4b 03 7c 10 f8       	add    -0x8(%r8,%r10,1),%rdi
 678:	41 0f 92 c3          	setb   %r11b
 67c:	4b 03 7c 11 f8       	add    -0x8(%r9,%r10,1),%rdi
 681:	4b 89 7c 10 f8       	mov    %rdi,-0x8(%r8,%r10,1)
 686:	4f 13 1c 10          	adc    (%r8,%r10,1),%r11
 68a:	40 0f 92 c7          	setb   %dil
 68e:	40 0f b6 ff          	movzbl %dil,%edi
 692:	4f 03 1c 11          	add    (%r9,%r10,1),%r11
 696:	48 83 d7 00          	adc    $0x0,%rdi
 69a:	4f 89 1c 10          	mov    %r11,(%r8,%r10,1)
 69e:	49 83 c2 10          	add    $0x10,%r10
 6a2:	4c 39 d1             	cmp    %r10,%rcx
 6a5:	75 c9                	jne    670 <verigmp::toom_multiply::full+0x670>
 6a7:	48 29 ee             	sub    %rbp,%rsi
 6aa:	4c 8b 94 24 90 00 00 	mov    0x90(%rsp),%r10
 6b1:	00 
 6b2:	0f 84 ce 00 00 00    	je     786 <verigmp::toom_multiply::full+0x786>
 6b8:	48 85 ff             	test   %rdi,%rdi
 6bb:	0f 84 c5 00 00 00    	je     786 <verigmp::toom_multiply::full+0x786>
 6c1:	48 8d 14 ea          	lea    (%rdx,%rbp,8),%rdx
 6c5:	41 b8 01 00 00 00    	mov    $0x1,%r8d
 6cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 6d0:	45 31 c9             	xor    %r9d,%r9d
 6d3:	4a 01 7c c2 f8       	add    %rdi,-0x8(%rdx,%r8,8)
 6d8:	40 0f 92 c7          	setb   %dil
 6dc:	49 39 f0             	cmp    %rsi,%r8
 6df:	0f 83 a1 00 00 00    	jae    786 <verigmp::toom_multiply::full+0x786>
 6e5:	41 88 f9             	mov    %dil,%r9b
 6e8:	49 ff c0             	inc    %r8
 6eb:	4c 89 cf             	mov    %r9,%rdi
 6ee:	45 84 c9             	test   %r9b,%r9b
 6f1:	75 dd                	jne    6d0 <verigmp::toom_multiply::full+0x6d0>
 6f3:	e9 8e 00 00 00       	jmp    786 <verigmp::toom_multiply::full+0x786>
 6f8:	4d 8d 04 1f          	lea    (%r15,%rbx,1),%r8
 6fc:	49 83 c0 08          	add    $0x8,%r8
 700:	4a 8d 34 6d 00 00 00 	lea    0x0(,%r13,2),%rsi
 707:	00 
 708:	4c 01 ee             	add    %r13,%rsi
 70b:	48 c1 e6 04          	shl    $0x4,%rsi
 70f:	4e 8d 0c 16          	lea    (%rsi,%r10,1),%r9
 713:	49 83 c1 38          	add    $0x38,%r9
 717:	4d 89 e2             	mov    %r12,%r10
 71a:	49 83 e2 fe          	and    $0xfffffffffffffffe,%r10
 71e:	49 29 fa             	sub    %rdi,%r10
 721:	31 f6                	xor    %esi,%esi
 723:	31 ff                	xor    %edi,%edi
 725:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 72c:	00 00 00 00 
 730:	45 31 db             	xor    %r11d,%r11d
 733:	49 03 74 f8 f8       	add    -0x8(%r8,%rdi,8),%rsi
 738:	41 0f 92 c3          	setb   %r11b
 73c:	49 03 74 f9 f8       	add    -0x8(%r9,%rdi,8),%rsi
 741:	49 89 74 f8 f8       	mov    %rsi,-0x8(%r8,%rdi,8)
 746:	4d 13 1c f8          	adc    (%r8,%rdi,8),%r11
 74a:	40 0f 92 c6          	setb   %sil
 74e:	40 0f b6 f6          	movzbl %sil,%esi
 752:	4d 03 1c f9          	add    (%r9,%rdi,8),%r11
 756:	48 83 d6 00          	adc    $0x0,%rsi
 75a:	4d 89 1c f8          	mov    %r11,(%r8,%rdi,8)
 75e:	48 83 c7 02          	add    $0x2,%rdi
 762:	49 39 fa             	cmp    %rdi,%r10
 765:	75 c9                	jne    730 <verigmp::toom_multiply::full+0x730>
 767:	41 f6 c4 01          	test   $0x1,%r12b
 76b:	4c 8b 94 24 90 00 00 	mov    0x90(%rsp),%r10
 772:	00 
 773:	74 11                	je     786 <verigmp::toom_multiply::full+0x786>
 775:	48 03 34 fa          	add    (%rdx,%rdi,8),%rsi
 779:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
 77e:	49 03 34 f8          	add    (%r8,%rdi,8),%rsi
 782:	48 89 34 fa          	mov    %rsi,(%rdx,%rdi,8)
 786:	4a 8d 3c 6d 00 00 00 	lea    0x0(,%r13,2),%rdi
 78d:	00 
 78e:	4c 01 ef             	add    %r13,%rdi
 791:	4c 89 e2             	mov    %r12,%rdx
 794:	48 29 fa             	sub    %rdi,%rdx
 797:	48 8d 34 fb          	lea    (%rbx,%rdi,8),%rsi
 79b:	48 39 ea             	cmp    %rbp,%rdx
 79e:	73 16                	jae    7b6 <verigmp::toom_multiply::full+0x7b6>
 7a0:	48 8d 4f 01          	lea    0x1(%rdi),%rcx
 7a4:	49 39 cc             	cmp    %rcx,%r12
 7a7:	0f 85 b8 00 00 00    	jne    865 <verigmp::toom_multiply::full+0x865>
 7ad:	31 c9                	xor    %ecx,%ecx
 7af:	31 ff                	xor    %edi,%edi
 7b1:	e9 14 01 00 00       	jmp    8ca <verigmp::toom_multiply::full+0x8ca>
 7b6:	4c 8d 04 fb          	lea    (%rbx,%rdi,8),%r8
 7ba:	49 83 c0 08          	add    $0x8,%r8
 7be:	4c 89 ef             	mov    %r13,%rdi
 7c1:	48 c1 e7 06          	shl    $0x6,%rdi
 7c5:	4e 8d 0c 17          	lea    (%rdi,%r10,1),%r9
 7c9:	49 83 c1 48          	add    $0x48,%r9
 7cd:	31 ff                	xor    %edi,%edi
 7cf:	45 31 d2             	xor    %r10d,%r10d
 7d2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 7d9:	1f 84 00 00 00 00 00 
 7e0:	45 31 db             	xor    %r11d,%r11d
 7e3:	4b 03 7c 10 f8       	add    -0x8(%r8,%r10,1),%rdi
 7e8:	41 0f 92 c3          	setb   %r11b
 7ec:	4b 03 7c 11 f8       	add    -0x8(%r9,%r10,1),%rdi
 7f1:	4b 89 7c 10 f8       	mov    %rdi,-0x8(%r8,%r10,1)
 7f6:	4f 13 1c 10          	adc    (%r8,%r10,1),%r11
 7fa:	40 0f 92 c7          	setb   %dil
 7fe:	40 0f b6 ff          	movzbl %dil,%edi
 802:	4f 03 1c 11          	add    (%r9,%r10,1),%r11
 806:	48 83 d7 00          	adc    $0x0,%rdi
 80a:	4f 89 1c 10          	mov    %r11,(%r8,%r10,1)
 80e:	49 83 c2 10          	add    $0x10,%r10
 812:	4c 39 d1             	cmp    %r10,%rcx
 815:	75 c9                	jne    7e0 <verigmp::toom_multiply::full+0x7e0>
 817:	48 29 ea             	sub    %rbp,%rdx
 81a:	0f 84 bb 00 00 00    	je     8db <verigmp::toom_multiply::full+0x8db>
 820:	48 85 ff             	test   %rdi,%rdi
 823:	0f 84 b2 00 00 00    	je     8db <verigmp::toom_multiply::full+0x8db>
 829:	48 8d 0c ee          	lea    (%rsi,%rbp,8),%rcx
 82d:	be 01 00 00 00       	mov    $0x1,%esi
 832:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 839:	1f 84 00 00 00 00 00 
 840:	45 31 c0             	xor    %r8d,%r8d
 843:	48 01 7c f1 f8       	add    %rdi,-0x8(%rcx,%rsi,8)
 848:	40 0f 92 c7          	setb   %dil
 84c:	48 39 d6             	cmp    %rdx,%rsi
 84f:	0f 83 86 00 00 00    	jae    8db <verigmp::toom_multiply::full+0x8db>
 855:	41 88 f8             	mov    %dil,%r8b
 858:	48 ff c6             	inc    %rsi
 85b:	4c 89 c7             	mov    %r8,%rdi
 85e:	45 84 c0             	test   %r8b,%r8b
 861:	75 dd                	jne    840 <verigmp::toom_multiply::full+0x840>
 863:	eb 76                	jmp    8db <verigmp::toom_multiply::full+0x8db>
 865:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
 86c:	ff ff 0f 
 86f:	49 21 d0             	and    %rdx,%r8
 872:	4c 8d 0c fb          	lea    (%rbx,%rdi,8),%r9
 876:	49 83 c1 08          	add    $0x8,%r9
 87a:	4c 89 e9             	mov    %r13,%rcx
 87d:	48 c1 e1 06          	shl    $0x6,%rcx
 881:	49 01 ca             	add    %rcx,%r10
 884:	49 83 c2 48          	add    $0x48,%r10
 888:	31 c9                	xor    %ecx,%ecx
 88a:	31 ff                	xor    %edi,%edi
 88c:	0f 1f 40 00          	nopl   0x0(%rax)
 890:	45 31 db             	xor    %r11d,%r11d
 893:	49 03 4c f9 f8       	add    -0x8(%r9,%rdi,8),%rcx
 898:	41 0f 92 c3          	setb   %r11b
 89c:	49 03 4c fa f8       	add    -0x8(%r10,%rdi,8),%rcx
 8a1:	49 89 4c f9 f8       	mov    %rcx,-0x8(%r9,%rdi,8)
 8a6:	4d 13 1c f9          	adc    (%r9,%rdi,8),%r11
 8aa:	0f 92 c1             	setb   %cl
 8ad:	0f b6 c9             	movzbl %cl,%ecx
 8b0:	4d 03 1c fa          	add    (%r10,%rdi,8),%r11
 8b4:	48 83 d1 00          	adc    $0x0,%rcx
 8b8:	4d 89 1c f9          	mov    %r11,(%r9,%rdi,8)
 8bc:	48 83 c7 02          	add    $0x2,%rdi
 8c0:	49 39 f8             	cmp    %rdi,%r8
 8c3:	75 cb                	jne    890 <verigmp::toom_multiply::full+0x890>
 8c5:	f6 c2 01             	test   $0x1,%dl
 8c8:	74 11                	je     8db <verigmp::toom_multiply::full+0x8db>
 8ca:	48 03 0c fe          	add    (%rsi,%rdi,8),%rcx
 8ce:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
 8d3:	48 03 0c fa          	add    (%rdx,%rdi,8),%rcx
 8d7:	48 89 0c fe          	mov    %rcx,(%rsi,%rdi,8)
 8db:	49 c1 e5 02          	shl    $0x2,%r13
 8df:	4d 39 ec             	cmp    %r13,%r12
 8e2:	0f 84 87 00 00 00    	je     96f <verigmp::toom_multiply::full+0x96f>
 8e8:	49 8d 4d 01          	lea    0x1(%r13),%rcx
 8ec:	49 39 cc             	cmp    %rcx,%r12
 8ef:	75 06                	jne    8f7 <verigmp::toom_multiply::full+0x8f7>
 8f1:	31 c9                	xor    %ecx,%ecx
 8f3:	31 d2                	xor    %edx,%edx
 8f5:	eb 64                	jmp    95b <verigmp::toom_multiply::full+0x95b>
 8f7:	48 8d 34 18          	lea    (%rax,%rbx,1),%rsi
 8fb:	48 83 c6 08          	add    $0x8,%rsi
 8ff:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
 906:	00 
 907:	49 8d 3c 0f          	lea    (%r15,%rcx,1),%rdi
 90b:	48 83 c7 18          	add    $0x18,%rdi
 90f:	4d 89 e0             	mov    %r12,%r8
 912:	49 83 e0 fe          	and    $0xfffffffffffffffe,%r8
 916:	4d 29 e8             	sub    %r13,%r8
 919:	31 c9                	xor    %ecx,%ecx
 91b:	31 d2                	xor    %edx,%edx
 91d:	0f 1f 00             	nopl   (%rax)
 920:	45 31 c9             	xor    %r9d,%r9d
 923:	48 03 4c d6 f8       	add    -0x8(%rsi,%rdx,8),%rcx
 928:	41 0f 92 c1          	setb   %r9b
 92c:	48 03 4c d7 f8       	add    -0x8(%rdi,%rdx,8),%rcx
 931:	48 89 4c d6 f8       	mov    %rcx,-0x8(%rsi,%rdx,8)
 936:	4c 13 0c d6          	adc    (%rsi,%rdx,8),%r9
 93a:	0f 92 c1             	setb   %cl
 93d:	0f b6 c9             	movzbl %cl,%ecx
 940:	4c 03 0c d7          	add    (%rdi,%rdx,8),%r9
 944:	48 83 d1 00          	adc    $0x0,%rcx
 948:	4c 89 0c d6          	mov    %r9,(%rsi,%rdx,8)
 94c:	48 83 c2 02          	add    $0x2,%rdx
 950:	49 39 d0             	cmp    %rdx,%r8
 953:	75 cb                	jne    920 <verigmp::toom_multiply::full+0x920>
 955:	41 f6 c4 01          	test   $0x1,%r12b
 959:	74 14                	je     96f <verigmp::toom_multiply::full+0x96f>
 95b:	48 01 c3             	add    %rax,%rbx
 95e:	48 03 0c d3          	add    (%rbx,%rdx,8),%rcx
 962:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
 967:	48 03 0c d0          	add    (%rax,%rdx,8),%rcx
 96b:	48 89 0c d3          	mov    %rcx,(%rbx,%rdx,8)
 96f:	48 83 c4 58          	add    $0x58,%rsp
 973:	5b                   	pop    %rbx
 974:	41 5c                	pop    %r12
 976:	41 5d                	pop    %r13
 978:	41 5e                	pop    %r14
 97a:	41 5f                	pop    %r15
 97c:	5d                   	pop    %rbp
 97d:	c3                   	ret
 97e:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 985 <verigmp::toom_multiply::full+0x985>
			981: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.126-0x4
 985:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 98c <verigmp::toom_multiply::full+0x98c>
			988: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.127-0x4
 98c:	be 5e 00 00 00       	mov    $0x5e,%esi
 991:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 997 <verigmp::toom_multiply::full+0x997>
			993: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 997:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 99e <verigmp::toom_multiply::full+0x99e>
			99a: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.123-0x4
 99e:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 9a5 <verigmp::toom_multiply::full+0x9a5>
			9a1: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.125-0x4
 9a5:	be 51 00 00 00       	mov    $0x51,%esi
 9aa:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 9b0 <verigmp::toom_multiply::full+0x9b0>
			9ac: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 9b0:	48 8d 05 00 00 00 00 	lea    0x0(%rip),%rax        # 9b7 <verigmp::toom_multiply::full+0x9b7>
			9b3: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.133-0x4
 9b7:	31 ff                	xor    %edi,%edi
 9b9:	4c 89 ee             	mov    %r13,%rsi
 9bc:	48 89 ca             	mov    %rcx,%rdx
 9bf:	48 89 c1             	mov    %rax,%rcx
 9c2:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 9c8 <verigmp::toom_multiply::full+0x9c8>
			9c4: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 9c8:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 9cf <verigmp::toom_multiply::full+0x9cf>
			9cb: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.131-0x4
 9cf:	31 ff                	xor    %edi,%edi
 9d1:	4c 89 fe             	mov    %r15,%rsi
 9d4:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 9da <verigmp::toom_multiply::full+0x9da>
			9d6: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 9da:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 9e1 <verigmp::toom_multiply::full+0x9e1>
			9dd: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.117-0x4
 9e1:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 9e8 <verigmp::toom_multiply::full+0x9e8>
			9e4: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.122-0x4
 9e8:	be 3e 00 00 00       	mov    $0x3e,%esi
 9ed:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 9f3 <verigmp::toom_multiply::full+0x9f3>
			9ef: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 9f3:	4c 89 e2             	mov    %r12,%rdx
 9f6:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 9fd <verigmp::toom_multiply::full+0x9fd>
			9f9: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.130-0x4
 9fd:	31 ff                	xor    %edi,%edi
 9ff:	48 89 ee             	mov    %rbp,%rsi
 a02:	ff 15 00 00 00 00    	call   *0x0(%rip)        # a08 <verigmp::toom_multiply::full+0xa08>
			a04: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 a08:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # a0f <verigmp::toom_multiply::full+0xa0f>
			a0b: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.0-0x4
 a0f:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # a16 <verigmp::toom_multiply::full+0xa16>
			a12: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.128-0x4
 a16:	be 13 00 00 00       	mov    $0x13,%esi
 a1b:	ff 15 00 00 00 00    	call   *0x0(%rip)        # a21 <verigmp::toom_multiply::full+0xa21>
			a1d: R_X86_64_GOTPCREL	core::panicking::panic_fmt-0x4
 a21:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # a28 <verigmp::toom_multiply::full+0xa28>
			a24: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.0-0x4
 a28:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # a2f <verigmp::toom_multiply::full+0xa2f>
			a2b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.129-0x4
 a2f:	be 13 00 00 00       	mov    $0x13,%esi
 a34:	ff 15 00 00 00 00    	call   *0x0(%rip)        # a3a <verigmp::toom_multiply::full+0xa3a>
			a36: R_X86_64_GOTPCREL	core::panicking::panic_fmt-0x4
 a3a:	48 8d 05 00 00 00 00 	lea    0x0(%rip),%rax        # a41 <verigmp::toom_multiply::full+0xa41>
			a3d: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.132-0x4
 a41:	4c 89 ef             	mov    %r13,%rdi
 a44:	48 89 ca             	mov    %rcx,%rdx
 a47:	48 89 c1             	mov    %rax,%rcx
 a4a:	ff 15 00 00 00 00    	call   *0x0(%rip)        # a50 <verigmp::toom_multiply::full+0xa50>
			a4c: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp14packed_product12coefficients:

0000000000000000 <verigmp::packed_product::coefficients>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_product::coefficients+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_product::coefficients+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.135-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_product::coefficients+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp14packed_product12exact_output:

0000000000000000 <verigmp::packed_product::exact_output>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_product::exact_output+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_product::exact_output+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.136-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_product::exact_output+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp14packed_product12guard_domain:

0000000000000000 <verigmp::packed_product::guard_domain>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_product::guard_domain+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_product::guard_domain+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.137-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_product::guard_domain+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp14packed_product19exact_product_slots:

0000000000000000 <verigmp::packed_product::exact_product_slots>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_product::exact_product_slots+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_product::exact_product_slots+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.138-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_product::exact_product_slots+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp14packed_product22extracted_exact_output:

0000000000000000 <verigmp::packed_product::extracted_exact_output>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_product::extracted_exact_output+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_product::extracted_exact_output+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.139-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_product::extracted_exact_output+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp14packed_product24complete_slots_canonical:

0000000000000000 <verigmp::packed_product::complete_slots_canonical>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_product::complete_slots_canonical+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_product::complete_slots_canonical+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.140-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_product::complete_slots_canonical+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp16square_base_spec15square_identity:

0000000000000000 <verigmp::square_base_spec::square_identity>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::square_base_spec::square_identity+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::square_base_spec::square_identity+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.142-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::square_base_spec::square_identity+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp16square_base_spec18diagonal_drop_high:

0000000000000000 <verigmp::square_base_spec::diagonal_drop_high>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::square_base_spec::diagonal_drop_high+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::square_base_spec::diagonal_drop_high+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.143-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::square_base_spec::diagonal_drop_high+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp16square_base_spec8diagonal:

0000000000000000 <verigmp::square_base_spec::diagonal>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::square_base_spec::diagonal+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::square_base_spec::diagonal+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.144-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::square_base_spec::diagonal+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp16square_base_spec8triangle:

0000000000000000 <verigmp::square_base_spec::triangle>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::square_base_spec::triangle+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::square_base_spec::triangle+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.145-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::square_base_spec::triangle+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp16toom_interpolate11interpolate:

0000000000000000 <verigmp::toom_interpolate::interpolate>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	50                   	push   %rax
   b:	48 39 ce             	cmp    %rcx,%rsi
   e:	0f 85 49 06 00 00    	jne    65d <verigmp::toom_interpolate::interpolate+0x65d>
  14:	4c 39 ce             	cmp    %r9,%rsi
  17:	0f 85 40 06 00 00    	jne    65d <verigmp::toom_interpolate::interpolate+0x65d>
  1d:	48 39 74 24 70       	cmp    %rsi,0x70(%rsp)
  22:	0f 85 35 06 00 00    	jne    65d <verigmp::toom_interpolate::interpolate+0x65d>
  28:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
  2d:	49 39 f2             	cmp    %rsi,%r10
  30:	0f 87 40 06 00 00    	ja     676 <verigmp::toom_interpolate::interpolate+0x676>
  36:	4c 8b 5c 24 58       	mov    0x58(%rsp),%r11
  3b:	49 39 f3             	cmp    %rsi,%r11
  3e:	0f 87 32 06 00 00    	ja     676 <verigmp::toom_interpolate::interpolate+0x676>
  44:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
  49:	74 16                	je     61 <verigmp::toom_interpolate::interpolate+0x61>
  4b:	48 85 f6             	test   %rsi,%rsi
  4e:	0f 84 fa 05 00 00    	je     64e <verigmp::toom_interpolate::interpolate+0x64e>
  54:	48 83 fe 01          	cmp    $0x1,%rsi
  58:	75 1f                	jne    79 <verigmp::toom_interpolate::interpolate+0x79>
  5a:	45 31 c9             	xor    %r9d,%r9d
  5d:	31 c0                	xor    %eax,%eax
  5f:	eb 7d                	jmp    de <verigmp::toom_interpolate::interpolate+0xde>
  61:	48 85 f6             	test   %rsi,%rsi
  64:	0f 84 e4 05 00 00    	je     64e <verigmp::toom_interpolate::interpolate+0x64e>
  6a:	48 83 fe 01          	cmp    $0x1,%rsi
  6e:	75 7f                	jne    ef <verigmp::toom_interpolate::interpolate+0xef>
  70:	31 c0                	xor    %eax,%eax
  72:	31 c9                	xor    %ecx,%ecx
  74:	e9 c0 00 00 00       	jmp    139 <verigmp::toom_interpolate::interpolate+0x139>
  79:	48 b9 fe ff ff ff ff 	movabs $0xffffffffffffffe,%rcx
  80:	ff ff 0f 
  83:	48 21 f1             	and    %rsi,%rcx
  86:	45 31 c9             	xor    %r9d,%r9d
  89:	31 c0                	xor    %eax,%eax
  8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  90:	48 8b 1c c7          	mov    (%rdi,%rax,8),%rbx
  94:	48 2b 1c c2          	sub    (%rdx,%rax,8),%rbx
  98:	40 0f 92 c5          	setb   %bpl
  9c:	4c 29 cb             	sub    %r9,%rbx
  9f:	41 0f 92 c1          	setb   %r9b
  a3:	41 08 e9             	or     %bpl,%r9b
  a6:	45 0f b6 c9          	movzbl %r9b,%r9d
  aa:	48 89 1c c2          	mov    %rbx,(%rdx,%rax,8)
  ae:	48 8b 5c c7 08       	mov    0x8(%rdi,%rax,8),%rbx
  b3:	48 2b 5c c2 08       	sub    0x8(%rdx,%rax,8),%rbx
  b8:	40 0f 92 c5          	setb   %bpl
  bc:	4c 29 cb             	sub    %r9,%rbx
  bf:	41 0f 92 c1          	setb   %r9b
  c3:	41 08 e9             	or     %bpl,%r9b
  c6:	45 0f b6 c9          	movzbl %r9b,%r9d
  ca:	48 89 5c c2 08       	mov    %rbx,0x8(%rdx,%rax,8)
  cf:	48 83 c0 02          	add    $0x2,%rax
  d3:	48 39 c1             	cmp    %rax,%rcx
  d6:	75 b8                	jne    90 <verigmp::toom_interpolate::interpolate+0x90>
  d8:	40 f6 c6 01          	test   $0x1,%sil
  dc:	74 67                	je     145 <verigmp::toom_interpolate::interpolate+0x145>
  de:	48 8b 0c c7          	mov    (%rdi,%rax,8),%rcx
  e2:	4c 03 0c c2          	add    (%rdx,%rax,8),%r9
  e6:	4c 29 c9             	sub    %r9,%rcx
  e9:	48 89 0c c2          	mov    %rcx,(%rdx,%rax,8)
  ed:	eb 56                	jmp    145 <verigmp::toom_interpolate::interpolate+0x145>
  ef:	49 b9 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r9
  f6:	ff ff 0f 
  f9:	49 21 f1             	and    %rsi,%r9
  fc:	31 c0                	xor    %eax,%eax
  fe:	31 c9                	xor    %ecx,%ecx
 100:	31 db                	xor    %ebx,%ebx
 102:	48 03 04 ca          	add    (%rdx,%rcx,8),%rax
 106:	0f 92 c3             	setb   %bl
 109:	48 03 04 cf          	add    (%rdi,%rcx,8),%rax
 10d:	48 89 04 ca          	mov    %rax,(%rdx,%rcx,8)
 111:	48 13 5c ca 08       	adc    0x8(%rdx,%rcx,8),%rbx
 116:	0f 92 c0             	setb   %al
 119:	0f b6 c0             	movzbl %al,%eax
 11c:	48 03 5c cf 08       	add    0x8(%rdi,%rcx,8),%rbx
 121:	48 83 d0 00          	adc    $0x0,%rax
 125:	48 89 5c ca 08       	mov    %rbx,0x8(%rdx,%rcx,8)
 12a:	48 83 c1 02          	add    $0x2,%rcx
 12e:	49 39 c9             	cmp    %rcx,%r9
 131:	75 cd                	jne    100 <verigmp::toom_interpolate::interpolate+0x100>
 133:	40 f6 c6 01          	test   $0x1,%sil
 137:	74 0c                	je     145 <verigmp::toom_interpolate::interpolate+0x145>
 139:	48 03 04 ca          	add    (%rdx,%rcx,8),%rax
 13d:	48 03 04 cf          	add    (%rdi,%rcx,8),%rax
 141:	48 89 04 ca          	mov    %rax,(%rdx,%rcx,8)
 145:	48 b9 fe ff ff ff ff 	movabs $0xffffffffffffffe,%rcx
 14c:	ff ff 0f 
 14f:	48 89 f0             	mov    %rsi,%rax
 152:	48 ff c8             	dec    %rax
 155:	48 89 04 24          	mov    %rax,(%rsp)
 159:	74 4b                	je     1a6 <verigmp::toom_interpolate::interpolate+0x1a6>
 15b:	49 89 f6             	mov    %rsi,%r14
 15e:	49 21 ce             	and    %rcx,%r14
 161:	31 c0                	xor    %eax,%eax
 163:	48 89 f3             	mov    %rsi,%rbx
 166:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 16d:	00 00 00 
 170:	4c 8b 7c da f0       	mov    -0x10(%rdx,%rbx,8),%r15
 175:	4c 8b 64 da f8       	mov    -0x8(%rdx,%rbx,8),%r12
 17a:	4c 0f a4 e0 3f       	shld   $0x3f,%r12,%rax
 17f:	48 89 44 da f8       	mov    %rax,-0x8(%rdx,%rbx,8)
 184:	44 89 f8             	mov    %r15d,%eax
 187:	4d 0f ac e7 01       	shrd   $0x1,%r12,%r15
 18c:	83 e0 01             	and    $0x1,%eax
 18f:	4c 89 7c da f0       	mov    %r15,-0x10(%rdx,%rbx,8)
 194:	48 83 c3 fe          	add    $0xfffffffffffffffe,%rbx
 198:	49 83 c6 fe          	add    $0xfffffffffffffffe,%r14
 19c:	75 d2                	jne    170 <verigmp::toom_interpolate::interpolate+0x170>
 19e:	40 f6 c6 01          	test   $0x1,%sil
 1a2:	75 07                	jne    1ab <verigmp::toom_interpolate::interpolate+0x1ab>
 1a4:	eb 0c                	jmp    1b2 <verigmp::toom_interpolate::interpolate+0x1b2>
 1a6:	31 c0                	xor    %eax,%eax
 1a8:	48 89 f3             	mov    %rsi,%rbx
 1ab:	48 0f ac 44 da f8 01 	shrd   $0x1,%rax,-0x8(%rdx,%rbx,8)
 1b2:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
 1b7:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
 1bc:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
 1c1:	45 31 e4             	xor    %r12d,%r12d
 1c4:	45 31 ff             	xor    %r15d,%r15d
 1c7:	eb 30                	jmp    1f9 <verigmp::toom_interpolate::interpolate+0x1f9>
 1c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1d0:	4e 8b 2c fa          	mov    (%rdx,%r15,8),%r13
 1d4:	4a 8b 2c ff          	mov    (%rdi,%r15,8),%rbp
 1d8:	4c 29 ed             	sub    %r13,%rbp
 1db:	41 0f 92 c5          	setb   %r13b
 1df:	4c 29 e5             	sub    %r12,%rbp
 1e2:	41 0f 92 c4          	setb   %r12b
 1e6:	45 08 ec             	or     %r13b,%r12b
 1e9:	45 0f b6 e4          	movzbl %r12b,%r12d
 1ed:	4a 89 2c ff          	mov    %rbp,(%rdi,%r15,8)
 1f1:	49 ff c7             	inc    %r15
 1f4:	4c 39 fe             	cmp    %r15,%rsi
 1f7:	74 0a                	je     203 <verigmp::toom_interpolate::interpolate+0x203>
 1f9:	49 39 f7             	cmp    %rsi,%r15
 1fc:	72 d2                	jb     1d0 <verigmp::toom_interpolate::interpolate+0x1d0>
 1fe:	45 31 ed             	xor    %r13d,%r13d
 201:	eb d1                	jmp    1d4 <verigmp::toom_interpolate::interpolate+0x1d4>
 203:	45 31 e4             	xor    %r12d,%r12d
 206:	45 31 ff             	xor    %r15d,%r15d
 209:	eb 2e                	jmp    239 <verigmp::toom_interpolate::interpolate+0x239>
 20b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 210:	4e 8b 2c fb          	mov    (%rbx,%r15,8),%r13
 214:	4a 8b 2c fa          	mov    (%rdx,%r15,8),%rbp
 218:	4c 29 ed             	sub    %r13,%rbp
 21b:	41 0f 92 c5          	setb   %r13b
 21f:	4c 29 e5             	sub    %r12,%rbp
 222:	41 0f 92 c4          	setb   %r12b
 226:	45 08 ec             	or     %r13b,%r12b
 229:	45 0f b6 e4          	movzbl %r12b,%r12d
 22d:	4a 89 2c fa          	mov    %rbp,(%rdx,%r15,8)
 231:	49 ff c7             	inc    %r15
 234:	4c 39 fe             	cmp    %r15,%rsi
 237:	74 0a                	je     243 <verigmp::toom_interpolate::interpolate+0x243>
 239:	4d 39 d7             	cmp    %r10,%r15
 23c:	72 d2                	jb     210 <verigmp::toom_interpolate::interpolate+0x210>
 23e:	45 31 ed             	xor    %r13d,%r13d
 241:	eb d1                	jmp    214 <verigmp::toom_interpolate::interpolate+0x214>
 243:	45 31 e4             	xor    %r12d,%r12d
 246:	45 31 ff             	xor    %r15d,%r15d
 249:	eb 2e                	jmp    279 <verigmp::toom_interpolate::interpolate+0x279>
 24b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 250:	4f 8b 2c fe          	mov    (%r14,%r15,8),%r13
 254:	4a 8b 2c fa          	mov    (%rdx,%r15,8),%rbp
 258:	4c 29 ed             	sub    %r13,%rbp
 25b:	41 0f 92 c5          	setb   %r13b
 25f:	4c 29 e5             	sub    %r12,%rbp
 262:	41 0f 92 c4          	setb   %r12b
 266:	45 08 ec             	or     %r13b,%r12b
 269:	45 0f b6 e4          	movzbl %r12b,%r12d
 26d:	4a 89 2c fa          	mov    %rbp,(%rdx,%r15,8)
 271:	49 ff c7             	inc    %r15
 274:	4c 39 fe             	cmp    %r15,%rsi
 277:	74 0a                	je     283 <verigmp::toom_interpolate::interpolate+0x283>
 279:	4d 39 df             	cmp    %r11,%r15
 27c:	72 d2                	jb     250 <verigmp::toom_interpolate::interpolate+0x250>
 27e:	45 31 ed             	xor    %r13d,%r13d
 281:	eb d1                	jmp    254 <verigmp::toom_interpolate::interpolate+0x254>
 283:	4c 8b 24 24          	mov    (%rsp),%r12
 287:	4d 85 e4             	test   %r12,%r12
 28a:	74 7b                	je     307 <verigmp::toom_interpolate::interpolate+0x307>
 28c:	49 89 f4             	mov    %rsi,%r12
 28f:	49 21 cc             	and    %rcx,%r12
 292:	45 31 ed             	xor    %r13d,%r13d
 295:	eb 1b                	jmp    2b2 <verigmp::toom_interpolate::interpolate+0x2b2>
 297:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 29e:	00 00 
 2a0:	4b 8b 6c fe 08       	mov    0x8(%r14,%r15,8),%rbp
 2a5:	4a 89 6c f8 08       	mov    %rbp,0x8(%rax,%r15,8)
 2aa:	49 ff c5             	inc    %r13
 2ad:	4d 39 e5             	cmp    %r12,%r13
 2b0:	74 3d                	je     2ef <verigmp::toom_interpolate::interpolate+0x2ef>
 2b2:	4d 89 ef             	mov    %r13,%r15
 2b5:	4d 39 dd             	cmp    %r11,%r13
 2b8:	73 16                	jae    2d0 <verigmp::toom_interpolate::interpolate+0x2d0>
 2ba:	4f 8b 2c fe          	mov    (%r14,%r15,8),%r13
 2be:	4e 89 2c f8          	mov    %r13,(%rax,%r15,8)
 2c2:	4d 8d 6f 01          	lea    0x1(%r15),%r13
 2c6:	4d 39 dd             	cmp    %r11,%r13
 2c9:	72 d5                	jb     2a0 <verigmp::toom_interpolate::interpolate+0x2a0>
 2cb:	eb 13                	jmp    2e0 <verigmp::toom_interpolate::interpolate+0x2e0>
 2cd:	0f 1f 00             	nopl   (%rax)
 2d0:	45 31 ed             	xor    %r13d,%r13d
 2d3:	4e 89 2c f8          	mov    %r13,(%rax,%r15,8)
 2d7:	4d 8d 6f 01          	lea    0x1(%r15),%r13
 2db:	4d 39 dd             	cmp    %r11,%r13
 2de:	72 c0                	jb     2a0 <verigmp::toom_interpolate::interpolate+0x2a0>
 2e0:	31 ed                	xor    %ebp,%ebp
 2e2:	4a 89 6c f8 08       	mov    %rbp,0x8(%rax,%r15,8)
 2e7:	49 ff c5             	inc    %r13
 2ea:	4d 39 e5             	cmp    %r12,%r13
 2ed:	75 c3                	jne    2b2 <verigmp::toom_interpolate::interpolate+0x2b2>
 2ef:	40 f6 c6 01          	test   $0x1,%sil
 2f3:	4c 8b 24 24          	mov    (%rsp),%r12
 2f7:	74 1e                	je     317 <verigmp::toom_interpolate::interpolate+0x317>
 2f9:	49 83 c7 02          	add    $0x2,%r15
 2fd:	4d 39 df             	cmp    %r11,%r15
 300:	72 0d                	jb     30f <verigmp::toom_interpolate::interpolate+0x30f>
 302:	45 31 db             	xor    %r11d,%r11d
 305:	eb 0c                	jmp    313 <verigmp::toom_interpolate::interpolate+0x313>
 307:	45 31 ff             	xor    %r15d,%r15d
 30a:	4d 39 df             	cmp    %r11,%r15
 30d:	73 f3                	jae    302 <verigmp::toom_interpolate::interpolate+0x302>
 30f:	4f 8b 1c fe          	mov    (%r14,%r15,8),%r11
 313:	4e 89 1c f8          	mov    %r11,(%rax,%r15,8)
 317:	4d 85 e4             	test   %r12,%r12
 31a:	74 5e                	je     37a <verigmp::toom_interpolate::interpolate+0x37a>
 31c:	49 89 f7             	mov    %rsi,%r15
 31f:	49 21 cf             	and    %rcx,%r15
 322:	45 31 db             	xor    %r11d,%r11d
 325:	45 31 f6             	xor    %r14d,%r14d
 328:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 32f:	00 
 330:	4e 8b 24 f0          	mov    (%rax,%r14,8),%r12
 334:	4e 8b 6c f0 08       	mov    0x8(%rax,%r14,8),%r13
 339:	4c 89 e5             	mov    %r12,%rbp
 33c:	48 c1 ed 3c          	shr    $0x3c,%rbp
 340:	49 c1 e4 04          	shl    $0x4,%r12
 344:	4d 89 e9             	mov    %r13,%r9
 347:	49 c1 e9 3c          	shr    $0x3c,%r9
 34b:	49 c1 e5 04          	shl    $0x4,%r13
 34f:	4d 01 dc             	add    %r11,%r12
 352:	49 11 ed             	adc    %rbp,%r13
 355:	4d 89 cb             	mov    %r9,%r11
 358:	49 83 d3 00          	adc    $0x0,%r11
 35c:	4e 89 24 f0          	mov    %r12,(%rax,%r14,8)
 360:	4e 89 6c f0 08       	mov    %r13,0x8(%rax,%r14,8)
 365:	49 83 c6 02          	add    $0x2,%r14
 369:	4d 39 f7             	cmp    %r14,%r15
 36c:	75 c2                	jne    330 <verigmp::toom_interpolate::interpolate+0x330>
 36e:	40 f6 c6 01          	test   $0x1,%sil
 372:	4c 8b 24 24          	mov    (%rsp),%r12
 376:	75 08                	jne    380 <verigmp::toom_interpolate::interpolate+0x380>
 378:	eb 15                	jmp    38f <verigmp::toom_interpolate::interpolate+0x38f>
 37a:	45 31 db             	xor    %r11d,%r11d
 37d:	45 31 f6             	xor    %r14d,%r14d
 380:	4e 8b 0c f0          	mov    (%rax,%r14,8),%r9
 384:	49 c1 e1 04          	shl    $0x4,%r9
 388:	4d 01 d9             	add    %r11,%r9
 38b:	4e 89 0c f0          	mov    %r9,(%rax,%r14,8)
 38f:	45 31 f6             	xor    %r14d,%r14d
 392:	45 31 db             	xor    %r11d,%r11d
 395:	eb 32                	jmp    3c9 <verigmp::toom_interpolate::interpolate+0x3c9>
 397:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 39e:	00 00 
 3a0:	4e 8b 3c db          	mov    (%rbx,%r11,8),%r15
 3a4:	4f 8b 0c d8          	mov    (%r8,%r11,8),%r9
 3a8:	4d 29 f9             	sub    %r15,%r9
 3ab:	40 0f 92 c5          	setb   %bpl
 3af:	4d 29 f1             	sub    %r14,%r9
 3b2:	41 0f 92 c6          	setb   %r14b
 3b6:	41 08 ee             	or     %bpl,%r14b
 3b9:	45 0f b6 f6          	movzbl %r14b,%r14d
 3bd:	4f 89 0c d8          	mov    %r9,(%r8,%r11,8)
 3c1:	49 ff c3             	inc    %r11
 3c4:	4c 39 de             	cmp    %r11,%rsi
 3c7:	74 0a                	je     3d3 <verigmp::toom_interpolate::interpolate+0x3d3>
 3c9:	4d 39 d3             	cmp    %r10,%r11
 3cc:	72 d2                	jb     3a0 <verigmp::toom_interpolate::interpolate+0x3a0>
 3ce:	45 31 ff             	xor    %r15d,%r15d
 3d1:	eb d1                	jmp    3a4 <verigmp::toom_interpolate::interpolate+0x3a4>
 3d3:	45 31 db             	xor    %r11d,%r11d
 3d6:	45 31 d2             	xor    %r10d,%r10d
 3d9:	eb 2d                	jmp    408 <verigmp::toom_interpolate::interpolate+0x408>
 3db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 3e0:	4a 8b 1c d0          	mov    (%rax,%r10,8),%rbx
 3e4:	4f 8b 0c d0          	mov    (%r8,%r10,8),%r9
 3e8:	49 29 d9             	sub    %rbx,%r9
 3eb:	0f 92 c3             	setb   %bl
 3ee:	4d 29 d9             	sub    %r11,%r9
 3f1:	41 0f 92 c3          	setb   %r11b
 3f5:	41 08 db             	or     %bl,%r11b
 3f8:	45 0f b6 db          	movzbl %r11b,%r11d
 3fc:	4f 89 0c d0          	mov    %r9,(%r8,%r10,8)
 400:	49 ff c2             	inc    %r10
 403:	4c 39 d6             	cmp    %r10,%rsi
 406:	74 09                	je     411 <verigmp::toom_interpolate::interpolate+0x411>
 408:	49 39 f2             	cmp    %rsi,%r10
 40b:	72 d3                	jb     3e0 <verigmp::toom_interpolate::interpolate+0x3e0>
 40d:	31 db                	xor    %ebx,%ebx
 40f:	eb d3                	jmp    3e4 <verigmp::toom_interpolate::interpolate+0x3e4>
 411:	4d 85 e4             	test   %r12,%r12
 414:	74 51                	je     467 <verigmp::toom_interpolate::interpolate+0x467>
 416:	48 89 f3             	mov    %rsi,%rbx
 419:	48 21 cb             	and    %rcx,%rbx
 41c:	45 31 d2             	xor    %r10d,%r10d
 41f:	49 89 f3             	mov    %rsi,%r11
 422:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 429:	1f 84 00 00 00 00 00 
 430:	4f 8b 4c d8 f0       	mov    -0x10(%r8,%r11,8),%r9
 435:	4f 8b 74 d8 f8       	mov    -0x8(%r8,%r11,8),%r14
 43a:	4d 0f a4 f2 3f       	shld   $0x3f,%r14,%r10
 43f:	4f 89 54 d8 f8       	mov    %r10,-0x8(%r8,%r11,8)
 444:	45 89 ca             	mov    %r9d,%r10d
 447:	4d 0f ac f1 01       	shrd   $0x1,%r14,%r9
 44c:	41 83 e2 01          	and    $0x1,%r10d
 450:	4f 89 4c d8 f0       	mov    %r9,-0x10(%r8,%r11,8)
 455:	49 83 c3 fe          	add    $0xfffffffffffffffe,%r11
 459:	48 83 c3 fe          	add    $0xfffffffffffffffe,%rbx
 45d:	75 d1                	jne    430 <verigmp::toom_interpolate::interpolate+0x430>
 45f:	40 f6 c6 01          	test   $0x1,%sil
 463:	75 08                	jne    46d <verigmp::toom_interpolate::interpolate+0x46d>
 465:	eb 0d                	jmp    474 <verigmp::toom_interpolate::interpolate+0x474>
 467:	45 31 d2             	xor    %r10d,%r10d
 46a:	49 89 f3             	mov    %rsi,%r11
 46d:	4f 0f ac 54 d8 f8 01 	shrd   $0x1,%r10,-0x8(%r8,%r11,8)
 474:	45 31 db             	xor    %r11d,%r11d
 477:	45 31 d2             	xor    %r10d,%r10d
 47a:	eb 2c                	jmp    4a8 <verigmp::toom_interpolate::interpolate+0x4a8>
 47c:	0f 1f 40 00          	nopl   0x0(%rax)
 480:	4a 8b 1c d7          	mov    (%rdi,%r10,8),%rbx
 484:	4f 8b 0c d0          	mov    (%r8,%r10,8),%r9
 488:	49 29 d9             	sub    %rbx,%r9
 48b:	0f 92 c3             	setb   %bl
 48e:	4d 29 d9             	sub    %r11,%r9
 491:	41 0f 92 c3          	setb   %r11b
 495:	41 08 db             	or     %bl,%r11b
 498:	45 0f b6 db          	movzbl %r11b,%r11d
 49c:	4f 89 0c d0          	mov    %r9,(%r8,%r10,8)
 4a0:	49 ff c2             	inc    %r10
 4a3:	4c 39 d6             	cmp    %r10,%rsi
 4a6:	74 09                	je     4b1 <verigmp::toom_interpolate::interpolate+0x4b1>
 4a8:	49 39 f2             	cmp    %rsi,%r10
 4ab:	72 d3                	jb     480 <verigmp::toom_interpolate::interpolate+0x480>
 4ad:	31 db                	xor    %ebx,%ebx
 4af:	eb d3                	jmp    484 <verigmp::toom_interpolate::interpolate+0x484>
 4b1:	4d 85 e4             	test   %r12,%r12
 4b4:	74 6c                	je     522 <verigmp::toom_interpolate::interpolate+0x522>
 4b6:	49 89 f3             	mov    %rsi,%r11
 4b9:	49 21 cb             	and    %rcx,%r11
 4bc:	31 db                	xor    %ebx,%ebx
 4be:	eb 12                	jmp    4d2 <verigmp::toom_interpolate::interpolate+0x4d2>
 4c0:	4e 8b 74 d2 08       	mov    0x8(%rdx,%r10,8),%r14
 4c5:	4e 89 74 d0 08       	mov    %r14,0x8(%rax,%r10,8)
 4ca:	48 ff c3             	inc    %rbx
 4cd:	4c 39 db             	cmp    %r11,%rbx
 4d0:	74 3d                	je     50f <verigmp::toom_interpolate::interpolate+0x50f>
 4d2:	49 89 da             	mov    %rbx,%r10
 4d5:	48 39 f3             	cmp    %rsi,%rbx
 4d8:	73 16                	jae    4f0 <verigmp::toom_interpolate::interpolate+0x4f0>
 4da:	4a 8b 1c d2          	mov    (%rdx,%r10,8),%rbx
 4de:	4a 89 1c d0          	mov    %rbx,(%rax,%r10,8)
 4e2:	49 8d 5a 01          	lea    0x1(%r10),%rbx
 4e6:	48 39 f3             	cmp    %rsi,%rbx
 4e9:	72 d5                	jb     4c0 <verigmp::toom_interpolate::interpolate+0x4c0>
 4eb:	eb 12                	jmp    4ff <verigmp::toom_interpolate::interpolate+0x4ff>
 4ed:	0f 1f 00             	nopl   (%rax)
 4f0:	31 db                	xor    %ebx,%ebx
 4f2:	4a 89 1c d0          	mov    %rbx,(%rax,%r10,8)
 4f6:	49 8d 5a 01          	lea    0x1(%r10),%rbx
 4fa:	48 39 f3             	cmp    %rsi,%rbx
 4fd:	72 c1                	jb     4c0 <verigmp::toom_interpolate::interpolate+0x4c0>
 4ff:	45 31 f6             	xor    %r14d,%r14d
 502:	4e 89 74 d0 08       	mov    %r14,0x8(%rax,%r10,8)
 507:	48 ff c3             	inc    %rbx
 50a:	4c 39 db             	cmp    %r11,%rbx
 50d:	75 c3                	jne    4d2 <verigmp::toom_interpolate::interpolate+0x4d2>
 50f:	40 f6 c6 01          	test   $0x1,%sil
 513:	74 1d                	je     532 <verigmp::toom_interpolate::interpolate+0x532>
 515:	49 83 c2 02          	add    $0x2,%r10
 519:	49 39 f2             	cmp    %rsi,%r10
 51c:	72 0c                	jb     52a <verigmp::toom_interpolate::interpolate+0x52a>
 51e:	31 d2                	xor    %edx,%edx
 520:	eb 0c                	jmp    52e <verigmp::toom_interpolate::interpolate+0x52e>
 522:	45 31 d2             	xor    %r10d,%r10d
 525:	49 39 f2             	cmp    %rsi,%r10
 528:	73 f4                	jae    51e <verigmp::toom_interpolate::interpolate+0x51e>
 52a:	4a 8b 14 d2          	mov    (%rdx,%r10,8),%rdx
 52e:	4a 89 14 d0          	mov    %rdx,(%rax,%r10,8)
 532:	4d 85 e4             	test   %r12,%r12
 535:	74 4d                	je     584 <verigmp::toom_interpolate::interpolate+0x584>
 537:	48 21 f1             	and    %rsi,%rcx
 53a:	31 d2                	xor    %edx,%edx
 53c:	45 31 c9             	xor    %r9d,%r9d
 53f:	90                   	nop
 540:	4e 8b 14 c8          	mov    (%rax,%r9,8),%r10
 544:	4e 8b 5c c8 08       	mov    0x8(%rax,%r9,8),%r11
 549:	4c 89 d3             	mov    %r10,%rbx
 54c:	48 c1 eb 3f          	shr    $0x3f,%rbx
 550:	4d 01 d2             	add    %r10,%r10
 553:	4d 89 de             	mov    %r11,%r14
 556:	49 c1 ee 3f          	shr    $0x3f,%r14
 55a:	4d 01 db             	add    %r11,%r11
 55d:	49 01 d2             	add    %rdx,%r10
 560:	49 11 db             	adc    %rbx,%r11
 563:	4c 89 f2             	mov    %r14,%rdx
 566:	48 83 d2 00          	adc    $0x0,%rdx
 56a:	4e 89 14 c8          	mov    %r10,(%rax,%r9,8)
 56e:	4e 89 5c c8 08       	mov    %r11,0x8(%rax,%r9,8)
 573:	49 83 c1 02          	add    $0x2,%r9
 577:	4c 39 c9             	cmp    %r9,%rcx
 57a:	75 c4                	jne    540 <verigmp::toom_interpolate::interpolate+0x540>
 57c:	40 f6 c6 01          	test   $0x1,%sil
 580:	75 07                	jne    589 <verigmp::toom_interpolate::interpolate+0x589>
 582:	eb 11                	jmp    595 <verigmp::toom_interpolate::interpolate+0x595>
 584:	31 d2                	xor    %edx,%edx
 586:	45 31 c9             	xor    %r9d,%r9d
 589:	4a 8b 0c c8          	mov    (%rax,%r9,8),%rcx
 58d:	48 8d 0c 4a          	lea    (%rdx,%rcx,2),%rcx
 591:	4a 89 0c c8          	mov    %rcx,(%rax,%r9,8)
 595:	31 d2                	xor    %edx,%edx
 597:	31 c9                	xor    %ecx,%ecx
 599:	eb 2c                	jmp    5c7 <verigmp::toom_interpolate::interpolate+0x5c7>
 59b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 5a0:	4c 8b 0c c8          	mov    (%rax,%rcx,8),%r9
 5a4:	4d 8b 14 c8          	mov    (%r8,%rcx,8),%r10
 5a8:	4d 29 ca             	sub    %r9,%r10
 5ab:	41 0f 92 c1          	setb   %r9b
 5af:	49 29 d2             	sub    %rdx,%r10
 5b2:	0f 92 c2             	setb   %dl
 5b5:	44 08 ca             	or     %r9b,%dl
 5b8:	0f b6 d2             	movzbl %dl,%edx
 5bb:	4d 89 14 c8          	mov    %r10,(%r8,%rcx,8)
 5bf:	48 ff c1             	inc    %rcx
 5c2:	48 39 ce             	cmp    %rcx,%rsi
 5c5:	74 0a                	je     5d1 <verigmp::toom_interpolate::interpolate+0x5d1>
 5c7:	48 39 f1             	cmp    %rsi,%rcx
 5ca:	72 d4                	jb     5a0 <verigmp::toom_interpolate::interpolate+0x5a0>
 5cc:	45 31 c9             	xor    %r9d,%r9d
 5cf:	eb d3                	jmp    5a4 <verigmp::toom_interpolate::interpolate+0x5a4>
 5d1:	31 c9                	xor    %ecx,%ecx
 5d3:	49 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r9
 5da:	aa aa aa 
 5dd:	49 89 f2             	mov    %rsi,%r10
 5e0:	4f 8b 5c d0 f8       	mov    -0x8(%r8,%r10,8),%r11
 5e5:	4c 01 d9             	add    %r11,%rcx
 5e8:	48 83 d1 00          	adc    $0x0,%rcx
 5ec:	48 89 c8             	mov    %rcx,%rax
 5ef:	49 f7 e1             	mul    %r9
 5f2:	48 d1 ea             	shr    $1,%rdx
 5f5:	48 8d 04 52          	lea    (%rdx,%rdx,2),%rax
 5f9:	48 29 c1             	sub    %rax,%rcx
 5fc:	49 29 cb             	sub    %rcx,%r11
 5ff:	4d 0f af d9          	imul   %r9,%r11
 603:	4f 89 5c d0 f8       	mov    %r11,-0x8(%r8,%r10,8)
 608:	49 ff ca             	dec    %r10
 60b:	75 d3                	jne    5e0 <verigmp::toom_interpolate::interpolate+0x5e0>
 60d:	31 c9                	xor    %ecx,%ecx
 60f:	31 c0                	xor    %eax,%eax
 611:	eb 32                	jmp    645 <verigmp::toom_interpolate::interpolate+0x645>
 613:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 61a:	84 00 00 00 00 00 
 620:	49 8b 14 c0          	mov    (%r8,%rax,8),%rdx
 624:	4c 8b 0c c7          	mov    (%rdi,%rax,8),%r9
 628:	49 29 d1             	sub    %rdx,%r9
 62b:	0f 92 c2             	setb   %dl
 62e:	49 29 c9             	sub    %rcx,%r9
 631:	0f 92 c1             	setb   %cl
 634:	08 d1                	or     %dl,%cl
 636:	0f b6 c9             	movzbl %cl,%ecx
 639:	4c 89 0c c7          	mov    %r9,(%rdi,%rax,8)
 63d:	48 ff c0             	inc    %rax
 640:	48 39 c6             	cmp    %rax,%rsi
 643:	74 09                	je     64e <verigmp::toom_interpolate::interpolate+0x64e>
 645:	48 39 f0             	cmp    %rsi,%rax
 648:	72 d6                	jb     620 <verigmp::toom_interpolate::interpolate+0x620>
 64a:	31 d2                	xor    %edx,%edx
 64c:	eb d6                	jmp    624 <verigmp::toom_interpolate::interpolate+0x624>
 64e:	48 83 c4 08          	add    $0x8,%rsp
 652:	5b                   	pop    %rbx
 653:	41 5c                	pop    %r12
 655:	41 5d                	pop    %r13
 657:	41 5e                	pop    %r14
 659:	41 5f                	pop    %r15
 65b:	5d                   	pop    %rbp
 65c:	c3                   	ret
 65d:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 664 <verigmp::toom_interpolate::interpolate+0x664>
			660: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.146-0x4
 664:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 66b <verigmp::toom_interpolate::interpolate+0x66b>
			667: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.148-0x4
 66b:	be 5b 00 00 00       	mov    $0x5b,%esi
 670:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 676 <verigmp::toom_interpolate::interpolate+0x676>
			672: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 676:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 67d <verigmp::toom_interpolate::interpolate+0x67d>
			679: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.149-0x4
 67d:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 684 <verigmp::toom_interpolate::interpolate+0x684>
			680: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.150-0x4
 684:	be 3e 00 00 00       	mov    $0x3e,%esi
 689:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 68f <verigmp::toom_interpolate::interpolate+0x68f>
			68b: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution10guard_bits:

0000000000000000 <verigmp::packed_convolution::guard_bits>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::guard_bits+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::guard_bits+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.152-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::guard_bits+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution10slot_power:

0000000000000000 <verigmp::packed_convolution::slot_power>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::slot_power+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::slot_power+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.153-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::slot_power+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution11coefficient:

0000000000000000 <verigmp::packed_convolution::coefficient>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::coefficient+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::coefficient+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.154-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::coefficient+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution11convolution:

0000000000000000 <verigmp::packed_convolution::convolution>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::convolution+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::convolution+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.155-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::convolution+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution12overlap_step:

0000000000000000 <verigmp::packed_convolution::overlap_step>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::overlap_step+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::overlap_step+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.156-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::overlap_step+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution12packed_range:

0000000000000000 <verigmp::packed_convolution::packed_range>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::packed_range+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::packed_range+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.157-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::packed_range+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution12packed_split:

0000000000000000 <verigmp::packed_convolution::packed_split>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::packed_split+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::packed_split+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.158-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::packed_split+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution12row_identity:

0000000000000000 <verigmp::packed_convolution::row_identity>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::row_identity+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::row_identity+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.159-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::row_identity+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution12slots_prefix:

0000000000000000 <verigmp::packed_convolution::slots_prefix>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::slots_prefix+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::slots_prefix+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.160-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::slots_prefix+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution13empty_product:

0000000000000000 <verigmp::packed_convolution::empty_product>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::empty_product+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::empty_product+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.161-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::empty_product+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution13extract_digit:

0000000000000000 <verigmp::packed_convolution::extract_digit>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::extract_digit+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::extract_digit+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.162-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::extract_digit+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution13packed_prefix:

0000000000000000 <verigmp::packed_convolution::packed_prefix>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::packed_prefix+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::packed_prefix+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.163-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::packed_prefix+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution13packed_suffix:

0000000000000000 <verigmp::packed_convolution::packed_suffix>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::packed_suffix+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::packed_suffix+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.164-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::packed_suffix+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution13slots_integer:

0000000000000000 <verigmp::packed_convolution::slots_integer>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::slots_integer+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::slots_integer+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.165-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::slots_integer+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution13weighted_step:

0000000000000000 <verigmp::packed_convolution::weighted_step>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::weighted_step+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::weighted_step+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.166-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::weighted_step+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution13weighted_zero:

0000000000000000 <verigmp::packed_convolution::weighted_zero>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::weighted_zero+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::weighted_zero+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.167-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::weighted_zero+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution14no_carry_bound:

0000000000000000 <verigmp::packed_convolution::no_carry_bound>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::no_carry_bound+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::no_carry_bound+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.168-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::no_carry_bound+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution14power_positive:

0000000000000000 <verigmp::packed_convolution::power_positive>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::power_positive+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::power_positive+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.169-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::power_positive+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution15truncate_prefix:

0000000000000000 <verigmp::packed_convolution::truncate_prefix>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::truncate_prefix+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::truncate_prefix+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.170-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::truncate_prefix+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution16coefficient_zero:

0000000000000000 <verigmp::packed_convolution::coefficient_zero>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::coefficient_zero+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::coefficient_zero+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.171-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::coefficient_zero+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution16weighted_product:

0000000000000000 <verigmp::packed_convolution::weighted_product>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::weighted_product+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::weighted_product+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.172-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::weighted_product+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution17coefficient_bound:

0000000000000000 <verigmp::packed_convolution::coefficient_bound>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::coefficient_bound+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::coefficient_bound+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.173-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::coefficient_bound+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution17truncated_extract:

0000000000000000 <verigmp::packed_convolution::truncated_extract>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::truncated_extract+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::truncated_extract+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.174-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::truncated_extract+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution18convolution_prefix:

0000000000000000 <verigmp::packed_convolution::convolution_prefix>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::convolution_prefix+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::convolution_prefix+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.175-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::convolution_prefix+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution18word_aligned_guard:

0000000000000000 <verigmp::packed_convolution::word_aligned_guard>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::word_aligned_guard+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::word_aligned_guard+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.176-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::word_aligned_guard+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution19convolution_product:

0000000000000000 <verigmp::packed_convolution::convolution_product>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::convolution_product+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::convolution_product+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.177-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::convolution_product+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution20power_of_two_divides:

0000000000000000 <verigmp::packed_convolution::power_of_two_divides>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::power_of_two_divides+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::power_of_two_divides+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.178-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::power_of_two_divides+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution20truncate_coefficient:

0000000000000000 <verigmp::packed_convolution::truncate_coefficient>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::truncate_coefficient+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::truncate_coefficient+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.179-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::truncate_coefficient+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution25packed_convolution_prefix:

0000000000000000 <verigmp::packed_convolution::packed_convolution_prefix>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::packed_convolution_prefix+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::packed_convolution_prefix+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.180-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::packed_convolution_prefix+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution26packed_convolution_extract:

0000000000000000 <verigmp::packed_convolution::packed_convolution_extract>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::packed_convolution_extract+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::packed_convolution_extract+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.181-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::packed_convolution_extract+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution26packed_convolution_residue:

0000000000000000 <verigmp::packed_convolution::packed_convolution_residue>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::packed_convolution_residue+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::packed_convolution_residue+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.182-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::packed_convolution_residue+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution3row:

0000000000000000 <verigmp::packed_convolution::row>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::row+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::row+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.183-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::row+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution4term:

0000000000000000 <verigmp::packed_convolution::term>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::term+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::term+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.184-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::term+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution5power:

0000000000000000 <verigmp::packed_convolution::power>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::power+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::power+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.185-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::power+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution5slots:

0000000000000000 <verigmp::packed_convolution::slots>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::slots+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::slots+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.186-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::slots+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution6packed:

0000000000000000 <verigmp::packed_convolution::packed>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::packed+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::packed+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.187-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::packed+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution7overlap:

0000000000000000 <verigmp::packed_convolution::overlap>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::overlap+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::overlap+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.188-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::overlap+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution7shorter:

0000000000000000 <verigmp::packed_convolution::shorter>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::shorter+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::shorter+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.189-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::shorter+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution8retained:

0000000000000000 <verigmp::packed_convolution::retained>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::retained+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::retained+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.190-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::retained+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution8weighted:

0000000000000000 <verigmp::packed_convolution::weighted>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::weighted+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::weighted+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.191-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::weighted+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution9canonical:

0000000000000000 <verigmp::packed_convolution::canonical>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::canonical+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::canonical+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.192-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::canonical+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp18packed_convolution9power_add:

0000000000000000 <verigmp::packed_convolution::power_add>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::packed_convolution::power_add+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::packed_convolution::power_add+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.193-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::packed_convolution::power_add+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp4mac412add_mul_word:

0000000000000000 <verigmp::mac4::add_mul_word>:
   0:	41 56                	push   %r14
   2:	53                   	push   %rbx
   3:	50                   	push   %rax
   4:	48 39 ce             	cmp    %rcx,%rsi
   7:	0f 87 e0 01 00 00    	ja     1ed <verigmp::mac4::add_mul_word+0x1ed>
   d:	49 89 d1             	mov    %rdx,%r9
  10:	45 31 db             	xor    %r11d,%r11d
  13:	48 89 f3             	mov    %rsi,%rbx
  16:	41 be 00 00 00 00    	mov    $0x0,%r14d
  1c:	48 83 eb 03          	sub    $0x3,%rbx
  20:	49 0f 42 db          	cmovb  %r11,%rbx
  24:	77 28                	ja     4e <verigmp::mac4::add_mul_word+0x4e>
  26:	4c 39 de             	cmp    %r11,%rsi
  29:	0f 86 36 01 00 00    	jbe    165 <verigmp::mac4::add_mul_word+0x165>
  2f:	89 f0                	mov    %esi,%eax
  31:	44 29 d8             	sub    %r11d,%eax
  34:	4d 8d 53 01          	lea    0x1(%r11),%r10
  38:	a8 01                	test   $0x1,%al
  3a:	0f 85 2a 01 00 00    	jne    16a <verigmp::mac4::add_mul_word+0x16a>
  40:	4c 39 d6             	cmp    %r10,%rsi
  43:	0f 85 46 01 00 00    	jne    18f <verigmp::mac4::add_mul_word+0x18f>
  49:	e9 94 01 00 00       	jmp    1e2 <verigmp::mac4::add_mul_word+0x1e2>
  4e:	4c 89 c0             	mov    %r8,%rax
  51:	49 f7 21             	mulq   (%r9)
  54:	49 89 d3             	mov    %rdx,%r11
  57:	48 03 07             	add    (%rdi),%rax
  5a:	49 83 d3 00          	adc    $0x0,%r11
  5e:	48 89 07             	mov    %rax,(%rdi)
  61:	48 83 f9 02          	cmp    $0x2,%rcx
  65:	0f 82 f1 01 00 00    	jb     25c <verigmp::mac4::add_mul_word+0x25c>
  6b:	41 ba 02 00 00 00    	mov    $0x2,%r10d
  71:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  78:	0f 1f 84 00 00 00 00 
  7f:	00 
  80:	49 8d 42 ff          	lea    -0x1(%r10),%rax
  84:	48 39 f0             	cmp    %rsi,%rax
  87:	0f 83 bf 01 00 00    	jae    24c <verigmp::mac4::add_mul_word+0x24c>
  8d:	4c 89 c0             	mov    %r8,%rax
  90:	4b f7 64 d1 f8       	mulq   -0x8(%r9,%r10,8)
  95:	45 31 f6             	xor    %r14d,%r14d
  98:	4e 03 5c d7 f8       	add    -0x8(%rdi,%r10,8),%r11
  9d:	41 0f 92 c6          	setb   %r14b
  a1:	49 01 c3             	add    %rax,%r11
  a4:	49 11 d6             	adc    %rdx,%r14
  a7:	4e 89 5c d7 f8       	mov    %r11,-0x8(%rdi,%r10,8)
  ac:	49 39 ca             	cmp    %rcx,%r10
  af:	0f 83 84 01 00 00    	jae    239 <verigmp::mac4::add_mul_word+0x239>
  b5:	49 39 f2             	cmp    %rsi,%r10
  b8:	0f 83 6b 01 00 00    	jae    229 <verigmp::mac4::add_mul_word+0x229>
  be:	4c 89 c0             	mov    %r8,%rax
  c1:	4b f7 24 d1          	mulq   (%r9,%r10,8)
  c5:	45 31 db             	xor    %r11d,%r11d
  c8:	4e 03 34 d7          	add    (%rdi,%r10,8),%r14
  cc:	41 0f 92 c3          	setb   %r11b
  d0:	49 01 c6             	add    %rax,%r14
  d3:	49 11 d3             	adc    %rdx,%r11
  d6:	4e 89 34 d7          	mov    %r14,(%rdi,%r10,8)
  da:	49 8d 42 01          	lea    0x1(%r10),%rax
  de:	48 39 c8             	cmp    %rcx,%rax
  e1:	0f 83 2f 01 00 00    	jae    216 <verigmp::mac4::add_mul_word+0x216>
  e7:	48 39 f0             	cmp    %rsi,%rax
  ea:	0f 83 16 01 00 00    	jae    206 <verigmp::mac4::add_mul_word+0x206>
  f0:	4c 89 c0             	mov    %r8,%rax
  f3:	4b f7 64 d1 08       	mulq   0x8(%r9,%r10,8)
  f8:	45 31 f6             	xor    %r14d,%r14d
  fb:	4e 03 5c d7 08       	add    0x8(%rdi,%r10,8),%r11
 100:	41 0f 92 c6          	setb   %r14b
 104:	49 01 c3             	add    %rax,%r11
 107:	49 11 d6             	adc    %rdx,%r14
 10a:	4e 89 5c d7 08       	mov    %r11,0x8(%rdi,%r10,8)
 10f:	4d 8d 5a 02          	lea    0x2(%r10),%r11
 113:	49 39 db             	cmp    %rbx,%r11
 116:	0f 83 0a ff ff ff    	jae    26 <verigmp::mac4::add_mul_word+0x26>
 11c:	4c 89 c0             	mov    %r8,%rax
 11f:	4b f7 64 d1 10       	mulq   0x10(%r9,%r10,8)
 124:	45 31 db             	xor    %r11d,%r11d
 127:	4e 03 74 d7 10       	add    0x10(%rdi,%r10,8),%r14
 12c:	41 0f 92 c3          	setb   %r11b
 130:	49 01 c6             	add    %rax,%r14
 133:	49 11 d3             	adc    %rdx,%r11
 136:	4e 89 74 d7 10       	mov    %r14,0x10(%rdi,%r10,8)
 13b:	49 8d 42 04          	lea    0x4(%r10),%rax
 13f:	49 83 c2 03          	add    $0x3,%r10
 143:	49 39 ca             	cmp    %rcx,%r10
 146:	49 89 c2             	mov    %rax,%r10
 149:	0f 82 31 ff ff ff    	jb     80 <verigmp::mac4::add_mul_word+0x80>
 14f:	48 ff c8             	dec    %rax
 152:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 159 <verigmp::mac4::add_mul_word+0x159>
			155: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.197-0x4
 159:	48 89 c7             	mov    %rax,%rdi
 15c:	48 89 ce             	mov    %rcx,%rsi
 15f:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 165 <verigmp::mac4::add_mul_word+0x165>
			161: R_X86_64_GOTPCREL	core::panicking::panic_bounds_check-0x4
 165:	4c 89 f1             	mov    %r14,%rcx
 168:	eb 78                	jmp    1e2 <verigmp::mac4::add_mul_word+0x1e2>
 16a:	4c 89 c0             	mov    %r8,%rax
 16d:	4b f7 24 d9          	mulq   (%r9,%r11,8)
 171:	31 c9                	xor    %ecx,%ecx
 173:	4e 03 34 df          	add    (%rdi,%r11,8),%r14
 177:	0f 92 c1             	setb   %cl
 17a:	49 01 c6             	add    %rax,%r14
 17d:	48 11 d1             	adc    %rdx,%rcx
 180:	4e 89 34 df          	mov    %r14,(%rdi,%r11,8)
 184:	49 89 ce             	mov    %rcx,%r14
 187:	4d 89 d3             	mov    %r10,%r11
 18a:	4c 39 d6             	cmp    %r10,%rsi
 18d:	74 53                	je     1e2 <verigmp::mac4::add_mul_word+0x1e2>
 18f:	4c 89 f1             	mov    %r14,%rcx
 192:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 199:	1f 84 00 00 00 00 00 
 1a0:	4c 89 c0             	mov    %r8,%rax
 1a3:	4b f7 24 d9          	mulq   (%r9,%r11,8)
 1a7:	45 31 d2             	xor    %r10d,%r10d
 1aa:	4a 03 0c df          	add    (%rdi,%r11,8),%rcx
 1ae:	41 0f 92 c2          	setb   %r10b
 1b2:	48 01 c1             	add    %rax,%rcx
 1b5:	49 11 d2             	adc    %rdx,%r10
 1b8:	4a 89 0c df          	mov    %rcx,(%rdi,%r11,8)
 1bc:	4c 89 c0             	mov    %r8,%rax
 1bf:	4b f7 64 d9 08       	mulq   0x8(%r9,%r11,8)
 1c4:	31 c9                	xor    %ecx,%ecx
 1c6:	4e 03 54 df 08       	add    0x8(%rdi,%r11,8),%r10
 1cb:	0f 92 c1             	setb   %cl
 1ce:	49 01 c2             	add    %rax,%r10
 1d1:	48 11 d1             	adc    %rdx,%rcx
 1d4:	4e 89 54 df 08       	mov    %r10,0x8(%rdi,%r11,8)
 1d9:	49 83 c3 02          	add    $0x2,%r11
 1dd:	4c 39 de             	cmp    %r11,%rsi
 1e0:	75 be                	jne    1a0 <verigmp::mac4::add_mul_word+0x1a0>
 1e2:	48 89 c8             	mov    %rcx,%rax
 1e5:	48 83 c4 08          	add    $0x8,%rsp
 1e9:	5b                   	pop    %rbx
 1ea:	41 5e                	pop    %r14
 1ec:	c3                   	ret
 1ed:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 1f4 <verigmp::mac4::add_mul_word+0x1f4>
			1f0: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.194-0x4
 1f4:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 1fb <verigmp::mac4::add_mul_word+0x1fb>
			1f7: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.196-0x4
 1fb:	be 28 00 00 00       	mov    $0x28,%esi
 200:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 206 <verigmp::mac4::add_mul_word+0x206>
			202: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 206:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 20d <verigmp::mac4::add_mul_word+0x20d>
			209: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.202-0x4
 20d:	48 89 c7             	mov    %rax,%rdi
 210:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 216 <verigmp::mac4::add_mul_word+0x216>
			212: R_X86_64_GOTPCREL	core::panicking::panic_bounds_check-0x4
 216:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 21d <verigmp::mac4::add_mul_word+0x21d>
			219: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.201-0x4
 21d:	48 89 c7             	mov    %rax,%rdi
 220:	48 89 ce             	mov    %rcx,%rsi
 223:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 229 <verigmp::mac4::add_mul_word+0x229>
			225: R_X86_64_GOTPCREL	core::panicking::panic_bounds_check-0x4
 229:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 230 <verigmp::mac4::add_mul_word+0x230>
			22c: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.200-0x4
 230:	4c 89 d7             	mov    %r10,%rdi
 233:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 239 <verigmp::mac4::add_mul_word+0x239>
			235: R_X86_64_GOTPCREL	core::panicking::panic_bounds_check-0x4
 239:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 240 <verigmp::mac4::add_mul_word+0x240>
			23c: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.199-0x4
 240:	4c 89 d7             	mov    %r10,%rdi
 243:	48 89 ce             	mov    %rcx,%rsi
 246:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 24c <verigmp::mac4::add_mul_word+0x24c>
			248: R_X86_64_GOTPCREL	core::panicking::panic_bounds_check-0x4
 24c:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 253 <verigmp::mac4::add_mul_word+0x253>
			24f: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.198-0x4
 253:	48 89 c7             	mov    %rax,%rdi
 256:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 25c <verigmp::mac4::add_mul_word+0x25c>
			258: R_X86_64_GOTPCREL	core::panicking::panic_bounds_check-0x4
 25c:	b8 01 00 00 00       	mov    $0x1,%eax
 261:	e9 ec fe ff ff       	jmp    152 <verigmp::mac4::add_mul_word+0x152>

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp4pow213normalize_top:

0000000000000000 <verigmp::pow2::normalize_top>:
   0:	50                   	push   %rax
   1:	48 85 f6             	test   %rsi,%rsi
   4:	74 45                	je     4b <verigmp::pow2::normalize_top+0x4b>
   6:	8d 42 ff             	lea    -0x1(%rdx),%eax
   9:	83 f8 40             	cmp    $0x40,%eax
   c:	73 24                	jae    32 <verigmp::pow2::normalize_top+0x32>
   e:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  15:	49 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%r8
  1c:	89 d1                	mov    %edx,%ecx
  1e:	49 d3 e0             	shl    %cl,%r8
  21:	83 fa 40             	cmp    $0x40,%edx
  24:	49 f7 d0             	not    %r8
  27:	4c 0f 44 c0          	cmove  %rax,%r8
  2b:	4c 21 44 f7 f8       	and    %r8,-0x8(%rdi,%rsi,8)
  30:	58                   	pop    %rax
  31:	c3                   	ret
  32:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 39 <verigmp::pow2::normalize_top+0x39>
			35: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.212-0x4
  39:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 40 <verigmp::pow2::normalize_top+0x40>
			3c: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.213-0x4
  40:	be 29 00 00 00       	mov    $0x29,%esi
  45:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4b <verigmp::pow2::normalize_top+0x4b>
			47: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  4b:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 52 <verigmp::pow2::normalize_top+0x52>
			4e: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.203-0x4
  52:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 59 <verigmp::pow2::normalize_top+0x59>
			55: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.205-0x4
  59:	be 1f 00 00 00       	mov    $0x1f,%esi
  5e:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 64 <verigmp::pow2::normalize_top+0x64>
			60: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp4pow214add_mod_assign:

0000000000000000 <verigmp::pow2::add_mod_assign>:
   0:	50                   	push   %rax
   1:	48 85 f6             	test   %rsi,%rsi
   4:	0f 84 bc 00 00 00    	je     c6 <verigmp::pow2::add_mod_assign+0xc6>
   a:	41 8d 40 ff          	lea    -0x1(%r8),%eax
   e:	83 f8 40             	cmp    $0x40,%eax
  11:	0f 83 96 00 00 00    	jae    ad <verigmp::pow2::add_mod_assign+0xad>
  17:	48 39 ce             	cmp    %rcx,%rsi
  1a:	0f 85 bf 00 00 00    	jne    df <verigmp::pow2::add_mod_assign+0xdf>
  20:	48 83 fe 01          	cmp    $0x1,%rsi
  24:	75 06                	jne    2c <verigmp::pow2::add_mod_assign+0x2c>
  26:	31 c0                	xor    %eax,%eax
  28:	31 c9                	xor    %ecx,%ecx
  2a:	eb 4f                	jmp    7b <verigmp::pow2::add_mod_assign+0x7b>
  2c:	49 b9 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r9
  33:	ff ff 0f 
  36:	49 21 f1             	and    %rsi,%r9
  39:	31 c0                	xor    %eax,%eax
  3b:	31 c9                	xor    %ecx,%ecx
  3d:	0f 1f 00             	nopl   (%rax)
  40:	45 31 d2             	xor    %r10d,%r10d
  43:	48 03 04 cf          	add    (%rdi,%rcx,8),%rax
  47:	41 0f 92 c2          	setb   %r10b
  4b:	48 03 04 ca          	add    (%rdx,%rcx,8),%rax
  4f:	48 89 04 cf          	mov    %rax,(%rdi,%rcx,8)
  53:	4c 13 54 cf 08       	adc    0x8(%rdi,%rcx,8),%r10
  58:	0f 92 c0             	setb   %al
  5b:	0f b6 c0             	movzbl %al,%eax
  5e:	4c 03 54 ca 08       	add    0x8(%rdx,%rcx,8),%r10
  63:	48 83 d0 00          	adc    $0x0,%rax
  67:	4c 89 54 cf 08       	mov    %r10,0x8(%rdi,%rcx,8)
  6c:	48 83 c1 02          	add    $0x2,%rcx
  70:	49 39 c9             	cmp    %rcx,%r9
  73:	75 cb                	jne    40 <verigmp::pow2::add_mod_assign+0x40>
  75:	40 f6 c6 01          	test   $0x1,%sil
  79:	74 0c                	je     87 <verigmp::pow2::add_mod_assign+0x87>
  7b:	48 03 04 cf          	add    (%rdi,%rcx,8),%rax
  7f:	48 03 04 ca          	add    (%rdx,%rcx,8),%rax
  83:	48 89 04 cf          	mov    %rax,(%rdi,%rcx,8)
  87:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  8e:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  95:	44 89 c1             	mov    %r8d,%ecx
  98:	48 d3 e2             	shl    %cl,%rdx
  9b:	41 83 f8 40          	cmp    $0x40,%r8d
  9f:	48 f7 d2             	not    %rdx
  a2:	48 0f 44 d0          	cmove  %rax,%rdx
  a6:	48 21 54 f7 f8       	and    %rdx,-0x8(%rdi,%rsi,8)
  ab:	58                   	pop    %rax
  ac:	c3                   	ret
  ad:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # b4 <verigmp::pow2::add_mod_assign+0xb4>
			b0: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.1-0x4
  b4:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # bb <verigmp::pow2::add_mod_assign+0xbb>
			b7: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.207-0x4
  bb:	be 27 00 00 00       	mov    $0x27,%esi
  c0:	ff 15 00 00 00 00    	call   *0x0(%rip)        # c6 <verigmp::pow2::add_mod_assign+0xc6>
			c2: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  c6:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # cd <verigmp::pow2::add_mod_assign+0xcd>
			c9: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.203-0x4
  cd:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # d4 <verigmp::pow2::add_mod_assign+0xd4>
			d0: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.206-0x4
  d4:	be 1f 00 00 00       	mov    $0x1f,%esi
  d9:	ff 15 00 00 00 00    	call   *0x0(%rip)        # df <verigmp::pow2::add_mod_assign+0xdf>
			db: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  df:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # e6 <verigmp::pow2::add_mod_assign+0xe6>
			e2: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.13-0x4
  e6:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # ed <verigmp::pow2::add_mod_assign+0xed>
			e9: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.226-0x4
  ed:	be 28 00 00 00       	mov    $0x28,%esi
  f2:	ff 15 00 00 00 00    	call   *0x0(%rip)        # f8 <verigmp::pow2::add_mod_assign+0xf8>
			f4: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp4pow214sub_mod_assign:

0000000000000000 <verigmp::pow2::sub_mod_assign>:
   0:	53                   	push   %rbx
   1:	48 85 f6             	test   %rsi,%rsi
   4:	0f 84 ca 00 00 00    	je     d4 <verigmp::pow2::sub_mod_assign+0xd4>
   a:	41 8d 40 ff          	lea    -0x1(%r8),%eax
   e:	83 f8 40             	cmp    $0x40,%eax
  11:	0f 83 a4 00 00 00    	jae    bb <verigmp::pow2::sub_mod_assign+0xbb>
  17:	48 39 ce             	cmp    %rcx,%rsi
  1a:	0f 85 cd 00 00 00    	jne    ed <verigmp::pow2::sub_mod_assign+0xed>
  20:	48 83 fe 01          	cmp    $0x1,%rsi
  24:	75 07                	jne    2d <verigmp::pow2::sub_mod_assign+0x2d>
  26:	45 31 c9             	xor    %r9d,%r9d
  29:	31 c0                	xor    %eax,%eax
  2b:	eb 60                	jmp    8d <verigmp::pow2::sub_mod_assign+0x8d>
  2d:	48 b9 fe ff ff ff ff 	movabs $0xffffffffffffffe,%rcx
  34:	ff ff 0f 
  37:	48 21 f1             	and    %rsi,%rcx
  3a:	45 31 c9             	xor    %r9d,%r9d
  3d:	31 c0                	xor    %eax,%eax
  3f:	90                   	nop
  40:	4c 8b 14 c7          	mov    (%rdi,%rax,8),%r10
  44:	4c 8b 5c c7 08       	mov    0x8(%rdi,%rax,8),%r11
  49:	4c 2b 14 c2          	sub    (%rdx,%rax,8),%r10
  4d:	0f 92 c3             	setb   %bl
  50:	4d 29 ca             	sub    %r9,%r10
  53:	41 0f 92 c1          	setb   %r9b
  57:	41 08 d9             	or     %bl,%r9b
  5a:	45 0f b6 c9          	movzbl %r9b,%r9d
  5e:	4c 89 14 c7          	mov    %r10,(%rdi,%rax,8)
  62:	4c 2b 5c c2 08       	sub    0x8(%rdx,%rax,8),%r11
  67:	41 0f 92 c2          	setb   %r10b
  6b:	4d 29 cb             	sub    %r9,%r11
  6e:	41 0f 92 c1          	setb   %r9b
  72:	45 08 d1             	or     %r10b,%r9b
  75:	45 0f b6 c9          	movzbl %r9b,%r9d
  79:	4c 89 5c c7 08       	mov    %r11,0x8(%rdi,%rax,8)
  7e:	48 83 c0 02          	add    $0x2,%rax
  82:	48 39 c1             	cmp    %rax,%rcx
  85:	75 b9                	jne    40 <verigmp::pow2::sub_mod_assign+0x40>
  87:	40 f6 c6 01          	test   $0x1,%sil
  8b:	74 08                	je     95 <verigmp::pow2::sub_mod_assign+0x95>
  8d:	4c 03 0c c2          	add    (%rdx,%rax,8),%r9
  91:	4c 29 0c c7          	sub    %r9,(%rdi,%rax,8)
  95:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  9c:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  a3:	44 89 c1             	mov    %r8d,%ecx
  a6:	48 d3 e2             	shl    %cl,%rdx
  a9:	41 83 f8 40          	cmp    $0x40,%r8d
  ad:	48 f7 d2             	not    %rdx
  b0:	48 0f 44 d0          	cmove  %rax,%rdx
  b4:	48 21 54 f7 f8       	and    %rdx,-0x8(%rdi,%rsi,8)
  b9:	5b                   	pop    %rbx
  ba:	c3                   	ret
  bb:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # c2 <verigmp::pow2::sub_mod_assign+0xc2>
			be: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.1-0x4
  c2:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # c9 <verigmp::pow2::sub_mod_assign+0xc9>
			c5: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.209-0x4
  c9:	be 27 00 00 00       	mov    $0x27,%esi
  ce:	ff 15 00 00 00 00    	call   *0x0(%rip)        # d4 <verigmp::pow2::sub_mod_assign+0xd4>
			d0: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  d4:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # db <verigmp::pow2::sub_mod_assign+0xdb>
			d7: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.203-0x4
  db:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # e2 <verigmp::pow2::sub_mod_assign+0xe2>
			de: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.208-0x4
  e2:	be 1f 00 00 00       	mov    $0x1f,%esi
  e7:	ff 15 00 00 00 00    	call   *0x0(%rip)        # ed <verigmp::pow2::sub_mod_assign+0xed>
			e9: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  ed:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # f4 <verigmp::pow2::sub_mod_assign+0xf4>
			f0: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.13-0x4
  f4:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # fb <verigmp::pow2::sub_mod_assign+0xfb>
			f7: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.227-0x4
  fb:	be 28 00 00 00       	mov    $0x28,%esi
 100:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 106 <verigmp::pow2::sub_mod_assign+0x106>
			102: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp4pow216precision_layout:

0000000000000000 <verigmp::pow2::precision_layout>:
   0:	48 85 ff             	test   %rdi,%rdi
   3:	74 15                	je     1a <verigmp::pow2::precision_layout+0x1a>
   5:	48 ff cf             	dec    %rdi
   8:	48 89 f8             	mov    %rdi,%rax
   b:	48 c1 e8 06          	shr    $0x6,%rax
   f:	48 ff c0             	inc    %rax
  12:	83 e7 3f             	and    $0x3f,%edi
  15:	ff c7                	inc    %edi
  17:	89 fa                	mov    %edi,%edx
  19:	c3                   	ret
  1a:	50                   	push   %rax
  1b:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 22 <verigmp::pow2::precision_layout+0x22>
			1e: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.210-0x4
  22:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 29 <verigmp::pow2::precision_layout+0x29>
			25: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.211-0x4
  29:	be 1a 00 00 00       	mov    $0x1a,%esi
  2e:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 34 <verigmp::pow2::precision_layout+0x34>
			30: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp4pow29mask_word:

0000000000000000 <verigmp::pow2::mask_word>:
   0:	8d 46 ff             	lea    -0x1(%rsi),%eax
   3:	83 f8 40             	cmp    $0x40,%eax
   6:	73 21                	jae    29 <verigmp::pow2::mask_word+0x29>
   8:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
   f:	89 f1                	mov    %esi,%ecx
  11:	48 d3 e0             	shl    %cl,%rax
  14:	48 c7 c1 ff ff ff ff 	mov    $0xffffffffffffffff,%rcx
  1b:	83 fe 40             	cmp    $0x40,%esi
  1e:	48 f7 d0             	not    %rax
  21:	48 0f 44 c1          	cmove  %rcx,%rax
  25:	48 21 f8             	and    %rdi,%rax
  28:	c3                   	ret
  29:	50                   	push   %rax
  2a:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 31 <verigmp::pow2::mask_word+0x31>
			2d: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.212-0x4
  31:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 38 <verigmp::pow2::mask_word+0x38>
			34: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.213-0x4
  38:	be 29 00 00 00       	mov    $0x29,%esi
  3d:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 43 <verigmp::pow2::mask_word+0x43>
			3f: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp4toom12monomial_mul:

0000000000000000 <verigmp::toom::monomial_mul>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom::monomial_mul+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom::monomial_mul+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.215-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom::monomial_mul+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp4toom13interpolation:

0000000000000000 <verigmp::toom::interpolation>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom::interpolation+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom::interpolation+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.216-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom::interpolation+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp4toom14triple_product:

0000000000000000 <verigmp::toom::triple_product>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom::triple_product+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom::triple_product+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.217-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom::triple_product+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp4toom17evaluation_bounds:

0000000000000000 <verigmp::toom::evaluation_bounds>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom::evaluation_bounds+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom::evaluation_bounds+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.218-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom::evaluation_bounds+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp4toom18coefficient_bounds:

0000000000000000 <verigmp::toom::coefficient_bounds>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom::coefficient_bounds+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom::coefficient_bounds+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.219-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom::coefficient_bounds+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp4toom2c1:

0000000000000000 <verigmp::toom::c1>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom::c1+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom::c1+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.220-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom::c1+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp4toom2c2:

0000000000000000 <verigmp::toom::c2>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom::c2+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom::c2+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.221-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom::c2+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp4toom2c3:

0000000000000000 <verigmp::toom::c3>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom::c3+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom::c3+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.222-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom::c3+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp4toom4eval:

0000000000000000 <verigmp::toom::eval>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom::eval+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom::eval+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.223-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom::eval+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp4toom9recompose:

0000000000000000 <verigmp::toom::recompose>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::toom::recompose+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::toom::recompose+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.224-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::toom::recompose+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp5limbs10add_assign:

0000000000000000 <verigmp::limbs::add_assign>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	0f 85 7c 00 00 00    	jne    85 <verigmp::limbs::add_assign+0x85>
   9:	48 85 f6             	test   %rsi,%rsi
   c:	74 0c                	je     1a <verigmp::limbs::add_assign+0x1a>
   e:	48 83 fe 01          	cmp    $0x1,%rsi
  12:	75 09                	jne    1d <verigmp::limbs::add_assign+0x1d>
  14:	31 c0                	xor    %eax,%eax
  16:	31 c9                	xor    %ecx,%ecx
  18:	eb 51                	jmp    6b <verigmp::limbs::add_assign+0x6b>
  1a:	31 c0                	xor    %eax,%eax
  1c:	c3                   	ret
  1d:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  24:	ff ff 0f 
  27:	49 21 f0             	and    %rsi,%r8
  2a:	31 c0                	xor    %eax,%eax
  2c:	31 c9                	xor    %ecx,%ecx
  2e:	66 90                	xchg   %ax,%ax
  30:	45 31 c9             	xor    %r9d,%r9d
  33:	48 03 04 cf          	add    (%rdi,%rcx,8),%rax
  37:	41 0f 92 c1          	setb   %r9b
  3b:	48 03 04 ca          	add    (%rdx,%rcx,8),%rax
  3f:	48 89 04 cf          	mov    %rax,(%rdi,%rcx,8)
  43:	4c 13 4c cf 08       	adc    0x8(%rdi,%rcx,8),%r9
  48:	0f 92 c0             	setb   %al
  4b:	0f b6 c0             	movzbl %al,%eax
  4e:	4c 03 4c ca 08       	add    0x8(%rdx,%rcx,8),%r9
  53:	48 83 d0 00          	adc    $0x0,%rax
  57:	4c 89 4c cf 08       	mov    %r9,0x8(%rdi,%rcx,8)
  5c:	48 83 c1 02          	add    $0x2,%rcx
  60:	49 39 c8             	cmp    %rcx,%r8
  63:	75 cb                	jne    30 <verigmp::limbs::add_assign+0x30>
  65:	40 f6 c6 01          	test   $0x1,%sil
  69:	74 19                	je     84 <verigmp::limbs::add_assign+0x84>
  6b:	31 f6                	xor    %esi,%esi
  6d:	48 03 04 cf          	add    (%rdi,%rcx,8),%rax
  71:	40 0f 92 c6          	setb   %sil
  75:	48 03 04 ca          	add    (%rdx,%rcx,8),%rax
  79:	48 83 d6 00          	adc    $0x0,%rsi
  7d:	48 89 04 cf          	mov    %rax,(%rdi,%rcx,8)
  81:	48 89 f0             	mov    %rsi,%rax
  84:	c3                   	ret
  85:	50                   	push   %rax
  86:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8d <verigmp::limbs::add_assign+0x8d>
			89: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.13-0x4
  8d:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 94 <verigmp::limbs::add_assign+0x94>
			90: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.226-0x4
  94:	be 28 00 00 00       	mov    $0x28,%esi
  99:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 9f <verigmp::limbs::add_assign+0x9f>
			9b: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp5limbs10sub_assign:

0000000000000000 <verigmp::limbs::sub_assign>:
   0:	48 39 ce             	cmp    %rcx,%rsi
   3:	0f 85 8c 00 00 00    	jne    95 <verigmp::limbs::sub_assign+0x95>
   9:	48 85 f6             	test   %rsi,%rsi
   c:	74 0c                	je     1a <verigmp::limbs::sub_assign+0x1a>
   e:	48 83 fe 01          	cmp    $0x1,%rsi
  12:	75 09                	jne    1d <verigmp::limbs::sub_assign+0x1d>
  14:	31 c0                	xor    %eax,%eax
  16:	31 c9                	xor    %ecx,%ecx
  18:	eb 60                	jmp    7a <verigmp::limbs::sub_assign+0x7a>
  1a:	31 c0                	xor    %eax,%eax
  1c:	c3                   	ret
  1d:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  24:	ff ff 0f 
  27:	49 21 f0             	and    %rsi,%r8
  2a:	31 c0                	xor    %eax,%eax
  2c:	31 c9                	xor    %ecx,%ecx
  2e:	66 90                	xchg   %ax,%ax
  30:	4c 8b 0c cf          	mov    (%rdi,%rcx,8),%r9
  34:	4c 8b 54 cf 08       	mov    0x8(%rdi,%rcx,8),%r10
  39:	4c 2b 0c ca          	sub    (%rdx,%rcx,8),%r9
  3d:	41 0f 92 c3          	setb   %r11b
  41:	49 29 c1             	sub    %rax,%r9
  44:	0f 92 c0             	setb   %al
  47:	44 08 d8             	or     %r11b,%al
  4a:	0f b6 c0             	movzbl %al,%eax
  4d:	4c 89 0c cf          	mov    %r9,(%rdi,%rcx,8)
  51:	4c 2b 54 ca 08       	sub    0x8(%rdx,%rcx,8),%r10
  56:	41 0f 92 c1          	setb   %r9b
  5a:	49 29 c2             	sub    %rax,%r10
  5d:	0f 92 c0             	setb   %al
  60:	44 08 c8             	or     %r9b,%al
  63:	0f b6 c0             	movzbl %al,%eax
  66:	4c 89 54 cf 08       	mov    %r10,0x8(%rdi,%rcx,8)
  6b:	48 83 c1 02          	add    $0x2,%rcx
  6f:	49 39 c8             	cmp    %rcx,%r8
  72:	75 bc                	jne    30 <verigmp::limbs::sub_assign+0x30>
  74:	40 f6 c6 01          	test   $0x1,%sil
  78:	74 1a                	je     94 <verigmp::limbs::sub_assign+0x94>
  7a:	48 8b 34 cf          	mov    (%rdi,%rcx,8),%rsi
  7e:	48 2b 34 ca          	sub    (%rdx,%rcx,8),%rsi
  82:	0f 92 c2             	setb   %dl
  85:	48 29 c6             	sub    %rax,%rsi
  88:	0f 92 c0             	setb   %al
  8b:	08 d0                	or     %dl,%al
  8d:	0f b6 c0             	movzbl %al,%eax
  90:	48 89 34 cf          	mov    %rsi,(%rdi,%rcx,8)
  94:	c3                   	ret
  95:	50                   	push   %rax
  96:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 9d <verigmp::limbs::sub_assign+0x9d>
			99: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.13-0x4
  9d:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # a4 <verigmp::limbs::sub_assign+0xa4>
			a0: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.227-0x4
  a4:	be 28 00 00 00       	mov    $0x28,%esi
  a9:	ff 15 00 00 00 00    	call   *0x0(%rip)        # af <verigmp::limbs::sub_assign+0xaf>
			ab: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp5radix12equal_prefix:

0000000000000000 <verigmp::radix::equal_prefix>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::radix::equal_prefix+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::radix::equal_prefix+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.229-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::radix::equal_prefix+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp5radix12prefix_range:

0000000000000000 <verigmp::radix::prefix_range>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::radix::prefix_range+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::radix::prefix_range+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.230-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::radix::prefix_range+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp5radix14radix_positive:

0000000000000000 <verigmp::radix::radix_positive>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::radix::radix_positive+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::radix::radix_positive+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.231-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::radix::radix_positive+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp5radix21radix_is_power_of_two:

0000000000000000 <verigmp::radix::radix_is_power_of_two>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::radix::radix_is_power_of_two+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::radix::radix_is_power_of_two+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.232-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::radix::radix_is_power_of_two+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp5radix4base:

0000000000000000 <verigmp::radix::base>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::radix::base+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::radix::base+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.233-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::radix::base+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp5radix5radix:

0000000000000000 <verigmp::radix::radix>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::radix::radix+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::radix::radix+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.234-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::radix::radix+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp5radix5value:

0000000000000000 <verigmp::radix::value>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::radix::value+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::radix::value+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.235-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::radix::value+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp5radix6prefix:

0000000000000000 <verigmp::radix::prefix>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::radix::prefix+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::radix::prefix+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.236-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::radix::prefix+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp6square4full:

0000000000000000 <verigmp::square::full>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	48 83 ec 48          	sub    $0x48,%rsp
   e:	48 85 c9             	test   %rcx,%rcx
  11:	0f 84 78 02 00 00    	je     28f <verigmp::square::full+0x28f>
  17:	49 89 cf             	mov    %rcx,%r15
  1a:	48 8d 04 09          	lea    (%rcx,%rcx,1),%rax
  1e:	48 39 c6             	cmp    %rax,%rsi
  21:	0f 85 4f 02 00 00    	jne    276 <verigmp::square::full+0x276>
  27:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
  2b:	49 39 c1             	cmp    %rax,%r9
  2e:	0f 82 42 02 00 00    	jb     276 <verigmp::square::full+0x276>
  34:	48 8b ac 24 80 00 00 	mov    0x80(%rsp),%rbp
  3b:	00 
  3c:	48 83 fd 07          	cmp    $0x7,%rbp
  40:	0f 86 62 02 00 00    	jbe    2a8 <verigmp::square::full+0x2a8>
  46:	49 39 ef             	cmp    %rbp,%r15
  49:	0f 86 ed 01 00 00    	jbe    23c <verigmp::square::full+0x23c>
  4f:	4c 89 f8             	mov    %r15,%rax
  52:	48 d1 e8             	shr    $1,%rax
  55:	4d 89 fc             	mov    %r15,%r12
  58:	49 29 c4             	sub    %rax,%r12
  5b:	49 89 f5             	mov    %rsi,%r13
  5e:	4d 29 e5             	sub    %r12,%r13
  61:	0f 82 5a 02 00 00    	jb     2c1 <verigmp::square::full+0x2c1>
  67:	4c 89 c3             	mov    %r8,%rbx
  6a:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
  6f:	4e 8d 04 e2          	lea    (%rdx,%r12,8),%r8
  73:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  78:	4c 89 e6             	mov    %r12,%rsi
  7b:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  80:	4c 89 e1             	mov    %r12,%rcx
  83:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
  88:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  8d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  92:	49 89 c1             	mov    %rax,%r9
  95:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 9b <verigmp::square::full+0x9b>
			97: R_X86_64_GOTPCREL	verigmp::fast_words::abs_difference-0x4
  9b:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  a0:	4f 8d 34 24          	lea    (%r12,%r12,1),%r14
  a4:	4c 29 f0             	sub    %r14,%rax
  a7:	0f 82 29 02 00 00    	jb     2d6 <verigmp::square::full+0x2d6>
  ad:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  b2:	4e 8d 04 f3          	lea    (%rbx,%r14,8),%r8
  b6:	48 89 2c 24          	mov    %rbp,(%rsp)
  ba:	48 89 df             	mov    %rbx,%rdi
  bd:	4c 89 f6             	mov    %r14,%rsi
  c0:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  c5:	4c 89 e1             	mov    %r12,%rcx
  c8:	49 89 c1             	mov    %rax,%r9
  cb:	49 89 c5             	mov    %rax,%r13
  ce:	ff 15 00 00 00 00    	call   *0x0(%rip)        # d4 <verigmp::square::full+0xd4>
			d0: R_X86_64_GOTPCREL	verigmp::square::full-0x4
  d4:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  d9:	48 89 d0             	mov    %rdx,%rax
  dc:	4c 29 f0             	sub    %r14,%rax
  df:	0f 82 0a 02 00 00    	jb     2ef <verigmp::square::full+0x2ef>
  e5:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  ea:	4a 8d 3c f1          	lea    (%rcx,%r14,8),%rdi
  ee:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  f3:	48 89 2c 24          	mov    %rbp,(%rsp)
  f7:	48 89 c6             	mov    %rax,%rsi
  fa:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  ff:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
 104:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
 109:	4e 8d 04 f3          	lea    (%rbx,%r14,8),%r8
 10d:	4d 89 e9             	mov    %r13,%r9
 110:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 116 <verigmp::square::full+0x116>
			112: R_X86_64_GOTPCREL	verigmp::square::full-0x4
 116:	48 89 2c 24          	mov    %rbp,(%rsp)
 11a:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
 11f:	48 89 ef             	mov    %rbp,%rdi
 122:	4c 89 f6             	mov    %r14,%rsi
 125:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
 12a:	4c 89 e1             	mov    %r12,%rcx
 12d:	4e 8d 04 f3          	lea    (%rbx,%r14,8),%r8
 131:	4d 89 e9             	mov    %r13,%r9
 134:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 13a <verigmp::square::full+0x13a>
			136: R_X86_64_GOTPCREL	verigmp::square::full-0x4
 13a:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
 141:	48 89 df             	mov    %rbx,%rdi
 144:	4c 89 f6             	mov    %r14,%rsi
 147:	48 89 ea             	mov    %rbp,%rdx
 14a:	4c 89 f1             	mov    %r14,%rcx
 14d:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
 152:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
 157:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 15d <verigmp::square::full+0x15d>
			159: R_X86_64_GOTPCREL	verigmp::fast_words::combine_cross-0x4
 15d:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
 162:	4d 39 f1             	cmp    %r14,%r9
 165:	0f 82 97 01 00 00    	jb     302 <verigmp::square::full+0x302>
 16b:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
 170:	4a 8d 14 e1          	lea    (%rcx,%r12,8),%rdx
 174:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
 179:	48 c1 e6 03          	shl    $0x3,%rsi
 17d:	4a 8d 0c f9          	lea    (%rcx,%r15,8),%rcx
 181:	48 29 f1             	sub    %rsi,%rcx
 184:	48 83 c1 08          	add    $0x8,%rcx
 188:	31 f6                	xor    %esi,%esi
 18a:	31 ff                	xor    %edi,%edi
 18c:	0f 1f 40 00          	nopl   0x0(%rax)
 190:	45 31 c0             	xor    %r8d,%r8d
 193:	48 03 74 f9 f8       	add    -0x8(%rcx,%rdi,8),%rsi
 198:	41 0f 92 c0          	setb   %r8b
 19c:	48 03 34 fb          	add    (%rbx,%rdi,8),%rsi
 1a0:	48 89 74 f9 f8       	mov    %rsi,-0x8(%rcx,%rdi,8)
 1a5:	4c 13 04 f9          	adc    (%rcx,%rdi,8),%r8
 1a9:	40 0f 92 c6          	setb   %sil
 1ad:	40 0f b6 f6          	movzbl %sil,%esi
 1b1:	4c 03 44 fb 08       	add    0x8(%rbx,%rdi,8),%r8
 1b6:	48 83 d6 00          	adc    $0x0,%rsi
 1ba:	4c 89 04 f9          	mov    %r8,(%rcx,%rdi,8)
 1be:	48 83 c7 02          	add    $0x2,%rdi
 1c2:	49 39 fe             	cmp    %rdi,%r14
 1c5:	75 c9                	jne    190 <verigmp::square::full+0x190>
 1c7:	4c 89 c9             	mov    %r9,%rcx
 1ca:	4a 8d 14 f2          	lea    (%rdx,%r14,8),%rdx
 1ce:	4c 29 f1             	sub    %r14,%rcx
 1d1:	74 2c                	je     1ff <verigmp::square::full+0x1ff>
 1d3:	48 85 f6             	test   %rsi,%rsi
 1d6:	74 27                	je     1ff <verigmp::square::full+0x1ff>
 1d8:	bf 01 00 00 00       	mov    $0x1,%edi
 1dd:	0f 1f 00             	nopl   (%rax)
 1e0:	45 31 c0             	xor    %r8d,%r8d
 1e3:	48 01 74 fa f8       	add    %rsi,-0x8(%rdx,%rdi,8)
 1e8:	40 0f 92 c6          	setb   %sil
 1ec:	48 39 cf             	cmp    %rcx,%rdi
 1ef:	73 0e                	jae    1ff <verigmp::square::full+0x1ff>
 1f1:	41 88 f0             	mov    %sil,%r8b
 1f4:	48 ff c7             	inc    %rdi
 1f7:	4c 89 c6             	mov    %r8,%rsi
 1fa:	45 84 c0             	test   %r8b,%r8b
 1fd:	75 e1                	jne    1e0 <verigmp::square::full+0x1e0>
 1ff:	4d 39 f1             	cmp    %r14,%r9
 202:	74 29                	je     22d <verigmp::square::full+0x22d>
 204:	48 85 c0             	test   %rax,%rax
 207:	74 24                	je     22d <verigmp::square::full+0x22d>
 209:	be 01 00 00 00       	mov    $0x1,%esi
 20e:	66 90                	xchg   %ax,%ax
 210:	31 ff                	xor    %edi,%edi
 212:	48 01 44 f2 f8       	add    %rax,-0x8(%rdx,%rsi,8)
 217:	0f 92 c0             	setb   %al
 21a:	48 39 ce             	cmp    %rcx,%rsi
 21d:	73 0e                	jae    22d <verigmp::square::full+0x22d>
 21f:	40 88 c7             	mov    %al,%dil
 222:	48 ff c6             	inc    %rsi
 225:	48 89 f8             	mov    %rdi,%rax
 228:	40 84 ff             	test   %dil,%dil
 22b:	75 e3                	jne    210 <verigmp::square::full+0x210>
 22d:	48 83 c4 48          	add    $0x48,%rsp
 231:	5b                   	pop    %rbx
 232:	41 5c                	pop    %r12
 234:	41 5d                	pop    %r13
 236:	41 5e                	pop    %r14
 238:	41 5f                	pop    %r15
 23a:	5d                   	pop    %rbp
 23b:	c3                   	ret
 23c:	49 83 ff 08          	cmp    $0x8,%r15
 240:	73 1d                	jae    25f <verigmp::square::full+0x25f>
 242:	4c 89 f9             	mov    %r15,%rcx
 245:	49 89 d0             	mov    %rdx,%r8
 248:	4d 89 f9             	mov    %r15,%r9
 24b:	48 83 c4 48          	add    $0x48,%rsp
 24f:	5b                   	pop    %rbx
 250:	41 5c                	pop    %r12
 252:	41 5d                	pop    %r13
 254:	41 5e                	pop    %r14
 256:	41 5f                	pop    %r15
 258:	5d                   	pop    %rbp
 259:	ff 25 00 00 00 00    	jmp    *0x0(%rip)        # 25f <verigmp::square::full+0x25f>
			25b: R_X86_64_GOTPCREL	verigmp::fast_multiply::base_full-0x4
 25f:	4c 89 f9             	mov    %r15,%rcx
 262:	48 83 c4 48          	add    $0x48,%rsp
 266:	5b                   	pop    %rbx
 267:	41 5c                	pop    %r12
 269:	41 5d                	pop    %r13
 26b:	41 5e                	pop    %r14
 26d:	41 5f                	pop    %r15
 26f:	5d                   	pop    %rbp
 270:	ff 25 00 00 00 00    	jmp    *0x0(%rip)        # 276 <verigmp::square::full+0x276>
			272: R_X86_64_GOTPCREL	verigmp::square_base::full-0x4
 276:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 27d <verigmp::square::full+0x27d>
			279: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.85-0x4
 27d:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 284 <verigmp::square::full+0x284>
			280: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.239-0x4
 284:	be 4a 00 00 00       	mov    $0x4a,%esi
 289:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 28f <verigmp::square::full+0x28f>
			28b: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 28f:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 296 <verigmp::square::full+0x296>
			292: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.18-0x4
 296:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 29d <verigmp::square::full+0x29d>
			299: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.238-0x4
 29d:	be 33 00 00 00       	mov    $0x33,%esi
 2a2:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2a8 <verigmp::square::full+0x2a8>
			2a4: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 2a8:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 2af <verigmp::square::full+0x2af>
			2ab: R_X86_64_PC32	.Lanon.d1b2563b732ee79941e9b189853f7bd7.87-0x4
 2af:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 2b6 <verigmp::square::full+0x2b6>
			2b2: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.240-0x4
 2b6:	be 20 00 00 00       	mov    $0x20,%esi
 2bb:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2c1 <verigmp::square::full+0x2c1>
			2bd: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 2c1:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 2c8 <verigmp::square::full+0x2c8>
			2c4: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.243-0x4
 2c8:	31 ff                	xor    %edi,%edi
 2ca:	48 89 f2             	mov    %rsi,%rdx
 2cd:	4c 89 e6             	mov    %r12,%rsi
 2d0:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2d6 <verigmp::square::full+0x2d6>
			2d2: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 2d6:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 2dd <verigmp::square::full+0x2dd>
			2d9: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.0-0x4
 2dd:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 2e4 <verigmp::square::full+0x2e4>
			2e0: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.241-0x4
 2e4:	be 13 00 00 00       	mov    $0x13,%esi
 2e9:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2ef <verigmp::square::full+0x2ef>
			2eb: R_X86_64_GOTPCREL	core::panicking::panic_fmt-0x4
 2ef:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 2f6 <verigmp::square::full+0x2f6>
			2f2: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.242-0x4
 2f6:	4c 89 f7             	mov    %r14,%rdi
 2f9:	48 89 d6             	mov    %rdx,%rsi
 2fc:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 302 <verigmp::square::full+0x302>
			2fe: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 302:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 309 <verigmp::square::full+0x309>
			305: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.7-0x4
 309:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 310 <verigmp::square::full+0x310>
			30c: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.17-0x4
 310:	be 28 00 00 00       	mov    $0x28,%esi
 315:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 31b <verigmp::square::full+0x31b>
			317: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp7product11split_value:

0000000000000000 <verigmp::product::split_value>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::product::split_value+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::product::split_value+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.245-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::product::split_value+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp7product14subrange_value:

0000000000000000 <verigmp::product::subrange_value>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::product::subrange_value+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::product::subrange_value+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.246-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::product::subrange_value+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp7product15mac_prefix_step:

0000000000000000 <verigmp::product::mac_prefix_step>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::product::mac_prefix_step+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::product::mac_prefix_step+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.247-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::product::mac_prefix_step+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp7product4tail:

0000000000000000 <verigmp::product::tail>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::product::tail+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::product::tail+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.248-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::product::tail+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp7product9radix_add:

0000000000000000 <verigmp::product::radix_add>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::product::radix_add+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::product::radix_add+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.249-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::product::radix_add+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp8multiply10add_mul_at:

0000000000000000 <verigmp::multiply::add_mul_at>:
   0:	41 57                	push   %r15
   2:	41 56                	push   %r14
   4:	53                   	push   %rbx
   5:	48 39 ce             	cmp    %rcx,%rsi
   8:	0f 85 a5 00 00 00    	jne    b3 <verigmp::multiply::add_mul_at+0xb3>
   e:	48 89 f1             	mov    %rsi,%rcx
  11:	4c 29 c9             	sub    %r9,%rcx
  14:	0f 82 b2 00 00 00    	jb     cc <verigmp::multiply::add_mul_at+0xcc>
  1a:	0f 84 8d 00 00 00    	je     ad <verigmp::multiply::add_mul_at+0xad>
  20:	49 89 d2             	mov    %rdx,%r10
  23:	49 8d 41 01          	lea    0x1(%r9),%rax
  27:	48 39 c6             	cmp    %rax,%rsi
  2a:	75 07                	jne    33 <verigmp::multiply::add_mul_at+0x33>
  2c:	45 31 db             	xor    %r11d,%r11d
  2f:	31 f6                	xor    %esi,%esi
  31:	eb 66                	jmp    99 <verigmp::multiply::add_mul_at+0x99>
  33:	48 bb fe ff ff ff ff 	movabs $0xffffffffffffffe,%rbx
  3a:	ff ff 0f 
  3d:	48 21 cb             	and    %rcx,%rbx
  40:	4e 8d 34 cf          	lea    (%rdi,%r9,8),%r14
  44:	49 83 c6 08          	add    $0x8,%r14
  48:	45 31 db             	xor    %r11d,%r11d
  4b:	31 f6                	xor    %esi,%esi
  4d:	0f 1f 00             	nopl   (%rax)
  50:	4c 89 c0             	mov    %r8,%rax
  53:	49 f7 24 f2          	mulq   (%r10,%rsi,8)
  57:	45 31 ff             	xor    %r15d,%r15d
  5a:	4d 03 5c f6 f8       	add    -0x8(%r14,%rsi,8),%r11
  5f:	41 0f 92 c7          	setb   %r15b
  63:	49 01 c3             	add    %rax,%r11
  66:	49 11 d7             	adc    %rdx,%r15
  69:	4d 89 5c f6 f8       	mov    %r11,-0x8(%r14,%rsi,8)
  6e:	4c 89 c0             	mov    %r8,%rax
  71:	49 f7 64 f2 08       	mulq   0x8(%r10,%rsi,8)
  76:	45 31 db             	xor    %r11d,%r11d
  79:	4d 03 3c f6          	add    (%r14,%rsi,8),%r15
  7d:	41 0f 92 c3          	setb   %r11b
  81:	49 01 c7             	add    %rax,%r15
  84:	49 11 d3             	adc    %rdx,%r11
  87:	4d 89 3c f6          	mov    %r15,(%r14,%rsi,8)
  8b:	48 83 c6 02          	add    $0x2,%rsi
  8f:	48 39 f3             	cmp    %rsi,%rbx
  92:	75 bc                	jne    50 <verigmp::multiply::add_mul_at+0x50>
  94:	f6 c1 01             	test   $0x1,%cl
  97:	74 14                	je     ad <verigmp::multiply::add_mul_at+0xad>
  99:	4a 8d 04 cf          	lea    (%rdi,%r9,8),%rax
  9d:	4d 0f af 04 f2       	imul   (%r10,%rsi,8),%r8
  a2:	4c 03 1c f0          	add    (%rax,%rsi,8),%r11
  a6:	4d 01 c3             	add    %r8,%r11
  a9:	4c 89 1c f0          	mov    %r11,(%rax,%rsi,8)
  ad:	5b                   	pop    %rbx
  ae:	41 5e                	pop    %r14
  b0:	41 5f                	pop    %r15
  b2:	c3                   	ret
  b3:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # ba <verigmp::multiply::add_mul_at+0xba>
			b6: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.13-0x4
  ba:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # c1 <verigmp::multiply::add_mul_at+0xc1>
			bd: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.251-0x4
  c1:	be 28 00 00 00       	mov    $0x28,%esi
  c6:	ff 15 00 00 00 00    	call   *0x0(%rip)        # cc <verigmp::multiply::add_mul_at+0xcc>
			c8: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  cc:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # d3 <verigmp::multiply::add_mul_at+0xd3>
			cf: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.28-0x4
  d3:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # da <verigmp::multiply::add_mul_at+0xda>
			d6: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.252-0x4
  da:	be 25 00 00 00       	mov    $0x25,%esi
  df:	ff 15 00 00 00 00    	call   *0x0(%rip)        # e5 <verigmp::multiply::add_mul_at+0xe5>
			e1: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp8multiply12add_mul_word:

0000000000000000 <verigmp::multiply::add_mul_word>:
   0:	53                   	push   %rbx
   1:	48 39 ce             	cmp    %rcx,%rsi
   4:	0f 87 9f 00 00 00    	ja     a9 <verigmp::multiply::add_mul_word+0xa9>
   a:	48 85 f6             	test   %rsi,%rsi
   d:	74 10                	je     1f <verigmp::multiply::add_mul_word+0x1f>
   f:	49 89 d1             	mov    %rdx,%r9
  12:	48 83 fe 01          	cmp    $0x1,%rsi
  16:	75 0e                	jne    26 <verigmp::multiply::add_mul_word+0x26>
  18:	31 c9                	xor    %ecx,%ecx
  1a:	45 31 d2             	xor    %r10d,%r10d
  1d:	eb 67                	jmp    86 <verigmp::multiply::add_mul_word+0x86>
  1f:	31 c9                	xor    %ecx,%ecx
  21:	48 89 c8             	mov    %rcx,%rax
  24:	5b                   	pop    %rbx
  25:	c3                   	ret
  26:	49 bb fe ff ff ff ff 	movabs $0xffffffffffffffe,%r11
  2d:	ff ff 0f 
  30:	49 21 f3             	and    %rsi,%r11
  33:	31 c9                	xor    %ecx,%ecx
  35:	45 31 d2             	xor    %r10d,%r10d
  38:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  3f:	00 
  40:	4c 89 c0             	mov    %r8,%rax
  43:	4b f7 24 d1          	mulq   (%r9,%r10,8)
  47:	31 db                	xor    %ebx,%ebx
  49:	4a 03 0c d7          	add    (%rdi,%r10,8),%rcx
  4d:	0f 92 c3             	setb   %bl
  50:	48 01 c1             	add    %rax,%rcx
  53:	48 11 d3             	adc    %rdx,%rbx
  56:	4a 89 0c d7          	mov    %rcx,(%rdi,%r10,8)
  5a:	4c 89 c0             	mov    %r8,%rax
  5d:	4b f7 64 d1 08       	mulq   0x8(%r9,%r10,8)
  62:	31 c9                	xor    %ecx,%ecx
  64:	4a 03 5c d7 08       	add    0x8(%rdi,%r10,8),%rbx
  69:	0f 92 c1             	setb   %cl
  6c:	48 01 c3             	add    %rax,%rbx
  6f:	48 11 d1             	adc    %rdx,%rcx
  72:	4a 89 5c d7 08       	mov    %rbx,0x8(%rdi,%r10,8)
  77:	49 83 c2 02          	add    $0x2,%r10
  7b:	4d 39 d3             	cmp    %r10,%r11
  7e:	75 c0                	jne    40 <verigmp::multiply::add_mul_word+0x40>
  80:	40 f6 c6 01          	test   $0x1,%sil
  84:	74 9b                	je     21 <verigmp::multiply::add_mul_word+0x21>
  86:	4c 89 c0             	mov    %r8,%rax
  89:	4b f7 24 d1          	mulq   (%r9,%r10,8)
  8d:	31 f6                	xor    %esi,%esi
  8f:	4a 03 0c d7          	add    (%rdi,%r10,8),%rcx
  93:	40 0f 92 c6          	setb   %sil
  97:	48 01 c1             	add    %rax,%rcx
  9a:	48 11 d6             	adc    %rdx,%rsi
  9d:	4a 89 0c d7          	mov    %rcx,(%rdi,%r10,8)
  a1:	48 89 f1             	mov    %rsi,%rcx
  a4:	48 89 c8             	mov    %rcx,%rax
  a7:	5b                   	pop    %rbx
  a8:	c3                   	ret
  a9:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # b0 <verigmp::multiply::add_mul_word+0xb0>
			ac: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.194-0x4
  b0:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # b7 <verigmp::multiply::add_mul_word+0xb7>
			b3: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.253-0x4
  b7:	be 28 00 00 00       	mov    $0x28,%esi
  bc:	ff 15 00 00 00 00    	call   *0x0(%rip)        # c2 <verigmp::multiply::add_mul_word+0xc2>
			be: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp8multiply7mul_low:

0000000000000000 <verigmp::multiply::mul_low>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	50                   	push   %rax
   b:	48 89 3c 24          	mov    %rdi,(%rsp)
   f:	48 39 ce             	cmp    %rcx,%rsi
  12:	0f 85 fa 00 00 00    	jne    112 <verigmp::multiply::mul_low+0x112>
  18:	49 89 f7             	mov    %rsi,%r15
  1b:	4c 39 ce             	cmp    %r9,%rsi
  1e:	0f 85 07 01 00 00    	jne    12b <verigmp::multiply::mul_low+0x12b>
  24:	4d 85 ff             	test   %r15,%r15
  27:	0f 84 d6 00 00 00    	je     103 <verigmp::multiply::mul_low+0x103>
  2d:	4c 89 c3             	mov    %r8,%rbx
  30:	49 89 d6             	mov    %rdx,%r14
  33:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
  3a:	00 
  3b:	45 31 ed             	xor    %r13d,%r13d
  3e:	4c 8b 24 24          	mov    (%rsp),%r12
  42:	4c 89 e7             	mov    %r12,%rdi
  45:	31 f6                	xor    %esi,%esi
  47:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4d <verigmp::multiply::mul_low+0x4d>
			49: R_X86_64_GOTPCREL	memset-0x4
  4d:	49 8d 74 24 08       	lea    0x8(%r12),%rsi
  52:	4c 89 ff             	mov    %r15,%rdi
  55:	eb 36                	jmp    8d <verigmp::multiply::mul_low+0x8d>
  57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  5e:	00 00 
  60:	45 31 d2             	xor    %r10d,%r10d
  63:	45 31 c9             	xor    %r9d,%r9d
  66:	48 8b 04 24          	mov    (%rsp),%rax
  6a:	4a 8d 04 e8          	lea    (%rax,%r13,8),%rax
  6e:	4a 0f af 0c cb       	imul   (%rbx,%r9,8),%rcx
  73:	4e 03 14 c8          	add    (%rax,%r9,8),%r10
  77:	49 01 ca             	add    %rcx,%r10
  7a:	4e 89 14 c8          	mov    %r10,(%rax,%r9,8)
  7e:	48 83 c6 08          	add    $0x8,%rsi
  82:	48 ff cf             	dec    %rdi
  85:	4d 89 c5             	mov    %r8,%r13
  88:	4d 39 f8             	cmp    %r15,%r8
  8b:	74 76                	je     103 <verigmp::multiply::mul_low+0x103>
  8d:	4d 8d 45 01          	lea    0x1(%r13),%r8
  91:	4b 8b 0c ee          	mov    (%r14,%r13,8),%rcx
  95:	4d 39 c7             	cmp    %r8,%r15
  98:	74 c6                	je     60 <verigmp::multiply::mul_low+0x60>
  9a:	48 89 fd             	mov    %rdi,%rbp
  9d:	48 83 e5 fe          	and    $0xfffffffffffffffe,%rbp
  a1:	4d 89 fb             	mov    %r15,%r11
  a4:	4d 29 eb             	sub    %r13,%r11
  a7:	45 31 d2             	xor    %r10d,%r10d
  aa:	45 31 c9             	xor    %r9d,%r9d
  ad:	0f 1f 00             	nopl   (%rax)
  b0:	48 89 c8             	mov    %rcx,%rax
  b3:	4a f7 24 cb          	mulq   (%rbx,%r9,8)
  b7:	45 31 e4             	xor    %r12d,%r12d
  ba:	4e 03 54 ce f8       	add    -0x8(%rsi,%r9,8),%r10
  bf:	41 0f 92 c4          	setb   %r12b
  c3:	49 01 c2             	add    %rax,%r10
  c6:	49 11 d4             	adc    %rdx,%r12
  c9:	4e 89 54 ce f8       	mov    %r10,-0x8(%rsi,%r9,8)
  ce:	48 89 c8             	mov    %rcx,%rax
  d1:	4a f7 64 cb 08       	mulq   0x8(%rbx,%r9,8)
  d6:	45 31 d2             	xor    %r10d,%r10d
  d9:	4e 03 24 ce          	add    (%rsi,%r9,8),%r12
  dd:	41 0f 92 c2          	setb   %r10b
  e1:	49 01 c4             	add    %rax,%r12
  e4:	49 11 d2             	adc    %rdx,%r10
  e7:	4e 89 24 ce          	mov    %r12,(%rsi,%r9,8)
  eb:	49 83 c1 02          	add    $0x2,%r9
  ef:	4c 39 cd             	cmp    %r9,%rbp
  f2:	75 bc                	jne    b0 <verigmp::multiply::mul_low+0xb0>
  f4:	41 f6 c3 01          	test   $0x1,%r11b
  f8:	0f 85 68 ff ff ff    	jne    66 <verigmp::multiply::mul_low+0x66>
  fe:	e9 7b ff ff ff       	jmp    7e <verigmp::multiply::mul_low+0x7e>
 103:	48 83 c4 08          	add    $0x8,%rsp
 107:	5b                   	pop    %rbx
 108:	41 5c                	pop    %r12
 10a:	41 5d                	pop    %r13
 10c:	41 5e                	pop    %r14
 10e:	41 5f                	pop    %r15
 110:	5d                   	pop    %rbp
 111:	c3                   	ret
 112:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 119 <verigmp::multiply::mul_low+0x119>
			115: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.254-0x4
 119:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 120 <verigmp::multiply::mul_low+0x120>
			11c: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.255-0x4
 120:	be 28 00 00 00       	mov    $0x28,%esi
 125:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 12b <verigmp::multiply::mul_low+0x12b>
			127: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 12b:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 132 <verigmp::multiply::mul_low+0x132>
			12e: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.256-0x4
 132:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 139 <verigmp::multiply::mul_low+0x139>
			135: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.257-0x4
 139:	be 28 00 00 00       	mov    $0x28,%esi
 13e:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 144 <verigmp::multiply::mul_low+0x144>
			140: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp8multiply7mul_mod:

0000000000000000 <verigmp::multiply::mul_mod>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	50                   	push   %rax
   b:	48 89 3c 24          	mov    %rdi,(%rsp)
   f:	48 85 f6             	test   %rsi,%rsi
  12:	0f 84 4b 01 00 00    	je     163 <verigmp::multiply::mul_mod+0x163>
  18:	8b 44 24 40          	mov    0x40(%rsp),%eax
  1c:	ff c8                	dec    %eax
  1e:	83 f8 40             	cmp    $0x40,%eax
  21:	0f 83 23 01 00 00    	jae    14a <verigmp::multiply::mul_mod+0x14a>
  27:	49 89 f4             	mov    %rsi,%r12
  2a:	48 39 ce             	cmp    %rcx,%rsi
  2d:	0f 85 49 01 00 00    	jne    17c <verigmp::multiply::mul_mod+0x17c>
  33:	4d 39 cc             	cmp    %r9,%r12
  36:	0f 85 59 01 00 00    	jne    195 <verigmp::multiply::mul_mod+0x195>
  3c:	4d 89 c7             	mov    %r8,%r15
  3f:	49 89 d5             	mov    %rdx,%r13
  42:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
  49:	00 
  4a:	31 ed                	xor    %ebp,%ebp
  4c:	48 8b 1c 24          	mov    (%rsp),%rbx
  50:	48 89 df             	mov    %rbx,%rdi
  53:	31 f6                	xor    %esi,%esi
  55:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 5b <verigmp::multiply::mul_mod+0x5b>
			57: R_X86_64_GOTPCREL	memset-0x4
  5b:	48 8d 73 08          	lea    0x8(%rbx),%rsi
  5f:	4c 89 e3             	mov    %r12,%rbx
  62:	eb 39                	jmp    9d <verigmp::multiply::mul_mod+0x9d>
  64:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6b:	00 00 00 00 00 
  70:	45 31 d2             	xor    %r10d,%r10d
  73:	45 31 c9             	xor    %r9d,%r9d
  76:	48 8b 04 24          	mov    (%rsp),%rax
  7a:	48 8d 04 e8          	lea    (%rax,%rbp,8),%rax
  7e:	4b 0f af 0c cf       	imul   (%r15,%r9,8),%rcx
  83:	4e 03 14 c8          	add    (%rax,%r9,8),%r10
  87:	49 01 ca             	add    %rcx,%r10
  8a:	4e 89 14 c8          	mov    %r10,(%rax,%r9,8)
  8e:	48 83 c6 08          	add    $0x8,%rsi
  92:	48 ff cb             	dec    %rbx
  95:	4c 89 c5             	mov    %r8,%rbp
  98:	4d 39 e0             	cmp    %r12,%r8
  9b:	74 76                	je     113 <verigmp::multiply::mul_mod+0x113>
  9d:	4c 8d 45 01          	lea    0x1(%rbp),%r8
  a1:	49 8b 4c ed 00       	mov    0x0(%r13,%rbp,8),%rcx
  a6:	4d 39 c4             	cmp    %r8,%r12
  a9:	74 c5                	je     70 <verigmp::multiply::mul_mod+0x70>
  ab:	48 89 df             	mov    %rbx,%rdi
  ae:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
  b2:	4d 89 e3             	mov    %r12,%r11
  b5:	49 29 eb             	sub    %rbp,%r11
  b8:	45 31 d2             	xor    %r10d,%r10d
  bb:	45 31 c9             	xor    %r9d,%r9d
  be:	66 90                	xchg   %ax,%ax
  c0:	48 89 c8             	mov    %rcx,%rax
  c3:	4b f7 24 cf          	mulq   (%r15,%r9,8)
  c7:	45 31 f6             	xor    %r14d,%r14d
  ca:	4e 03 54 ce f8       	add    -0x8(%rsi,%r9,8),%r10
  cf:	41 0f 92 c6          	setb   %r14b
  d3:	49 01 c2             	add    %rax,%r10
  d6:	49 11 d6             	adc    %rdx,%r14
  d9:	4e 89 54 ce f8       	mov    %r10,-0x8(%rsi,%r9,8)
  de:	48 89 c8             	mov    %rcx,%rax
  e1:	4b f7 64 cf 08       	mulq   0x8(%r15,%r9,8)
  e6:	45 31 d2             	xor    %r10d,%r10d
  e9:	4e 03 34 ce          	add    (%rsi,%r9,8),%r14
  ed:	41 0f 92 c2          	setb   %r10b
  f1:	49 01 c6             	add    %rax,%r14
  f4:	49 11 d2             	adc    %rdx,%r10
  f7:	4e 89 34 ce          	mov    %r14,(%rsi,%r9,8)
  fb:	49 83 c1 02          	add    $0x2,%r9
  ff:	4c 39 cf             	cmp    %r9,%rdi
 102:	75 bc                	jne    c0 <verigmp::multiply::mul_mod+0xc0>
 104:	41 f6 c3 01          	test   $0x1,%r11b
 108:	0f 85 68 ff ff ff    	jne    76 <verigmp::multiply::mul_mod+0x76>
 10e:	e9 7b ff ff ff       	jmp    8e <verigmp::multiply::mul_mod+0x8e>
 113:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 11a:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
 121:	8b 4c 24 40          	mov    0x40(%rsp),%ecx
 125:	48 d3 e2             	shl    %cl,%rdx
 128:	83 f9 40             	cmp    $0x40,%ecx
 12b:	48 f7 d2             	not    %rdx
 12e:	48 0f 44 d0          	cmove  %rax,%rdx
 132:	48 8b 04 24          	mov    (%rsp),%rax
 136:	4a 21 54 e0 f8       	and    %rdx,-0x8(%rax,%r12,8)
 13b:	48 83 c4 08          	add    $0x8,%rsp
 13f:	5b                   	pop    %rbx
 140:	41 5c                	pop    %r12
 142:	41 5d                	pop    %r13
 144:	41 5e                	pop    %r14
 146:	41 5f                	pop    %r15
 148:	5d                   	pop    %rbp
 149:	c3                   	ret
 14a:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 151 <verigmp::multiply::mul_mod+0x151>
			14d: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.1-0x4
 151:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 158 <verigmp::multiply::mul_mod+0x158>
			154: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.259-0x4
 158:	be 27 00 00 00       	mov    $0x27,%esi
 15d:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 163 <verigmp::multiply::mul_mod+0x163>
			15f: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 163:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 16a <verigmp::multiply::mul_mod+0x16a>
			166: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.203-0x4
 16a:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 171 <verigmp::multiply::mul_mod+0x171>
			16d: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.258-0x4
 171:	be 1f 00 00 00       	mov    $0x1f,%esi
 176:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 17c <verigmp::multiply::mul_mod+0x17c>
			178: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 17c:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 183 <verigmp::multiply::mul_mod+0x183>
			17f: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.254-0x4
 183:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 18a <verigmp::multiply::mul_mod+0x18a>
			186: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.255-0x4
 18a:	be 28 00 00 00       	mov    $0x28,%esi
 18f:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 195 <verigmp::multiply::mul_mod+0x195>
			191: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 195:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 19c <verigmp::multiply::mul_mod+0x19c>
			198: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.256-0x4
 19c:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 1a3 <verigmp::multiply::mul_mod+0x1a3>
			19f: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.257-0x4
 1a3:	be 28 00 00 00       	mov    $0x28,%esi
 1a8:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1ae <verigmp::multiply::mul_mod+0x1ae>
			1aa: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp8toom_low3low:

0000000000000000 <verigmp::toom_low::low>:
   0:	55                   	push   %rbp
   1:	41 57                	push   %r15
   3:	41 56                	push   %r14
   5:	41 55                	push   %r13
   7:	41 54                	push   %r12
   9:	53                   	push   %rbx
   a:	48 83 ec 28          	sub    $0x28,%rsp
   e:	48 85 c9             	test   %rcx,%rcx
  11:	0f 84 d8 04 00 00    	je     4ef <verigmp::toom_low::low+0x4ef>
  17:	4c 39 c9             	cmp    %r9,%rcx
  1a:	0f 85 cf 04 00 00    	jne    4ef <verigmp::toom_low::low+0x4ef>
  20:	49 89 d3             	mov    %rdx,%r11
  23:	49 89 fe             	mov    %rdi,%r14
  26:	4c 8b 54 24 70       	mov    0x70(%rsp),%r10
  2b:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
  30:	48 39 ce             	cmp    %rcx,%rsi
  33:	0f 94 c2             	sete   %dl
  36:	48 8d 04 8d 00 00 00 	lea    0x0(,%rcx,4),%rax
  3d:	00 
  3e:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  42:	48 39 c7             	cmp    %rax,%rdi
  45:	0f 93 c0             	setae  %al
  48:	20 d0                	and    %dl,%al
  4a:	49 83 fa 18          	cmp    $0x18,%r10
  4e:	0f 82 53 04 00 00    	jb     4a7 <verigmp::toom_low::low+0x4a7>
  54:	48 89 ce             	mov    %rcx,%rsi
  57:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  5c:	48 83 f9 18          	cmp    $0x18,%rcx
  60:	0f 82 41 04 00 00    	jb     4a7 <verigmp::toom_low::low+0x4a7>
  66:	8b 94 24 80 00 00 00 	mov    0x80(%rsp),%edx
  6d:	83 fa 02             	cmp    $0x2,%edx
  70:	0f 87 31 04 00 00    	ja     4a7 <verigmp::toom_low::low+0x4a7>
  76:	84 c0                	test   %al,%al
  78:	0f 84 46 04 00 00    	je     4c4 <verigmp::toom_low::low+0x4c4>
  7e:	4d 89 c4             	mov    %r8,%r12
  81:	48 39 ce             	cmp    %rcx,%rsi
  84:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  89:	4c 89 5c 24 18       	mov    %r11,0x18(%rsp)
  8e:	76 4d                	jbe    dd <verigmp::toom_low::low+0xdd>
  90:	83 fa 02             	cmp    $0x2,%edx
  93:	0f 84 a3 01 00 00    	je     23c <verigmp::toom_low::low+0x23c>
  99:	83 fa 01             	cmp    $0x1,%edx
  9c:	0f 85 d2 01 00 00    	jne    274 <verigmp::toom_low::low+0x274>
  a2:	48 b9 8f e3 38 8e e3 	movabs $0xe38e38e38e38e38f,%rcx
  a9:	38 8e e3 
  ac:	48 89 f0             	mov    %rsi,%rax
  af:	48 f7 e1             	mul    %rcx
  b2:	48 c1 ea 05          	shr    $0x5,%rdx
  b6:	48 8d 04 92          	lea    (%rdx,%rdx,4),%rax
  ba:	48 8d 04 42          	lea    (%rdx,%rax,2),%rax
  be:	c1 e2 02             	shl    $0x2,%edx
  c1:	8d 0c d2             	lea    (%rdx,%rdx,8),%ecx
  c4:	89 f2                	mov    %esi,%edx
  c6:	29 ca                	sub    %ecx,%edx
  c8:	8d 0c 92             	lea    (%rdx,%rdx,4),%ecx
  cb:	8d 0c 4a             	lea    (%rdx,%rcx,2),%ecx
  ce:	0f b7 c9             	movzwl %cx,%ecx
  d1:	44 69 e9 1d 07 00 00 	imul   $0x71d,%ecx,%r13d
  d8:	e9 8e 01 00 00       	jmp    26b <verigmp::toom_low::low+0x26b>
  dd:	49 8b 0b             	mov    (%r11),%rcx
  e0:	48 89 f0             	mov    %rsi,%rax
  e3:	48 ff c8             	dec    %rax
  e6:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  eb:	74 66                	je     153 <verigmp::toom_low::low+0x153>
  ed:	49 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%r10
  f4:	ff ff 0f 
  f7:	49 21 f2             	and    %rsi,%r10
  fa:	45 31 c0             	xor    %r8d,%r8d
  fd:	45 31 c9             	xor    %r9d,%r9d
 100:	48 89 c8             	mov    %rcx,%rax
 103:	4b f7 24 cc          	mulq   (%r12,%r9,8)
 107:	48 89 d6             	mov    %rdx,%rsi
 10a:	48 89 c7             	mov    %rax,%rdi
 10d:	4e 8d 1c 00          	lea    (%rax,%r8,1),%r11
 111:	48 89 c8             	mov    %rcx,%rax
 114:	4b f7 64 cc 08       	mulq   0x8(%r12,%r9,8)
 119:	4c 01 c7             	add    %r8,%rdi
 11c:	48 11 f0             	adc    %rsi,%rax
 11f:	49 89 d0             	mov    %rdx,%r8
 122:	49 83 d0 00          	adc    $0x0,%r8
 126:	4f 89 1c ce          	mov    %r11,(%r14,%r9,8)
 12a:	4b 89 44 ce 08       	mov    %rax,0x8(%r14,%r9,8)
 12f:	49 83 c1 02          	add    $0x2,%r9
 133:	4d 39 ca             	cmp    %r9,%r10
 136:	75 c8                	jne    100 <verigmp::toom_low::low+0x100>
 138:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 13d:	40 f6 c6 01          	test   $0x1,%sil
 141:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
 146:	75 11                	jne    159 <verigmp::toom_low::low+0x159>
 148:	48 83 fe 02          	cmp    $0x2,%rsi
 14c:	73 21                	jae    16f <verigmp::toom_low::low+0x16f>
 14e:	e9 45 03 00 00       	jmp    498 <verigmp::toom_low::low+0x498>
 153:	45 31 c0             	xor    %r8d,%r8d
 156:	45 31 c9             	xor    %r9d,%r9d
 159:	4b 0f af 0c cc       	imul   (%r12,%r9,8),%rcx
 15e:	4c 01 c1             	add    %r8,%rcx
 161:	4b 89 0c ce          	mov    %rcx,(%r14,%r9,8)
 165:	48 83 fe 02          	cmp    $0x2,%rsi
 169:	0f 82 29 03 00 00    	jb     498 <verigmp::toom_low::low+0x498>
 16f:	48 8d 5e fe          	lea    -0x2(%rsi),%rbx
 173:	49 8d 7e 10          	lea    0x10(%r14),%rdi
 177:	41 b9 01 00 00 00    	mov    $0x1,%r9d
 17d:	45 31 d2             	xor    %r10d,%r10d
 180:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
 185:	eb 39                	jmp    1c0 <verigmp::toom_low::low+0x1c0>
 187:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 18e:	00 00 
 190:	45 31 ed             	xor    %r13d,%r13d
 193:	45 31 ff             	xor    %r15d,%r15d
 196:	4b 8d 04 ce          	lea    (%r14,%r9,8),%rax
 19a:	4b 0f af 0c fc       	imul   (%r12,%r15,8),%rcx
 19f:	4e 03 2c f8          	add    (%rax,%r15,8),%r13
 1a3:	49 01 cd             	add    %rcx,%r13
 1a6:	4e 89 2c f8          	mov    %r13,(%rax,%r15,8)
 1aa:	49 ff c1             	inc    %r9
 1ad:	49 ff c2             	inc    %r10
 1b0:	48 83 c7 08          	add    $0x8,%rdi
 1b4:	49 ff c8             	dec    %r8
 1b7:	49 39 f1             	cmp    %rsi,%r9
 1ba:	0f 84 d8 02 00 00    	je     498 <verigmp::toom_low::low+0x498>
 1c0:	4b 8b 0c cb          	mov    (%r11,%r9,8),%rcx
 1c4:	4c 39 d3             	cmp    %r10,%rbx
 1c7:	74 c7                	je     190 <verigmp::toom_low::low+0x190>
 1c9:	4d 89 c3             	mov    %r8,%r11
 1cc:	49 83 e3 fe          	and    $0xfffffffffffffffe,%r11
 1d0:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
 1d5:	4c 29 d5             	sub    %r10,%rbp
 1d8:	45 31 ed             	xor    %r13d,%r13d
 1db:	45 31 ff             	xor    %r15d,%r15d
 1de:	66 90                	xchg   %ax,%ax
 1e0:	48 89 c8             	mov    %rcx,%rax
 1e3:	4b f7 24 fc          	mulq   (%r12,%r15,8)
 1e7:	31 f6                	xor    %esi,%esi
 1e9:	4e 03 6c ff f8       	add    -0x8(%rdi,%r15,8),%r13
 1ee:	40 0f 92 c6          	setb   %sil
 1f2:	49 01 c5             	add    %rax,%r13
 1f5:	48 11 d6             	adc    %rdx,%rsi
 1f8:	4e 89 6c ff f8       	mov    %r13,-0x8(%rdi,%r15,8)
 1fd:	48 89 c8             	mov    %rcx,%rax
 200:	4b f7 64 fc 08       	mulq   0x8(%r12,%r15,8)
 205:	45 31 ed             	xor    %r13d,%r13d
 208:	4a 03 34 ff          	add    (%rdi,%r15,8),%rsi
 20c:	41 0f 92 c5          	setb   %r13b
 210:	48 01 c6             	add    %rax,%rsi
 213:	49 11 d5             	adc    %rdx,%r13
 216:	4a 89 34 ff          	mov    %rsi,(%rdi,%r15,8)
 21a:	49 83 c7 02          	add    $0x2,%r15
 21e:	4d 39 fb             	cmp    %r15,%r11
 221:	75 bd                	jne    1e0 <verigmp::toom_low::low+0x1e0>
 223:	40 f6 c5 01          	test   $0x1,%bpl
 227:	4c 8b 5c 24 18       	mov    0x18(%rsp),%r11
 22c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
 231:	0f 85 5f ff ff ff    	jne    196 <verigmp::toom_low::low+0x196>
 237:	e9 6e ff ff ff       	jmp    1aa <verigmp::toom_low::low+0x1aa>
 23c:	48 b9 cd cc cc cc cc 	movabs $0xcccccccccccccccd,%rcx
 243:	cc cc cc 
 246:	48 89 f0             	mov    %rsi,%rax
 249:	48 f7 e1             	mul    %rcx
 24c:	48 c1 ea 05          	shr    $0x5,%rdx
 250:	48 8d 04 d2          	lea    (%rdx,%rdx,8),%rax
 254:	c1 e2 03             	shl    $0x3,%edx
 257:	8d 0c 92             	lea    (%rdx,%rdx,4),%ecx
 25a:	89 f2                	mov    %esi,%edx
 25c:	29 ca                	sub    %ecx,%edx
 25e:	8d 0c d2             	lea    (%rdx,%rdx,8),%ecx
 261:	0f b7 c9             	movzwl %cx,%ecx
 264:	44 69 e9 67 06 00 00 	imul   $0x667,%ecx,%r13d
 26b:	41 c1 ed 10          	shr    $0x10,%r13d
 26f:	49 01 c5             	add    %rax,%r13
 272:	eb 06                	jmp    27a <verigmp::toom_low::low+0x27a>
 274:	49 89 f5             	mov    %rsi,%r13
 277:	49 d1 ed             	shr    $1,%r13
 27a:	48 89 f3             	mov    %rsi,%rbx
 27d:	4c 29 eb             	sub    %r13,%rbx
 280:	4c 8d 3c 1b          	lea    (%rbx,%rbx,1),%r15
 284:	48 89 f8             	mov    %rdi,%rax
 287:	4c 29 f8             	sub    %r15,%rax
 28a:	0f 82 78 02 00 00    	jb     508 <verigmp::toom_low::low+0x508>
 290:	48 8b 6c 24 60       	mov    0x60(%rsp),%rbp
 295:	48 83 ec 08          	sub    $0x8,%rsp
 299:	48 89 ef             	mov    %rbp,%rdi
 29c:	4c 89 fe             	mov    %r15,%rsi
 29f:	4c 89 da             	mov    %r11,%rdx
 2a2:	48 89 d9             	mov    %rbx,%rcx
 2a5:	4d 89 e0             	mov    %r12,%r8
 2a8:	49 89 d9             	mov    %rbx,%r9
 2ab:	41 52                	push   %r10
 2ad:	50                   	push   %rax
 2ae:	4a 8d 04 fd 00 00 00 	lea    0x0(,%r15,8),%rax
 2b5:	00 
 2b6:	48 01 e8             	add    %rbp,%rax
 2b9:	50                   	push   %rax
 2ba:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2c0 <verigmp::toom_low::low+0x2c0>
			2bc: R_X86_64_GOTPCREL	verigmp::toom_multiply::full-0x4
 2c0:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
 2c5:	48 83 c4 20          	add    $0x20,%rsp
 2c9:	4c 39 fe             	cmp    %r15,%rsi
 2cc:	0f 87 0b 02 00 00    	ja     4dd <verigmp::toom_low::low+0x4dd>
 2d2:	48 8d 14 f5 00 00 00 	lea    0x0(,%rsi,8),%rdx
 2d9:	00 
 2da:	4c 89 f7             	mov    %r14,%rdi
 2dd:	48 89 ee             	mov    %rbp,%rsi
 2e0:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 2e6 <verigmp::toom_low::low+0x2e6>
			2e2: R_X86_64_GOTPCREL	memcpy-0x4
 2e6:	4e 8d 1c ed 00 00 00 	lea    0x0(,%r13,8),%r11
 2ed:	00 
 2ee:	49 01 eb             	add    %rbp,%r11
 2f1:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
 2f6:	4c 29 e8             	sub    %r13,%rax
 2f9:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
 2fe:	49 8d 14 df          	lea    (%r15,%rbx,8),%rdx
 302:	48 83 ec 08          	sub    $0x8,%rsp
 306:	48 89 ef             	mov    %rbp,%rdi
 309:	4c 89 ee             	mov    %r13,%rsi
 30c:	4c 89 e9             	mov    %r13,%rcx
 30f:	4d 89 e0             	mov    %r12,%r8
 312:	4d 89 e9             	mov    %r13,%r9
 315:	44 8b 94 24 88 00 00 	mov    0x88(%rsp),%r10d
 31c:	00 
 31d:	41 52                	push   %r10
 31f:	ff b4 24 88 00 00 00 	push   0x88(%rsp)
 326:	ff b4 24 88 00 00 00 	push   0x88(%rsp)
 32d:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
 332:	50                   	push   %rax
 333:	41 53                	push   %r11
 335:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 33b <verigmp::toom_low::low+0x33b>
			337: R_X86_64_GOTPCREL	verigmp::toom_low::low-0x4
 33b:	48 83 c4 30          	add    $0x30,%rsp
 33f:	4d 85 ed             	test   %r13,%r13
 342:	0f 84 a7 01 00 00    	je     4ef <verigmp::toom_low::low+0x4ef>
 348:	4c 89 fa             	mov    %r15,%rdx
 34b:	49 89 da             	mov    %rbx,%r10
 34e:	4d 8d 0c de          	lea    (%r14,%rbx,8),%r9
 352:	4d 89 ef             	mov    %r13,%r15
 355:	49 ff cf             	dec    %r15
 358:	74 63                	je     3bd <verigmp::toom_low::low+0x3bd>
 35a:	4d 89 e8             	mov    %r13,%r8
 35d:	49 83 e0 fe          	and    $0xfffffffffffffffe,%r8
 361:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
 368:	00 
 369:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
 36e:	49 8d 34 ce          	lea    (%r14,%rcx,8),%rsi
 372:	48 29 c6             	sub    %rax,%rsi
 375:	48 83 c6 08          	add    $0x8,%rsi
 379:	31 c0                	xor    %eax,%eax
 37b:	31 c9                	xor    %ecx,%ecx
 37d:	0f 1f 00             	nopl   (%rax)
 380:	31 ff                	xor    %edi,%edi
 382:	48 03 44 ce f8       	add    -0x8(%rsi,%rcx,8),%rax
 387:	40 0f 92 c7          	setb   %dil
 38b:	48 03 44 cd 00       	add    0x0(%rbp,%rcx,8),%rax
 390:	48 89 44 ce f8       	mov    %rax,-0x8(%rsi,%rcx,8)
 395:	48 13 3c ce          	adc    (%rsi,%rcx,8),%rdi
 399:	0f 92 c0             	setb   %al
 39c:	0f b6 c0             	movzbl %al,%eax
 39f:	48 03 7c cd 08       	add    0x8(%rbp,%rcx,8),%rdi
 3a4:	48 83 d0 00          	adc    $0x0,%rax
 3a8:	48 89 3c ce          	mov    %rdi,(%rsi,%rcx,8)
 3ac:	48 83 c1 02          	add    $0x2,%rcx
 3b0:	49 39 c8             	cmp    %rcx,%r8
 3b3:	75 cb                	jne    380 <verigmp::toom_low::low+0x380>
 3b5:	41 f6 c5 01          	test   $0x1,%r13b
 3b9:	75 06                	jne    3c1 <verigmp::toom_low::low+0x3c1>
 3bb:	eb 11                	jmp    3ce <verigmp::toom_low::low+0x3ce>
 3bd:	31 c0                	xor    %eax,%eax
 3bf:	31 c9                	xor    %ecx,%ecx
 3c1:	49 03 04 c9          	add    (%r9,%rcx,8),%rax
 3c5:	48 03 44 cd 00       	add    0x0(%rbp,%rcx,8),%rax
 3ca:	49 89 04 c9          	mov    %rax,(%r9,%rcx,8)
 3ce:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
 3d3:	4f 8d 04 d4          	lea    (%r12,%r10,8),%r8
 3d7:	48 83 ec 08          	sub    $0x8,%rsp
 3db:	48 89 ef             	mov    %rbp,%rdi
 3de:	4c 89 ee             	mov    %r13,%rsi
 3e1:	4c 89 e9             	mov    %r13,%rcx
 3e4:	4d 89 e9             	mov    %r13,%r9
 3e7:	8b 84 24 88 00 00 00 	mov    0x88(%rsp),%eax
 3ee:	50                   	push   %rax
 3ef:	ff b4 24 88 00 00 00 	push   0x88(%rsp)
 3f6:	ff b4 24 88 00 00 00 	push   0x88(%rsp)
 3fd:	ff 74 24 30          	push   0x30(%rsp)
 401:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
 408:	00 
 409:	48 01 e8             	add    %rbp,%rax
 40c:	50                   	push   %rax
 40d:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 413 <verigmp::toom_low::low+0x413>
			40f: R_X86_64_GOTPCREL	verigmp::toom_low::low-0x4
 413:	48 83 c4 30          	add    $0x30,%rsp
 417:	4d 85 ff             	test   %r15,%r15
 41a:	74 66                	je     482 <verigmp::toom_low::low+0x482>
 41c:	4c 89 ea             	mov    %r13,%rdx
 41f:	48 83 e2 fe          	and    $0xfffffffffffffffe,%rdx
 423:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
 42a:	00 
 42b:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
 430:	49 8d 34 ce          	lea    (%r14,%rcx,8),%rsi
 434:	48 29 c6             	sub    %rax,%rsi
 437:	48 83 c6 08          	add    $0x8,%rsi
 43b:	31 c0                	xor    %eax,%eax
 43d:	31 c9                	xor    %ecx,%ecx
 43f:	90                   	nop
 440:	31 ff                	xor    %edi,%edi
 442:	48 03 44 ce f8       	add    -0x8(%rsi,%rcx,8),%rax
 447:	40 0f 92 c7          	setb   %dil
 44b:	48 03 44 cd 00       	add    0x0(%rbp,%rcx,8),%rax
 450:	48 89 44 ce f8       	mov    %rax,-0x8(%rsi,%rcx,8)
 455:	48 13 3c ce          	adc    (%rsi,%rcx,8),%rdi
 459:	0f 92 c0             	setb   %al
 45c:	0f b6 c0             	movzbl %al,%eax
 45f:	48 03 7c cd 08       	add    0x8(%rbp,%rcx,8),%rdi
 464:	48 83 d0 00          	adc    $0x0,%rax
 468:	48 89 3c ce          	mov    %rdi,(%rsi,%rcx,8)
 46c:	48 83 c1 02          	add    $0x2,%rcx
 470:	48 39 ca             	cmp    %rcx,%rdx
 473:	75 cb                	jne    440 <verigmp::toom_low::low+0x440>
 475:	41 f6 c5 01          	test   $0x1,%r13b
 479:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 47e:	75 0b                	jne    48b <verigmp::toom_low::low+0x48b>
 480:	eb 16                	jmp    498 <verigmp::toom_low::low+0x498>
 482:	31 c0                	xor    %eax,%eax
 484:	31 c9                	xor    %ecx,%ecx
 486:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
 48b:	48 03 04 ca          	add    (%rdx,%rcx,8),%rax
 48f:	48 03 44 cd 00       	add    0x0(%rbp,%rcx,8),%rax
 494:	48 89 04 ca          	mov    %rax,(%rdx,%rcx,8)
 498:	48 83 c4 28          	add    $0x28,%rsp
 49c:	5b                   	pop    %rbx
 49d:	41 5c                	pop    %r12
 49f:	41 5d                	pop    %r13
 4a1:	41 5e                	pop    %r14
 4a3:	41 5f                	pop    %r15
 4a5:	5d                   	pop    %rbp
 4a6:	c3                   	ret
 4a7:	84 c0                	test   %al,%al
 4a9:	74 19                	je     4c4 <verigmp::toom_low::low+0x4c4>
 4ab:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 4b2 <verigmp::toom_low::low+0x4b2>
			4ae: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.23-0x4
 4b2:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 4b9 <verigmp::toom_low::low+0x4b9>
			4b5: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.264-0x4
 4b9:	be 47 00 00 00       	mov    $0x47,%esi
 4be:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4c4 <verigmp::toom_low::low+0x4c4>
			4c0: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 4c4:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 4cb <verigmp::toom_low::low+0x4cb>
			4c7: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.262-0x4
 4cb:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 4d2 <verigmp::toom_low::low+0x4d2>
			4ce: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.263-0x4
 4d2:	be 47 00 00 00       	mov    $0x47,%esi
 4d7:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4dd <verigmp::toom_low::low+0x4dd>
			4d9: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 4dd:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 4e4 <verigmp::toom_low::low+0x4e4>
			4e0: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.266-0x4
 4e4:	31 ff                	xor    %edi,%edi
 4e6:	4c 89 fa             	mov    %r15,%rdx
 4e9:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 4ef <verigmp::toom_low::low+0x4ef>
			4eb: R_X86_64_GOTPCREL	core::slice::index::slice_index_fail-0x4
 4ef:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 4f6 <verigmp::toom_low::low+0x4f6>
			4f2: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.18-0x4
 4f6:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 4fd <verigmp::toom_low::low+0x4fd>
			4f9: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.261-0x4
 4fd:	be 33 00 00 00       	mov    $0x33,%esi
 502:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 508 <verigmp::toom_low::low+0x508>
			504: R_X86_64_GOTPCREL	core::panicking::panic-0x4
 508:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 50f <verigmp::toom_low::low+0x50f>
			50b: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.0-0x4
 50f:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 516 <verigmp::toom_low::low+0x516>
			512: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.265-0x4
 516:	be 13 00 00 00       	mov    $0x13,%esi
 51b:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 521 <verigmp::toom_low::low+0x521>
			51d: R_X86_64_GOTPCREL	core::panicking::panic_fmt-0x4

Disassembly of section .text._RNvNtCs9Cc19I5TWaA_7verigmp8toom_low7modular:

0000000000000000 <verigmp::toom_low::modular>:
   0:	41 57                	push   %r15
   2:	41 56                	push   %r14
   4:	53                   	push   %rbx
   5:	44 8b 7c 24 30       	mov    0x30(%rsp),%r15d
   a:	41 8d 47 ff          	lea    -0x1(%r15),%eax
   e:	83 f8 40             	cmp    $0x40,%eax
  11:	73 58                	jae    6b <verigmp::toom_low::modular+0x6b>
  13:	48 89 f3             	mov    %rsi,%rbx
  16:	49 89 fe             	mov    %rdi,%r14
  19:	8b 44 24 48          	mov    0x48(%rsp),%eax
  1d:	48 83 ec 08          	sub    $0x8,%rsp
  21:	50                   	push   %rax
  22:	ff 74 24 50          	push   0x50(%rsp)
  26:	ff 74 24 50          	push   0x50(%rsp)
  2a:	ff 74 24 48          	push   0x48(%rsp)
  2e:	ff 74 24 48          	push   0x48(%rsp)
  32:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 38 <verigmp::toom_low::modular+0x38>
			34: R_X86_64_GOTPCREL	verigmp::toom_low::low-0x4
  38:	48 83 c4 30          	add    $0x30,%rsp
  3c:	48 85 db             	test   %rbx,%rbx
  3f:	74 43                	je     84 <verigmp::toom_low::modular+0x84>
  41:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  48:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  4f:	44 89 f9             	mov    %r15d,%ecx
  52:	48 d3 e2             	shl    %cl,%rdx
  55:	41 83 ff 40          	cmp    $0x40,%r15d
  59:	48 f7 d2             	not    %rdx
  5c:	48 0f 44 d0          	cmove  %rax,%rdx
  60:	49 21 54 de f8       	and    %rdx,-0x8(%r14,%rbx,8)
  65:	5b                   	pop    %rbx
  66:	41 5e                	pop    %r14
  68:	41 5f                	pop    %r15
  6a:	c3                   	ret
  6b:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 72 <verigmp::toom_low::modular+0x72>
			6e: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.1-0x4
  72:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 79 <verigmp::toom_low::modular+0x79>
			75: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.268-0x4
  79:	be 27 00 00 00       	mov    $0x27,%esi
  7e:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 84 <verigmp::toom_low::modular+0x84>
			80: R_X86_64_GOTPCREL	core::panicking::panic-0x4
  84:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8b <verigmp::toom_low::modular+0x8b>
			87: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.203-0x4
  8b:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 92 <verigmp::toom_low::modular+0x92>
			8e: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.205-0x4
  92:	be 1f 00 00 00       	mov    $0x1f,%esi
  97:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 9d <verigmp::toom_low::modular+0x9d>
			99: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp9precision13bit_precision:

0000000000000000 <verigmp::precision::bit_precision>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::precision::bit_precision+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::precision::bit_precision+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.270-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::precision::bit_precision+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp9precision18modulus_properties:

0000000000000000 <verigmp::precision::modulus_properties>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::precision::modulus_properties+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::precision::modulus_properties+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.271-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::precision::modulus_properties+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp9precision22top_replacement_is_mod:

0000000000000000 <verigmp::precision::top_replacement_is_mod>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::precision::top_replacement_is_mod+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::precision::top_replacement_is_mod+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.272-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::precision::top_replacement_is_mod+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

Disassembly of section .text.unlikely._RNvNtCs9Cc19I5TWaA_7verigmp9precision7modulus:

0000000000000000 <verigmp::precision::modulus>:
   0:	50                   	push   %rax
   1:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 8 <verigmp::precision::modulus+0x8>
			4: R_X86_64_PC32	.rodata..Lanon.d1b2563b732ee79941e9b189853f7bd7.43-0x4
   8:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # f <verigmp::precision::modulus+0xf>
			b: R_X86_64_PC32	.data.rel.ro..Lanon.d1b2563b732ee79941e9b189853f7bd7.273-0x4
   f:	be 0e 00 00 00       	mov    $0xe,%esi
  14:	ff 15 00 00 00 00    	call   *0x0(%rip)        # 1a <verigmp::precision::modulus+0x1a>
			16: R_X86_64_GOTPCREL	core::panicking::panic-0x4

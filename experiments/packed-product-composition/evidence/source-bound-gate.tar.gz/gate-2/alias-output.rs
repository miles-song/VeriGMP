use packed_product_consumer::consume;
fn main() {
    let mut words = [1u64];
    let right = [1u64];
    let mut output = [0u64; 2];
    let mut packed_left = [0u64; 1];
    let mut packed_right = [0u64; 1];
    let mut product = [0u64; 2];
    let mut scratch = [0u64; 12];
    let result = consume(&mut product, &words, &right, &mut packed_left, &mut packed_right, &mut product, &mut scratch, 1, 1, 2, 1);
}

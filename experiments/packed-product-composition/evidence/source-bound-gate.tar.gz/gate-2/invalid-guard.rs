use vstd::prelude::*;
use verigmp::packed_layout as layout;
use packed_product_consumer::consume;
verus! {
pub fn invalid_call(output: &mut [u64], left: &[u64], right: &[u64],
    packed_left: &mut [u64], packed_right: &mut [u64],
    product: &mut [u64], scratch: &mut [u64])
    requires
        layout::compact_coefficients(left@, 3, 1),
        layout::compact_coefficients(right@, 3, 1),
        old(output)@.len() == 6, old(packed_left)@.len() == 3,
        old(packed_right)@.len() == 3, old(product)@.len() == 6,
        old(scratch)@.len() == 36,
{
    let result = consume(output, left, right, packed_left, packed_right,
                         product, scratch, 3, 1, 3, 1);
}
}

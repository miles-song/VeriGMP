use vstd::prelude::*;
use verigmp::packed_layout as layout;
use packed_product_consumer::consume;
verus! {
pub fn invalid_call(output: &mut [u64], left: &[u64], right: &[u64],
    packed_left: &mut [u64], packed_right: &mut [u64],
    product: &mut [u64], scratch: &mut [u64])
    requires
        verigmp::packed_product::guard_domain(1, 1, 2, 1),
        layout::compact_coefficients(left@, 1, 1),
        layout::compact_coefficients(right@, 1, 1),
        old(output)@.len() == 2, old(packed_left)@.len() == 1,
        old(packed_right)@.len() == 1, old(product)@.len() == 2,
        old(scratch)@.len() == 11,
{
    let result = consume(output, left, right, packed_left, packed_right,
                         product, scratch, 1, 1, 2, 1);
}
}

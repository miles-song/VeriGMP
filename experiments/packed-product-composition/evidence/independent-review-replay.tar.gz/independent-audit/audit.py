"""Independent frozen-package audit and retained-producer preparation; no timings."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import struct
import subprocess
import tarfile
import zipfile

ROOT = Path('/mnt/e/3sat/VeriGMP-packed-product-refinement-20261108')
OUT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'experiments/packed-product-composition'
TIP = '0d7d0db8b939229489b3da8fa84d8be5d5356db0'
GATE = '0daa481d1087d742e55ecb77ca01422a3688f451'
FIRST = '886fc176bd542422b00dddd00a8b259c563e0296'
BASE = '8cc144b349269d31a59b18838aea28f52645a8fa'
MAIN = '98f755792ea5b66456dc330972563714c2ba820d'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['/mnt/c/Program Files/Git/cmd/git.exe', '-C',
                                    'E:/3sat/VeriGMP-packed-product-refinement-20261108', *args])


def source_bytes(commit, names):
    with zipfile.ZipFile(io.BytesIO(git('archive', '--format=zip', commit, *sorted(names)))) as archive:
        return {name: archive.read(name) for name in names}


def elf_function(data):
    assert data[:6] == b'\x7fELF\x02\x01'
    assert struct.unpack_from('<H', data, 18)[0] == 62  # x86-64
    section_offset = struct.unpack_from('<Q', data, 40)[0]
    section_size, section_count, string_index = struct.unpack_from('<HHH', data, 58)
    assert section_size == 64
    sections = [struct.unpack_from('<IIQQQQIIQQ', data, section_offset + 64 * i)
                for i in range(section_count)]

    def section_bytes(index):
        section = sections[index]
        return data[section[4]:section[4] + section[5]]

    def string(table, offset):
        return table[offset:table.index(b'\0', offset)].decode()

    names = section_bytes(string_index)
    symbols = {}
    functions = []
    for index, section in enumerate(sections):
        if section[1] != 2:  # SHT_SYMTAB
            continue
        assert section[9] == 24
        strings = section_bytes(section[6])
        entries = []
        for offset in range(section[4], section[4] + section[5], 24):
            name, info, other, target, value, length = struct.unpack_from('<IBBHQQ', data, offset)
            symbol = dict(name=string(strings, name), section=target, value=value, size=length)
            entries.append(symbol)
            if info & 15 == 2 and target != 0:
                functions.append(symbol)
        symbols[index] = entries
    assert len(functions) == 1 and functions[0]['name'].endswith('7consume')
    symbol = functions[0]
    assert symbol['value'] == 0
    body = section_bytes(symbol['section'])
    assert len(body) == symbol['size'] == 286
    relocations = []
    for section in sections:
        if section[1] == 4 and section[7] == symbol['section']:  # SHT_RELA
            assert section[9] == 24
            for offset in range(section[4], section[4] + section[5], 24):
                address, info, addend = struct.unpack_from('<QQq', data, offset)
                target = symbols[section[6]][info >> 32]['name']
                relocations.append(dict(offset=address, type=info & 0xffffffff,
                                        addend=addend, target=target))
    assert [r['offset'] for r in relocations] == [0x45, 0x82, 0xeb, 0x10b]
    assert all(r['type'] == 9 and r['addend'] == -4 for r in relocations)
    assert ['pack_coefficients' in r['target'] for r in relocations] == [True, True, False, False]
    assert 'toom_multiply4full' in relocations[2]['target']
    assert 'extract_coefficients' in relocations[3]['target']
    return dict(symbol=symbol['name'], section=string(names, sections[symbol['section']][0]),
                size=len(body), body_sha256=sha(body), object_sha256=sha(data), relocations=relocations)


def check_fixtures(data, metadata):
    stream = io.BytesIO(data)
    assert stream.read(8) == b'VGMPPRD1'

    def word():
        return struct.unpack('<Q', stream.read(8))[0]

    def vector():
        length = word()
        return stream.read(8 * length)

    count = word()
    assert count == len(metadata) == 476
    totals = dict(cases=count, nonempty_cases=0, coefficient_values=0, input_integer_values=0,
                  maximum_nonempty_precision=0, maximum_count=0, maximum_result_precision=0)
    for case in range(count):
        case_id, n, p, q, slot, extra = (word() for _ in range(6))
        assert case_id == case
        row = metadata[case]
        assert [row[k] for k in ('id', 'n', 'p', 'q', 'slot', 'scratch_extra')] == [case_id, n, p, q, slot, extra]
        vectors = [vector() for _ in range(6)]
        assert list(map(sha, vectors)) == row['vector_sha256']
        assert [len(v) // 8 for v in vectors] == row['vector_lengths']
        cp, cq = (p + 63) // 64, (q + 63) // 64
        assert p > 0 and q > 0 and slot >= max(cp, cq)
        assert [len(v) for v in vectors] == [8 * k for k in (n * cp, n * cp, n * slot, n * slot, 2 * n * slot, 2 * n * cq)]
        if not n:
            assert all(v == b'' for v in vectors)
            continue
        assert q >= 2 * p and n <= 1 << (q - 2 * p)
        left = [int.from_bytes(vectors[0][8 * cp * i:8 * cp * (i + 1)], 'little') for i in range(n)]
        right = [int.from_bytes(vectors[1][8 * cp * i:8 * cp * (i + 1)], 'little') for i in range(n)]
        assert all(0 <= value < 1 << p for value in left + right)
        for values, packed in ((left, vectors[2]), (right, vectors[3])):
            assert b''.join(value.to_bytes(8 * slot, 'little') for value in values) == packed
        exact_integer = int.from_bytes(vectors[2], 'little') * int.from_bytes(vectors[3], 'little')
        assert exact_integer.to_bytes(16 * n * slot, 'little') == vectors[4]
        # Independently use diagonal finite sums instead of the generator's scatter accumulation.
        coefficients = [sum(left[i] * right[k - i] for i in range(max(0, k - n + 1), min(n, k + 1)))
                        for k in range(2 * n)]
        assert coefficients[-1] == 0 and all(0 <= c < 1 << q for c in coefficients)
        assert b''.join(c.to_bytes(8 * cq, 'little') for c in coefficients) == vectors[5]
        assert b''.join(c.to_bytes(8 * slot, 'little') for c in coefficients) == vectors[4]
        totals['nonempty_cases'] += 1
        totals['coefficient_values'] += len(coefficients)
        totals['input_integer_values'] += 2 * n
        totals['maximum_nonempty_precision'] = max(totals['maximum_nonempty_precision'], p)
        totals['maximum_count'] = max(totals['maximum_count'], n)
        totals['maximum_result_precision'] = max(totals['maximum_result_precision'], q)
    assert not stream.read(1)
    return totals


def main():
    evidence = PACKAGE / 'evidence'
    manifest_data = (evidence / 'manifest.json').read_bytes()
    report_data = (evidence / 'verification.json').read_bytes()
    archive_data = (evidence / 'source-bound-gate.tar.gz').read_bytes()
    assert sha(manifest_data) == '95229fc2a2459c25a6379c7461bb7709c4c3925b6b0be6898143ba374e26a985'
    assert sha(report_data) == 'e64a33d921810b456e343de139ccff96b4be484adc93e0cf642229fbc3568fe8'
    assert sha(archive_data) == '844e1f9e16889d8c81deb73a42692c4c9d6bbdc8248e14e3b5f0e0af82574f23'
    manifest, report = json.loads(manifest_data), json.loads(report_data)
    assert len(archive_data) == manifest['archive_bytes'] == 5325921
    assert git('rev-parse', 'HEAD').decode().strip() == TIP
    assert git('rev-parse', TIP + '^{tree}').decode().strip() == '5000f7a417926e663602336bd38b5e5f4913060c'
    entries = {row['path']: row for row in manifest['members']}
    assert len(entries) == len(manifest['members']) == 307
    retained = OUT / 'retained'
    retained.mkdir()
    with tarfile.open(fileobj=io.BytesIO(archive_data), mode='r:gz') as archive:
        members = archive.getmembers()
        assert len(members) == len(entries) and {m.name for m in members} == entries.keys()
        for member in members:
            assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
            data = archive.extractfile(member).read()
            assert len(data) == entries[member.name]['size'] and sha(data) == entries[member.name]['sha256']
            target = retained / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            target.chmod(member.mode & 0o777)
    gate = retained / 'gate-2'
    origin = retained / 'producer-origin'
    assert (gate / 'verification.json').read_bytes() == report_data
    producer = json.loads((origin / 'verification.json').read_bytes())
    assert sha((origin / 'verification.json').read_bytes()) == report['producer_reuse']['report_sha256']
    assert report['source_git']['head'] == GATE and report['status'] == 'pass'
    assert producer['source_git']['head'] == report['producer_reuse']['source_head']
    for description, snapshot in ((report, gate), (producer, origin)):
        source_map = description['source_git']['source_sha256']
        committed = source_bytes(description['source_git']['head'], source_map)
        for name, expected in source_map.items():
            assert sha(committed[name]) == expected, name
            archived = snapshot / 'source' / name
            if description is report or name.startswith('native/'):
                assert archived.read_bytes() == committed[name], name
    for command in report['commands']:
        assert not command['timeout']
        for channel in ('stdout', 'stderr'):
            assert sha((gate / (command['name'] + '.' + channel + '.log')).read_bytes()) == command[channel + '_sha256']
    original_command = next(c for c in producer['commands'] if c['name'] == 'library-proof-release')
    assert original_command == report['producer_reuse']['original_complete_build_command']
    assert original_command['returncode'] == 0 and not original_command['timeout']
    assert '--no-cheating' in original_command['argv'] and '--compile' in original_command['argv'] and '-O' in original_command['argv']
    for channel in ('stdout', 'stderr'):
        data = (origin / ('library-proof-release.' + channel + '.log')).read_bytes()
        assert sha(data) == original_command[channel + '_sha256']
        assert data == (gate / ('reused-library-proof-release.' + channel + '.log')).read_bytes()
    assert (origin / 'library-proof-release.stdout.log').read_text().strip() == 'verification results:: 358 verified, 0 errors'
    assert not (origin / 'library-proof-release.stderr.log').read_bytes()
    native = {n for n in report['source_git']['source_sha256'] if n.startswith('native/') and n.endswith('.rs')}
    assert len(native) == 50
    current = source_bytes(TIP, report['source_git']['source_sha256'])
    for name in native | {'native/toolchain.json'}:
        expected = report['source_git']['source_sha256'][name]
        assert producer['source_git']['source_sha256'][name] == sha(current[name]) == expected
    for name in current:
        if name.endswith(('.rs', '.py')):
            assert sha(current[name]) == report['source_git']['source_sha256'][name]
    core = ('native/lib.rs', 'native/specs/packed_product.rs',
            'experiments/packed-product-composition/consumer.rs', 'experiments/packed-product-composition/control.rs')
    assert source_bytes(FIRST, core) == {name: current[name] for name in core}
    old_native = native - {'native/lib.rs', 'native/specs/packed_product.rs'}
    assert source_bytes(MAIN, old_native) == {name: current[name] for name in old_native}
    assert not git('diff', '--name-only', BASE, MAIN, '--', 'native').strip()
    main_changes = set(git('diff', '--name-only', BASE, MAIN).decode().splitlines())
    feature_changes = set(git('diff', '--name-only', BASE, TIP).decode().splitlines())
    assert not main_changes & feature_changes
    assert producer['toolchain'] == report['toolchain']
    for path, expected in report['toolchain']['actual_file_sha256'].items():
        assert sha(Path(path).read_bytes()) == expected, path
    for name, expected in report['exports_sha256'].items():
        assert sha((gate / name).read_bytes()) == expected
    for name in ('libverigmp.rlib', 'verigmp.vir'):
        assert producer['exports_sha256'][name] == report['exports_sha256'][name]
    for name, key in (('runtime', 'runtime_oracle'), ('layout-runtime', 'layout_oracle')):
        assert sha((gate / name).read_bytes()) == report[key]['executable_sha256']
    objects = [(gate / (name + '.o')).read_bytes() for name in ('consumer', 'control')]
    assert objects[0] == objects[1]
    elf = [elf_function(data) for data in objects]
    assert elf[0] == elf[1]
    for calculated, recorded in zip(elf, report['erasure']['symbols']):
        assert calculated['object_sha256'] == recorded['object_sha256']
        assert calculated['body_sha256'] == recorded['body_sha256']
        assert calculated['size'] == recorded['full_symbol_bytes']
    fixture_data = (gate / 'oracle/cases.bin').read_bytes()
    assert sha(fixture_data) == report['oracle']['binary_sha256']
    oracle = check_fixtures(fixture_data, [json.loads(row) for row in (gate / 'oracle/cases.jsonl').read_text().splitlines()])
    # Derived input directory enables the public replay command without stale original paths.
    reusable = OUT / 'reused-producer'
    reusable.mkdir()
    for name in ('verification.json', 'library-proof-release.stdout.log', 'library-proof-release.stderr.log'):
        shutil.copyfile(origin / name, reusable / name)
    for name in ('libverigmp.rlib', 'verigmp.vir'):
        shutil.copyfile(gate / name, reusable / name)
    result = dict(status='pass', reviewed_commit=TIP, reviewed_tree='5000f7a417926e663602336bd38b5e5f4913060c',
                  source_gate_commit=GATE, first_source=FIRST, main_commit=MAIN,
                  archive_sha256=sha(archive_data), archive_members=len(entries),
                  gate_source_files=len(report['source_git']['source_sha256']),
                  producer_source_files=len(producer['source_git']['source_sha256']),
                  same_producer_native_files=len(native), unchanged_native_files_against_main=len(old_native),
                  actual_tool_files=len(report['toolchain']['actual_file_sha256']),
                  producer_enclosing_status=producer['status'], producer_verified_items=358,
                  producer_reuse='Original producer report/logs plus hash-identical retained gate-2 rlib/vir in derived directory',
                  main_and_feature_paths_disjoint=True, independent_elf=elf[0], independent_fixture_audit=oracle,
                  script_sha256=sha(Path(__file__).read_bytes()))
    (OUT / 'integrity-audit.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()

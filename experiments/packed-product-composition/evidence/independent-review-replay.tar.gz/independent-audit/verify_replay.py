"""Independently check the focused replay's outputs and retain its complete evidence."""
import hashlib
import json
from pathlib import Path
import re
import tarfile
import audit

OUT = Path(__file__).resolve().parent
REPLAY = OUT / 'focused-replay'
EVIDENCE = audit.PACKAGE / 'evidence'
report = json.loads((REPLAY / 'verification.json').read_bytes())
assert report['status'] == 'pass' and report['source_git']['head'] == audit.TIP
assert report['library_verified_items'] == 358 and report['consumer_verified_items'] == 5
assert report['codegen_verified_items'] == 5
original = json.loads((EVIDENCE / 'verification.json').read_bytes())
assert report['toolchain'] == original['toolchain']
for name in ('libverigmp.rlib', 'verigmp.vir'):
    assert report['exports_sha256'][name] == original['exports_sha256'][name]
for name, expected in report['exports_sha256'].items():
    assert audit.sha((REPLAY / name).read_bytes()) == expected

logical = {}
for command in report['commands']:
    assert not command['timeout']
    text = ''
    for channel in ('stdout', 'stderr'):
        data = (REPLAY / (command['name'] + '.' + channel + '.log')).read_bytes()
        assert audit.sha(data) == command[channel + '_sha256']
        text += data.decode()
    name = command['name']
    if name in ('consumer-proof-release', 'consumer-codegen'):
        assert command['returncode'] == 0
        assert re.findall(r'(?m)^verification results:: (\d+) verified, (\d+) errors$', text) == [('5', '0')]
    if name.startswith(('mutant-', 'invalid-')):
        summaries = re.findall(r'(?m)^verification results:: (\d+) verified, (\d+) errors(.*)$', text)
        assert command['returncode'] == 1 and len(summaries) == 1 and int(summaries[0][1]) > 0
        assert not re.search(r'(?i)timeout|timed out|resource limit|rlimit|unknown|panic|failed to load|error\[E\d+\]', text)
        diagnostics = re.findall(r'(?m)^error: (.*)$', text)
        assert any(line.startswith(('assertion failed', 'postcondition not satisfied', 'precondition not satisfied')) for line in diagnostics)
        assert all(line.startswith(('assertion failed', 'postcondition not satisfied', 'precondition not satisfied', 'aborting due to')) for line in diagnostics)
        if name in ('mutant-insufficient-guard', 'mutant-nonzero-final-tail'):
            assert summaries == [('7', '1', ' (partial verification with `--verify-*`)')]
            assert re.findall(r'(?m)^note: verifying module (.*)$', text) == ['packed_product']
        elif name.startswith('mutant-'):
            assert summaries == [('4', '1', '')]
        else:
            anchor = {'invalid-scratch': 'old(scratch)@.len() >= 12',
                      'invalid-guard': 'packed_product::guard_domain',
                      'invalid-output': 'old(output)@.len() == 2'}[name]
            client = (REPLAY / 'source/experiments/packed-product-composition/consumer.rs').read_text().splitlines()
            line = next(i + 1 for i, value in enumerate(client) if anchor in value)
            assert str(line) in re.findall(r'consumer\.rs:(\d+):\d+', text)
        logical[name] = summaries[0]
    if name in ('alias-input', 'alias-output'):
        expected = 'E0502' if name == 'alias-input' else 'E0499'
        assert command['returncode'] == 1
        assert re.findall(r'(?m)^error\[([^\]]+)\]:', text) == [expected]
assert len(logical) == 7
for filename in ('cases.bin', 'cases.jsonl'):
    assert (REPLAY / 'oracle' / filename).read_bytes() == (OUT / 'retained/gate-2/oracle' / filename).read_bytes()
assert report['runtime_oracle']['stdout'] == 'passed 476 exact packed-product fixtures with all intermediate words and canaries\n'
assert report['layout_oracle']['runtime_executed']
assert (report['layout_oracle']['valid_cases'], report['layout_oracle']['error_cases']) == (208, 18)
objects = [(REPLAY / (name + '.o')).read_bytes() for name in ('consumer', 'control')]
assert objects[0] == objects[1] == (OUT / 'retained/gate-2/consumer.o').read_bytes()
elf = audit.elf_function(objects[0])
assert elf == json.loads((OUT / 'integrity-audit.json').read_bytes())['independent_elf']
for name, expected in report['source_git']['source_sha256'].items():
    assert audit.sha((REPLAY / 'source' / name).read_bytes()) == expected

result = dict(status='pass', reviewed_commit=audit.TIP,
              report_sha256=audit.sha((REPLAY / 'verification.json').read_bytes()),
              complete_library_proof_reused=358, actual_client_items_replayed=5,
              product_cases_replayed=476, layout_cases_replayed=208, layout_errors_replayed=18,
              borrow_rejections=['E0502', 'E0499'], fresh_logical_rejections=logical,
              independent_elf=elf, source_files=len(report['source_git']['source_sha256']),
              commands=len(report['commands']), same_oracle_bytes=True, new_timings=False,
              script_sha256=audit.sha(Path(__file__).read_bytes()))
(OUT / 'replay-audit.json').write_text(json.dumps(result, indent=2) + '\n')

archive_path = EVIDENCE / 'independent-review-replay.tar.gz'
assert not archive_path.exists()
files = [(path, 'focused-replay/' + path.relative_to(REPLAY).as_posix())
         for path in sorted(REPLAY.rglob('*')) if path.is_file()]
files += [(OUT / name, 'independent-audit/' + name)
          for name in ('audit.py', 'integrity-audit.json', 'verify_replay.py', 'replay-audit.json')]
with tarfile.open(archive_path, 'w:gz') as archive:
    for path, name in files:
        archive.add(path, arcname=name, recursive=False)
manifest = dict(reviewed_commit=audit.TIP, archive=archive_path.name,
                archive_sha256=audit.sha(archive_path.read_bytes()), archive_bytes=archive_path.stat().st_size,
                independent_integrity_sha256=audit.sha((OUT / 'integrity-audit.json').read_bytes()),
                replay_audit_sha256=audit.sha((OUT / 'replay-audit.json').read_bytes()),
                focused_gate_report_sha256=result['report_sha256'],
                members=[dict(path=name, size=path.stat().st_size, sha256=audit.sha(path.read_bytes()))
                         for path, name in files])
with tarfile.open(archive_path, 'r:gz') as archive:
    assert len(archive.getmembers()) == len(files)
    for item in manifest['members']:
        data = archive.extractfile(item['path']).read()
        assert len(data) == item['size'] and audit.sha(data) == item['sha256']
(EVIDENCE / 'independent-review-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(EVIDENCE / 'independent-review-verification.json').write_bytes((REPLAY / 'verification.json').read_bytes())
(EVIDENCE / 'independent-integrity-audit.json').write_bytes((OUT / 'integrity-audit.json').read_bytes())
(EVIDENCE / 'independent-replay-audit.json').write_bytes((OUT / 'replay-audit.json').read_bytes())
print(json.dumps(dict(status='pass', reviewed_commit=audit.TIP, archive_members=len(files),
                     archive_sha256=manifest['archive_sha256'], archive_bytes=manifest['archive_bytes'],
                     focused_gate_report_sha256=result['report_sha256']), indent=2))
